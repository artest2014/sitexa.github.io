package com.cct9k.entity.discount;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cct9k.entity.member.Member;


/**
 * The persistent class for the T_DISCOUNT_GROUP_REF database table.
 */
@Entity
@Table(name = "T_DISCOUNT_GROUP_REF")
public class DiscountGroupRef implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String ref_id;
    
	@ManyToOne
    @JoinColumn(name = "discountgroupid")
    private DiscountGroupInfo discountgroupinfo;
    
    @ManyToOne
    @JoinColumn(name ="memberid")
    private Member member;

    private String objecttypecatid;
    
    private String objecttypeid;
    
    private String enableflag;
    
    private String objectid;
    
    private Date updatetime;
    
    private String ifftp;
    
    @Transient
    private String deptname;
    
    
    public String getIfftp() {
		return ifftp;
	}

	public void setIfftp(String ifftp) {
		this.ifftp = ifftp;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getRef_id() {
  		return ref_id;
  	}

  	public void setRef_id(String ref_id) {
  		this.ref_id = ref_id;
  	}

	public DiscountGroupInfo getDiscountgroupinfo() {
		return discountgroupinfo;
	}

	public void setDiscountgroupinfo(DiscountGroupInfo discountgroupinfo) {
		this.discountgroupinfo = discountgroupinfo;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public String getObjecttypecatid() {
		return objecttypecatid;
	}

	public void setObjecttypecatid(String objecttypecatid) {
		this.objecttypecatid = objecttypecatid;
	}

	public String getObjecttypeid() {
		return objecttypeid;
	}

	public void setObjecttypeid(String objecttypeid) {
		this.objecttypeid = objecttypeid;
	}

	public String getEnableflag() {
		return enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public String getObjectid() {
		return objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	public Date getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
    

}