package com.cct9k.entity.discount;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.cct9k.entity.member.Member;



/**
 * The persistent class for the T_DISCOUNT_GROUP_REF_LOG database table.
 */
@Entity
@Table(name = "T_DISCOUNT_GROUP_REF_LOG")
public class DiscountGroupRefLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String log_id;

    @ManyToOne
    @JoinColumn(name ="memberid")
    private Member member;

    @ManyToOne
    @JoinColumn(name = "discountgroupid")
    private DiscountGroupInfo discountgroupinfo;

    private String objecttypecatid;
    
    private String objecttypeid;
    
    private String objectid;
    
    private String enableflag;
    
    private Date updatetime;

	public String getLog_id() {
		return log_id;
	}

	public void setLog_id(String log_id) {
		this.log_id = log_id;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public DiscountGroupInfo getDiscountgroupinfo() {
		return discountgroupinfo;
	}

	public void setDiscountgroupinfo(DiscountGroupInfo discountgroupinfo) {
		this.discountgroupinfo = discountgroupinfo;
	}

	public String getObjecttypecatid() {
		return objecttypecatid;
	}

	public void setObjecttypecatid(String objecttypecatid) {
		this.objecttypecatid = objecttypecatid;
	}

	public String getObjecttypeid() {
		return objecttypeid;
	}

	public void setObjecttypeid(String objecttypeid) {
		this.objecttypeid = objecttypeid;
	}

	public String getObjectid() {
		return objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	public String getEnableflag() {
		return enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public Date getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
    
   

}