package com.cct9k.entity.discount;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.cct9k.entity.member.Member;



/**
 * The persistent class for the T_DISCOUNT_GROUP_INFO database table.
 */
@Entity
@Table(name = "T_DISCOUNT_GROUP_INFO")
public class DiscountGroupInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String discountgroupid;

	private String discountname;

    private BigDecimal discountratio;

    private String candelete;
    
    private Date createtime;
    
    private String enableflag;
    
    @ManyToOne
    @JoinColumn(name ="memberid")
    private Member member;
    
    public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	@OneToMany(mappedBy = "discountgroupinfo")
    private List<DiscountGroupRef> discountGroupRefs;
    
	public List<DiscountGroupRef> getDiscountGroupRefs() {
		return discountGroupRefs;
	}

	public void setDiscountGroupRefs(List<DiscountGroupRef> discountGroupRefs) {
		this.discountGroupRefs = discountGroupRefs;
	}

	public String getDiscountgroupid() {
		return discountgroupid;
	}

	public void setDiscountgroupid(String discountgroupid) {
		this.discountgroupid = discountgroupid;
	}

	public String getDiscountname() {
		return discountname;
	}

	public void setDiscountname(String discountname) {
		this.discountname = discountname;
	}

	public BigDecimal getDiscountratio() {
		return discountratio;
	}

	public void setDiscountratio(BigDecimal discountratio) {
		this.discountratio = discountratio;
	}

	public String getCandelete() {
		return candelete;
	}

	public void setCandelete(String candelete) {
		this.candelete = candelete;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getEnableflag() {
		return enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}
    

}