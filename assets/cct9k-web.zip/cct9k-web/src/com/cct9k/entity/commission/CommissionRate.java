package com.cct9k.entity.commission;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.cct9k.entity.member.Member;


/**
 * The persistent class for the T_COMMISSION_RATE database table.
 */
@Entity
@Table(name = "T_COMMISSION_RATE")
public class CommissionRate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String rate_id;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "applyid")
	private Member member;

    private Date applytime;

    private String applyname;
    
    private Date begintime;
    
    private Date endtime;
    
    private BigDecimal rate;
    
    private Date updatetime;
    
    private String statues;
    
    private Date trueendtime;
    
    //bi-directional many-to-one association to TGroupMember
  	@OneToMany(cascade = CascadeType.REMOVE,mappedBy="commissionrate")
  	private List<CommissionRelate> commissionRelates;
 
	public List<CommissionRelate> getCommissionRelates() {
		return commissionRelates;
	}

	public void setCommissionRelates(List<CommissionRelate> commissionRelates) {
		this.commissionRelates = commissionRelates;
	}

	public String getRate_id() {
		return rate_id;
	}

	public void setRate_id(String rate_id) {
		this.rate_id = rate_id;
	}

	public Date getApplytime() {
		return applytime;
	}

	public void setApplytime(Date applytime) {
		this.applytime = applytime;
	}

	public String getApplyname() {
		return applyname;
	}

	public void setApplyname(String applyname) {
		this.applyname = applyname;
	}

	public Date getBegintime() {
		return begintime;
	}

	public void setBegintime(Date begintime) {
		this.begintime = begintime;
	}

	public Date getEndtime() {
		return endtime;
	}

	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public Date getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}

	public String getStatues() {
		return statues;
	}

	public void setStatues(String statues) {
		this.statues = statues;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public Date getTrueendtime() {
		return trueendtime;
	}

	public void setTrueendtime(Date trueendtime) {
		this.trueendtime = trueendtime;
	}

}