package com.cct9k.entity.commission;

import javax.persistence.*;

import com.cct9k.entity.member.Member;

import java.io.Serializable;


/**
 * The persistent class for the T_TUNELINK_MEMBER database table.
 */
@Entity
@Table(name = "T_TUNELINK_MEMBER")
public class TunelinkMember implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String relateid;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "memberid")
	private Member member;

    private String cardtype;

    private String cardcateid;
    
    private String cardId;

    public String getRelateid() {
		return relateid;
	}

	public void setRelateid(String relateid) {
		this.relateid = relateid;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public String getCardtype() {
		return cardtype;
	}

	public void setCardtype(String cardtype) {
		this.cardtype = cardtype;
	}

	public String getCardcateid() {
		return cardcateid;
	}

	public void setCardcateid(String cardcateid) {
		this.cardcateid = cardcateid;
	}

	public String getCardid() {
		return cardid;
	}

	public void setCardid(String cardid) {
		this.cardid = cardid;
	}

	private String cardid;

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

    
}