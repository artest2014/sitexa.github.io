package com.cct9k.entity.commission;

import javax.persistence.*;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * The persistent class for the T_COMMISSION_RELATE database table.
 */
@Entity
@Table(name = "T_COMMISSION_RELATE")
public class CommissionRelate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "rate_id")
	private CommissionRate commissionrate;

    private String member_id;

    private String member_name;
    
    private BigDecimal rate;
    
    @Transient
    private String cardid;

	public String getCardid() {
		return cardid;
	}

	public void setCardid(String cardid) {
		this.cardid = cardid;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMember_id() {
		return member_id;
	}

	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}

	public String getMember_name() {
		return member_name;
	}

	public CommissionRate getCommissionrate() {
		return commissionrate;
	}

	public void setCommissionrate(CommissionRate commissionrate) {
		this.commissionrate = commissionrate;
	}

	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}
    
}