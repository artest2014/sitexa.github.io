package com.cct9k.entity.commission;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.cct9k.entity.member.Member;


/**
 * The persistent class for the T_SHOP_COMMISSION_ADD database table.
 */
@Entity
@Table(name = "T_SHOP_COMMISSION_ADD")
public class ShopCommissionAdd implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String add_id;
    
    private String batch;

    private String shopaccountid;

    private BigDecimal amount;
    
    private String result;
    
    private String ifpay;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "memberid")
	private Member member;
    
    private String ifsend;
    
    private Date senddate;

	public String getAdd_id() {
		return add_id;
	}

	public void setAdd_id(String add_id) {
		this.add_id = add_id;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getShopaccountid() {
		return shopaccountid;
	}

	public void setShopaccountid(String shopaccountid) {
		this.shopaccountid = shopaccountid;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getIfpay() {
		return ifpay;
	}

	public void setIfpay(String ifpay) {
		this.ifpay = ifpay;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public String getIfsend() {
		return ifsend;
	}

	public void setIfsend(String ifsend) {
		this.ifsend = ifsend;
	}

	public Date getSenddate() {
		return senddate;
	}

	public void setSenddate(Date senddate) {
		this.senddate = senddate;
	}
    
    
}