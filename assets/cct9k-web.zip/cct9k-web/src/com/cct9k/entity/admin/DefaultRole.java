package com.cct9k.entity.admin;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
/**
 * @description: 默认角色实体
 * @author: caimao 328691091@qq.com
 * @createtime:2013年11月7日 上午11:27:58
 */
@Entity
@Table(name="t_defaultrole")
public class DefaultRole implements Serializable{
	private static final long serialVersionUID = 1L;
	/**
	 * id
	 */
	@Id
	private String roleId;
	/**
	 * 标识
	 */
	private String roleName;
	/**
	 * 中文名称
	 */
	private String roleText;
	/**
	 * 所属应用
	 */
	@ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
	@JoinColumn(name="appid")
	private Application application;
	/**
	 * 是否可用 -1:不可用，1,可用
	 */
	private String enable;
	
	/**
	 * 角色描述
	 */
	private String depsciption;
	
	/**
	 * 对应的资源
	 */
    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @JoinTable(name = "T_DEFAULTROLE_RESOURCE",
            joinColumns = {@JoinColumn(name = "defaultroleid", referencedColumnName = "roleid")},
            inverseJoinColumns = {@JoinColumn(name = "resourceid", referencedColumnName = "resid")})
    //TODO cm list和set映射的区别？？
	private List<Resources> resources = new ArrayList<Resources>();
    
    /**
     * 角色类型
     */
    private String roletype;
	
	
	public DefaultRole() {
		super();
	}
	
	public DefaultRole(String roleId, String roleName, String roleText,
			Application application, String enable,String depsciption) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
		this.roleText = roleText;
		this.application = application;
		this.enable = enable;
		this.depsciption = depsciption;
	}

	public DefaultRole(String roleId, String roleName, String roleText,
			Application application, String enable, List<Resources> resources, String depsciption) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
		this.roleText = roleText;
		this.application = application;
		this.enable = enable;
		this.resources = resources;
		this.depsciption = depsciption;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleText() {
		return roleText;
	}

	public void setRoleText(String roleText) {
		this.roleText = roleText;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getEnable() {
		return enable;
	}

	public void setEnable(String enable) {
		this.enable = enable;
	}

	public String getDepsciption() {
		return depsciption;
	}

	public void setDepsciption(String depsciption) {
		this.depsciption = depsciption;
	}

	public List<Resources> getResources() {
		return resources;
	}

	public void setResources(List<Resources> resources) {
		this.resources = resources;
	}

	public String getRoletype() {
		return roletype;
	}

	public void setRoletype(String roletype) {
		this.roletype = roletype;
	}
	
	

	
	
	
}
