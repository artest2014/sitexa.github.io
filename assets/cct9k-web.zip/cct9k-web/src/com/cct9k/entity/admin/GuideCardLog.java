package com.cct9k.entity.admin;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the T_GUIDE_CARD_LOG database table.
 * 
 */
@Entity
@Table(name="T_GUIDE_CARD_LOG")
public class GuideCardLog implements Serializable {
	private static final long serialVersionUID = 1L;

	private String bankcardno;

	private String dateno;
	@Id
	private String id;

	private String idnumber;

    @Temporal( TemporalType.DATE)
	private Date issuecarddate;

	private String mobile;

	private String name;

    public GuideCardLog() {
    }

	public String getBankcardno() {
		return this.bankcardno;
	}

	public void setBankcardno(String bankcardno) {
		this.bankcardno = bankcardno;
	}

	public String getDateno() {
		return this.dateno;
	}

	public void setDateno(String dateno) {
		this.dateno = dateno;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIdnumber() {
		return this.idnumber;
	}

	public void setIdnumber(String idnumber) {
		this.idnumber = idnumber;
	}

	public Date getIssuecarddate() {
		return this.issuecarddate;
	}

	public void setIssuecarddate(Date issuecarddate) {
		this.issuecarddate = issuecarddate;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}