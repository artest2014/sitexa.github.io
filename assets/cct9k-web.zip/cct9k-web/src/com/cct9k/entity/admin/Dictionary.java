package com.cct9k.entity.admin;

import javax.persistence.*;

import org.codehaus.jackson.annotate.JsonIgnore;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the T_DICTIONARY database table.
 */
@Entity
@Table(name = "T_DICTIONARY")
public class Dictionary implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 254246444936358929L;

    @Id
    private String dictid;

    @ManyToOne(cascade=CascadeType.PERSIST)
    @JoinColumn(name = "cateid")
    private DictionaryCategory category;

    private String typeid;

    private String typename;

    private int sortorder;
    
    @Transient
	private List<Dictionary> sonDictionary;

    public Dictionary() {
    }

    public Dictionary(String dictid) {
    	this.dictid = dictid;
    }
    
    public String getDictid() {
        return dictid;
    }

    public void setDictid(String dictid) {
        this.dictid = dictid;
    }

    @JsonIgnore public DictionaryCategory getCategory() {
        return category;
    }

    public void setCategory(DictionaryCategory category) {
        this.category = category;
    }

    public String getTypeid() {
        return typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid;
    }

    public String getTypename() {
        return typename;
    }

    public void setTypename(String typename) {
        this.typename = typename;
    }

    public int getSortorder() {
        return sortorder;
    }

    public void setSortorder(int sortorder) {
        this.sortorder = sortorder;
    }

	public List<Dictionary> getSonDictionary() {
		return sonDictionary;
	}

	public void setSonDictionary(List<Dictionary> sonDictionary) {
		this.sonDictionary = sonDictionary;
	}
    
}