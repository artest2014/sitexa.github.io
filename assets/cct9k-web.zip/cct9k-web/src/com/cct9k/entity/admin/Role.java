package com.cct9k.entity.admin;

import com.cct9k.entity.member.Member;

import org.hibernate.annotations.Where;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "T_ROLE")
public class Role implements Serializable {

    private static final long serialVersionUID = -2234787721782724711L;

    @Id
    String roleid;

    private String enable;

    @ManyToOne
    @JoinColumn(name = "appid")
    private Application application;

    private String rolename;

    private String roletext;

    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @Where(clause = "menu=1")
    @OrderBy("priority asc")
    @JoinTable(name = "t_role_resource",
            joinColumns = {@JoinColumn(name = "roleid", referencedColumnName = "roleid")},
            inverseJoinColumns = {@JoinColumn(name = "resid", referencedColumnName = "resid")})
    private Set<Resources> menuResources = new HashSet<Resources>(0);

    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @JoinTable(name = "t_member_role",
            joinColumns = {@JoinColumn(name = "roleid", referencedColumnName = "roleid")},
            inverseJoinColumns = {@JoinColumn(name = "memberid", referencedColumnName = "memberid")})
    private Set<Member> members = new HashSet<Member>(0);
    
    
    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @JoinTable(name = "t_role_resource",
            joinColumns = {@JoinColumn(name = "roleid", referencedColumnName = "roleid")},
            inverseJoinColumns = {@JoinColumn(name = "resid", referencedColumnName = "resid")})
    private Set<Resources> allResources = new HashSet<Resources>(0);
    
    /**
     * 所属部门
     */
    @ManyToOne
    @JoinColumn(name="departmentid")
    private Department department;
    
    private String orgid;
    
    
    private String description;

	public Role() {
    }
	
	
	
    public Role(String roleid, String enable, Application application,
			String rolename, String roletext, Set<Resources> menuResources,
			Set<Member> members) {
		super();
		this.roleid = roleid;
		this.enable = enable;
		this.application = application;
		this.rolename = rolename;
		this.roletext = roletext;
		this.menuResources = menuResources;
		this.members = members;
	}



	public Role(String roleid, String enable, Application application,
			String rolename, String roletext,
			Set<Resources> menuResources,Department department,String description, String orgid) {
		super();
		this.roleid = roleid;
		this.enable = enable;
		this.application = application;
		this.rolename = rolename;
		this.roletext = roletext;
		this.menuResources = menuResources;
		this.department = department;
		this.description = description;
		this.orgid = orgid;
	}

    public Application getApplication() {
        return application;
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    public String getRoleid() {
        return roleid;
    }

    public void setRoleid(String roleid) {
        this.roleid = roleid;
    }

    public String getRolename() {
        return rolename;
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }

    public String getEnable() {
        return enable;
    }

    public void setEnable(String enable) {
        this.enable = enable;
    }

    public Set<Resources> getMenuResources() {
        return menuResources;
    }

    public void setMenuResources(Set<Resources> menuResources) {
        this.menuResources = menuResources;
    }

    public Set<Member> getMembers() {
        return members;
    }

    public void setMembers(Set<Member> members) {
        this.members = members;
    }

    public String getRoletext() {
        return roletext;
    }

    public void setRoletext(String roletext) {
        this.roletext = roletext;
    }

    public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}

	public String getOrgid() {
		return orgid;
	}

	public void setOrgid(String orgid) {
		this.orgid = orgid;
	}
	
	

	public Set<Resources> getAllResources() {
		return allResources;
	}



	public void setAllResources(Set<Resources> allResources) {
		this.allResources = allResources;
	}



	@Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        } else if (this == obj) {
            return true;
        } else if (obj instanceof Role) {
            Role r = (Role) obj;
            return r.getRoleid().equals(this.getRoleid());
        }
        return false;
    }

    @Override
    public int hashCode() {
        //TODO cm返回一个什么值好呢？
        return 2;
    }
}