package com.cct9k.entity.admin;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnore;

import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the T_DICTIONARY_CATEGORY database table.
 */
@Entity
@Table(name = "T_DICTIONARY_CATEGORY")
public class DictionaryCategory implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 3923895404147467177L;

    @Id
    private String cateid;

    private String catename;

    private int sortorder;
    
    @OneToMany(cascade=CascadeType.PERSIST,mappedBy="category")
    private List<Dictionary> dictionary;
    public DictionaryCategory() {
    }

    public String getCateid() {
        return cateid;
    }

    public void setCateid(String cateid) {
        this.cateid = cateid;
    }

    public String getCatename() {
        return catename;
    }

    public void setCatename(String catename) {
        this.catename = catename;
    }

    public int getSortorder() {
        return sortorder;
    }

    public void setSortorder(int sortorder) {
        this.sortorder = sortorder;
    }

    @JsonIgnore public List<Dictionary> getDictionary() {
		return dictionary;
	}

	public void setDictionary(List<Dictionary> dictionary) {
		this.dictionary = dictionary;
	}
    
}