package com.cct9k.entity.admin;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.cct9k.entity.member.Member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * 功能应用
 * 
 * */
@Entity
@Table(name = "t_application")
public class Application implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
    private String appid;
	
	private String appintroduction;
	
	private String appname;

	private String appexpand1;
	
	private String appexpand2;
	
	private String appexpand3;
	
	private String appneedask;
	
	public String getAppneedask() {
		return appneedask;
	}

	public void setAppneedask(String appneedask) {
		this.appneedask = appneedask;
	}

	@OneToMany(mappedBy="application" ,fetch = FetchType.LAZY)
	private List<Role>  roles;

	
	@ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
	@JoinTable(name = "t_member_application",
	            joinColumns = {@JoinColumn(name = "appid", referencedColumnName = "appid")},
	            inverseJoinColumns = {@JoinColumn(name = "memberid", referencedColumnName = "memberid")})
	 private List<Member> members = new ArrayList<Member>(0);

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getAppintroduction() {
		return appintroduction;
	}

	public void setAppintroduction(String appintroduction) {
		this.appintroduction = appintroduction;
	}

	public String getAppname() {
		return appname;
	}

	public void setAppname(String appname) {
		this.appname = appname;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public List<Member> getMembers() {
		return members;
	}

	public void setMembers(List<Member> members) {
		this.members = members;
	}
	
	public String getAppexpand1() {
		return appexpand1;
	}

	public void setAppexpand1(String appexpand1) {
		this.appexpand1 = appexpand1;
	}

	public String getAppexpand2() {
		return appexpand2;
	}

	public void setAppexpand2(String appexpand2) {
		this.appexpand2 = appexpand2;
	}

	public String getAppexpand3() {
		return appexpand3;
	}

	public void setAppexpand3(String appexpand3) {
		this.appexpand3 = appexpand3;
	}
	
}