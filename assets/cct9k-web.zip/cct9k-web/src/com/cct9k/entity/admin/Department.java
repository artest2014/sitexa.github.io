package com.cct9k.entity.admin;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.cct9k.entity.member.Member;

/**
 * @description: 部门实体
 * @author: caimao 328691091@qq.com
 * @createtime:2013年11月7日 上午11:25:42
 */
@Entity
@Table(name="t_department")
public class Department implements Serializable{
	private static final long serialVersionUID = 1L;
	
	/**
	 * 对象id
	 */
	private String objectid;
	
	/**
	 * 部门编号:由具体的对象决定：如酒店id
	 */
	@Id
	private String departmentId;
	/**
	 * 部门名称
	 */
	private String departmentName;
	/**
	 * 部门创建人
	 */
	@ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
	@JoinColumn(name="creatorid")
	private Member creator;
	/**
	 * 部门拥有者
	 */
	@ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
	@JoinColumn(name="ownerid")
	private Member owner;
	/**
	 * 上级部门
	 */
	@ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @JoinColumn(name = "parentId")
	private Department parentDepartment;
	
	/**
	 * 子部门
	 */
	@OneToMany(mappedBy = "parentDepartment", fetch = FetchType.LAZY)
	private List<Department> childrenDepartments;
	
	/**
	 * 部门所属类型，比如酒店类型
	 */
	@Column(name="objectTypeId")
	private String objectType;
	/**
	 * 部门描述
	 */
	private String departmentDes;
	/**
	 * 部门是否正常运转，-1:非正常运转，1:正常运转
	 */
	private String enable;
	
	@OneToMany(mappedBy="department" ,fetch = FetchType.LAZY)
	private List<Role> roles = new ArrayList<Role>();
	
	public Department() {
		super();
	}
	public Department(String departmentId, String departmentName,
			Member creator, Member owner, Department parentDepartment,
			String objectType, String departmentDes, String enable) {
		super();
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.creator = creator;
		this.owner = owner;
		this.parentDepartment = parentDepartment;
		this.objectType = objectType;
		this.departmentDes = departmentDes;
		this.enable = enable;
	}
	
	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public Member getCreator() {
		return creator;
	}
	public void setCreator(Member creator) {
		this.creator = creator;
	}
	public Member getOwner() {
		return owner;
	}
	public void setOwner(Member owner) {
		this.owner = owner;
	}
	public Department getParentDepartment() {
		return parentDepartment;
	}
	public void setParentDepartment(Department parentDepartment) {
		this.parentDepartment = parentDepartment;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public String getDepartmentDes() {
		return departmentDes;
	}
	public void setDepartmentDes(String departmentDes) {
		this.departmentDes = departmentDes;
	}
	public String getEnable() {
		return enable;
	}
	public void setEnable(String enable) {
		this.enable = enable;
	}
	public List<Department> getChildrenDepartments() {
		return childrenDepartments;
	}
	public void setChildrenDepartments(List<Department> childrenDepartments) {
		this.childrenDepartments = childrenDepartments;
	}
	public List<Role> getRoles() {
		return roles;
	}
	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}
	public String getObjectid() {
		return objectid;
	}
	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}
	
}
