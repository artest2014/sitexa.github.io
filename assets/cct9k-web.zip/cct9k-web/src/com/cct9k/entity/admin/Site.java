package com.cct9k.entity.admin;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;


/**
 * The persistent class for the T_SITE database table.
 */
@Entity
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
@Table(name = "T_SITE")
public class Site implements Serializable {

    private static final long serialVersionUID = -1641940246690820313L;
    
    @Id
    private String siteid;

    private String city;

    private String country;

    private String county;

    private String fullname;

    private String name;

    @Column(name = "state")
    private String state;

    @ManyToOne
    @JoinColumn(name = "typeid")
    private SiteType siteType;

    @ManyToOne
    @JoinColumn(name = "parentid")
    private Site parent;

    @OneToMany(cascade = {CascadeType.REMOVE}, mappedBy = "parent", fetch = FetchType.LAZY)
    @OrderBy("siteid")
    private List<Site> children;

    private String parentId;

    public Site(String siteid){
    	this.siteid = siteid;
    }
    
    public Site() {
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getSiteid() {
        return this.siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCounty() {
        return this.county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getFullname() {
        return this.fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Site getParent() {
        return parent;
    }

    public void setParent(Site tSite) {
        parent = tSite;
    }

    public SiteType getSiteType() {
        return this.siteType;
    }

    public void setSiteType(SiteType siteType) {
        this.siteType = siteType;
    }

    @JsonIgnore public List<Site> getChildren() {
        return children;
    }

    public void setChildren(List<Site> children) {
        this.children = children;
    }
}