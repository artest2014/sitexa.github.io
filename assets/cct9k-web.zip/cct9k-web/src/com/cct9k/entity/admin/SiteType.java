package com.cct9k.entity.admin;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;


/**
 * The persistent class for the T_SITE_TYPE database table.
 */
@Entity
@Table(name = "T_SITE_TYPE")
public class SiteType implements Serializable {
	private static final long serialVersionUID = -8011190783291914631L;
	@Id
    private String typeid;
    private String typename;

    public SiteType() {
    }

    public String getTypeid() {
        return this.typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid;
    }

    public String getTypename() {
        return this.typename;
    }

    public void setTypename(String typename) {
        this.typename = typename;
    }

}