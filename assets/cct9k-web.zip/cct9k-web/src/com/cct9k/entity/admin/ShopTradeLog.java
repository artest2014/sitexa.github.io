package com.cct9k.entity.admin;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.util.common.DateUtil;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_SHOP_TRADE_LOG database table.
 * 
 */
@Entity
@Table(name="T_SHOP_TRADE_LOG")
public class ShopTradeLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String bankcardno;

	private String cardno;

	private String dateno;

	private String deviceno;

	private String shopno;

	private String sysno;

	private BigDecimal tradeamount;

    @Temporal( TemporalType.DATE)
	private Date tradedate;
    
    private String tradetime;
    
    @Transient
    private String tradedateStr;
    @Transient
    private String dateFormat = "yyyyMMdd";

    public ShopTradeLog() {
    }
    
    public ShopTradeLog(String dateFormat){
    	this.dateFormat = dateFormat;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBankcardno() {
		return this.bankcardno;
	}

	public void setBankcardno(String bankcardno) {
		this.bankcardno = bankcardno;
	}

	public String getCardno() {
		return this.cardno;
	}

	public void setCardno(String cardno) {
		this.cardno = cardno;
	}

	public String getDateno() {
		return this.dateno;
	}

	public void setDateno(String dateno) {
		this.dateno = dateno;
	}

	public String getDeviceno() {
		return this.deviceno;
	}

	public void setDeviceno(String deviceno) {
		this.deviceno = deviceno;
	}

	public String getShopno() {
		return this.shopno;
	}

	public void setShopno(String shopno) {
		this.shopno = shopno;
	}

	public String getSysno() {
		return this.sysno;
	}

	public void setSysno(String sysno) {
		this.sysno = sysno;
	}

	public BigDecimal getTradeamount() {
		return this.tradeamount;
	}

	public void setTradeamount(BigDecimal tradeamount) {
		this.tradeamount = tradeamount;
	}

	public Date getTradedate() {
		return this.tradedate;
	}

	public void setTradedate(Date tradedate) {
		this.tradedate = tradedate;
	}

	/**
	 * @return the tradedateStr
	 */
	public String getTradedateStr() {
		if(this.tradedateStr!=null)return this.tradedateStr;
		if(this.tradedate==null)return null;
		tradedateStr = DateUtil.format(this.tradedate, this.dateFormat);
		return tradedateStr;
	}

	/**
	 * @param tradedateStr the tradedateStr to set
	 */
	public void setTradedateStr(String tradedateStr) {
		this.tradedateStr = tradedateStr;
		setTradedate(DateUtil.toDate(this.tradedateStr, this.dateFormat));
	}

	/**
	 * @return the tradetime
	 */
	public String getTradetime() {
		return tradetime;
	}

	/**
	 * @param tradetime the tradetime to set
	 */
	public void setTradetime(String tradetime) {
		this.tradetime = tradetime;
	}


}