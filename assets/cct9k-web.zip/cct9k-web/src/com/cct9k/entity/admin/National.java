package com.cct9k.entity.admin;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the T_NATIONAL database table.
 * 
 */
@Entity
@Table(name="T_NATIONAL")
public class National implements Serializable {

	private static final long serialVersionUID = 7093595037069998897L;
	@Id
	private String id;

	private String name;

	public National() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}