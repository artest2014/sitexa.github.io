package com.cct9k.entity.admin;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cct9k.entity.finance.Audit;
import com.cct9k.entity.member.Member;

@Entity
@Table(name = "t_member_application_audit")
public class MemberApplicationAudit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String id;
	
	 @OneToOne
	@JoinColumn(name = "appid")
	private Application appid;
	
	 @OneToOne(cascade =CascadeType.ALL)
	@JoinColumn(name = "auditid")
	private Audit audit;

	 @OneToOne(cascade =CascadeType.ALL)
	@JoinColumn(name = "memberid")
	private Member member;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public Application getAppid() {
		return appid;
	}

	public void setAppid(Application appid) {
		this.appid = appid;
	}

	public Audit getAudit() {
		return audit;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}
	
}
