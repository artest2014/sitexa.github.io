package com.cct9k.entity.admin;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.hibernate.annotations.Where;

import javax.persistence.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * The persistent class for the T_RESOURCES database table.
 */
@Entity
@Table(name = "T_RESOURCE")
public class Resources implements Serializable, Comparable<Object> {

    private static final long serialVersionUID = 1L;

    @Id
    private String resid;

    @Transient
    private String parentid;

    @Transient
    private boolean show;

    private String description;

    private int menu = 0;

    private String name;

    private int priority = 0;

    private String resurl;

    private String code;

    @Column(name = "\"TYPE\"")
    private int type = 0;

    //bi-directional many-to-one association to TResource

    @ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @JoinColumn(name = "parentid")
    private Resources parent;

    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY)
    @OrderBy("priority asc,code asc")
    @Where(clause = "menu = 1")
    private List<Resources> children;

    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY)
    @OrderBy("priority asc,code asc")
    private List<Resources> child;

    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @JoinTable(name = "t_role_resource",
            joinColumns = {@JoinColumn(name = "resid", referencedColumnName = "resid")},
            inverseJoinColumns = {@JoinColumn(name = "roleid", referencedColumnName = "roleid")})
    private Set<Role> roles = new HashSet<Role>(0);
    
    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @JoinTable(name = "T_DEFAULTROLE_RESOURCE",
            joinColumns = {@JoinColumn(name = "resourceid", referencedColumnName = "resid")},
            inverseJoinColumns = {@JoinColumn(name = "defaultroleid", referencedColumnName = "roleid")})
    private Set<DefaultRole> defaultroles = new HashSet<DefaultRole>();
    
    private String layer;

    private String app;//所属应用
   
	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public Resources() {
    }

    public String getParentid() {
        return parentid;
    }

    public void setParentid(String parentid) {
        this.parentid = parentid;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public String getResid() {
        return resid;
    }

    public void setResid(String resid) {
        this.resid = resid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getResurl() {
        return resurl;
    }

    public void setResurl(String resurl) {
        this.resurl = resurl;
    }

    public Resources getParent() {
        return parent;
    }

    public void setParent(Resources parent) {
        this.parent = parent;
    }

    @JsonIgnore
    public List<Resources> getChildren() {
        return children;
    }

    public void setChildren(List<Resources> children) {
        this.children = children;
    }

    public boolean isShow() {
        return show;
    }

    public void setShow(boolean show) {
        this.show = show;
    }

    @JsonIgnore
    public List<Resources> getChild() {
        return child;
    }

    public void setChild(List<Resources> child) {
        this.child = child;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        } else if (this == obj) {
            return true;
        } else if (obj instanceof Resources) {
            Resources r = (Resources) obj;
            return r.getResid().equals(this.getResid());
        }
        return false;
    }

    @Override
    public int compareTo(Object arg0) {
        Resources res = (Resources) arg0;
        return new BigDecimal(priority).compareTo(new BigDecimal(res.getPriority()));
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getMenu() {
        return menu;
    }

    public void setMenu(int menu) {
        this.menu = menu;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
    
    public Set<DefaultRole> getDefaultroles() {
		return defaultroles;
	}

	public void setDefaultroles(Set<DefaultRole> defaultroles) {
		this.defaultroles = defaultroles;
	}

	public String getApp() {
		return app;
	}

	public void setApp(String app) {
		this.app = app;
	}
	
	

}