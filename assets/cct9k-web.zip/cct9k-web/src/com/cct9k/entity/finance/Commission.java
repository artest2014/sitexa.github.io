package com.cct9k.entity.finance;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.entity.member.Member;


import java.util.Date;


/**
 * The persistent class for the T_COMMISSION database table.
 * 佣金
 */
@Entity
@Table(name="T_COMMISSION")
public class Commission implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -699812447628212108L;
	@Id
	private String commissionid;
	private String commtype;

	@Column(name="\"CONTENTS\"")
	private String contents;

	@Temporal(TemporalType.DATE)
	private Date eventdate;

	private String billid;
	private String invoiceno;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "memberid")
    private Member member;

	@Temporal(TemporalType.DATE)
	private Date paydate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payerid")
    private Member payer;

	private String paystatus;
    private float amount;
    
    private String orderId;

	public Commission() {
	}

	public String getCommissionid() {
		return this.commissionid;
	}

	public void setCommissionid(String commissionid) {
		this.commissionid = commissionid;
	}

	public String getCommtype() {
		return this.commtype;
	}

	public void setCommtype(String commtype) {
		this.commtype = commtype;
	}

	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Date getEventdate() {
		return this.eventdate;
	}

	public void setEventdate(Date eventdate) {
		this.eventdate = eventdate;
	}

	public String getBillid() {
		return billid;
	}

	public void setBillid(String billid) {
		this.billid = billid;
	}
	  public String getInvoiceno() {
        return this.invoiceno;
    }

    public void setInvoiceno(String invoiceno) {
        this.invoiceno = invoiceno;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

	public Date getPaydate() {
		return this.paydate;
	}

	public void setPaydate(Date paydate) {
		this.paydate = paydate;
	}

    public Member getPayer() {
        return payer;
    }

    public void setPayer(Member payer) {
        this.payer = payer;
    }

	public String getPaystatus() {
		return this.paystatus;
	}

	public void setPaystatus(String paystatus) {
		this.paystatus = paystatus;
	}

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
    
    
}