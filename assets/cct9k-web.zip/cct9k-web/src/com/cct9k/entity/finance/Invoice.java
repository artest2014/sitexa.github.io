package com.cct9k.entity.finance;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.customer.Customer;
import com.cct9k.entity.member.Member;


/**
 * The persistent class for the T_INVOICE database table.
 * 
 */
@Entity
@Table(name="T_INVOICE")
public class Invoice implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3679857289794803788L;
	public static final String INVOICE_EDIT = "68";
	public static final String INVOICE_AUDIT = "69";
	public static final String INVOICE_AGREE = "70";
	public static final String INVOICE_REJECT = "71";
	
	public static final String INVOICE_TYPE_RESTAURANT = "62";
	public static final String INVOICE_TYPE_HOTEL = "63";
	public static final String INVOICE_TYPE_TRANSPORT = "64";
	public static final String INVOICE_TYPE_GATE = "65";
	public static final String INVOICE_TYPE_SHOP = "66";
	public static final String INVOICE_TYPE_SHOW = "67";

	@Id
	private String invoiceid;

	private float amount;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="buyer")
	private Member buyer;

	@Column(name="\"CONTENTS\"")
	private String contents;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="handlers")
	private Member handlers;

	@Temporal(TemporalType.TIMESTAMP)
	private Date invoicedate;

	private String invoiceno;

	private String objectid;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="seller")
	private Customer seller;

	//bi-directional many-to-one association to TCheckSheet
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="sheetid")
	private CheckSheet checksheet;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="invoicestatus")
	private Dictionary invoicestatus;
	

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="objecttype")
	private Dictionary objecttype;

	private String sellername;
	
	private String buyername;
	public Invoice() {
	}

	public String getInvoiceid() {
		return this.invoiceid;
	}

	public void setInvoiceid(String invoiceid) {
		this.invoiceid = invoiceid;
	}

	public float getAmount() {
		return this.amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	
	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Date getInvoicedate() {
		return this.invoicedate;
	}

	public void setInvoicedate(Date invoicedate) {
		this.invoicedate = invoicedate;
	}

	public String getInvoiceno() {
		return this.invoiceno;
	}

	public void setInvoiceno(String invoiceno) {
		this.invoiceno = invoiceno;
	}


	public String getObjectid() {
		return this.objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}


	public CheckSheet getChecksheet() {
		return checksheet;
	}

	public void setChecksheet(CheckSheet checksheet) {
		this.checksheet = checksheet;
	}

	public Member getBuyer() {
		return buyer;
	}

	public void setBuyer(Member buyer) {
		this.buyer = buyer;
	}

	public Member getHandlers() {
		return handlers;
	}

	public void setHandlers(Member handlers) {
		this.handlers = handlers;
	}

	public Customer getSeller() {
		return seller;
	}

	public void setSeller(Customer seller) {
		this.seller = seller;
	}
	
	public Dictionary getInvoicestatus() {
		return invoicestatus;
	}

	public void setInvoicestatus(Dictionary invoicestatus) {
		this.invoicestatus = invoicestatus;
	}

	public Dictionary getObjecttype() {
		return objecttype;
	}

	public void setObjecttype(Dictionary objecttype) {
		this.objecttype = objecttype;
	}

	public String getSellername() {
		return sellername;
	}

	public void setSellername(String sellername) {
		this.sellername = sellername;
	}

	public String getBuyername() {
		return buyername;
	}

	public void setBuyername(String buyername) {
		this.buyername = buyername;
	}

}