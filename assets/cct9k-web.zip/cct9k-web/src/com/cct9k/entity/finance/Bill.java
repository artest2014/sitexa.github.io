package com.cct9k.entity.finance;

import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.GenericOrder;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the T_BILL database table.
 * 付款单
 */
@Entity
@Table(name = "T_BILL")
public class Bill implements Serializable {

    private static final long serialVersionUID = -2577558299266754680L;

    @Id
    private String billid;

    private float amount;

    private String billname;

    private String description;
    
    private float collectamount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "orderid")
    private GenericOrder order;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "objecttype")
    private Dictionary objecttype;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payer")
    private Member payer;

    @Temporal(TemporalType.TIMESTAMP)
    private Date paymentdate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paymentmethod")
    private Dictionary paymentmethod;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "receiver")
    private Member receiver;

    private String remark;

    private String billType;

    private String billTypeCate;

    private String moneyresource;

    private String refundBillId;

    private String transactionId;
    
    private String ifpay;

    public Bill() {
    }

    public String getBillid() {
        return this.billid;
    }

    public void setBillid(String billid) {
        this.billid = billid;
    }

    public float getAmount() {
        return this.amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getBillname() {
        return this.billname;
    }

    public void setBillname(String billname) {
        this.billname = billname;
    }

    public String getIfpay() {
		return ifpay;
	}

	public void setIfpay(String ifpay) {
		this.ifpay = ifpay;
	}

	public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getPaymentdate() {
        return this.paymentdate;
    }

    public void setPaymentdate(Date paymentdate) {
        this.paymentdate = paymentdate;
    }

    public Member getPayer() {
        return payer;
    }

    public float getCollectamount() {
		return collectamount;
	}

	public void setCollectamount(float collectamount) {
		this.collectamount = collectamount;
	}

	public void setPayer(Member payer) {
        this.payer = payer;
    }

    public Member getReceiver() {
        return receiver;
    }

    public void setReceiver(Member receiver) {
        this.receiver = receiver;
    }

    public String getRemark() {
        return this.remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType;
    }

    public String getBillTypeCate() {
        return billTypeCate;
    }

    public void setBillTypeCate(String billTypeCate) {
        this.billTypeCate = billTypeCate;
    }

    public String getMoneyresource() {
        return moneyresource;
    }

    public void setMoneyresource(String moneyresource) {
        this.moneyresource = moneyresource;
    }

    public String getRefundBillId() {
        return refundBillId;
    }

    public void setRefundBillId(String refundBillId) {
        this.refundBillId = refundBillId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public GenericOrder getOrder() {
        return order;
    }

    public void setOrder(GenericOrder order) {
        this.order = order;
    }

    public Dictionary getObjecttype() {
		return objecttype;
	}

	public void setObjecttype(Dictionary objecttype) {
		this.objecttype = objecttype;
	}

	public Dictionary getPaymentmethod() {
        return paymentmethod;
    }

    public void setPaymentmethod(Dictionary paymentmethod) {
        this.paymentmethod = paymentmethod;
    }


}