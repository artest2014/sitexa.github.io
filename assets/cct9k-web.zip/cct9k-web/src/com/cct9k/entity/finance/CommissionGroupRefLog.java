package com.cct9k.entity.finance;

import javax.persistence.*;

import com.cct9k.entity.member.Member;

import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the T_COMMISSION_GROUP_REF_LOG database table.
 */
@Entity
@Table(name = "T_COMMISSION_GROUP_REF_LOG")
public class CommissionGroupRefLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String log_id;

    @ManyToOne
    @JoinColumn(name = "groupid")
    private CommissionGroupInfo groupInfo;

    private String objectid;

    private String objecttypecatid;

    private String objecttypeid;
    
    private String getcommisiontype;
    
    private String enableflag;
    
    public String getLog_id() {
		return log_id;
	}

	public void setLog_id(String log_id) {
		this.log_id = log_id;
	}


	public CommissionGroupInfo getGroupInfo() {
		return groupInfo;
	}

	public void setGroupInfo(CommissionGroupInfo groupInfo) {
		this.groupInfo = groupInfo;
	}

	public String getObjectid() {
		return objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	public String getObjecttypecatid() {
		return objecttypecatid;
	}

	public void setObjecttypecatid(String objecttypecatid) {
		this.objecttypecatid = objecttypecatid;
	}

	public String getObjecttypeid() {
		return objecttypeid;
	}

	public void setObjecttypeid(String objecttypeid) {
		this.objecttypeid = objecttypeid;
	}

	public String getGetcommisiontype() {
		return getcommisiontype;
	}

	public void setGetcommisiontype(String getcommisiontype) {
		this.getcommisiontype = getcommisiontype;
	}

	public String getEnableflag() {
		return enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public Date getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	
	

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}


    private Date updatetime;
    
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "memberid")
	private Member member;
    
}