package com.cct9k.entity.finance;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;


/**
 * The persistent class for the T_BANK database table.
 */
@Entity
@Table(name = "T_BANK")
public class Bank implements Serializable {
	private static final long serialVersionUID = 2162047632692211927L;
	@Id
    private String bankno;
    private String bankname;
    private int banksort;
    private String remark;

    public Bank() {
    }

    public String getBankno() {
        return this.bankno;
    }

    public void setBankno(String bankno) {
        this.bankno = bankno;
    }

    public String getBankname() {
        return this.bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname;
    }

    public int getBanksort() {
        return this.banksort;
    }

    public void setBanksort(int banksort) {
        this.banksort = banksort;
    }

    public String getRemark() {
        return this.remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

}