package com.cct9k.entity.finance;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the T_COMMISION_GROUP_REF database table.
 */
@Entity
@Table(name = "T_COMMISSION_GROUP_REF")
public class CommissionGroupRef implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    private String commisiontype;

    private String objectid;

    private String objecttypecatid;

    private String objecttypeid;
    
    private String enableflag;
    
    private String memberid;
    
    private Date updatetime;
    
    public String getEnableflag() {
		return enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	@Transient
    private String deptname;
    
    public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	//bi-directional many-to-one association to CommisionGroupInfo
    @ManyToOne
    @JoinColumn(name = "GROUPID")
    private CommissionGroupInfo groupInfo;

    public CommissionGroupRef() {
    }

    public String getCommisiontype() {
        return commisiontype;
    }

    public void setCommisiontype(String commisiontype) {
        this.commisiontype = commisiontype;
    }

    public CommissionGroupInfo getGroupInfo() {
        return groupInfo;
    }

    public void setGroupInfo(CommissionGroupInfo groupInfo) {
        this.groupInfo = groupInfo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getObjectid() {
        return objectid;
    }

    public void setObjectid(String objectid) {
        this.objectid = objectid;
    }

    public String getObjecttypecatid() {
        return objecttypecatid;
    }

    public void setObjecttypecatid(String objecttypecatid) {
        this.objecttypecatid = objecttypecatid;
    }

    public String getObjecttypeid() {
        return objecttypeid;
    }

    public String getMemberid() {
		return memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public void setObjecttypeid(String objecttypeid) {
        this.objecttypeid = objecttypeid;
    }

	public Date getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
    
    
}