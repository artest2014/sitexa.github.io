package com.cct9k.entity.finance;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the T_ACCOUNT_OFFSET database table.
 * 
 */
@Entity
@Table(name="T_ACCOUNT_OFFSET")
public class AccountOffset implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String offsetid;

	private float amount;

	private String beoffsetaccountid;

	private String offsetaccountid;

	@Column(name="\"SEQUENCE\"")
	private int sequence;

	public AccountOffset() {
	}

	public String getOffsetid() {
		return this.offsetid;
	}

	public void setOffsetid(String offsetid) {
		this.offsetid = offsetid;
	}

	public float getAmount() {
		return this.amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getBeoffsetaccountid() {
		return this.beoffsetaccountid;
	}

	public void setBeoffsetaccountid(String beoffsetaccountid) {
		this.beoffsetaccountid = beoffsetaccountid;
	}

	public String getOffsetaccountid() {
		return this.offsetaccountid;
	}

	public void setOffsetaccountid(String offsetaccountid) {
		this.offsetaccountid = offsetaccountid;
	}

	public int getSequence() {
		return this.sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

}