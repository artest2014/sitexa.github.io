package com.cct9k.entity.finance;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the T_ACCOUNT_ITEM database table.
 * 
 */
@Entity
@Table(name="T_ACCOUNT_ITEM")
public class AccountItem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String  accountitemid;
	private String itemid;
	private String depth;

	private String isleaf;

	private String itemname;

	private String memberid;

	private String parentid;

	private String remark;

	private String status;
	
	private String itemtype;

	//bi-directional many-to-one association to TAccount
	@OneToMany(mappedBy="AccountItem")
	private List<Account> Accounts;

	public String getAccountitemid() {
		return accountitemid;
	}

	public void setAccountitemid(String accountitemid) {
		this.accountitemid = accountitemid;
	}

	public AccountItem() {
	}

	public String getItemid() {
		return this.itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}

	public String getDepth() {
		return this.depth;
	}

	public void setDepth(String depth) {
		this.depth = depth;
	}

	public String getIsleaf() {
		return this.isleaf;
	}

	public void setIsleaf(String isleaf) {
		this.isleaf = isleaf;
	}

	public String getItemname() {
		return this.itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public String getParentid() {
		return this.parentid;
	}

	public void setParentid(String parentid) {
		this.parentid = parentid;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<Account> getAccounts() {
		return this.Accounts;
	}

	public void setAccounts(List<Account> Accounts) {
		this.Accounts = Accounts;
	}

	public Account addAccount(Account Account) {
		getAccounts().add(Account);
		Account.setAccountItem(this);

		return Account;
	}

	public Account removeAccount(Account Account) {
		getAccounts().remove(Account);
		Account.setAccountItem(null);

		return Account;
	}

	public String getItemtype() {
		return itemtype;
	}

	public void setItemtype(String itemtype) {
		this.itemtype = itemtype;
	}
	
}