package com.cct9k.entity.finance;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;

import java.util.Date;


/**
 * The persistent class for the T_AUDIT database table.
 * 审核
 */
@Entity
@Table(name="T_AUDIT")
public class Audit implements Serializable {
	
	private static final long serialVersionUID = 1076960978394493343L;
	public static final String AUDIT_OBJECT_TYPE_GROUPMEMBER = "39";
	public static final String AUDIT_OBJECT_TYPE_PLAN = "40";
	public static final String AUDIT_OBJECT_TYPE_CHECKSHEET = "41";
	public static final String AUDIT_OBJECT_TYPE_CONTRACT = "48";//合同
	public static final String AUDIT_OBJECT_TYPE_COMMISSION_RULE = "49";//佣金返利规则
	
	
	public static final String AUDIT_AGREE = "42";
	public static final String AUDIT_REJECT = "43";
	
	@Id
	private String auditid;

	private String auditcontent1;

	private String auditcontent2;

	@Temporal(TemporalType.TIMESTAMP)
	private Date auditdate1;

	@Temporal(TemporalType.TIMESTAMP)
	private Date auditdate2;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="auditor1")
	private Member auditor1;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="auditor2")
	private Member auditor2;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="auditstatus1")
	private Dictionary auditstatus1;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="auditstatus2")
	private Dictionary auditstatus2;

	private String objectid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="objecttype")
	private Dictionary objecttype;
	

	public Dictionary getObjecttype() {
		return objecttype;
	}

	public void setObjecttype(Dictionary objecttype) {
		this.objecttype = objecttype;
	}

	public Audit() {
	}

	public String getAuditid() {
		return this.auditid;
	}

	public void setAuditid(String auditid) {
		this.auditid = auditid;
	}

	public String getAuditcontent1() {
		return this.auditcontent1;
	}

	public void setAuditcontent1(String auditcontent1) {
		this.auditcontent1 = auditcontent1;
	}

	public String getAuditcontent2() {
		return this.auditcontent2;
	}

	public void setAuditcontent2(String auditcontent2) {
		this.auditcontent2 = auditcontent2;
	}

	public Date getAuditdate1() {
		return this.auditdate1;
	}

	public void setAuditdate1(Date auditdate1) {
		this.auditdate1 = auditdate1;
	}

	public Date getAuditdate2() {
		return this.auditdate2;
	}

	public void setAuditdate2(Date auditdate2) {
		this.auditdate2 = auditdate2;
	}

	public Member getAuditor1() {
		return auditor1;
	}

	public void setAuditor1(Member auditor1) {
		this.auditor1 = auditor1;
	}

	public Member getAuditor2() {
		return auditor2;
	}

	public void setAuditor2(Member auditor2) {
		this.auditor2 = auditor2;
	}

	public String getObjectid() {
		return this.objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	public Dictionary getAuditstatus1() {
		return auditstatus1;
	}

	public void setAuditstatus1(Dictionary auditstatus1) {
		this.auditstatus1 = auditstatus1;
	}

	public Dictionary getAuditstatus2() {
		return auditstatus2;
	}

	public void setAuditstatus2(Dictionary auditstatus2) {
		this.auditstatus2 = auditstatus2;
	}

}