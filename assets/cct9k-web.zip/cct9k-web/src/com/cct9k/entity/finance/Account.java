package com.cct9k.entity.finance;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;


/**
 * The persistent class for the T_ACCOUNT database table.
 * 
 */
@Entity
@Table(name="T_ACCOUNT")
public class Account implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String accountid;
	@Temporal(TemporalType.TIMESTAMP)
	private Date accountdate;

	private float amount;

	private String buyerid;

	private String certificateid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "consumetype")
	private Dictionary consumetype;

	private String itemtype;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "memberid")
	private Member member;

	private String paymethod;

	private String remark;


	private String salerid;

	private String sourceid;
	
	private String sourcetype;

	//bi-directional many-to-one association to AccountItem
    @ManyToOne
	@JoinColumn(name="ITEMID")
	private AccountItem AccountItem;
    
    private String associateobjectid;
    private String status;
    private String creatorid;
    private Date tradedate;
    private String ifoffset;
    private float  offsetamount;
    private String  accountmethod;
    private String  sourcetypefrom;
    
    private String objecttypecatid;
    private String customertype;
    private String objecttypeid;
    
    public Account() {
    }

	public String getAccountid() {
		return this.accountid;
	}

	public void setAccountid(String accountid) {
		this.accountid = accountid;
	}


	public Date getAccountdate() {
		return accountdate;
	}

	public void setAccountdate(Date accountdate) {
		this.accountdate = accountdate;
	}



	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}



	public String getCertificateid() {
		return this.certificateid;
	}

	public void setCertificateid(String certificateid) {
		this.certificateid = certificateid;
	}

	public Dictionary getConsumetype() {
		return consumetype;
	}

	public void setConsumetype(Dictionary consumetype) {
		this.consumetype = consumetype;
	}

	public String getItemtype() {
		return this.itemtype;
	}

	public void setItemtype(String itemtype) {
		this.itemtype = itemtype;
	}

	

	public String getAssociateobjectid() {
		return associateobjectid;
	}

	public void setAssociateobjectid(String associateobjectid) {
		this.associateobjectid = associateobjectid;
	}

	public String getPaymethod() {
		return this.paymethod;
	}

	public void setPaymethod(String paymethod) {
		this.paymethod = paymethod;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}






	public String getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(String buyerid) {
		this.buyerid = buyerid;
	}



	public String getSalerid() {
		return salerid;
	}

	public void setSalerid(String salerid) {
		this.salerid = salerid;
	}

	public String getSourceid() {
		return this.sourceid;
	}

	public void setSourceid(String sourceid) {
		this.sourceid = sourceid;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}


	public String getSourcetype() {
		return sourcetype;
	}

	public void setSourcetype(String sourcetype) {
		this.sourcetype = sourcetype;
	}

	public AccountItem getAccountItem() {
		return this.AccountItem;
	}

	public void setAccountItem(AccountItem AccountItem) {
		this.AccountItem = AccountItem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatorid() {
		return creatorid;
	}

	public void setCreatorid(String creatorid) {
		this.creatorid = creatorid;
	}

	public Date getTradedate() {
		return tradedate;
	}

	public void setTradedate(Date tradedate) {
		this.tradedate = tradedate;
	}

	public String getIfoffset() {
		return ifoffset;
	}

	public void setIfoffset(String ifoffset) {
		this.ifoffset = ifoffset;
	}

	public float getOffsetamount() {
		return offsetamount;
	}

	public void setOffsetamount(float offsetamount) {
		this.offsetamount = offsetamount;
	}

	public String getAccountmethod() {
		return accountmethod;
	}

	public void setAccountmethod(String accountmethod) {
		this.accountmethod = accountmethod;
	}

	public String getSourcetypefrom() {
		return sourcetypefrom;
	}

	public void setSourcetypefrom(String sourcetypefrom) {
		this.sourcetypefrom = sourcetypefrom;
	}

	public String getObjecttypecatid() {
		return objecttypecatid;
	}

	public void setObjecttypecatid(String objecttypecatid) {
		this.objecttypecatid = objecttypecatid;
	}

	public String getCustomertype() {
		return customertype;
	}

	public void setCustomertype(String customertype) {
		this.customertype = customertype;
	}

	public String getObjecttypeid() {
		return objecttypeid;
	}

	public void setObjecttypeid(String objecttypeid) {
		this.objecttypeid = objecttypeid;
	}
	
	
	
}