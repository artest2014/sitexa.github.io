package com.cct9k.entity.finance;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_ACCOUNT_LOG database table.
 */
@Entity
@Table(name = "T_ACCOUNT_LOG")
public class AccountLog implements Serializable {

    private static final long serialVersionUID = -9149220038805480812L;

    @Id
    private String logid;

    private float amount;

    @Column(name = "CONTENTS")
    private String contents;

    private BigDecimal incdec;

    @Temporal(TemporalType.DATE)
    private Date logdate;

    private String orderid;

    @ManyToOne
    @JoinColumn(name = "MEMBERID")
    private MemberAccount memberAccount;

    public AccountLog() {
    }

    public String getLogid() {
        return this.logid;
    }

    public void setLogid(String logid) {
        this.logid = logid;
    }

    public double getAmount() {
        return this.amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getContents() {
        return this.contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public BigDecimal getIncdec() {
        return this.incdec;
    }

    public void setIncdec(BigDecimal incdec) {
        this.incdec = incdec;
    }

    public Date getLogdate() {
        return this.logdate;
    }

    public void setLogdate(Date logdate) {
        this.logdate = logdate;
    }

    public String getOrderid() {
        return this.orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public MemberAccount getMemberAccount() {
        return this.memberAccount;
    }

    public void setMemberAccount(MemberAccount memberAccount) {
        this.memberAccount = memberAccount;
    }

}