package com.cct9k.entity.finance;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_CASH_COUPON_INFO database table.
 */
@Entity
@Table(name = "T_CASH_COUPON_INFO")
public class CashCouponInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String cashcouponid;

    private BigDecimal cashcoufacevalue;

    private String cashcoutypecatid;

    private String createby;

    @Temporal(TemporalType.DATE)
    private Date createtime;

    private BigDecimal grantedsumnum;

    private BigDecimal issuenum;

    @Temporal(TemporalType.DATE)
    private Date validenddate;

    @Temporal(TemporalType.DATE)
    private Date validstartdate;

    public CashCouponInfo() {
    }

    public String getCashcouponid() {
        return this.cashcouponid;
    }

    public void setCashcouponid(String cashcouponid) {
        this.cashcouponid = cashcouponid;
    }

    public BigDecimal getCashcoufacevalue() {
        return this.cashcoufacevalue;
    }

    public void setCashcoufacevalue(BigDecimal cashcoufacevalue) {
        this.cashcoufacevalue = cashcoufacevalue;
    }

    public String getCashcoutypecatid() {
        return this.cashcoutypecatid;
    }

    public void setCashcoutypecatid(String cashcoutypecatid) {
        this.cashcoutypecatid = cashcoutypecatid;
    }

    public String getCreateby() {
        return this.createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public Date getCreatetime() {
        return this.createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public BigDecimal getGrantedsumnum() {
        return this.grantedsumnum;
    }

    public void setGrantedsumnum(BigDecimal grantedsumnum) {
        this.grantedsumnum = grantedsumnum;
    }

    public BigDecimal getIssuenum() {
        return this.issuenum;
    }

    public void setIssuenum(BigDecimal issuenum) {
        this.issuenum = issuenum;
    }

    public Date getValidenddate() {
        return this.validenddate;
    }

    public void setValidenddate(Date validenddate) {
        this.validenddate = validenddate;
    }

    public Date getValidstartdate() {
        return this.validstartdate;
    }

    public void setValidstartdate(Date validstartdate) {
        this.validstartdate = validstartdate;
    }

}