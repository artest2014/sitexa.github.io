package com.cct9k.entity.finance;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the T_ACCOUNT_ADJUSTMENT database table.
 * 
 */
@Entity
@Table(name="T_ACCOUNT_ADJUSTMENT")
public class AccountAdjustment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String accountadjustmentid;

	private Timestamp adjustdate;

	private String adjusttype;

	private float amount;

	private String auditstatus;

	private String memberid;
	
	private String orderid;

	private String parentid;

	private String remark;

	private String status;

	private String transactionid;

	public AccountAdjustment() {
	}

	public String getAccountadjustmentid() {
		return this.accountadjustmentid;
	}

	public void setAccountadjustmentid(String accountadjustmentid) {
		this.accountadjustmentid = accountadjustmentid;
	}

	public Timestamp getAdjustdate() {
		return this.adjustdate;
	}

	public void setAdjustdate(Timestamp adjustdate) {
		this.adjustdate = adjustdate;
	}

	public String getAdjusttype() {
		return this.adjusttype;
	}

	public void setAdjusttype(String adjusttype) {
		this.adjusttype = adjusttype;
	}

	public float getAmount() {
		return this.amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getAuditstatus() {
		return this.auditstatus;
	}

	public void setAuditstatus(String auditstatus) {
		this.auditstatus = auditstatus;
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public String getOrderid() {
		return this.orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public String getParentid() {
		return this.parentid;
	}

	public void setParentid(String parentid) {
		this.parentid = parentid;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransactionid() {
		return this.transactionid;
	}

	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}

}