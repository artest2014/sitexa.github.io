package com.cct9k.entity.finance;

import javax.persistence.*;

import com.cct9k.entity.admin.Site;
import com.cct9k.entity.member.Member;

import java.io.Serializable;


/**
 * The persistent class for the T_CARD database table.
 */
@Entity
@Table(name = "T_CARD")
public class Card implements Serializable {
	private static final long serialVersionUID = -1031777824655418925L;
	@Id
    private String cardno;
    private String bankaccount;
    private String bankbranch;
    private String bankbranchcode;
    private String bankdetail;
    private String bankname;
    @Column(name = "BIND")
    private String bind;
    private String cardstate;
    private String cardtype;
    private String datastate;
    @ManyToOne
    @JoinColumn(name = "BANKNO")
    private Bank bank;
    @ManyToOne
    @JoinColumn(name = "TYPENO")
    private CardType cardType;
    @ManyToOne
    @JoinColumn(name = "MEMBERID")
    private Member member;
    @ManyToOne
    @JoinColumn(name = "SITEID")
    private Site site;

    public Card() {
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }

    public String getCardno() {
        return this.cardno;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public String getBankaccount() {
        return this.bankaccount;
    }

    public void setBankaccount(String bankaccount) {
        this.bankaccount = bankaccount;
    }

    public String getBankbranch() {
        return this.bankbranch;
    }

    public void setBankbranch(String bankbranch) {
        this.bankbranch = bankbranch;
    }

    public String getBankbranchcode() {
        return this.bankbranchcode;
    }

    public void setBankbranchcode(String bankbranchcode) {
        this.bankbranchcode = bankbranchcode;
    }

    public String getBankdetail() {
        return this.bankdetail;
    }

    public void setBankdetail(String bankdetail) {
        this.bankdetail = bankdetail;
    }
    public String getBankname() {
        return this.bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname;
    }

    public String getBind() {
        return this.bind;
    }

    public void setBind(String bind) {
        this.bind = bind;
    }

    public String getCardstate() {
        return this.cardstate;
    }

    public void setCardstate(String cardstate) {
        this.cardstate = cardstate;
    }

    public String getCardtype() {
        return this.cardtype;
    }

    public void setCardtype(String cardtype) {
        this.cardtype = cardtype;
    }

    public String getDatastate() {
        return this.datastate;
    }

    public void setDatastate(String datastate) {
        this.datastate = datastate;
    }

    public CardType getCardType() {
        return this.cardType;
    }

    public void setCardType(CardType cardType) {
        this.cardType = cardType;
    }

    public Member getMember() {
        return this.member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public Site getSite() {
        return this.site;
    }

    public void setSite(Site site) {
        this.site = site;
    }

}