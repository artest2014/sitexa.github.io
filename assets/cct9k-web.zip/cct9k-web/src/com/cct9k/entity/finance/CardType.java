package com.cct9k.entity.finance;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;


/**
 * The persistent class for the T_CARD_TYPE database table.
 */
@Entity
@Table(name = "T_CARD_TYPE")
public class CardType implements Serializable {
	private static final long serialVersionUID = -5417911452247860226L;
	@Id
    private String typeno;
    private String category;
    private String remark;
    private String typename;

    public CardType() {
    }

    public String getTypeno() {
        return this.typeno;
    }

    public void setTypeno(String typeno) {
        this.typeno = typeno;
    }

    public String getCategory() {
        return this.category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getRemark() {
        return this.remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getTypename() {
        return this.typename;
    }

    public void setTypename(String typename) {
        this.typename = typename;
    }

}