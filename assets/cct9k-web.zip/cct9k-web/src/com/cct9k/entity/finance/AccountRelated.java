package com.cct9k.entity.finance;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the T_ACCOUNT_RELATED database table.
 * 
 */
@Entity
@Table(name="T_ACCOUNT_RELATED")
public class AccountRelated implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String relateid;

	private String memberid;

	private String name;

	private String notes;

	private String relatesource;

	private String relatetype;
	
	private String relatememberid;

	public AccountRelated() {
	}

	public String getRelateid() {
		return this.relateid;
	}

	public void setRelateid(String relateid) {
		this.relateid = relateid;
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getRelatesource() {
		return this.relatesource;
	}

	public void setRelatesource(String relatesource) {
		this.relatesource = relatesource;
	}

	public String getRelatetype() {
		return this.relatetype;
	}

	public void setRelatetype(String relatetype) {
		this.relatetype = relatetype;
	}

	public String getRelatememberid() {
		return relatememberid;
	}

	public void setRelatememberid(String relatememberid) {
		this.relatememberid = relatememberid;
	}
	
}