package com.cct9k.entity.finance;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_COUPON_ISSUE_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_COUPON_ISSUE_DETAIL")
public class CouponIssueDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String issuedetailid;

	private String cashcouponid;

	private String createby;

	@Temporal(TemporalType.DATE)
	private Date createtime;

	private BigDecimal grantednum;

	private String grantedtomember;

	public CouponIssueDetail() {
	}

	public String getIssuedetailid() {
		return this.issuedetailid;
	}

	public void setIssuedetailid(String issuedetailid) {
		this.issuedetailid = issuedetailid;
	}

	public String getCashcouponid() {
		return this.cashcouponid;
	}

	public void setCashcouponid(String cashcouponid) {
		this.cashcouponid = cashcouponid;
	}

	public String getCreateby() {
		return this.createby;
	}

	public void setCreateby(String createby) {
		this.createby = createby;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public BigDecimal getGrantednum() {
		return this.grantednum;
	}

	public void setGrantednum(BigDecimal grantednum) {
		this.grantednum = grantednum;
	}

	public String getGrantedtomember() {
		return this.grantedtomember;
	}

	public void setGrantedtomember(String grantedtomember) {
		this.grantedtomember = grantedtomember;
	}

}