package com.cct9k.entity.finance;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the T_COMMISION_GROUP_INFO database table.
 */
@Entity
@Table(name = "T_COMMISSION_GROUP_INFO")
public class CommissionGroupInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String groupid;

    private String groupname;

    private BigDecimal commissionrate;
    
    private String memberid;
    
    private BigDecimal industryrate;
    
    private BigDecimal platrate;

    private String enableflag;
    
    public String getEnableflag() {
		return enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public BigDecimal getCommissionrate() {
		return commissionrate;
	}

	public void setCommissionrate(BigDecimal commissionrate) {
		this.commissionrate = commissionrate;
	}

	public String getMemberid() {
		return memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public BigDecimal getIndustryrate() {
		return industryrate;
	}

	public void setIndustryrate(BigDecimal industryrate) {
		this.industryrate = industryrate;
	}

	public BigDecimal getPlatrate() {
		return platrate;
	}

	public void setPlatrate(BigDecimal platrate) {
		this.platrate = platrate;
	}

	private String candelete;

    public String getCandelete() {
		return candelete;
	}

	public void setCandelete(String candelete) {
		this.candelete = candelete;
	}

	@Temporal(TemporalType.DATE)
    private Date createtime;

    private String tradetype;

    //bi-directional many-to-one association to CommisionGroupRef
    @OneToMany(mappedBy = "groupInfo")
    private List<CommissionGroupRef> groupRefs;

    public CommissionGroupInfo() {
    }



    public List<CommissionGroupRef> getGroupRefs() {
        return groupRefs;
    }

    public void setGroupRefs(List<CommissionGroupRef> groupRefs) {
        this.groupRefs = groupRefs;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }


    public String getTradetype() {
        return tradetype;
    }

    public void setTradetype(String tradetype) {
        this.tradetype = tradetype;
    }
}