package com.cct9k.entity.finance;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Plan;

/**
 * The persistent class for the T_CHECK_SHEET database table.
 * 报帐单
 */
@Entity
@Table(name = "T_CHECK_SHEET")
public class CheckSheet implements Serializable {
	public static final String CHECK_SHEET_EDIT = "36";
	public static final String CHECK_SHEET_DISPATCHER_AUDIT = "44";
	public static final String CHECK_SHEET_FINANCE_AUDIT = "2";
	public static final String CHECK_SHEET_REJECT = "46";
	public static final String CHECK_SHEET_AGREE = "38";
	
	public static final String CHECK_PLAN_YES = "2";
	public static final String CHECK_PLAN_NO = "0";

	private static final long serialVersionUID = -3692059931374143306L;

	public static final String QUERY_OBJECT_BY_PLANID = "from CheckSheet as model where model.plan.planid = :planid"; 
	
	@Id
	private String sheetid;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdate;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date commitdate;

	public Date getCommitdate() {
		return commitdate;
	}

	public void setCommitdate(Date commitdate) {
		this.commitdate = commitdate;
	}

	private String description;

	private BigDecimal invoicenum;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "memberid")
	private Member memberid;

	private String remark;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status")
	private Dictionary status;

	// bi-directional many-to-one association to TPlan
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "planid")
	private Plan plan;

	// bi-directional many-to-one association to TInvoice
	@OneToMany(mappedBy = "checksheet")
	private List<Invoice> invoices;
	
	@Transient
	private Audit audit;

	public CheckSheet() {
	}

	
	
	public Audit getAudit() {
		return audit;
	}


	public void setAudit(Audit audit) {
		this.audit = audit;
	}



	public String getSheetid() {
		return this.sheetid;
	}

	public void setSheetid(String sheetid) {
		this.sheetid = sheetid;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getInvoicenum() {
		return this.invoicenum;
	}

	public void setInvoicenum(BigDecimal invoicenum) {
		this.invoicenum = invoicenum;
	}

	public Member getMemberid() {
		return this.memberid;
	}

	public void setMemberid(Member memberid) {
		this.memberid = memberid;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Dictionary getStatus() {
		return this.status;
	}

	public void setStatus(Dictionary status) {
		this.status = status;
	}

	public Plan getPlan() {
		return this.plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}



	public Invoice addInvoice(Invoice invoice) {
		getInvoices().add(invoice);
		invoice.setChecksheet(this);
		return invoice;
	}
	

	public List<Invoice> getInvoices() {
		return invoices;
	}

	public void setInvoices(List<Invoice> invoices) {
		this.invoices = invoices;
	}

	public Invoice removeInvoice(Invoice invoice) {
		getInvoices().remove(invoice);
		invoice.setChecksheet(null);
		return invoice;
	}

}