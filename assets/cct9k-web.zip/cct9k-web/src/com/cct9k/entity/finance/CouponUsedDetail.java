package com.cct9k.entity.finance;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_COUPON_USED_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_COUPON_USED_DETAIL")
public class CouponUsedDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String useddetailid;

	private String cashcouponid;

	private String usedby;

	private String usedorderid;

	@Temporal(TemporalType.DATE)
	private Date usedtimeid;

	private BigDecimal usernum;

	public CouponUsedDetail() {
	}

	public String getUseddetailid() {
		return this.useddetailid;
	}

	public void setUseddetailid(String useddetailid) {
		this.useddetailid = useddetailid;
	}

	public String getCashcouponid() {
		return this.cashcouponid;
	}

	public void setCashcouponid(String cashcouponid) {
		this.cashcouponid = cashcouponid;
	}

	public String getUsedby() {
		return this.usedby;
	}

	public void setUsedby(String usedby) {
		this.usedby = usedby;
	}

	public String getUsedorderid() {
		return this.usedorderid;
	}

	public void setUsedorderid(String usedorderid) {
		this.usedorderid = usedorderid;
	}

	public Date getUsedtimeid() {
		return this.usedtimeid;
	}

	public void setUsedtimeid(Date usedtimeid) {
		this.usedtimeid = usedtimeid;
	}

	public BigDecimal getUsernum() {
		return this.usernum;
	}

	public void setUsernum(BigDecimal usernum) {
		this.usernum = usernum;
	}

}