package com.cct9k.entity.allinpay;


public class PersonMemberInfoRequest {

	private String member_Id;//会员号
	private String member_Name;//会员名称
	private String register_Date;//注册日期
	private String register_Code;//会员注册流水号
	private String english_Name;//英文名
	private String types_of_Certificates;//证件类型1身份证、2护照、3军官证
	private String organization_Code;//证件编号
	private String gender;//性别0：男  1：女  9：不详
	private String date_of_Birth;//出生日期
	private String telephone;//联系电话
	private String address;//常用通信地址
	private String post_Code;//邮编
	private String noticeFlag;//及时语开通标志0 未开通 1 手机通知 2 邮件通知 3 手机和邮件通知
	private String noticeLow;//最低通知金额 设置通知所需的最低金额，默认为0
	private String fax;//传真
	private String mobile;//通知手机号
	private String email;//E-Mail地址
	private String operate_Flag;//0-新增；1-修改；2-销户。
	private String remark;//备注
	public String getMember_Id() {
		return member_Id;
	}
	public void setMember_Id(String member_Id) {
		this.member_Id = member_Id;
	}
	public String getMember_Name() {
		return member_Name;
	}
	public void setMember_Name(String member_Name) {
		this.member_Name = member_Name;
	}
	public String getRegister_Date() {
		return register_Date;
	}
	public void setRegister_Date(String register_Date) {
		this.register_Date = register_Date;
	}
	public String getRegister_Code() {
		return register_Code;
	}
	public void setRegister_Code(String register_Code) {
		this.register_Code = register_Code;
	}
	public String getEnglish_Name() {
		return english_Name;
	}
	public void setEnglish_Name(String english_Name) {
		this.english_Name = english_Name;
	}
	public String getTypes_of_Certificates() {
		return types_of_Certificates;
	}
	public void setTypes_of_Certificates(String types_of_Certificates) {
		this.types_of_Certificates = types_of_Certificates;
	}
	public String getOrganization_Code() {
		return organization_Code;
	}
	public void setOrganization_Code(String organization_Code) {
		this.organization_Code = organization_Code;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDate_of_Birth() {
		return date_of_Birth;
	}
	public void setDate_of_Birth(String date_of_Birth) {
		this.date_of_Birth = date_of_Birth;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPost_Code() {
		return post_Code;
	}
	public void setPost_Code(String post_Code) {
		this.post_Code = post_Code;
	}
	public String getNoticeFlag() {
		return noticeFlag;
	}
	public void setNoticeFlag(String noticeFlag) {
		this.noticeFlag = noticeFlag;
	}
	public String getNoticeLow() {
		return noticeLow;
	}
	public void setNoticeLow(String noticeLow) {
		this.noticeLow = noticeLow;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOperate_Flag() {
		return operate_Flag;
	}
	public void setOperate_Flag(String operate_Flag) {
		this.operate_Flag = operate_Flag;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
}
