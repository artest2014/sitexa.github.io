package com.cct9k.entity.allinpay;


public class DepositRequest {

	private String bank_Name_Out;//结算账户开户行名称\在浦发结算账户开户行名称
	private String account_Name_Out;//结算账户名称\浦发的结算账号名称
	private String account_Code_Out;//结算账户账号\浦发的结算账号
	private String trade_Dir;//借贷方向\0-借 1-贷 入金固定填 1

	private String amount_In;//入账金额\正值
	private String date_In;//入账日期\入金请求日期 yyyymmdd
	private String time_In;//入账时间\入金请求时间 HHMMSS
	private String bank_Name_In;//来账银行名称\入金会员帐号开户银行名称
	private String account_Name_In;//来账账户名\入金会员帐号名称
	private String account_Code_In;//来账账户账号\入金会员帐号
	private String bank_Remark;//银行备注\填写会员号
	private String apply_Code;//请求流水号\\主键。永不重复。


	private String flag;//抹账标志\固定填0
	private String fee;//手续费\正值
	private String channel;//渠道\固定填 01
	private String pay_Type;//支付方式0 代表组合支付方式1 代表个人网银支付  4代表企业网银支付   其他值非法
	private String issue_Id;//支付银行机构代码
	private String receive_Url;//入金结果接收地址 用于接收入金处理结果
	private String pickup_Url;//入金后跳转页面
	public String getBank_Name_Out() {
		return bank_Name_Out;
	}
	public void setBank_Name_Out(String bank_Name_Out) {
		this.bank_Name_Out = bank_Name_Out;
	}
	public String getAccount_Name_Out() {
		return account_Name_Out;
	}
	public void setAccount_Name_Out(String account_Name_Out) {
		this.account_Name_Out = account_Name_Out;
	}
	public String getAccount_Code_Out() {
		return account_Code_Out;
	}
	public void setAccount_Code_Out(String account_Code_Out) {
		this.account_Code_Out = account_Code_Out;
	}
	public String getTrade_Dir() {
		return trade_Dir;
	}
	public void setTrade_Dir(String trade_Dir) {
		this.trade_Dir = trade_Dir;
	}
	public String getAmount_In() {
		return amount_In;
	}
	public void setAmount_In(String amount_In) {
		this.amount_In = amount_In;
	}
	public String getDate_In() {
		return date_In;
	}
	public void setDate_In(String date_In) {
		this.date_In = date_In;
	}
	public String getTime_In() {
		return time_In;
	}
	public void setTime_In(String time_In) {
		this.time_In = time_In;
	}
	public String getBank_Name_In() {
		return bank_Name_In;
	}
	public void setBank_Name_In(String bank_Name_In) {
		this.bank_Name_In = bank_Name_In;
	}
	public String getAccount_Name_In() {
		return account_Name_In;
	}
	public void setAccount_Name_In(String account_Name_In) {
		this.account_Name_In = account_Name_In;
	}
	public String getAccount_Code_In() {
		return account_Code_In;
	}
	public void setAccount_Code_In(String account_Code_In) {
		this.account_Code_In = account_Code_In;
	}
	public String getBank_Remark() {
		return bank_Remark;
	}
	public void setBank_Remark(String bank_Remark) {
		this.bank_Remark = bank_Remark;
	}
	public String getApply_Code() {
		return apply_Code;
	}
	public void setApply_Code(String apply_Code) {
		this.apply_Code = apply_Code;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getFee() {
		return fee;
	}
	public void setFee(String fee) {
		this.fee = fee;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getPay_Type() {
		return pay_Type;
	}
	public void setPay_Type(String pay_Type) {
		this.pay_Type = pay_Type;
	}
	public String getIssue_Id() {
		return issue_Id;
	}
	public void setIssue_Id(String issue_Id) {
		this.issue_Id = issue_Id;
	}
	public String getReceive_Url() {
		return receive_Url;
	}
	public void setReceive_Url(String receive_Url) {
		this.receive_Url = receive_Url;
	}
	public String getPickup_Url() {
		return pickup_Url;
	}
	public void setPickup_Url(String pickup_Url) {
		this.pickup_Url = pickup_Url;
	}
	
	

}
