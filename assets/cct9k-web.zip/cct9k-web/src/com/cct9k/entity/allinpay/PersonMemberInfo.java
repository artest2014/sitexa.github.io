package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the T_TL_PERSON_MEMBER_INFO database table.
 * 
 */
@Entity
@Table(name="T_TL_PERSON_MEMBER_INFO")
public class PersonMemberInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String memberid;

	private float accountbalance;

	private float accountfreezebalance;

	private float accountusablebalance;
    
	private Date createtime;

	private String creator;

	private String email;

	private String enableflag;

	private String fax;

	private String lastupdateby;
    
	private Date lastupdatetime;

	private String mobile;

	private String noticeflag;

	private String noticelow;

	private String password;

	private String remark;
	
	private String identityNo;
	
	private String identityType;
	
	private String memberName;

	public PersonMemberInfo() {
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public float getAccountbalance() {
		return accountbalance;
	}

	public void setAccountbalance(float accountbalance) {
		this.accountbalance = accountbalance;
	}

	public float getAccountfreezebalance() {
		return accountfreezebalance;
	}

	public void setAccountfreezebalance(float accountfreezebalance) {
		this.accountfreezebalance = accountfreezebalance;
	}

	public float getAccountusablebalance() {
		return accountusablebalance;
	}

	public void setAccountusablebalance(float accountusablebalance) {
		this.accountusablebalance = accountusablebalance;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEnableflag() {
		return this.enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getLastupdateby() {
		return this.lastupdateby;
	}

	public void setLastupdateby(String lastupdateby) {
		this.lastupdateby = lastupdateby;
	}

	public Date getLastupdatetime() {
		return this.lastupdatetime;
	}

	public void setLastupdatetime(Date lastupdatetime) {
		this.lastupdatetime = lastupdatetime;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getNoticeflag() {
		return this.noticeflag;
	}

	public void setNoticeflag(String noticeflag) {
		this.noticeflag = noticeflag;
	}

	public String getNoticelow() {
		return this.noticelow;
	}

	public void setNoticelow(String noticelow) {
		this.noticelow = noticelow;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getIdentityNo() {
		return identityNo;
	}

	public void setIdentityNo(String identityNo) {
		this.identityNo = identityNo;
	}

	public String getIdentityType() {
		return identityType;
	}

	public void setIdentityType(String identityType) {
		this.identityType = identityType;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	
	

}