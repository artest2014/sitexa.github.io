package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_REFUND_APPLY_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_REFUND_APPLY_DETAIL")
public class RefundApplyDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String refundid;

	private float applyamount;

	private String applyreason;

	private String auditstatus;

	private String buyer;

	private float factrefundamount;

	private String handlingsuggestion;

	private float orderamount;

	private String orderid;

	private float receivablecharge;

	@Temporal(TemporalType.TIMESTAMP)
	private Date refundapplydate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date refunddate;

	private String remark;

	private String seller;

	public RefundApplyDetail() {
	}

	public String getRefundid() {
		return this.refundid;
	}

	public void setRefundid(String refundid) {
		this.refundid = refundid;
	}

	public String getApplyreason() {
		return this.applyreason;
	}

	public void setApplyreason(String applyreason) {
		this.applyreason = applyreason;
	}

	public String getAuditstatus() {
		return this.auditstatus;
	}

	public void setAuditstatus(String auditstatus) {
		this.auditstatus = auditstatus;
	}

	public String getBuyer() {
		return this.buyer;
	}

	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	public String getHandlingsuggestion() {
		return this.handlingsuggestion;
	}

	public void setHandlingsuggestion(String handlingsuggestion) {
		this.handlingsuggestion = handlingsuggestion;
	}

	public String getOrderid() {
		return this.orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public Date getRefundapplydate() {
		return this.refundapplydate;
	}

	public void setRefundapplydate(Date refundapplydate) {
		this.refundapplydate = refundapplydate;
	}

	public Date getRefunddate() {
		return this.refunddate;
	}

	public void setRefunddate(Date refunddate) {
		this.refunddate = refunddate;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getSeller() {
		return this.seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	public float getApplyamount() {
		return applyamount;
	}

	public void setApplyamount(float applyamount) {
		this.applyamount = applyamount;
	}

	public float getFactrefundamount() {
		return factrefundamount;
	}

	public void setFactrefundamount(float factrefundamount) {
		this.factrefundamount = factrefundamount;
	}

	public float getOrderamount() {
		return orderamount;
	}

	public void setOrderamount(float orderamount) {
		this.orderamount = orderamount;
	}

	public float getReceivablecharge() {
		return receivablecharge;
	}

	public void setReceivablecharge(float receivablecharge) {
		this.receivablecharge = receivablecharge;
	}
	
	

}