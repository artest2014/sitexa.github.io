package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_TL_FREEZE_THRAW_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_TL_FREEZE_THRAW_DETAIL")
public class FreezeThrawDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String freezethrawdetailid;

	private String bargaincode;

	private String errorcode;

	private String goodcode;

	private String goodname;

	private String goodquantity;

	private String membercode;

	private String membername;

	private String omembercode;

	private String omembername;

	private Date operatetime;

	private String operator;

	private String serialid;

	private String tradedate;

	private String trademode;

	private String trademoney;

	private String tradetype;

	public FreezeThrawDetail() {
	}

	public String getFreezethrawdetailid() {
		return this.freezethrawdetailid;
	}

	public void setFreezethrawdetailid(String freezethrawdetailid) {
		this.freezethrawdetailid = freezethrawdetailid;
	}

	public String getBargaincode() {
		return this.bargaincode;
	}

	public void setBargaincode(String bargaincode) {
		this.bargaincode = bargaincode;
	}

	public String getErrorcode() {
		return this.errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

	public String getGoodcode() {
		return this.goodcode;
	}

	public void setGoodcode(String goodcode) {
		this.goodcode = goodcode;
	}

	public String getGoodname() {
		return this.goodname;
	}

	public void setGoodname(String goodname) {
		this.goodname = goodname;
	}

	public String getGoodquantity() {
		return this.goodquantity;
	}

	public void setGoodquantity(String goodquantity) {
		this.goodquantity = goodquantity;
	}

	public String getMembercode() {
		return this.membercode;
	}

	public void setMembercode(String membercode) {
		this.membercode = membercode;
	}

	public String getMembername() {
		return this.membername;
	}

	public void setMembername(String membername) {
		this.membername = membername;
	}

	public String getOmembercode() {
		return this.omembercode;
	}

	public void setOmembercode(String omembercode) {
		this.omembercode = omembercode;
	}

	public String getOmembername() {
		return this.omembername;
	}

	public void setOmembername(String omembername) {
		this.omembername = omembername;
	}

	public Date getOperatetime() {
		return this.operatetime;
	}

	public void setOperatetime(Date operatetime) {
		this.operatetime = operatetime;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getSerialid() {
		return this.serialid;
	}

	public void setSerialid(String serialid) {
		this.serialid = serialid;
	}

	public String getTradedate() {
		return this.tradedate;
	}

	public void setTradedate(String tradedate) {
		this.tradedate = tradedate;
	}

	public String getTrademode() {
		return this.trademode;
	}

	public void setTrademode(String trademode) {
		this.trademode = trademode;
	}

	public String getTrademoney() {
		return this.trademoney;
	}

	public void setTrademoney(String trademoney) {
		this.trademoney = trademoney;
	}

	public String getTradetype() {
		return this.tradetype;
	}

	public void setTradetype(String tradetype) {
		this.tradetype = tradetype;
	}

}