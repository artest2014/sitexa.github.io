package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_TL_DEAL_TRANSACTION_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_TL_DEAL_TRANSACTION_DETAIL")
public class DealTransactionDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String dealtransactiondetailid;

	private String bargaincode;

	private String bmembercode;

	private String bmembername;

	private String errorcode;

	private String goodcode;

	private String goodname;

	private String goodquantity;

	private Date operatetime;

	private String operator;

	private String qsfee;

	private String serialid;

	private String smembercode;

	private String smembername;

	private String tradedate;

	private String trademode;

	private String trademoney;

	private String tradetype;

	public DealTransactionDetail() {
	}

	public String getDealtransactiondetailid() {
		return this.dealtransactiondetailid;
	}

	public void setDealtransactiondetailid(String dealtransactiondetailid) {
		this.dealtransactiondetailid = dealtransactiondetailid;
	}

	public String getBargaincode() {
		return this.bargaincode;
	}

	public void setBargaincode(String bargaincode) {
		this.bargaincode = bargaincode;
	}

	public String getBmembercode() {
		return this.bmembercode;
	}

	public void setBmembercode(String bmembercode) {
		this.bmembercode = bmembercode;
	}

	public String getBmembername() {
		return this.bmembername;
	}

	public void setBmembername(String bmembername) {
		this.bmembername = bmembername;
	}

	public String getErrorcode() {
		return this.errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

	public String getGoodcode() {
		return this.goodcode;
	}

	public void setGoodcode(String goodcode) {
		this.goodcode = goodcode;
	}

	public String getGoodname() {
		return this.goodname;
	}

	public void setGoodname(String goodname) {
		this.goodname = goodname;
	}

	public String getGoodquantity() {
		return this.goodquantity;
	}

	public void setGoodquantity(String goodquantity) {
		this.goodquantity = goodquantity;
	}

	public Date getOperatetime() {
		return this.operatetime;
	}

	public void setOperatetime(Date operatetime) {
		this.operatetime = operatetime;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getQsfee() {
		return this.qsfee;
	}

	public void setQsfee(String qsfee) {
		this.qsfee = qsfee;
	}

	public String getSerialid() {
		return this.serialid;
	}

	public void setSerialid(String serialid) {
		this.serialid = serialid;
	}

	public String getSmembercode() {
		return this.smembercode;
	}

	public void setSmembercode(String smembercode) {
		this.smembercode = smembercode;
	}

	public String getSmembername() {
		return this.smembername;
	}

	public void setSmembername(String smembername) {
		this.smembername = smembername;
	}

	public String getTradedate() {
		return this.tradedate;
	}

	public void setTradedate(String tradedate) {
		this.tradedate = tradedate;
	}

	public String getTrademode() {
		return this.trademode;
	}

	public void setTrademode(String trademode) {
		this.trademode = trademode;
	}

	public String getTrademoney() {
		return this.trademoney;
	}

	public void setTrademoney(String trademoney) {
		this.trademoney = trademoney;
	}

	public String getTradetype() {
		return tradetype;
	}

	public void setTradetype(String tradetype) {
		this.tradetype = tradetype;
	}

	

}