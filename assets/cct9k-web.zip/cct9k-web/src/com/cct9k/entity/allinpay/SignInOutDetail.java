package com.cct9k.entity.allinpay;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the T_TL_SIGN_IN_OUT_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_TL_SIGN_IN_OUT_DETAIL")
public class SignInOutDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String signdetailid;

	private String issign;

	private Date signdate;

	private String signtype;

	public SignInOutDetail() {
	}

	public String getSigndetailid() {
		return this.signdetailid;
	}

	public void setSigndetailid(String signdetailid) {
		this.signdetailid = signdetailid;
	}

	public String getIssign() {
		return this.issign;
	}

	public void setIssign(String issign) {
		this.issign = issign;
	}

	public Date getSigndate() {
		return this.signdate;
	}

	public void setSigndate(Date signdate) {
		this.signdate = signdate;
	}

	public String getSigntype() {
		return this.signtype;
	}

	public void setSigntype(String signtype) {
		this.signtype = signtype;
	}

}