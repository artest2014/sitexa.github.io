package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the T_TL_AREA_CODE database table.
 * 
 */
@Entity
@Table(name="T_TL_AREA_CODE")
public class AreaCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String areaid;

	private String areacode;

	private String areaname;

	private String status;

	//bi-directional many-to-one association to MemberAccountInfo
	@OneToMany(mappedBy="areaCode")
	private List<MemberAccountInfo> memberAccountInfos;

	//bi-directional many-to-one association to OrganMemberInfo
	@OneToMany(mappedBy="areaCode")
	private List<OrganMemberInfo> organMemberInfos;

	public AreaCode() {
	}

	public String getAreaid() {
		return this.areaid;
	}

	public void setAreaid(String areaid) {
		this.areaid = areaid;
	}

	public String getAreacode() {
		return this.areacode;
	}

	public void setAreacode(String areacode) {
		this.areacode = areacode;
	}

	public String getAreaname() {
		return this.areaname;
	}

	public void setAreaname(String areaname) {
		this.areaname = areaname;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<MemberAccountInfo> getMemberAccountInfos() {
		return memberAccountInfos;
	}

	public void setMemberAccountInfos(List<MemberAccountInfo> memberAccountInfos) {
		this.memberAccountInfos = memberAccountInfos;
	}

	public List<OrganMemberInfo> getOrganMemberInfos() {
		return organMemberInfos;
	}

	public void setOrganMemberInfos(List<OrganMemberInfo> organMemberInfos) {
		this.organMemberInfos = organMemberInfos;
	}

	

}