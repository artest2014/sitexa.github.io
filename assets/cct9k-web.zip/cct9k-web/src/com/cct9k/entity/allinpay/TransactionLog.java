package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;


/**
 * The persistent class for the T_TL_TRANSACTION_LOG database table.
 * 
 */
@Entity
@Table(name="T_TL_TRANSACTION_LOG")
public class TransactionLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String transactionlogid;

	private String dealresult;

	private String operator;
    
	private Date requestdate;

	@Lob
	private String requestparam;

	private String requestserialid;
   
	private Date responsedate;

	@Lob
	private String responseparam;

	private String tradetype;

	public TransactionLog() {
	}

	public String getTransactionlogid() {
		return this.transactionlogid;
	}

	public void setTransactionlogid(String transactionlogid) {
		this.transactionlogid = transactionlogid;
	}

	public String getDealresult() {
		return this.dealresult;
	}

	public void setDealresult(String dealresult) {
		this.dealresult = dealresult;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public Date getRequestdate() {
		return this.requestdate;
	}

	public void setRequestdate(Date requestdate) {
		this.requestdate = requestdate;
	}

	public String getRequestparam() {
		return this.requestparam;
	}

	public void setRequestparam(String requestparam) {
		this.requestparam = requestparam;
	}

	public String getRequestserialid() {
		return this.requestserialid;
	}

	public void setRequestserialid(String requestserialid) {
		this.requestserialid = requestserialid;
	}

	public Date getResponsedate() {
		return this.responsedate;
	}

	public void setResponsedate(Date responsedate) {
		this.responsedate = responsedate;
	}

	public String getResponseparam() {
		return this.responseparam;
	}

	public void setResponseparam(String responseparam) {
		this.responseparam = responseparam;
	}

	public String getTradetype() {
		return this.tradetype;
	}

	public void setTradetype(String tradetype) {
		this.tradetype = tradetype;
	}

}