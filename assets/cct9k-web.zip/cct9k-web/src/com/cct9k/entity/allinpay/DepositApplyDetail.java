package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_TL_DEPOSIT_APPLY_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_TL_DEPOSIT_APPLY_DETAIL")
public class DepositApplyDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String depositapplydetailid;

	private String accountcodein;

	private String accountcodeout;

	private String accountnamein;

	private String accountnameout;

	private String amountin;

	private String applycode;

	private String banknamein;

	private String banknameout;

	private String bankremark;

	private String channel;

	private String datein;

	private String errorcode;

	private String fee;

	private String flag;

	private String issueid;

	private String notifydealresult;

	private Date operatetime;

	private String operator;

	private String paytype;

	private String pickupurl;

	private String receiveurl;

	private String serialid;

	private String timein;

	private String tradedir;
	
	private String memberName;

	public DepositApplyDetail() {
	}

	public String getDepositapplydetailid() {
		return this.depositapplydetailid;
	}

	public void setDepositapplydetailid(String depositapplydetailid) {
		this.depositapplydetailid = depositapplydetailid;
	}

	public String getAccountcodein() {
		return this.accountcodein;
	}

	public void setAccountcodein(String accountcodein) {
		this.accountcodein = accountcodein;
	}

	public String getAccountcodeout() {
		return this.accountcodeout;
	}

	public void setAccountcodeout(String accountcodeout) {
		this.accountcodeout = accountcodeout;
	}

	public String getAccountnamein() {
		return this.accountnamein;
	}

	public void setAccountnamein(String accountnamein) {
		this.accountnamein = accountnamein;
	}

	public String getAccountnameout() {
		return this.accountnameout;
	}

	public void setAccountnameout(String accountnameout) {
		this.accountnameout = accountnameout;
	}

	public String getAmountin() {
		return this.amountin;
	}

	public void setAmountin(String amountin) {
		this.amountin = amountin;
	}

	public String getApplycode() {
		return this.applycode;
	}

	public void setApplycode(String applycode) {
		this.applycode = applycode;
	}

	public String getBanknamein() {
		return this.banknamein;
	}

	public void setBanknamein(String banknamein) {
		this.banknamein = banknamein;
	}

	public String getBanknameout() {
		return this.banknameout;
	}

	public void setBanknameout(String banknameout) {
		this.banknameout = banknameout;
	}

	public String getBankremark() {
		return this.bankremark;
	}

	public void setBankremark(String bankremark) {
		this.bankremark = bankremark;
	}

	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getDatein() {
		return this.datein;
	}

	public void setDatein(String datein) {
		this.datein = datein;
	}

	public String getErrorcode() {
		return this.errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

	public String getFee() {
		return this.fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getIssueid() {
		return this.issueid;
	}

	public void setIssueid(String issueid) {
		this.issueid = issueid;
	}

	public String getNotifydealresult() {
		return this.notifydealresult;
	}

	public void setNotifydealresult(String notifydealresult) {
		this.notifydealresult = notifydealresult;
	}

	public Date getOperatetime() {
		return this.operatetime;
	}

	public void setOperatetime(Date operatetime) {
		this.operatetime = operatetime;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getPaytype() {
		return this.paytype;
	}

	public void setPaytype(String paytype) {
		this.paytype = paytype;
	}

	public String getPickupurl() {
		return this.pickupurl;
	}

	public void setPickupurl(String pickupurl) {
		this.pickupurl = pickupurl;
	}

	public String getReceiveurl() {
		return this.receiveurl;
	}

	public void setReceiveurl(String receiveurl) {
		this.receiveurl = receiveurl;
	}

	public String getSerialid() {
		return this.serialid;
	}

	public void setSerialid(String serialid) {
		this.serialid = serialid;
	}

	public String getTimein() {
		return this.timein;
	}

	public void setTimein(String timein) {
		this.timein = timein;
	}

	public String getTradedir() {
		return this.tradedir;
	}

	public void setTradedir(String tradedir) {
		this.tradedir = tradedir;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	
	

}