package com.cct9k.entity.allinpay;

public class DealTransactionResponse {
	private String bargain_Code;	//成交合同号
	private String serial_Id;	//成交流水号
	private String trade_Money ;	//交易金额
	private String trade_Type;	//交易类型
	private String b_Member_Code;	//买方会员号
	private String s_Member_Code ;	//卖方会员号
	private String trade_Date;	//交易日期
	private String qs_Fee;	//清算费
	private String error_Code;	//错误代码
	private String responseCode;
	private String responseDesc;
	
	public String getBargain_Code() {
		return bargain_Code;
	}
	public void setBargain_Code(String bargain_Code) {
		this.bargain_Code = bargain_Code;
	}
	public String getSerial_Id() {
		return serial_Id;
	}
	public void setSerial_Id(String serial_Id) {
		this.serial_Id = serial_Id;
	}
	public String getTrade_Money() {
		return trade_Money;
	}
	public void setTrade_Money(String trade_Money) {
		this.trade_Money = trade_Money;
	}
	public String getTrade_Type() {
		return trade_Type;
	}
	public void setTrade_Type(String trade_Type) {
		this.trade_Type = trade_Type;
	}
	public String getB_Member_Code() {
		return b_Member_Code;
	}
	public void setB_Member_Code(String b_Member_Code) {
		this.b_Member_Code = b_Member_Code;
	}
	public String getS_Member_Code() {
		return s_Member_Code;
	}
	public void setS_Member_Code(String s_Member_Code) {
		this.s_Member_Code = s_Member_Code;
	}
	public String getTrade_Date() {
		return trade_Date;
	}
	public void setTrade_Date(String trade_Date) {
		this.trade_Date = trade_Date;
	}
	public String getQs_Fee() {
		return qs_Fee;
	}
	public void setQs_Fee(String qs_Fee) {
		this.qs_Fee = qs_Fee;
	}
	public String getError_Code() {
		return error_Code;
	}
	public void setError_Code(String error_Code) {
		this.error_Code = error_Code;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	
	
	
}
