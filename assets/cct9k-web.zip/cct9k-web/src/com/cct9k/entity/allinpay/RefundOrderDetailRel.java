package com.cct9k.entity.allinpay;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the T_REFUND_ORDER_DETAIL_REL database table.
 * 
 */
@Entity
@Table(name="T_REFUND_ORDER_DETAIL_REL")
public class RefundOrderDetailRel  {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private float buyerfactamount;

	private String detailid;

	private String refundid;

	public RefundOrderDetailRel() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public float getBuyerfactamount() {
		return this.buyerfactamount;
	}

	public void setBuyerfactamount(float buyerfactamount) {
		this.buyerfactamount = buyerfactamount;
	}

	public String getDetailid() {
		return this.detailid;
	}

	public void setDetailid(String detailid) {
		this.detailid = detailid;
	}

	public String getRefundid() {
		return this.refundid;
	}

	public void setRefundid(String refundid) {
		this.refundid = refundid;
	}

}