package com.cct9k.entity.allinpay;


public class OrganMemberInfoRequest {

	private String member_Id;//会员号
	private String member_Name;//会员名称
	private String protocol_Code;//入市协议编号 
	private String organization_Code;//证件编号
	private String register_Date;//商户注册日期
	private String address;//常用通信地址
	private String contact_Person;//联系人
	private String telephone;//联系电话
	private String fax;//传真
	private String mobile;//通知手机号
	private String email;//E-Mail地址
	private String represent_Name;//法定代表人
	private String registered_Capital;//注册资本
	private String area_Code;//所属区域
	private String check_Amount;//核定额度
	private String end_Date;//缴款截止日
	private String operate_Flag;//0-新增；1-修改；2-销户。
	private String remark;//备注
	private String noticeFlag;//及时语开通标志
	private String noticeLow;//最低通知金额
	
	public String getMember_Id() {
		return member_Id;
	}
	public void setMember_Id(String member_Id) {
		this.member_Id = member_Id;
	}
	public String getMember_Name() {
		return member_Name;
	}
	public void setMember_Name(String member_Name) {
		this.member_Name = member_Name;
	}
	public String getProtocol_Code() {
		return protocol_Code;
	}
	public void setProtocol_Code(String protocol_Code) {
		this.protocol_Code = protocol_Code;
	}
	public String getOrganization_Code() {
		return organization_Code;
	}
	public void setOrganization_Code(String organization_Code) {
		this.organization_Code = organization_Code;
	}
	public String getRegister_Date() {
		return register_Date;
	}
	public void setRegister_Date(String register_Date) {
		this.register_Date = register_Date;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact_Person() {
		return contact_Person;
	}
	public void setContact_Person(String contact_Person) {
		this.contact_Person = contact_Person;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRepresent_Name() {
		return represent_Name;
	}
	public void setRepresent_Name(String represent_Name) {
		this.represent_Name = represent_Name;
	}
	public String getRegistered_Capital() {
		return registered_Capital;
	}
	public void setRegistered_Capital(String registered_Capital) {
		this.registered_Capital = registered_Capital;
	}
	public String getArea_Code() {
		return area_Code;
	}
	public void setArea_Code(String area_Code) {
		this.area_Code = area_Code;
	}
	public String getCheck_Amount() {
		return check_Amount;
	}
	public void setCheck_Amount(String check_Amount) {
		this.check_Amount = check_Amount;
	}
	public String getEnd_Date() {
		return end_Date;
	}
	public void setEnd_Date(String end_Date) {
		this.end_Date = end_Date;
	}
	public String getOperate_Flag() {
		return operate_Flag;
	}
	public void setOperate_Flag(String operate_Flag) {
		this.operate_Flag = operate_Flag;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getNoticeFlag() {
		return noticeFlag;
	}
	public void setNoticeFlag(String noticeFlag) {
		this.noticeFlag = noticeFlag;
	}
	public String getNoticeLow() {
		return noticeLow;
	}
	public void setNoticeLow(String noticeLow) {
		this.noticeLow = noticeLow;
	}
	
	
	
	
}
