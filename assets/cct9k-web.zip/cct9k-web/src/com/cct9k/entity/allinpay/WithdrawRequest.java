package com.cct9k.entity.allinpay;


public class WithdrawRequest {
    
	 
	private String apply_Code;	//申请编号
	private String trade_Money;	//	划款金额
	private String member_Id;	//	会员号
	private String member_Name;	//	会员名称
	private String bank_Name_In;	//收账开户行名称
	private String account_Name_In;	//收账账号名称
	private String account_Id_In;	//收账账号
	private String trade_Date;	//	申请日期
	private String resume;	//	摘要
	
	public String getApply_Code() {
		return apply_Code;
	}
	public void setApply_Code(String apply_Code) {
		this.apply_Code = apply_Code;
	}
	public String getTrade_Money() {
		return trade_Money;
	}
	public void setTrade_Money(String trade_Money) {
		this.trade_Money = trade_Money;
	}
	public String getMember_Id() {
		return member_Id;
	}
	public void setMember_Id(String member_Id) {
		this.member_Id = member_Id;
	}
	public String getMember_Name() {
		return member_Name;
	}
	public void setMember_Name(String member_Name) {
		this.member_Name = member_Name;
	}
	public String getBank_Name_In() {
		return bank_Name_In;
	}
	public void setBank_Name_In(String bank_Name_In) {
		this.bank_Name_In = bank_Name_In;
	}
	public String getAccount_Name_In() {
		return account_Name_In;
	}
	public void setAccount_Name_In(String account_Name_In) {
		this.account_Name_In = account_Name_In;
	}
	public String getAccount_Id_In() {
		return account_Id_In;
	}
	public void setAccount_Id_In(String account_Id_In) {
		this.account_Id_In = account_Id_In;
	}
	public String getTrade_Date() {
		return trade_Date;
	}
	public void setTrade_Date(String trade_Date) {
		this.trade_Date = trade_Date;
	}
	public String getResume() {
		return resume;
	}
	public void setResume(String resume) {
		this.resume = resume;
	}
	
    
}
