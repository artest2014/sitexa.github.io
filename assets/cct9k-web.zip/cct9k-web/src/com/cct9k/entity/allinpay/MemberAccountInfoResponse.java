package com.cct9k.entity.allinpay;

public class MemberAccountInfoResponse {

	private String member_Id;	//会员号
	private String account_Code;	//账户账号
	private String error_Code;	//错误代码
	private String responseCode;
	private String responseDesc;
	public String getMember_Id() {
		return member_Id;
	}
	public void setMember_Id(String member_Id) {
		this.member_Id = member_Id;
	}
	public String getAccount_Code() {
		return account_Code;
	}
	public void setAccount_Code(String account_Code) {
		this.account_Code = account_Code;
	}
	public String getError_Code() {
		return error_Code;
	}
	public void setError_Code(String error_Code) {
		this.error_Code = error_Code;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	
	
}
