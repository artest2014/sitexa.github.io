package com.cct9k.entity.allinpay;



public class FreezeThrawRequest {

	private String serial_Id;	//业务流水号
	private String trade_Type;	//	交易类型
	private String trade_Money;	//交易金额
	private String member_Code;	//	交易会员号
	private String member_Name;	//交易会员名称
	private String o_Member_Code;	//交易对手会员号
	private String o_Member_Name;	//交易对手会员名称
	private String trade_Date;	//交易日期
	private String trade_Mode;	//交易方式
	
	private String good_Code;	//货物编号
	private String good_Name;	//货物名称
	private String good_Quantity;	//货物数量
	private String bargain_Code;	//成交合同号
	public String getSerial_Id() {
		return serial_Id;
	}
	public void setSerial_Id(String serial_Id) {
		this.serial_Id = serial_Id;
	}
	public String getTrade_Type() {
		return trade_Type;
	}
	public void setTrade_Type(String trade_Type) {
		this.trade_Type = trade_Type;
	}
	public String getTrade_Money() {
		return trade_Money;
	}
	public void setTrade_Money(String trade_Money) {
		this.trade_Money = trade_Money;
	}
	public String getMember_Code() {
		return member_Code;
	}
	public void setMember_Code(String member_Code) {
		this.member_Code = member_Code;
	}
	public String getMember_Name() {
		return member_Name;
	}
	public void setMember_Name(String member_Name) {
		this.member_Name = member_Name;
	}
	public String getO_Member_Code() {
		return o_Member_Code;
	}
	public void setO_Member_Code(String o_Member_Code) {
		this.o_Member_Code = o_Member_Code;
	}
	public String getO_Member_Name() {
		return o_Member_Name;
	}
	public void setO_Member_Name(String o_Member_Name) {
		this.o_Member_Name = o_Member_Name;
	}
	public String getTrade_Date() {
		return trade_Date;
	}
	public void setTrade_Date(String trade_Date) {
		this.trade_Date = trade_Date;
	}
	public String getTrade_Mode() {
		return trade_Mode;
	}
	public void setTrade_Mode(String trade_Mode) {
		this.trade_Mode = trade_Mode;
	}
	public String getGood_Code() {
		return good_Code;
	}
	public void setGood_Code(String good_Code) {
		this.good_Code = good_Code;
	}
	public String getGood_Name() {
		return good_Name;
	}
	public void setGood_Name(String good_Name) {
		this.good_Name = good_Name;
	}
	public String getGood_Quantity() {
		return good_Quantity;
	}
	public void setGood_Quantity(String good_Quantity) {
		this.good_Quantity = good_Quantity;
	}
	public String getBargain_Code() {
		return bargain_Code;
	}
	public void setBargain_Code(String bargain_Code) {
		this.bargain_Code = bargain_Code;
	}
	
	

}
