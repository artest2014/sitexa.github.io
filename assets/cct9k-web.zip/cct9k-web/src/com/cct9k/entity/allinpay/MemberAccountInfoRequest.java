package com.cct9k.entity.allinpay;


public class MemberAccountInfoRequest {

	private String member_Id;//会员号
	private String bank_Name;//银行名称
	private String account_Bank_Name;//账户开户行名称
	private String account_Name;//账户名称
	private String account_Code;//账户账号
	private String area_Code;//地区代码
	private String account_Type;//账户类型     1入金  2出金  3  入金和出金
	private String operate_Flag;//操作标志 0新增    1修改   2删除
	private String acctIn_Type;//收款账类型   1卡
	public String getMember_Id() {
		return member_Id;
	}
	public void setMember_Id(String member_Id) {
		this.member_Id = member_Id;
	}
	public String getBank_Name() {
		return bank_Name;
	}
	public void setBank_Name(String bank_Name) {
		this.bank_Name = bank_Name;
	}
	public String getAccount_Bank_Name() {
		return account_Bank_Name;
	}
	public void setAccount_Bank_Name(String account_Bank_Name) {
		this.account_Bank_Name = account_Bank_Name;
	}
	public String getAccount_Name() {
		return account_Name;
	}
	public void setAccount_Name(String account_Name) {
		this.account_Name = account_Name;
	}
	public String getAccount_Code() {
		return account_Code;
	}
	public void setAccount_Code(String account_Code) {
		this.account_Code = account_Code;
	}
	public String getArea_Code() {
		return area_Code;
	}
	public void setArea_Code(String area_Code) {
		this.area_Code = area_Code;
	}
	public String getAccount_Type() {
		return account_Type;
	}
	public void setAccount_Type(String account_Type) {
		this.account_Type = account_Type;
	}
	public String getOperate_Flag() {
		return operate_Flag;
	}
	public void setOperate_Flag(String operate_Flag) {
		this.operate_Flag = operate_Flag;
	}
	public String getAcctIn_Type() {
		return acctIn_Type;
	}
	public void setAcctIn_Type(String acctIn_Type) {
		this.acctIn_Type = acctIn_Type;
	}
	
	

}
