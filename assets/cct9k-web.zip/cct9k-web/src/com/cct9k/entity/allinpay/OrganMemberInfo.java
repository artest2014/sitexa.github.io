package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_TL_ORGAN_MEMBER_INFO database table.
 * 
 */
@Entity
@Table(name="T_TL_ORGAN_MEMBER_INFO")
public class OrganMemberInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String memberid;

	private float accountbalance;

	private float accountfreezebalance;

	private float accountusablebalance;

	private String checkamount;

	private Date createtime;

	private String creator;

	private String email;

	private String enableflag;

	private String enddate;

	private String fax;

	private String lastupdateby;

	private Date lastupdatetime;

	private String mobile;

	private String noticeflag;

	private String noticelow;

	private String password;

	private String protocolcode;

	private String remark;
	
	private String memberName;

	//bi-directional many-to-one association to AreaCode
	@ManyToOne
	@JoinColumn(name="AREACODE")
	private AreaCode areaCode;

	public OrganMemberInfo() {
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public float getAccountbalance() {
		return accountbalance;
	}

	public void setAccountbalance(float accountbalance) {
		this.accountbalance = accountbalance;
	}

	public float getAccountfreezebalance() {
		return accountfreezebalance;
	}

	public void setAccountfreezebalance(float accountfreezebalance) {
		this.accountfreezebalance = accountfreezebalance;
	}

	public float getAccountusablebalance() {
		return accountusablebalance;
	}

	public void setAccountusablebalance(float accountusablebalance) {
		this.accountusablebalance = accountusablebalance;
	}

	public String getCheckamount() {
		return this.checkamount;
	}

	public void setCheckamount(String checkamount) {
		this.checkamount = checkamount;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEnableflag() {
		return this.enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public String getEnddate() {
		return this.enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getLastupdateby() {
		return this.lastupdateby;
	}

	public void setLastupdateby(String lastupdateby) {
		this.lastupdateby = lastupdateby;
	}

	public Date getLastupdatetime() {
		return this.lastupdatetime;
	}

	public void setLastupdatetime(Date lastupdatetime) {
		this.lastupdatetime = lastupdatetime;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getNoticeflag() {
		return this.noticeflag;
	}

	public void setNoticeflag(String noticeflag) {
		this.noticeflag = noticeflag;
	}

	public String getNoticelow() {
		return this.noticelow;
	}

	public void setNoticelow(String noticelow) {
		this.noticelow = noticelow;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProtocolcode() {
		return this.protocolcode;
	}

	public void setProtocolcode(String protocolcode) {
		this.protocolcode = protocolcode;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public AreaCode getAreaCode() {
		return this.areaCode;
	}

	public void setAreaCode(AreaCode areaCode) {
		this.areaCode = areaCode;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	
	

}