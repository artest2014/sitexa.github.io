package com.cct9k.entity.allinpay;


public class FreezeThrawResponse {

	private String serial_Id  ;	//业务流水号
	private String trade_Type ;	//交易类型
	private String member_Code ;	//交易会员号
	private String trade_Money ;	//交易金额
	private String error_Code ;	//错误代码
	private String bargain_Code ;	//成交合同号
	private String responseCode;
	private String responseDesc;
	public String getSerial_Id() {
		return serial_Id;
	}
	public void setSerial_Id(String serial_Id) {
		this.serial_Id = serial_Id;
	}
	public String getTrade_Type() {
		return trade_Type;
	}
	public void setTrade_Type(String trade_Type) {
		this.trade_Type = trade_Type;
	}
	public String getMember_Code() {
		return member_Code;
	}
	public void setMember_Code(String member_Code) {
		this.member_Code = member_Code;
	}
	public String getTrade_Money() {
		return trade_Money;
	}
	public void setTrade_Money(String trade_Money) {
		this.trade_Money = trade_Money;
	}
	public String getError_Code() {
		return error_Code;
	}
	public void setError_Code(String error_Code) {
		this.error_Code = error_Code;
	}
	public String getBargain_Code() {
		return bargain_Code;
	}
	public void setBargain_Code(String bargain_Code) {
		this.bargain_Code = bargain_Code;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	
	
    
}
