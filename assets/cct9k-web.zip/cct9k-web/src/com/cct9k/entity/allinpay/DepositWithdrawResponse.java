package com.cct9k.entity.allinpay;

public class DepositWithdrawResponse {

	private String apply_Code;	//申请编号
	private String serial_Id;	//处理流水号
	private String error_Code;	//错误代码
	private String responseCode;
	private String responseDesc;
	public String getApply_Code() {
		return apply_Code;
	}
	public void setApply_Code(String apply_Code) {
		this.apply_Code = apply_Code;
	}
	public String getSerial_Id() {
		return serial_Id;
	}
	public void setSerial_Id(String serial_Id) {
		this.serial_Id = serial_Id;
	}
	public String getError_Code() {
		return error_Code;
	}
	public void setError_Code(String error_Code) {
		this.error_Code = error_Code;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	
	
	
	
}
