package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_TL_TRANSFER_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_TL_TRANSFER_DETAIL")
public class TransferDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String transferid;

	private String dealresult;

	private String dealserialid;

	private String freezeserialid;

	private Date operatetime;

	private String operator;

	private String payaccount;

	private String payer;

	private String payername;

	private String receiveaccount;

	private String receiver;

	private String receivername;

	private float transferamount;

	public TransferDetail() {
	}

	public String getTransferid() {
		return this.transferid;
	}

	public void setTransferid(String transferid) {
		this.transferid = transferid;
	}

	public String getDealresult() {
		return this.dealresult;
	}

	public void setDealresult(String dealresult) {
		this.dealresult = dealresult;
	}

	public String getDealserialid() {
		return this.dealserialid;
	}

	public void setDealserialid(String dealserialid) {
		this.dealserialid = dealserialid;
	}

	public String getFreezeserialid() {
		return this.freezeserialid;
	}

	public void setFreezeserialid(String freezeserialid) {
		this.freezeserialid = freezeserialid;
	}

	public Date getOperatetime() {
		return this.operatetime;
	}

	public void setOperatetime(Date operatetime) {
		this.operatetime = operatetime;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getPayaccount() {
		return this.payaccount;
	}

	public void setPayaccount(String payaccount) {
		this.payaccount = payaccount;
	}

	public String getPayer() {
		return this.payer;
	}

	public void setPayer(String payer) {
		this.payer = payer;
	}

	public String getPayername() {
		return this.payername;
	}

	public void setPayername(String payername) {
		this.payername = payername;
	}

	public String getReceiveaccount() {
		return this.receiveaccount;
	}

	public void setReceiveaccount(String receiveaccount) {
		this.receiveaccount = receiveaccount;
	}

	public String getReceiver() {
		return this.receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getReceivername() {
		return this.receivername;
	}

	public void setReceivername(String receivername) {
		this.receivername = receivername;
	}

	public float getTransferamount() {
		return transferamount;
	}

	public void setTransferamount(float transferamount) {
		this.transferamount = transferamount;
	}

	

}