package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_TL_WITHDRAW_APPLY_DETAIL database table.
 * 
 */
@Entity
@Table(name="T_TL_WITHDRAW_APPLY_DETAIL")
public class WithdrawApplyDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String withdrawapplydetailid;

	private String accountidin;

	private String accountnamein;

	private String applycode;

	private String banknamein;

	private String dealresult;

	private String dealstatus;

	private String errorcode;

	private String memberid;

	private String membername;

	private Date operatetime;

	private String operator;

	@Column(name="\"RESUME\"")
	private String resume;

	private String serialid;

	private String tradedate;

	private String trademoney;

	public WithdrawApplyDetail() {
	}

	public String getWithdrawapplydetailid() {
		return this.withdrawapplydetailid;
	}

	public void setWithdrawapplydetailid(String withdrawapplydetailid) {
		this.withdrawapplydetailid = withdrawapplydetailid;
	}

	public String getAccountidin() {
		return this.accountidin;
	}

	public void setAccountidin(String accountidin) {
		this.accountidin = accountidin;
	}

	public String getAccountnamein() {
		return this.accountnamein;
	}

	public void setAccountnamein(String accountnamein) {
		this.accountnamein = accountnamein;
	}

	public String getApplycode() {
		return this.applycode;
	}

	public void setApplycode(String applycode) {
		this.applycode = applycode;
	}

	public String getBanknamein() {
		return this.banknamein;
	}

	public void setBanknamein(String banknamein) {
		this.banknamein = banknamein;
	}

	public String getDealresult() {
		return this.dealresult;
	}

	public void setDealresult(String dealresult) {
		this.dealresult = dealresult;
	}

	public String getDealstatus() {
		return this.dealstatus;
	}

	public void setDealstatus(String dealstatus) {
		this.dealstatus = dealstatus;
	}

	public String getErrorcode() {
		return this.errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public String getMembername() {
		return this.membername;
	}

	public void setMembername(String membername) {
		this.membername = membername;
	}

	public Date getOperatetime() {
		return this.operatetime;
	}

	public void setOperatetime(Date operatetime) {
		this.operatetime = operatetime;
	}

	public String getOperator() {
		return this.operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getResume() {
		return this.resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

	public String getSerialid() {
		return this.serialid;
	}

	public void setSerialid(String serialid) {
		this.serialid = serialid;
	}

	public String getTradedate() {
		return this.tradedate;
	}

	public void setTradedate(String tradedate) {
		this.tradedate = tradedate;
	}

	public String getTrademoney() {
		return this.trademoney;
	}

	public void setTrademoney(String trademoney) {
		this.trademoney = trademoney;
	}

}