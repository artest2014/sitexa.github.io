package com.cct9k.entity.allinpay;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_TL_MEMBER_ACCOUNT_INFO database table.
 * 
 */
@Entity
@Table(name="T_TL_MEMBER_ACCOUNT_INFO")
public class MemberAccountInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String memberaccountid;

	private String accountbankname;

	private String accountcode;

	private String accountname;

	private String accounttype;

	private String acctintype;

	private Date createtime;

	private String creator;

	private String enableflag;

	private String lastupdateby;

	private Date lastupdatetime;

	private String memberid;
	
	private String membername;

	//bi-directional many-to-one association to AreaCode
	@ManyToOne
	@JoinColumn(name="TLAREAID")
	private AreaCode areaCode;

	public MemberAccountInfo() {
	}

	public String getMemberaccountid() {
		return this.memberaccountid;
	}

	public void setMemberaccountid(String memberaccountid) {
		this.memberaccountid = memberaccountid;
	}

	public String getAccountbankname() {
		return this.accountbankname;
	}

	public void setAccountbankname(String accountbankname) {
		this.accountbankname = accountbankname;
	}

	public String getAccountcode() {
		return this.accountcode;
	}

	public void setAccountcode(String accountcode) {
		this.accountcode = accountcode;
	}

	public String getAccountname() {
		return this.accountname;
	}

	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}

	public String getAccounttype() {
		return this.accounttype;
	}

	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}

	public String getAcctintype() {
		return this.acctintype;
	}

	public void setAcctintype(String acctintype) {
		this.acctintype = acctintype;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getEnableflag() {
		return this.enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public String getLastupdateby() {
		return this.lastupdateby;
	}

	public void setLastupdateby(String lastupdateby) {
		this.lastupdateby = lastupdateby;
	}

	public Date getLastupdatetime() {
		return this.lastupdatetime;
	}

	public void setLastupdatetime(Date lastupdatetime) {
		this.lastupdatetime = lastupdatetime;
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public AreaCode getAreaCode() {
		return this.areaCode;
	}

	public void setAreaCode(AreaCode areaCode) {
		this.areaCode = areaCode;
	}

	public String getMembername() {
		return membername;
	}

	public void setMembername(String membername) {
		this.membername = membername;
	}
	
	

}