package com.cct9k.entity.equipment;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.entity.member.Member;


import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_TUNELINK_CONSUMP_LOG database table.
 * 
 */
@Entity
@Table(name="T_TUNELINK_CONSUMP_LOG")
public class TunelinkConsumeLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String consumptionlogid;
	
	@ManyToOne(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY)
	@JoinColumn(name="buyer")
	private Member buyer;
	
	@ManyToOne(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY)
	@JoinColumn(name="sellor")
	private Member sellor;

	private BigDecimal tradeamount;

	private String tradesquence;

	@Temporal(TemporalType.DATE)
	private Date tradetime;

	//bi-directional many-to-one association to TravelTerminal
	@ManyToOne
	@JoinColumn(name="TERMINALID")
	private TravelTerminal travelTerminal;

	//bi-directional many-to-one association to Tunelink
	@ManyToOne
	@JoinColumn(name="CARDID")
	private Tunelink tunelink;

	public TunelinkConsumeLog() {
	}

	public String getConsumptionlogid() {
		return this.consumptionlogid;
	}

	public void setConsumptionlogid(String consumptionlogid) {
		this.consumptionlogid = consumptionlogid;
	}


	public Member getBuyer() {
		return buyer;
	}

	public void setBuyer(Member buyer) {
		this.buyer = buyer;
	}

	public Member getSellor() {
		return sellor;
	}

	public void setSellor(Member sellor) {
		this.sellor = sellor;
	}

	public BigDecimal getTradeamount() {
		return this.tradeamount;
	}

	public void setTradeamount(BigDecimal tradeamount) {
		this.tradeamount = tradeamount;
	}

	public String getTradesquence() {
		return this.tradesquence;
	}

	public void setTradesquence(String tradesquence) {
		this.tradesquence = tradesquence;
	}

	public Date getTradetime() {
		return this.tradetime;
	}

	public void setTradetime(Date tradetime) {
		this.tradetime = tradetime;
	}


	public TravelTerminal getTravelTerminal() {
		return travelTerminal;
	}

	public void setTravelTerminal(TravelTerminal travelTerminal) {
		this.travelTerminal = travelTerminal;
	}

	public Tunelink getTunelink() {
		return tunelink;
	}

	public void setTunelink(Tunelink tunelink) {
		this.tunelink = tunelink;
	}
	

}