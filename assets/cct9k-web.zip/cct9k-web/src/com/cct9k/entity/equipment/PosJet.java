package com.cct9k.entity.equipment;

import java.io.Serializable;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-11
 * Time: 下午5:13
 */
public class PosJet implements Serializable {

}
