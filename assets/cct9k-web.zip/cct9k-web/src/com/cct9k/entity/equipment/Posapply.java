package com.cct9k.entity.equipment;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the T_POSAPPLY database table.
 * 
 */
@Entity
@Table(name="T_POSAPPLY")
public class Posapply implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	private String applyid;

	private BigDecimal applyno;

	private Timestamp applytime;

	private String contactor;

	private String contactortel;

	private String notes;

	private String objecttypecatid;

	private String objecttypeid;

	private String shopaddress;

	private String shopname;

	private String siteid;

	private String status;
	
	private String memberid;//申请人
	
	//店铺的id
	private String associateobjectid;

	public Posapply() {
	}

	public String getApplyid() {
		return this.applyid;
	}

	public void setApplyid(String applyid) {
		this.applyid = applyid;
	}

	public BigDecimal getApplyno() {
		return this.applyno;
	}

	public void setApplyno(BigDecimal applyno) {
		this.applyno = applyno;
	}

	public Timestamp getApplytime() {
		return this.applytime;
	}

	public void setApplytime(Timestamp applytime) {
		this.applytime = applytime;
	}

	public String getContactor() {
		return this.contactor;
	}

	public void setContactor(String contactor) {
		this.contactor = contactor;
	}

	public String getContactortel() {
		return this.contactortel;
	}

	public void setContactortel(String contactortel) {
		this.contactortel = contactortel;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getObjecttypecatid() {
		return this.objecttypecatid;
	}

	public void setObjecttypecatid(String objecttypecatid) {
		this.objecttypecatid = objecttypecatid;
	}

	public String getObjecttypeid() {
		return this.objecttypeid;
	}

	public void setObjecttypeid(String objecttypeid) {
		this.objecttypeid = objecttypeid;
	}

	public String getShopaddress() {
		return this.shopaddress;
	}

	public void setShopaddress(String shopaddress) {
		this.shopaddress = shopaddress;
	}

	public String getShopname() {
		return this.shopname;
	}

	public void setShopname(String shopname) {
		this.shopname = shopname;
	}

	public String getSiteid() {
		return this.siteid;
	}

	public void setSiteid(String siteid) {
		this.siteid = siteid;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAssociateobjectid() {
		return associateobjectid;
	}

	public void setAssociateobjectid(String associateobjectid) {
		this.associateobjectid = associateobjectid;
	}

	public String getMemberid() {
		return memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	
	

	
}