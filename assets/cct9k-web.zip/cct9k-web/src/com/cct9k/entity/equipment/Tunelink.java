package com.cct9k.entity.equipment;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.entity.finance.Bank;
import com.cct9k.entity.member.Member;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the T_TUNELINK database table.
 * 
 */
@Entity
@Table(name="T_TUNELINK")
public class Tunelink implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String cardid;

	private String accountname;
	@ManyToOne(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY)
	@JoinColumn(name="bankno")
	private Bank bankno;

	private String cardcateid;

	private String cardno;

	private String cardstatus;

	private String cardtype;

	@Temporal(TemporalType.DATE)
	private Date createdate;

	private String enableflag;

	private String loancateid;

	private String loadtype;
    
	
	@ManyToOne(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY)
	@JoinColumn(name="recommandorid")
	private Member sellerid;

	private String siteid;

	private String statuscateid;

	@Temporal(TemporalType.DATE)
	private Date updatedate;

	//bi-directional many-to-one association to TunelinkConsumpLog
	@OneToMany(mappedBy="tunelink")
	private List<TunelinkConsumeLog> tunelinkConsumpLogs;

	//bi-directional many-to-one association to TunelinkOperLog
	@OneToMany(mappedBy="tunelink")
	private List<TunelinkOperLog> tunelinkOperLogs;
	
	private String mobileno;//电话号码
	
	private String identityid;//身份证号
	
	

	public Tunelink() {
	}

	public String getCardid() {
		return this.cardid;
	}

	public void setCardid(String cardid) {
		this.cardid = cardid;
	}

	public String getAccountname() {
		return this.accountname;
	}

	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}


	public Bank getBankno() {
		return bankno;
	}

	public void setBankno(Bank bankno) {
		this.bankno = bankno;
	}

	public void setTunelinkConsumpLogs(List<TunelinkConsumeLog> tunelinkConsumpLogs) {
		this.tunelinkConsumpLogs = tunelinkConsumpLogs;
	}

	public String getCardcateid() {
		return this.cardcateid;
	}

	public void setCardcateid(String cardcateid) {
		this.cardcateid = cardcateid;
	}

	public String getCardno() {
		return this.cardno;
	}

	public void setCardno(String cardno) {
		this.cardno = cardno;
	}

	public String getCardstatus() {
		return this.cardstatus;
	}

	public void setCardstatus(String cardstatus) {
		this.cardstatus = cardstatus;
	}

	public String getCardtype() {
		return this.cardtype;
	}

	public void setCardtype(String cardtype) {
		this.cardtype = cardtype;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getEnableflag() {
		return this.enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public String getLoancateid() {
		return this.loancateid;
	}

	public void setLoancateid(String loancateid) {
		this.loancateid = loancateid;
	}

	public String getLoantype() {
		return this.loadtype;
	}

	public void setLoantype(String loadtype) {
		this.loadtype = loadtype;
	}



	public Member getSellerid() {
		return sellerid;
	}

	public void setSellerid(Member sellerid) {
		this.sellerid = sellerid;
	}

	public String getSiteid() {
		return this.siteid;
	}

	public void setSiteid(String siteid) {
		this.siteid = siteid;
	}

	public String getStatuscateid() {
		return this.statuscateid;
	}

	public void setStatuscateid(String statuscateid) {
		this.statuscateid = statuscateid;
	}

	public Date getUpdatedate() {
		return this.updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public List<TunelinkConsumeLog> getTunelinkConsumpLogs() {
		return this.tunelinkConsumpLogs;
	}

	public void setTTunelinkConsumpLogs(List<TunelinkConsumeLog> tunelinkConsumpLogs) {
		this.tunelinkConsumpLogs = tunelinkConsumpLogs;
	}

	public TunelinkConsumeLog addTunelinkConsumpLog(TunelinkConsumeLog tunelinkConsumpLog) {
		getTunelinkConsumpLogs().add(tunelinkConsumpLog);
		tunelinkConsumpLog.setTunelink(this);

		return tunelinkConsumpLog;
	}

	public TunelinkConsumeLog removeTunelinkConsumpLog(TunelinkConsumeLog tunelinkConsumpLog) {
		getTunelinkConsumpLogs().remove(tunelinkConsumpLog);
		tunelinkConsumpLog.setTunelink(null);

		return tunelinkConsumpLog;
	}

	public List<TunelinkOperLog> getTunelinkOperLogs() {
		return this.tunelinkOperLogs;
	}

	public void setTunelinkOperLogs(List<TunelinkOperLog> tunelinkOperLogs) {
		this.tunelinkOperLogs = tunelinkOperLogs;
	}

	public TunelinkOperLog addTunelinkOperLog(TunelinkOperLog tunelinkOperLog) {
		getTunelinkOperLogs().add(tunelinkOperLog);
		tunelinkOperLog.setTunelink(this);

		return tunelinkOperLog;
	}

	public TunelinkOperLog removeTunelinkOperLog(TunelinkOperLog tunelinkOperLog) {
		getTunelinkOperLogs().remove(tunelinkOperLog);
		tunelinkOperLog.setTunelink(null);

		return tunelinkOperLog;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getIdentityid() {
		return identityid;
	}

	public void setIdentityid(String identityid) {
		this.identityid = identityid;
	}
	
	

	
}