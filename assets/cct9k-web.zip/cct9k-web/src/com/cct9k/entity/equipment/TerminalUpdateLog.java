package com.cct9k.entity.equipment;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "T_TERMINAL_UPDATE_LOG")
public class TerminalUpdateLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String logid;

    @ManyToOne
    @JoinColumn(name = "TERMINALID")
    private TravelTerminal terminal;

    @JoinColumn(name = "OBJECTID")
    private String objectid;

    @JoinColumn(name = "OBJECTTYPEID")
    private String objecttypeid;

    @JoinColumn(name = "OBJECTCATEID")
    private String objectcateid;

    @Temporal(TemporalType.DATE)
    private Date updatetime;

    private String updater;

    public String getLogid() {
        return logid;
    }

    public void setLogid(String logid) {
        this.logid = logid;
    }

    public TravelTerminal getTerminal() {
        return terminal;
    }

    public void setTerminal(TravelTerminal terminal) {
        this.terminal = terminal;
    }

    public String getObjectid() {
        return objectid;
    }

    public void setObjectid(String objectid) {
        this.objectid = objectid;
    }


    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getObjecttypeid() {
        return objecttypeid;
    }

    public void setObjecttypeid(String objecttypeid) {
        this.objecttypeid = objecttypeid;
    }

    public String getObjectcateid() {
        return objectcateid;
    }

    public void setObjectcateid(String objectcateid) {
        this.objectcateid = objectcateid;
    }


    public String getUpdater() {
        return updater;
    }

    public void setUpdater(String updater) {
        this.updater = updater;
    }


}
