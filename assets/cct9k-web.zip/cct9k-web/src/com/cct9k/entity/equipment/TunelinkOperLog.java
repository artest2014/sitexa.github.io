package com.cct9k.entity.equipment;

import java.io.Serializable;
import javax.persistence.*;


import java.util.Date;


/**
 * The persistent class for the T_TUNELINK_OPER_LOG database table.
 * 
 */
@Entity
@Table(name="T_TUNELINK_OPER_LOG")
public class TunelinkOperLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String operlogid;

	@Temporal(TemporalType.DATE)
	private Date opertime;

	private String opertypecateid;

	private String opertypeid;

	//bi-directional many-to-one association to TravelTerminal
	@ManyToOne
	@JoinColumn(name="TERMINALID")
	private TravelTerminal travelTerminal;

	//bi-directional many-to-one association to Tunelink
	@ManyToOne
	@JoinColumn(name="CARDID")
	private Tunelink tunelink;

	public TunelinkOperLog() {
	}

	public String getOperlogid() {
		return this.operlogid;
	}

	public void setOperlogid(String operlogid) {
		this.operlogid = operlogid;
	}

	public Date getOpertime() {
		return this.opertime;
	}

	public void setOpertime(Date opertime) {
		this.opertime = opertime;
	}

	public String getOpertypecateid() {
		return this.opertypecateid;
	}

	public void setOpertypecateid(String opertypecateid) {
		this.opertypecateid = opertypecateid;
	}

	public String getOpertypeid() {
		return this.opertypeid;
	}

	public void setOpertypeid(String opertypeid) {
		this.opertypeid = opertypeid;
	}

	public TravelTerminal getTravelTerminal() {
		return this.travelTerminal;
	}

	public void setTravelTerminal(TravelTerminal travelTerminal) {
		this.travelTerminal = travelTerminal;
	}

	public Tunelink getTunelink() {
		return this.tunelink;
	}

	public void setTunelink(Tunelink tunelink) {
		this.tunelink = tunelink;
	}

}