package com.cct9k.entity.equipment;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the T_TOURISTCARD database table.
 * 
 */
@Entity
@Table(name="T_TOURISTCARD")
public class Touristcard implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String cardid;

	private String accountname;

	private String batch;

	private String carcenterno;

	private String cardcateid;

	private String cardno;

	private String cardstatus;

	private String cardtype;

	@Temporal(TemporalType.DATE)
	private Date createdate;

	private String enableflag;

	private String identityid;

	private String randomno;

	private String recommandorid;

	private String sellerid;

	private String siteid;

	private String statuscateid;

	@Temporal(TemporalType.DATE)
	private Date updatedate;

	public Touristcard() {
	}

	public String getCardid() {
		return this.cardid;
	}

	public void setCardid(String cardid) {
		this.cardid = cardid;
	}

	public String getAccountname() {
		return this.accountname;
	}

	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}

	public String getBatch() {
		return this.batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getCarcenterno() {
		return this.carcenterno;
	}

	public void setCarcenterno(String carcenterno) {
		this.carcenterno = carcenterno;
	}

	public String getCardcateid() {
		return this.cardcateid;
	}

	public void setCardcateid(String cardcateid) {
		this.cardcateid = cardcateid;
	}

	public String getCardno() {
		return this.cardno;
	}

	public void setCardno(String cardno) {
		this.cardno = cardno;
	}

	public String getCardstatus() {
		return this.cardstatus;
	}

	public void setCardstatus(String cardstatus) {
		this.cardstatus = cardstatus;
	}

	public String getCardtype() {
		return this.cardtype;
	}

	public void setCardtype(String cardtype) {
		this.cardtype = cardtype;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getEnableflag() {
		return this.enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public String getIdentityid() {
		return this.identityid;
	}

	public void setIdentityid(String identityid) {
		this.identityid = identityid;
	}

	public String getRandomno() {
		return this.randomno;
	}

	public void setRandomno(String randomno) {
		this.randomno = randomno;
	}

	public String getRecommandorid() {
		return this.recommandorid;
	}

	public void setRecommandorid(String recommandorid) {
		this.recommandorid = recommandorid;
	}

	public String getSellerid() {
		return this.sellerid;
	}

	public void setSellerid(String sellerid) {
		this.sellerid = sellerid;
	}

	public String getSiteid() {
		return this.siteid;
	}

	public void setSiteid(String siteid) {
		this.siteid = siteid;
	}

	public String getStatuscateid() {
		return this.statuscateid;
	}

	public void setStatuscateid(String statuscateid) {
		this.statuscateid = statuscateid;
	}

	public Date getUpdatedate() {
		return this.updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

}