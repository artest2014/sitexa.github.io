package com.cct9k.entity.equipment;

import java.io.Serializable;
import javax.persistence.*;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the T_TRAVEL_TERMINAL database table.
 * 
 */
@Entity
@Table(name="T_TRAVEL_TERMINAL")
public class TravelTerminal implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String terminalid;

//	private String associateobjectid;

	@Temporal(TemporalType.DATE)
	private Date deliverydate;

	private BigDecimal deliveryprice;

	private String devicetype;

	private String enableflag;

	private String installaddress;

	private BigDecimal manufacturecost;

	@Temporal(TemporalType.DATE)
	private Date manufacturedate;

	private String manufacturefactory;

	private String memberid;

	private String objectcateid;

	private String objecttypeid;

	private String siteid;

	private String terminalname;

	private String terminaltype;

	//bi-directional many-to-one association to TunelinkConsumpLog
	@OneToMany(mappedBy="travelTerminal")
	private List<TunelinkConsumeLog> tunelinkConsumpLogs;

	//bi-directional many-to-one association to TunelinkOperLog
	@OneToMany(mappedBy="travelTerminal")
	private List<TunelinkOperLog> tunelinkOperLogs;

	public TravelTerminal() {
	}

	public String getTerminalid() {
		return this.terminalid;
	}

	public void setTerminalid(String terminalid) {
		this.terminalid = terminalid;
	}

	/*public String getAssociateobjectid() {
		return this.associateobjectid;
	}

	public void setAssociateobjectid(String associateobjectid) {
		this.associateobjectid = associateobjectid;
	}
*/
	public Date getDeliverydate() {
		return this.deliverydate;
	}

	public void setDeliverydate(Date deliverydate) {
		this.deliverydate = deliverydate;
	}

	public BigDecimal getDeliveryprice() {
		return this.deliveryprice;
	}

	public void setDeliveryprice(BigDecimal deliveryprice) {
		this.deliveryprice = deliveryprice;
	}

	public String getDevicetype() {
		return this.devicetype;
	}

	public void setDevicetype(String devicetype) {
		this.devicetype = devicetype;
	}

	public String getEnableflag() {
		return this.enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public String getInstalladdress() {
		return this.installaddress;
	}

	public void setInstalladdress(String installaddress) {
		this.installaddress = installaddress;
	}

	public BigDecimal getManufacturecost() {
		return this.manufacturecost;
	}

	public void setManufacturecost(BigDecimal manufacturecost) {
		this.manufacturecost = manufacturecost;
	}

	public Date getManufacturedate() {
		return this.manufacturedate;
	}

	public void setManufacturedate(Date manufacturedate) {
		this.manufacturedate = manufacturedate;
	}

	public String getManufacturefactory() {
		return this.manufacturefactory;
	}

	public void setManufacturefactory(String manufacturefactory) {
		this.manufacturefactory = manufacturefactory;
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public String getObjectcateid() {
		return this.objectcateid;
	}

	public void setObjectcateid(String objectcateid) {
		this.objectcateid = objectcateid;
	}

	public String getObjecttypeid() {
		return this.objecttypeid;
	}

	public void setObjecttypeid(String objecttypeid) {
		this.objecttypeid = objecttypeid;
	}

	public String getSiteid() {
		return this.siteid;
	}

	public void setSiteid(String siteid) {
		this.siteid = siteid;
	}

	public String getTerminalname() {
		return this.terminalname;
	}

	public void setTerminalname(String terminalname) {
		this.terminalname = terminalname;
	}

	public String getTerminaltype() {
		return this.terminaltype;
	}

	public void setTerminaltype(String terminaltype) {
		this.terminaltype = terminaltype;
	}

	public List<TunelinkConsumeLog> getTunelinkConsumpLogs() {
		return tunelinkConsumpLogs;
	}

	public void setTunelinkConsumpLogs(List<TunelinkConsumeLog> tunelinkConsumpLogs) {
		this.tunelinkConsumpLogs = tunelinkConsumpLogs;
	}

	public List<TunelinkOperLog> getTunelinkOperLogs() {
		return tunelinkOperLogs;
	}

	public void setTunelinkOperLogs(List<TunelinkOperLog> tunelinkOperLogs) {
		this.tunelinkOperLogs = tunelinkOperLogs;
	}



}