package com.cct9k.entity.customer;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;



/**
 * 客户产品表
 */
@Entity
@Table(name="T_CUSTOMER_PRODUCT")
public class CustomerProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String productid;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name="customerid")
	private Customer customer;

	private String productdetail;

	private String productname;

	private float productprice;

	private String producttype;
	
	@Transient
	private String title;
	
	private Float specialprice;
	
	private String product;
	
	@Transient
	private Object productObj;

	private String isenable;
	
	public String getIsenable() {
		return isenable;
	}

	public void setIsenable(String isenable) {
		this.isenable = isenable;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public CustomerProduct() {
	}

	public String getProductid() {
		return this.productid;
	}

	public void setProductid(String productid) {
		this.productid = productid;
	}




	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getProductdetail() {
		return this.productdetail;
	}

	public void setProductdetail(String productdetail) {
		this.productdetail = productdetail;
	}

	public String getProductname() {
		return this.productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public float getProductprice() {
		return this.productprice;
	}

	public void setProductprice(float productprice) {
		this.productprice = productprice;
	}

	public String getProducttype() {
		return this.producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	public Float getSpecialprice() {
		return specialprice;
	}

	public void setSpecialprice(Float specialprice) {
		this.specialprice = specialprice;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public Object getProductObj() {
		return productObj;
	}

	public void setProductObj(Object productObj) {
		this.productObj = productObj;
	}
	
	
	
}