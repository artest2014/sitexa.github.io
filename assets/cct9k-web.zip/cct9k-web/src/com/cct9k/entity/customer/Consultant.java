package com.cct9k.entity.customer;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the T_CONSULTANT database table.
 * 客户咨询
 */
@Entity
@Table(name="T_CONSULTANT")
public class Consultant implements Serializable {

	private static final long serialVersionUID = -1832622963488748773L;

	@Id
	private String consultantid;

	@Lob
	@Column(name="\"CONTENTS\"")
	private String contents;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdate;

	private String customer;

	private String memberid;

	private String objectid;

	private String objecttype;

	private String seller;
    
	@Column(name="\"STATUS\"")
	private String status;

	//bi-directional many-to-one association to TConsultant
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="parentid")
	private Consultant consultant;

	//bi-directional many-to-one association to TConsultant
	@OneToMany(mappedBy="consultant")
	private List<Consultant> consultants;

	public Consultant() {
	}

	public String getConsultantid() {
		return this.consultantid;
	}

	public void setConsultantid(String consultantid) {
		this.consultantid = consultantid;
	}

	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getCustomer() {
		return this.customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getMemberid() {
		return this.memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public String getObjectid() {
		return this.objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	public String getObjecttype() {
		return this.objecttype;
	}

	public void setObjecttype(String objecttype) {
		this.objecttype = objecttype;
	}

	public String getSeller() {
		return this.seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

    
	
	public Consultant getConsultant() {
		return consultant;
	}

	public void setConsultant(Consultant consultant) {
		this.consultant = consultant;
	}

	public List<Consultant> getConsultants() {
		return consultants;
	}

	public void setConsultants(List<Consultant> consultants) {
		this.consultants = consultants;
	}

	public Consultant addConsultant(Consultant consultant) {
		getConsultants().add(consultant);
		consultant.setConsultant(this);

		return consultant;
	}

	public Consultant removeConsultant(Consultant consultant) {
		getConsultants().remove(consultant);
		consultant.setConsultant(null);
		return consultant;
	}

}