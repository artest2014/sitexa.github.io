package com.cct9k.entity.customer;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the T_GROUP_PRODUCT database table.
 * 产品分组
 */
@Entity
@Table(name="T_GROUP_PRODUCT")
public class GroupProduct implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9103112453828799702L;

	@Id
	private String gpid;

	private float adultprice;

	private float childrenprice;

	private float discountrate;

	private String productid;

	private String producttype;
	
	@Transient
    private String productname; 
	
	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	//bi-directional many-to-one association to TVipGroup
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="groupid")
	private VipGroup vipgroup;

	public GroupProduct() {
	}

	public String getGpid() {
		return this.gpid;
	}

	public void setGpid(String gpid) {
		this.gpid = gpid;
	}

	public float getAdultprice() {
		return this.adultprice;
	}

	public void setAdultprice(float adultprice) {
		this.adultprice = adultprice;
	}

	public float getChildrenprice() {
		return this.childrenprice;
	}

	public void setChildrenprice(float childrenprice) {
		this.childrenprice = childrenprice;
	}

	public float getDiscountrate() {
		return this.discountrate;
	}

	public void setDiscountrate(float discountrate) {
		this.discountrate = discountrate;
	}

	public String getProductid() {
		return this.productid;
	}

	public void setProductid(String productid) {
		this.productid = productid;
	}

	public String getProducttype() {
		return this.producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	public VipGroup getVipgroup() {
		return vipgroup;
	}

	public void setVipgroup(VipGroup vipgroup) {
		this.vipgroup = vipgroup;
	}


}