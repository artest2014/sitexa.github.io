package com.cct9k.entity.customer;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the T_COMPLAIN database table.
 * 客户投诉
 */
@Entity
@Table(name="T_COMPLAIN")
public class Complain implements Serializable {

	private static final long serialVersionUID = 1358129551358578759L;

	@Id
	private String complainid;

	@Lob
	@Column(name="\"CONTENTS\"")
	private String contents;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdate;

	private String customer;

	private String member;

	private String objectid;

	private String objecttype;

	private String seller;

	private String status;

	//bi-directional many-to-one association to TComplain
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="parentid")
	private Complain complain;

	//bi-directional many-to-one association to TComplain
	@OneToMany(mappedBy="complain")
	private List<Complain> complains;

	public Complain() {
	}

	public String getComplainid() {
		return this.complainid;
	}

	public void setComplainid(String complainid) {
		this.complainid = complainid;
	}

	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getCustomer() {
		return this.customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getMember() {
		return this.member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public String getObjectid() {
		return this.objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	public String getObjecttype() {
		return this.objecttype;
	}

	public void setObjecttype(String objecttype) {
		this.objecttype = objecttype;
	}

	public String getSeller() {
		return this.seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	public Complain getComplain() {
		return complain;
	}

	public void setComplain(Complain complain) {
		this.complain = complain;
	}

	public List<Complain> getComplains() {
		return complains;
	}

	public void setComplains(List<Complain> complains) {
		this.complains = complains;
	}

	public Complain addComplain(Complain complain) {
		getComplains().add(complain);
		complain.setComplain(this);

		return complain;
	}

	public Complain removeComplain(Complain complain) {
		getComplains().remove(complain);
		complain.setComplain(null);

		return complain;
	}

}