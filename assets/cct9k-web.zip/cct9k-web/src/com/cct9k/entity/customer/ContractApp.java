package com.cct9k.entity.customer;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.entity.admin.Department;
import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.member.MemberDept;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the T_CONTRACT_APP database table.
 * 签约申请信息表
 */
@Entity
@Table(name="T_CONTRACT_APP")
public class ContractApp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String contractappid;
    
	//申请描述
	private String appdesc;
    
	//申请状态
	@ManyToOne
	@JoinColumn(name="appstatuscatid")
	private Dictionary appstatuscatid;
    
	//签约客户
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "buymemberid")
	private Member buyer;
    
	//签约客户类型
	@ManyToOne
	@JoinColumn(name="buymembertypecatid")
	private Dictionary buymembertypecatid;
    
	//签约名称
	private String contractname;
    
    //返劵金额
	private BigDecimal couponamount;
    
	//申请日期
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdate;
    
	//创建人
	@OneToOne
	@JoinColumn(name="creator")
	private Member creator;
    
	//挂账额度
	private BigDecimal creditlimit;
    
	//是否有效标示
	private String enableflag;
    
	//申请分组
	//bi-directional many-to-one association to TVipGroup
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="groupid")
	private VipGroup vipgroup;
    
	//是否返劵
	private String ifreturncashcoupon;
    
	//签约卖方（取总经理的账号）
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "salememberid")
    private Member seller;
    
	//发起签约机构
	@OneToOne
	@JoinColumn(name = "signapporg")
    private Department signapporg;

    //发起签约机构类型
    @ManyToOne
    @JoinColumn(name = "signcontracttype")
    private Dictionary signcontracttype;

    //扫描件路径
    private String signscancopyurl;

    //返券阀值
    private BigDecimal threshold;

    //审核时间
    @Temporal(TemporalType.DATE)
    private Date updatedate;

    //修改人
    @OneToOne
	@JoinColumn(name="updater")
    private Member updater;

	public ContractApp() {
	}

	public String getContractappid() {
		return this.contractappid;
	}

	public void setContractappid(String contractappid) {
		this.contractappid = contractappid;
	}

	public String getAppdesc() {
		return this.appdesc;
	}

	public void setAppdesc(String appdesc) {
		this.appdesc = appdesc;
	}

	public Dictionary getAppstatuscatid() {
		return appstatuscatid;
	}

	public void setAppstatuscatid(Dictionary appstatuscatid) {
		this.appstatuscatid = appstatuscatid;
	}

	public String getContractname() {
		return this.contractname;
	}

	public void setContractname(String contractname) {
		this.contractname = contractname;
	}

	public BigDecimal getCouponamount() {
		return this.couponamount;
	}

	public void setCouponamount(BigDecimal couponamount) {
		this.couponamount = couponamount;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}


	public Member getCreator() {
		return creator;
	}

	public BigDecimal getCreditlimit() {
		return this.creditlimit;
	}

	public void setCreditlimit(BigDecimal creditlimit) {
		this.creditlimit = creditlimit;
	}

	public String getEnableflag() {
		return this.enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	public VipGroup getVipgroup() {
		return vipgroup;
	}

	public void setVipgroup(VipGroup vipgroup) {
		this.vipgroup = vipgroup;
	}

	public String getIfreturncashcoupon() {
		return this.ifreturncashcoupon;
	}

	public void setIfreturncashcoupon(String ifreturncashcoupon) {
		this.ifreturncashcoupon = ifreturncashcoupon;
	}

	public Member getBuyer() {
		return buyer;
	}

	public void setBuyer(Member buyer) {
		this.buyer = buyer;
	}


	public Department getSignapporg() {
		return signapporg;
	}

	public void setSignapporg(Department signapporg) {
		this.signapporg = signapporg;
	}

	public Member getSeller() {
        return seller;
    }

    public void setSeller(Member seller) {
        this.seller = seller;
    }

	public Dictionary getBuymembertypecatid() {
		return buymembertypecatid;
	}

	public void setBuymembertypecatid(Dictionary buymembertypecatid) {
		this.buymembertypecatid = buymembertypecatid;
	}

	public Dictionary getSigncontracttype() {
		return signcontracttype;
	}

	public void setSigncontracttype(Dictionary signcontracttype) {
		this.signcontracttype = signcontracttype;
	}

	public String getSignscancopyurl() {
		return this.signscancopyurl;
	}

	public void setSignscancopyurl(String signscancopyurl) {
		this.signscancopyurl = signscancopyurl;
	}

	public BigDecimal getThreshold() {
		return this.threshold;
	}

	public void setThreshold(BigDecimal threshold) {
		this.threshold = threshold;
	}

	public Date getUpdatedate() {
		return this.updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public Member getUpdater() {
		return updater;
	}

	public void setUpdater(Member updater) {
		this.updater = updater;
	}

	public void setCreator(Member creator) {
		this.creator = creator;
	}
}