package com.cct9k.entity.customer;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;

import java.util.Date;


/**
 * The persistent class for the T_GROUP_MEMBER database table.
 * 客户分组成员
 */
@Entity
@Table(name="T_GROUP_MEMBER")
public class GroupMember implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3655312996876419991L;
	public static final String GROUP_MEMBER_EDIT = "32";
	public static final String GROUP_MEMBER_AUDIT = "33";
	public static final String GROUP_MEMBER_AGREE = "35";
	public static final String GROUP_MEMBER_REJECT = "34";

	@Id
	private String gmid;

	private String description;
	
	@ManyToOne
	@JoinColumn(name="quotatype")
	private Dictionary quotatype;
	
	private float quota;
	
	private float quotaused;
	
	private Float freezeamount;//冻结金额

	public Dictionary getQuotatype() {
		return quotatype;
	}

	public void setQuotatype(Dictionary quotatype) {
		this.quotatype = quotatype;
	}

	public float getQuota() {
		return quota;
	}

	public void setQuota(float quota) {
		this.quota = quota;
	}

	public float getQuotaused() {
		return quotaused;
	}

	public void setQuotaused(float quotaused) {
		this.quotaused = quotaused;
	}

	@Temporal(TemporalType.TIMESTAMP)
	private Date joindate;

	//private String memberid;
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="status")
	private Dictionary status;

	//bi-directional many-to-one association to TVipGroup
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="groupid")
	private VipGroup vipgroup;
	
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "memberid")
	private Member member;

	public GroupMember() {
	}
	
	@Transient
	private String contractname;

	public String getContractname() {
		return contractname;
	}

	public void setContractname(String contractname) {
		this.contractname = contractname;
	}

	public String getGmid() {
		return this.gmid;
	}

	public void setGmid(String gmid) {
		this.gmid = gmid;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getJoindate() {
		return this.joindate;
	}

	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}

	
	public VipGroup getVipgroup() {
		return vipgroup;
	}

	public void setVipgroup(VipGroup vipgroup) {
		this.vipgroup = vipgroup;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}
	
	public Dictionary getStatus() {
		return status;
	}

	public void setStatus(Dictionary status) {
		this.status = status;
	}

	public Float getFreezeamount() {
		return freezeamount;
	}

	public void setFreezeamount(Float freezeamount) {
		this.freezeamount = freezeamount;
	}
	
	

}