package com.cct9k.entity.customer;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;

import java.util.Date;
import java.util.List;

/**
 * The persistent class for the T_CONTRACT database table.
 * 合同
 */
@Entity
@Table(name = "T_CONTRACT")
public class Contract implements Serializable {

	/**
	 * 
	 */
    public static final String CONTRACT_STATUS_1 = "1";
	public static final String CONTRACT_STATUS_2 = "2";
	public static final String CONTRACT_STATUS_3 = "3";
	public static final String CONTRACT_STATUS_4 = "4";
	public static final String CONTRACT_STATUS_5 = "5";
	
	private static final long serialVersionUID = -6992524698371572271L;

	@Id
	private String contractid;

	private String attached;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "buyer")
	private Member buyer;

	@Lob
	@Column(name = "\"CONTENTS\"")
	private String contents;

	private String contractname;

	@Temporal(TemporalType.DATE)
	private Date enddate;

	@Column(name = "\"QUOTA\"")
	private float quota;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "seller")
	private Member seller;

	@Temporal(TemporalType.DATE)
	private Date signdate;

	@Temporal(TemporalType.DATE)
	private Date startdate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status")
	private Dictionary status;

	// bi-directional many-to-one association to TContractItem
	@OneToMany(mappedBy = "contract")
	private List<ContractItem> contractItems;

	public Contract() {
	}

	public String getContractid() {
		return this.contractid;
	}

	public void setContractid(String contractid) {
		this.contractid = contractid;
	}

	public String getAttached() {
		return this.attached;
	}

	public void setAttached(String attached) {
		this.attached = attached;
	}

	public String getContents() {
		return this.contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getContractname() {
		return this.contractname;
	}

	public Member getBuyer() {
		return buyer;
	}

	public Member getSeller() {
		return seller;
	}

	public void setBuyer(Member buyer) {
		this.buyer = buyer;
	}

	public void setSeller(Member seller) {
		this.seller = seller;
	}

	public void setContractname(String contractname) {
		this.contractname = contractname;
	}

	public Date getEnddate() {
		return this.enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public float getQuota() {
		return this.quota;
	}

	public void setQuota(float quota) {
		this.quota = quota;
	}

	public Date getSigndate() {
		return this.signdate;
	}

	public void setSigndate(Date signdate) {
		this.signdate = signdate;
	}

	public Date getStartdate() {
		return this.startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Dictionary getStatus() {
		return this.status;
	}

	public void setStatus(Dictionary status) {
		this.status = status;
	}

	public List<ContractItem> getContractItems() {
		return this.contractItems;
	}

	public void setContractItems(List<ContractItem> contractItems) {
		this.contractItems = contractItems;
	}

	public ContractItem addTContractItem(ContractItem contractItem) {
		getContractItems().add(contractItem);
		contractItem.setContract(this);

		return contractItem;
	}

	public ContractItem removeTContractItem(ContractItem contractItem) {
		getContractItems().remove(contractItem);
		contractItem.setContract(null);
		return contractItem;
	}

}