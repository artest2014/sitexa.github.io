package com.cct9k.entity.customer;

import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;

import javax.persistence.*;

import java.io.Serializable;
import java.util.List;


/**
 * 客户关系维护表
 */
@Entity
@Table(name = "T_CUSTOMER")
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String customerid;

    private String customername;
    
   // private String telephonenumber;

//    public String getTelephonenumber() {
//		return telephonenumber;
//	}
//
//	public void setTelephonenumber(String telephonenumber) {
//		this.telephonenumber = telephonenumber;
//	}
	@ManyToOne
    @JoinColumn(name = "customertype")
    private Dictionary customertype;

    private String email;

    private String gender;

    private String identityno;

    @ManyToOne
    @JoinColumn(name = "memberid")
    private Member member;

  
    private String mobile;
    		
    @ManyToOne
    @JoinColumn(name = "IDENTITYTYPE")
    private Dictionary identityType; 

    @ManyToOne
    @JoinColumn(name = "ownerid")
    private Member owner;
    
    public String getGroupname() {
		return groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public float getQuota() {
		return quota;
	}

	public void setQuota(float quota) {
		this.quota = quota;
	}

	public float getQuotaused() {
		return quotaused;
	}

	public void setQuotaused(float quotaused) {
		this.quotaused = quotaused;
	}
	@OneToMany(mappedBy = "customer",fetch=FetchType.LAZY)
    private List<CustomerProduct> customerProducts;
    
	private String objectId;
	
	@Transient
	private String title;
	
	@Transient
	private String groupname;
	
	@Transient
	private float quota;
	
	
	@Transient
	private float quotaused;
	
	@Transient
	private String shopName;
	
	private String isenable;
	

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getIsenable() {
		return isenable;
	}

	public void setIsenable(String isenable) {
		this.isenable = isenable;
	}
	@Transient
    private Object obj;
    
    public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Customer(String customerid) {
		this.customerid = customerid;
    }

    public Customer() {
    }

    public String getCustomerid() {
        return this.customerid;
    }

    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }

    public String getCustomername() {
        return this.customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public Dictionary getCustomertype() {
        return customertype;
    }

    public void setCustomertype(Dictionary customertype) {
        this.customertype = customertype;
    }

    public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentityno() {
        return this.identityno;
    }

    public void setIdentityno(String identityno) {
        this.identityno = identityno;
    }

    public String getMobile() {
        return this.mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public Member getOwner() {
        return owner;
    }

    public void setOwner(Member owner) {
        this.owner = owner;
    }

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	
	public List<CustomerProduct> getCustomerProducts() {
		return customerProducts;
	}

	public void setCustomerProducts(List<CustomerProduct> customerProducts) {
		this.customerProducts = customerProducts;
	}

	public Dictionary getIdentityType() {
		return identityType;
	}

	public void setIdentityType(Dictionary identityType) {
		this.identityType = identityType;
	}

	public Object getObj() 
	{
		return obj;
	}

	public void setObj(Object obj) 
	{
		this.obj = obj;
	}
	
	
    
}