package com.cct9k.entity.customer;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the T_CONTRACT_ITEM database table.
 * 合同项目
 */
@Entity
@Table(name="T_CONTRACT_ITEM")
public class ContractItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5899946148505961848L;

	@Id
	private String itemid;

	private float adultprice;

	private float childrenprice;

	private float discountrate;

	private String productid;

	private String producttype;

	private String remark;

	//bi-directional many-to-one association to TContract
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="contractid")
	private Contract contract;

	public ContractItem() {
	}
	
	@Transient
	private String routename;

	public String getRoutename() {
		return routename;
	}

	public void setRoutename(String routename) {
		this.routename = routename;
	}

	public String getItemid() {
		return this.itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}

	public float getAdultprice() {
		return this.adultprice;
	}

	public void setAdultprice(float adultprice) {
		this.adultprice = adultprice;
	}

	public float getChildrenprice() {
		return this.childrenprice;
	}

	public void setChildrenprice(float childrenprice) {
		this.childrenprice = childrenprice;
	}

	public float getDiscountrate() {
		return this.discountrate;
	}

	public void setDiscountrate(float discountrate) {
		this.discountrate = discountrate;
	}

	public String getProductid() {
		return this.productid;
	}

	public void setProductid(String productid) {
		this.productid = productid;
	}

	public String getProducttype() {
		return this.producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Contract getContract() {
		return contract;
	}

	public void setContract(Contract contract) {
		this.contract = contract;
	}

	

}