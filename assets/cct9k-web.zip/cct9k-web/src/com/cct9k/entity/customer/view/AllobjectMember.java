package com.cct9k.entity.customer.view;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the V_ALLOBJECT_MEMBER database table.
 * 
 */
@Entity
@Table(name="V_ALLOBJECT_MEMBER")
public class AllobjectMember implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	private String memberid;

	private String objectid;

	@Column(name="objecttype", columnDefinition="char(32)")
	private String objecttype;

	public String getMemberid() {
		return memberid;
	}

	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}

	public String getObjectid() {
		return objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	public String getObjecttype() {
		return objecttype;
	}

	public void setObjecttype(String objecttype) {
		this.objecttype = objecttype;
	}



}