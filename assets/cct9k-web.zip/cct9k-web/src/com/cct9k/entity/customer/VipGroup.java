package com.cct9k.entity.customer;

import java.io.Serializable;
import javax.persistence.*;

import com.cct9k.entity.admin.Dictionary;

import java.util.List;


/**
 * The persistent class for the T_VIP_GROUP database table.
 * 客户分组
 */
@Entity
@Table(name="T_VIP_GROUP")
public class VipGroup implements Serializable {
	private static final long serialVersionUID = -5077283724552613051L;

	@Id
	private String groupid;

	private String groupname;

	private float rate;

	private String remark;

	private String reseller;
	
	private String enableflag;
    
	public String getEnableflag() {
		return enableflag;
	}

	public void setEnableflag(String enableflag) {
		this.enableflag = enableflag;
	}

	//发起签约机构类型
	@ManyToOne
	@JoinColumn(name="grouptype")
	private Dictionary grouptype;
		
	public Dictionary getGrouptype() {
		return grouptype;
	}

	public void setGrouptype(Dictionary grouptype) {
		this.grouptype = grouptype;
	}

	//bi-directional many-to-one association to TGroupMember
	@OneToMany(cascade = CascadeType.REMOVE,mappedBy="vipgroup")
	private List<GroupMember> groupMembers;
	
	//bi-directional many-to-one association to TContractApp
	@OneToMany(cascade = CascadeType.REMOVE,mappedBy="vipgroup")
	private List<ContractApp> ContractApp;

	public List<ContractApp> getContractApp() {
		return ContractApp;
	}

	public void setContractApp(List<ContractApp> contractApp) {
		ContractApp = contractApp;
	}

	//bi-directional many-to-one association to TGroupProduct
	@OneToMany(cascade = CascadeType.REMOVE,mappedBy="vipgroup")
	private List<GroupProduct> roupProducts;

	public VipGroup() {
	}

	public String getGroupid() {
		return this.groupid;
	}

	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}

	public String getGroupname() {
		return this.groupname;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public float getRate() {
		return this.rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getReseller() {
		return this.reseller;
	}

	public void setReseller(String reseller) {
		this.reseller = reseller;
	}

	public List<GroupMember> getGroupMembers() {
		return groupMembers;
	}

	public void setGroupMembers(List<GroupMember> groupMembers) {
		this.groupMembers = groupMembers;
	}

	public List<GroupProduct> getRoupProducts() {
		return roupProducts;
	}

	public void setRoupProducts(List<GroupProduct> roupProducts) {
		this.roupProducts = roupProducts;
	}
	

}