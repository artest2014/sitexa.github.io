/**
 * <p>Class Name: ReComplain.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: yangkun</p>
 * <p>Date: 2013-7-27</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.entity.customer;

import java.util.Date;

/**
 * @author yangkun
 *
 */
public class ReComplain {
	private String complainid;

	private String contents;

	private String createdate;

	private String customer;

	private String member;

	private String objectid;

	private String objecttype;

	private String seller;
    
	private String status;
	
	private String customerName;
	
	private String replyName;
	
	private String sellerName;
	
	private String picStr;

	/**
	 * @return the complainid
	 */
	public String getComplainid() {
		return complainid;
	}

	/**
	 * @param complainid the complainid to set
	 */
	public void setComplainid(String complainid) {
		this.complainid = complainid;
	}

	/**
	 * @return the contents
	 */
	public String getContents() {
		return contents;
	}

	/**
	 * @param contents the contents to set
	 */
	public void setContents(String contents) {
		this.contents = contents;
	}

	/**
	 * @return the createdate
	 */
	public String getCreatedate() {
		return createdate;
	}

	/**
	 * @param createdate the createdate to set
	 */
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}

	/**
	 * @return the customer
	 */
	public String getCustomer() {
		return customer;
	}

	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(String customer) {
		this.customer = customer;
	}

	/**
	 * @return the member
	 */
	public String getMember() {
		return member;
	}

	/**
	 * @param member the member to set
	 */
	public void setMember(String member) {
		this.member = member;
	}

	/**
	 * @return the objectid
	 */
	public String getObjectid() {
		return objectid;
	}

	/**
	 * @param objectid the objectid to set
	 */
	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	/**
	 * @return the objecttype
	 */
	public String getObjecttype() {
		return objecttype;
	}

	/**
	 * @param objecttype the objecttype to set
	 */
	public void setObjecttype(String objecttype) {
		this.objecttype = objecttype;
	}

	/**
	 * @return the seller
	 */
	public String getSeller() {
		return seller;
	}

	/**
	 * @param seller the seller to set
	 */
	public void setSeller(String seller) {
		this.seller = seller;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the replyName
	 */
	public String getReplyName() {
		return replyName;
	}

	/**
	 * @param replyName the replyName to set
	 */
	public void setReplyName(String replyName) {
		this.replyName = replyName;
	}

	/**
	 * @return the sellerName
	 */
	public String getSellerName() {
		return sellerName;
	}

	/**
	 * @param sellerName the sellerName to set
	 */
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	/**
	 * @return the picStr
	 */
	public String getPicStr() {
		return picStr;
	}

	/**
	 * @param picStr the picStr to set
	 */
	public void setPicStr(String picStr) {
		this.picStr = picStr;
	}
	
	
	
}
