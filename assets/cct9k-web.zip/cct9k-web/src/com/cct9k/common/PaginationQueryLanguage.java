/**
 * Project :    cct9k-web
 * File name:	com.cct9k.common.PaginationSelectQueryLanguage.java
 * Description: 
 * Copyright:   Copyright 湖南三英特旅游智能技术有限公司 cct9000.com (c) 2013 All Rights Reserved
 * Company:     湖南三英特旅游智能技术有限公司
 * @author:     yanwei_clear
 * @version:    1.0
 * Create at:   2013年11月20日 上午8:29:18
 *
 * Modification History:
 * Date			Author		Version		Description
 * ------------------------------------------------------------------
 * 2013年11月20日   yanwei_clear	1.0		    1.0 Version
 */
package com.cct9k.common;

/**
 * @ClassName: PaginationSelectQueryLanguage
 * @Description: 分页查询SQL语句定义接口
 * @author yanwei_clear
 * @date 2013年11月20日 上午8:29:19
 *
 */
public interface PaginationQueryLanguage {


    /**
     * 
    * @Title: getNativeQueryLanguage
    * @Description: 获取本地查询语言
    * @param sql sql
    * @param pagination 分页对象
    * @return     
    * @throws
     */
    StringBuffer getNativeQueryLanguage(StringBuffer sql, Pagination pagination);
}
