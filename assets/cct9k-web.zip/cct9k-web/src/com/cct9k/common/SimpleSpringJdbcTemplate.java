/**
 * Project :    cct9k-web
 * File name:	com.cct9k.common.SimpleSpringJdbcTemplate.java
 * Description: 
 * Copyright:   Copyright 湖南三英特旅游智能技术有限公司 cct9000.com (c) 2013 All Rights Reserved
 * Company:     湖南三英特旅游智能技术有限公司
 * @author:     yanwei_clear
 * @version:    1.0
 * Create at:   2013年11月20日 上午9:07:06
 *
 * Modification History:
 * Date			Author		Version		Description
 * ------------------------------------------------------------------
 * 2013年11月20日   yanwei_clear	1.0		    1.0 Version
 */
package com.cct9k.common;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.Assert;

import com.cct9k.util.common.StringUtil;

/**
 * @ClassName: SimpleSpringJdbcTemplate
 * @Description: TODO
 * @author yanwei_clear
 * @date 2013年11月20日 上午9:07:06
 * 
 */
public class SimpleSpringJdbcTemplate extends SimpleSpringJdbcTemplateAbstract implements ExpandSimpleJdbcTemplate {

    private PaginationQueryLanguage paginationQueryLanguage;

    /**
     * <p>
     * Title: 构造SimpleSpringJdbcTemplate
     * </p>
     * <p>
     * Description: 如果不在外部注入封装该jdbc操作的模板所需要的资源的话就需要在这个构造方法中设置数据源
     * </p>
     * 
     * @param dataSource
     */
    public SimpleSpringJdbcTemplate(DataSource dataSource) {
        Assert.notNull(dataSource, "数据源为空");
        this.dataSource = dataSource;
        jdbcTemplate = new JdbcTemplate(dataSource);
        namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    /*
     * 
     * <p>Title: queryForPagination</p> <p>Description: </p>
     * 
     * @param sql
     * 
     * @param pagination
     * 
     * @param beanProperty
     * 
     * @param paramMap
     * 
     * @return
     * 
     * @see com.cct9k.common.ExpandSimpleJdbcTemplate#queryForPagination(java.lang .StringBuffer,
     * com.cct9k.common.Pagination, java.lang.Class, java.util.Map)
     */
    @Override
    public Pagination queryForPagination(StringBuffer sql, Pagination pagination, Class<?> beanProperty, Map<String, Object> paramMap) {
        StringBuffer nativeSql = settingPagination(sql, pagination, paramMap, null);
        // 获取结果集
        List resultList = this.queryForList(nativeSql, paramMap, beanProperty);
        pagination.setList(resultList);
        return pagination;
    }

    /*
     * 
     * <p>Title: queryForPaginationMap</p> <p>Description: </p>
     * 
     * @param sql
     * 
     * @param pagination
     * 
     * @param paramMap
     * 
     * @return
     * 
     * @see com.cct9k.common.ExpandSimpleJdbcTemplate#queryForPaginationMap(java. lang.StringBuffer,
     * com.cct9k.common.Pagination, java.util.Map)
     */
    @Override
    public Pagination queryForPaginationMap(StringBuffer sql, Pagination pagination, Map<String, Object> paramMap) {
        StringBuffer nativeSql = settingPagination(sql, pagination, paramMap, null);
        // 获取结果集
        List resultList = this.queryForMap(nativeSql, paramMap);
        pagination.setList(resultList);
        return pagination;
    }
    /**
     * 添加分页小计和总计支持
     */
    public Pagination queryForPaginationMap(StringBuffer sql, Pagination pagination, Map<String, Object> paramMap,Map<String, Object> sumParamMap,boolean isMinSum,boolean isTotalSum) {
        StringBuffer nativeSql = settingPagination(sql, pagination, paramMap, null);
        // 获取结果集
        List resultList = this.queryForMap(nativeSql, paramMap);
        pagination.setList(resultList);
        if(isMinSum&&sumParamMap!=null){
	        StringBuffer sumSql=buildSumSql(nativeSql,sumParamMap);
	        Map minSumMap=  this.namedParameterJdbcTemplate.queryForMap(sumSql.toString(), paramMap);
	        pagination.setMinSumMap(minSumMap);
        }
        if(isMinSum&&sumParamMap!=null){
	        StringBuffer sumSql=buildSumSql(sql,sumParamMap);
	        Map totalSumMap=  this.namedParameterJdbcTemplate.queryForMap(sumSql.toString(), paramMap);
	        pagination.setTotolalSumMap(totalSumMap);
        }
        return pagination;
    }

    /*
     * 
     * <p>Title: queryForPagination</p> <p>Description: </p>
     * 
     * @param sql
     * 
     * @param recordCount
     * 
     * @param pagination
     * 
     * @param beanProperty
     * 
     * @param paramMap
     * 
     * @return
     * 
     * @see com.cct9k.common.ExpandSimpleJdbcTemplate#queryForPagination(java.lang .StringBuffer, java.lang.Long,
     * com.cct9k.common.Pagination, java.lang.Class, java.util.Map)
     */
    @Override
    public Pagination queryForPagination(StringBuffer sql, Long recordCount, Pagination pagination, Class<?> beanProperty, Map<String, Object> paramMap) {
        StringBuffer nativeSql = settingPagination(sql, pagination, paramMap, recordCount);
        // 获取结果集
        List resultList = this.queryForList(nativeSql, paramMap, beanProperty);
        pagination.setList(resultList);
        return pagination;
    }
    public Pagination queryForPagination(StringBuffer sql, Long recordCount, Pagination pagination, Class<?> beanProperty, Map<String, Object> paramMap,Map<String, Object> sumParamMap,boolean isMinSum,boolean isTotalSum) {
        StringBuffer nativeSql = settingPagination(sql, pagination, paramMap, recordCount);
        // 获取结果集
        List resultList = this.queryForList(nativeSql, paramMap, beanProperty);
        pagination.setList(resultList);

        if(isMinSum&&sumParamMap.size()>0){
	        StringBuffer sumSql=buildSumSql(nativeSql,sumParamMap);
	        Map minSumMap=  this.namedParameterJdbcTemplate.queryForMap(sumSql.toString(), paramMap);
	        pagination.setMinSumMap(minSumMap);
        }
        if(isMinSum&&sumParamMap.size()>0){
	        StringBuffer sumSql=buildSumSql(sql,sumParamMap);
	        Map totalSumMap=  this.namedParameterJdbcTemplate.queryForMap(sumSql.toString(), paramMap);
	        pagination.setTotolalSumMap(totalSumMap);
        }
        return pagination;
    }
    private StringBuffer buildSumSql(StringBuffer nativeSql,Map<String, Object> sumParamMap){
    	StringBuffer sb = new StringBuffer("select ");
    	for (Map.Entry<String, Object> entry : sumParamMap.entrySet()) {
    		sb.append(entry.getValue()).append(" as ").append(entry.getKey()).append(",");
		}
    	String s=StringUtil.replaceLastString(sb.toString(),"," );
    	return 	new StringBuffer(s).append(" from (").append(nativeSql).append(")");
    }
    /**
     * @Title: settingPagination
     * @Description: 对Pagination对象进行处理
     * @param sql
     * @param pagination
     * @param paramMap
     * @return
     * @throws
     */
    private StringBuffer settingPagination(StringBuffer sql, Pagination pagination, Map<String, Object> paramMap, Long recordCount) {
        // 获得总记录数
        if (null != recordCount && recordCount.compareTo(0L) == 1) {
            pagination.setTotalCount(recordCount.intValue());
        } else {
            Long count = this.getRecordCount(new StringBuffer(sql), paramMap);
            pagination.setTotalCount(count.intValue());
        }
        // 获取本地sql
        StringBuffer nativeSql = paginationQueryLanguage.getNativeQueryLanguage(sql, pagination);
        return nativeSql;
    }

    public PaginationQueryLanguage getPaginationQueryLanguage() {
        return paginationQueryLanguage;
    }

    public void setPaginationQueryLanguage(PaginationQueryLanguage paginationQueryLanguage) {
        this.paginationQueryLanguage = paginationQueryLanguage;
    }

}
