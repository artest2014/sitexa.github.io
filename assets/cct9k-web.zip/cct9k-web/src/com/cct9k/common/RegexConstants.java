package com.cct9k.common;

public class RegexConstants {
    public static final String regEx_trn = "[\\t\\r\\n]";
    public static final String regEx_space = "(&nbsp;)*";
    public static final String regEx_link = "<([A|a][ ]*href)[^>]*>|</([A|a])[^>]*>";
    public static final String regEx_html = "<(([A-Z][A-Z0-9]*)|([a-z][a-z0-9]*))\\b[^>]*>|</(([A-Z][A-Z0-9]*)|([a-z][a-z0-9]*))>";
    public static final String regEx_subject = regEx_html + "|" + regEx_trn + "|" + regEx_space;
    public static final String regEx_content = regEx_link + "|" + regEx_trn + "|" + regEx_space;

}
