/**
 * Project :    cct9k-web
 * File name:	com.cct9k.common.OracleNativePaginationQuery.java
 * Description: 
 * Copyright:   Copyright 湖南三英特旅游智能技术有限公司 cct9000.com (c) 2013 All Rights Reserved
 * Company:     湖南三英特旅游智能技术有限公司
 * @author:     yanwei_clear
 * @version:    1.0
 * Create at:   2013年11月20日 上午8:56:44
 *
 * Modification History:
 * Date			Author		Version		Description
 * ------------------------------------------------------------------
 * 2013年11月20日   yanwei_clear	1.0		    1.0 Version
 */
package com.cct9k.common;

/**
 * @ClassName: OracleNativePaginationQuery
 * @Description: 实现Oracle本地分页查询的类
 * @author yanwei_clear
 * @date 2013年11月20日 上午8:56:44
 * 
 */
public class OracleNativePaginationQuery implements PaginationQueryLanguage {

    /*
     * 
    * <p>Title: getNativeQueryLanguage</p>
    * <p>Description: </p>
    * @param sql
    * @param pagination
    * @return
    * @see com.cct9k.common.PaginationSelectQueryLanguage#getNativeQueryLanguage(java.lang.StringBuffer, com.cct9k.common.Pagination)
     */
    @Override
    public StringBuffer getNativeQueryLanguage(StringBuffer sql, Pagination pagination) {
        StringBuffer nativeSql = new StringBuffer();
        // 开始条数
        int fristResult = Math.abs(pagination.getPageSize() * (pagination.getPageNo() - 1));
        // 结束条数
        int lastResult = pagination.getPageNo() * pagination.getPageSize();
        // 拼接查询语句
        nativeSql.append(" select * from ( select row_.*, rownum rownum_ from ( ");
        nativeSql.append(sql);
        nativeSql.append(" ) row_  where rownum <=  ");
        nativeSql.append(lastResult);
        nativeSql.append(" ) where rownum_ >  ");
        nativeSql.append(fristResult);
        return nativeSql;
    }

}
