package com.cct9k.dao.statistical.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.statistical.StatisticalDao;
import com.cct9k.entity.reseller.RoutePricePackage;
import com.cct9k.entity.reseller.RouteStop;


@Repository
public class StatisticalDaoImpl extends BaseDaoImpl<Object, String> implements StatisticalDao {

    /**
     * 查询酒店销售量
     * */
	@Override
	public List<Map<String, Object>> findHotelSaleStatistical(String memberId,Date startDate,Date  endDate){
		
		StringBuffer sql = new StringBuffer(" SELECT '13090' AS TYPE,  ODH.CHECKIN AS STARTDATE,MAX(ODH.CHECKOUT-1) AS ENDDATE,SUM(ODH.QUANTITY) AS QUANTITY  FROM T_GENERIC_ORDER GO ");
		sql.append(" INNER JOIN T_ORDER_DETAIL_HOTEL ODH ON GO.ORDERID = ODH.ORDERID ");    
		sql.append("  WHERE GO.SELLER =:MEMBERID AND GO.PAYMENTSTATUS = '1' ");
		sql.append(" AND ODH.CHECKIN <=:ENDDATE AND ODH.CHECKIN >=:STARTDATE   GROUP BY CHECKIN");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}
	
	
	/**
	 * 查询娱乐销售量 
	 **/
	@Override
	public List<Map<String, Object>> findShowSaleStatistical(String memberId,Date startDate,Date  endDate){
		
		StringBuffer sql = new StringBuffer("  SELECT '14070' AS TYPE,  ODS.STARTDATE AS STARTDATE,ODS.STARTDATE AS ENDDATE,SUM(ODS.QUANTITY) AS QUANTITY FROM  T_GENERIC_ORDER GO ");
		sql.append("  INNER JOIN  T_ORDER_DETAIL_SHOW ODS ON GO.ORDERID = ODS.ORDERID  ");
		sql.append("   WHERE GO.SELLER =:MEMBERID  AND GO.PAYMENTSTATUS = '1' ");
		sql.append(" AND ODS.STARTDATE <=:ENDDATE AND ODS.STARTDATE >=:STARTDATE  GROUP BY STARTDATE");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}
	
	
	/**
	 * 查询景点门票销售量 
	 **/
	@Override
	public List<Map<String, Object>> findGateSaleStatistical(String memberId,Date startDate,Date  endDate){
		
		StringBuffer sql = new StringBuffer("  SELECT '13489' AS TYPE,   ODG.STARTDATE AS STARTDATE,ODG.STARTDATE AS ENDDATE,SUM(ODG.QUANTITY) AS QUANTITY FROM T_GENERIC_ORDER GO");
		sql.append("  INNER JOIN T_ORDER_DETAIL_GATE ODG ON  GO.ORDERID = ODG.ORDERID  ");
		sql.append("   WHERE GO.SELLER =:MEMBERID  AND GO.PAYMENTSTATUS = '1' ");
		sql.append(" AND ODG.STARTDATE <=:ENDDATE AND ODG.STARTDATE >=:STARTDATE  GROUP BY STARTDATE");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}
	
	
	/**
	 * 查询旅运销售量 
	 **/
	@Override
	public List<Map<String, Object>> findTransportSaleStatistical(String memberId,Date startDate,Date  endDate){
		
		StringBuffer sql = new StringBuffer("  SELECT '14149' AS TYPE, ODT.STARTDATE AS STARTDATE,MAX(ODT.ENDDATE) AS ENDDATE,SUM(ODT.QUANTITY) AS QUANTITY FROM T_GENERIC_ORDER GO");
		sql.append("  INNER JOIN T_ORDER_DETAIL_TRANSPORT ODT ON  GO.ORDERID = ODT.ORDERID  ");
		sql.append("   WHERE GO.SELLER =:MEMBERID  AND GO.PAYMENTSTATUS = '1' ");
		sql.append(" AND ODT.STARTDATE <=:ENDDATE AND ODT.STARTDATE >=:STARTDATE  GROUP BY STARTDATE");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}
	
	/**
	 * 查询餐饮销售量 
	 **/
	@Override
	public List<Map<String, Object>> findRestaurantSaleStatistical(String memberId,Date startDate,Date  endDate){
		
		StringBuffer sql = new StringBuffer("  seleCT '14069' AS TYPE , TO_DATE(TO_CHAR(ODR.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD') AS STARTDATE ,TO_DATE(TO_CHAR(ODR.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD') AS ENDDATE ,SUM(ODR.QUANTITY) AS QUANTITY ");
		sql.append("   FROM T_GENERIC_ORDER GO INNER JOIN T_ORDER_DETAIL_RESTAURANT ODR ON GO.ORDERID=ODR.ORDERID ");
		sql.append("   WHERE GO.SELLER =:MEMBERID  AND GO.PAYMENTSTATUS = '1' ");
		sql.append("  AND ODR.STARTTIME <=:ENDDATE AND  ODR.STARTTIME >=:STARTDATE  GROUP BY  TO_DATE(TO_CHAR(ODR.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD') ");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}


	/**
	 *查询酒店一段时间内的酒店产品销售统计（已售，库存） 
	 *         type：13090    对象类型
	 *     objectid：对应对象（酒店id）
	 *    productid：对应产品（酒店产品id）
	 *    startdate：对应时间（针对某天的统计）
	 *   objectname：对象名称
	 *  productname：产品名称
	 *enablesalenum：可售数量
	 *     quantity：已售数量
	 **/
	
	@Override
	public List<Map<String, Object>> findHotelProductSaleStatistical(
			String memberId, Date startDate, Date endDate) {
		StringBuffer sql = new StringBuffer(" SELECT '13090' AS TYPE, OBJ.HOTELID  AS OBJECTID, OBJ.PRODUCTID  AS PRODUCTID, OBJ.CHECKIN AS STARTDATE,MAX(OBJ.CHECKOUT-1) AS ENDDATE ,");
		sql.append("  MAX(OBJ.HOTELNAME) AS OBJECTNAME, MAX(HP.PRODUCTNAME)  AS PRODUCTNAME, ");    
		sql.append("  MIN(SP.ENABLESALENUM) AS ENABLESALENUM,  SUM(OBJ.QUANTITY) AS QUANTITY ");
		sql.append("  FROM T_GENERIC_ORDER GO INNER JOIN T_ORDER_DETAIL_HOTEL OBJ ON GO.ORDERID = OBJ.ORDERID ");
		sql.append("  LEFT JOIN T_HOTEL_PRODUCT HP ON OBJ.PRODUCTID=HP.PRODUCTID ");
		sql.append("  INNER JOIN T_SALE_PLAN SP ON SP.OBJID=OBJ.PRODUCTID AND OBJ.CHECKIN=SP.PLANDATE ");
		sql.append("  WHERE GO.SELLER =:MEMBERID AND OBJ.CHECKIN <=:ENDDATE AND OBJ.CHECKIN >=:STARTDATE ");
		sql.append("  AND GO.PAYMENTSTATUS = '1'  GROUP BY OBJ.CHECKIN, OBJ.PRODUCTID, OBJ.HOTELID ");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}

	
	/**
	 *查询娱乐信息一段时间内的娱乐产品销售统计（已售，库存） 
	 *         type：14070    对象类型
	 *     objectid：对应对象（娱乐id）
	 *    productid：对应产品（娱乐产品id）
	 *    startdate：对应时间（针对某天的统计）
	 *   objectname：对象名称
	 *  productname：产品名称
	 *enablesalenum：可售数量
	 *     quantity：已售数量
	 **/
	@Override
	public List<Map<String, Object>> findShowProductSaleStatistical(
			String memberId, Date startDate, Date endDate) {
		StringBuffer sql = new StringBuffer(" SELECT '14070' AS TYPE, OBJ.ENTERTAINMENTID AS OBJECTID, OBJ.PRODUCTID  AS PRODUCTID, OBJ.STARTDATE AS STARTDATE, OBJ.STARTDATE AS ENDDATE, ");
		sql.append("  MAX(OBJ.SHOWNAME) AS OBJECTNAME, MAX(HP.PRODUCTNAME)  AS PRODUCTNAME, ");    
		sql.append("  MIN(SP.ENABLESALENUM) AS ENABLESALENUM,  SUM(OBJ.QUANTITY) AS QUANTITY ");
		sql.append("  FROM T_GENERIC_ORDER GO INNER JOIN T_ORDER_DETAIL_SHOW OBJ ON GO.ORDERID = OBJ.ORDERID ");
		sql.append("  LEFT JOIN T_ENTERTAINMENT_PRODUCT HP ON OBJ.PRODUCTID=HP.PRODUCTID ");
		sql.append("  INNER JOIN T_SALE_PLAN SP ON SP.OBJID=OBJ.PRODUCTID AND OBJ.STARTDATE=SP.PLANDATE ");
		sql.append("  WHERE GO.SELLER =:MEMBERID AND OBJ.STARTDATE <=:ENDDATE AND OBJ.STARTDATE >=:STARTDATE ");
		sql.append("  AND GO.PAYMENTSTATUS = '1'  GROUP BY OBJ.STARTDATE, OBJ.PRODUCTID,OBJ.ENTERTAINMENTID ");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}

	/**
	 *查询景点信息一段时间内的门票产品销售统计（已售，库存） 
	 *         type：13489    对象类型
	 *     objectid：对应对象（景点id）
	 *    productid：对应产品（门票产品id）
	 *    startdate：对应时间（针对某天的统计）
	 *   objectname：对象名称
	 *  productname：产品名称
	 *enablesalenum：可售数量
	 *     quantity：已售数量
	 **/
	@Override
	public List<Map<String, Object>> findGateProductSaleStatistical(
			String memberId, Date startDate, Date endDate) {
		StringBuffer sql = new StringBuffer(" SELECT '13489' AS TYPE,OBJ.SCENERYID AS OBJECTID, OBJ.PRODUCTID  AS PRODUCTID, OBJ.STARTDATE AS STARTDATE, OBJ.STARTDATE AS ENDDATE,");
		sql.append("  MAX(OBJ.GATENAME) AS OBJECTNAME, MAX(HP.PRODUCTNAME)  AS PRODUCTNAME, ");    
		sql.append("  MIN(SP.ENABLESALENUM) AS ENABLESALENUM,  SUM(OBJ.QUANTITY) AS QUANTITY ");
		sql.append("  FROM T_GENERIC_ORDER GO INNER JOIN T_ORDER_DETAIL_GATE OBJ ON GO.ORDERID = OBJ.ORDERID ");
		sql.append("  LEFT JOIN T_SCENERY_PRODUCT HP ON OBJ.PRODUCTID=HP.PRODUCTID ");
		sql.append("  INNER JOIN T_SALE_PLAN SP ON SP.OBJID=OBJ.PRODUCTID AND OBJ.STARTDATE=SP.PLANDATE ");
		sql.append("  WHERE GO.SELLER =:MEMBERID AND OBJ.STARTDATE <=:ENDDATE AND OBJ.STARTDATE >=:STARTDATE ");
		sql.append("  AND GO.PAYMENTSTATUS = '1'  GROUP BY OBJ.STARTDATE, OBJ.PRODUCTID,OBJ.SCENERYID ");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}

	
	/**
	 *查询旅运信息一段时间内的旅运产品销售统计（已售） 
	 *         type：14149    对象类型
	 *     objectid：对应对象（旅运公司id）
	 *    productid：对应产品（旅运产品id）
	 *    startdate：对应时间（针对某天的统计）
	 *   objectname：对象名称
	 *  productname：产品名称
	 *enablesalenum：可售数量（无上限）
	 *     quantity：已售数量
	 **/
	@Override
	public List<Map<String, Object>> findTransportProductSaleStatistical(
			String memberId, Date startDate, Date endDate) {
		StringBuffer sql = new StringBuffer(" SELECT '14149' AS TYPE, OBJ.TRANSPORTID AS OBJECTID, OBJ.PRODUCTID  AS PRODUCTID, OBJ.STARTDATE AS STARTDATE,MAX(OBJ.ENDDATE) AS ENDDATE,");
		sql.append("  MAX(OBJ.TRANSPORTNAME) AS OBJECTNAME, MAX(HP.PRODUCTNAME)  AS PRODUCTNAME,");    
		sql.append("  '99999' AS ENABLESALENUM,  SUM(OBJ.QUANTITY) AS QUANTITY" );
		sql.append("  FROM T_GENERIC_ORDER GO INNER JOIN T_ORDER_DETAIL_TRANSPORT OBJ ON GO.ORDERID = OBJ.ORDERID " );
		sql.append("  LEFT JOIN T_TRANSPORT_PRODUCT HP ON OBJ.PRODUCTID=HP.PRODUCTID ");
		sql.append("  WHERE GO.SELLER =:MEMBERID AND OBJ.STARTDATE <=:ENDDATE AND OBJ.STARTDATE >=:STARTDATE ");
		sql.append("  AND GO.PAYMENTSTATUS = '1'  GROUP BY OBJ.STARTDATE, OBJ.PRODUCTID,OBJ.TRANSPORTID ");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}

	
	/**
	 *查询餐饮信息一段时间内的餐饮产品销售统计（已售，库存） 
	 *         type：14069    对象类型
	 *     objectid：对应对象（餐馆id）
	 *    productid：对应产品（餐饮产品id）
	 *    startdate：对应时间（针对某天的统计）
	 *   objectname：对象名称
	 *  productname：产品名称
	 *enablesalenum：可售数量
	 *     quantity：已售数量
	 **/
	@Override
	public List<Map<String, Object>> findRestaurantProductSaleStatistical(
			String memberId, Date startDate, Date endDate) {
		StringBuffer sql = new StringBuffer(" SELECT '14069' AS TYPE,OBJ.RESTAURANTID AS OBJECTID, OBJ.PRODUCTID  AS PRODUCTID,   TO_DATE( TO_CHAR(OBJ.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD')  AS STARTDATE, TO_DATE( TO_CHAR(OBJ.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD')  AS ENDDATE,");
		sql.append("   MAX(OBJ.RESTAURANT) AS OBJECTNAME, MAX(HP.RESTAUPRODUCTNAME)  AS PRODUCTNAME, ");    
		sql.append("  MIN(SP.ENABLESALENUM) AS ENABLESALENUM,  SUM(OBJ.QUANTITY) AS QUANTITY ");
		sql.append("  FROM T_GENERIC_ORDER GO INNER JOIN T_ORDER_DETAIL_RESTAURANT OBJ ON GO.ORDERID = OBJ.ORDERID ");
		sql.append("  LEFT JOIN T_RESTAURANT_PRODUCT HP ON OBJ.PRODUCTID=HP.RESTAURANTPRODUCTID ");
		sql.append("  INNER JOIN T_SALE_PLAN SP ON SP.OBJID=OBJ.PRODUCTID AND TO_DATE(TO_CHAR(OBJ.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD')=SP.PLANDATE ");
		sql.append("  WHERE GO.SELLER =:MEMBERID AND TO_DATE( TO_CHAR(OBJ.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD') <=:ENDDATE AND TO_DATE( TO_CHAR(OBJ.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD') >=:STARTDATE ");
		sql.append("  AND GO.PAYMENTSTATUS = '1'   GROUP BY  TO_DATE( TO_CHAR(OBJ.STARTTIME,'YYYY-MM-DD'),'YYYY-MM-DD'), OBJ.PRODUCTID,OBJ.RESTAURANTID ");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("MEMBERID", memberId);
		query.setParameter("STARTDATE", startDate);
		query.setParameter("ENDDATE", endDate);
		return query.list();
	}
	
}
