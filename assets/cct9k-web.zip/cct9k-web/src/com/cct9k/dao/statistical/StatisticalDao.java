package com.cct9k.dao.statistical;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.cct9k.dao.BaseDao;


public interface StatisticalDao extends BaseDao<Object, String> {
	
	public List<Map<String, Object>> findHotelSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	public List<Map<String, Object>> findShowSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	public List<Map<String, Object>> findGateSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	public List<Map<String, Object>> findTransportSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	public List<Map<String, Object>> findRestaurantSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	
	
	public List<Map<String, Object>> findHotelProductSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	public List<Map<String, Object>> findShowProductSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	public List<Map<String, Object>> findGateProductSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	public List<Map<String, Object>> findTransportProductSaleStatistical(String memberId,Date startDate,Date  endDate);
	
	public List<Map<String, Object>> findRestaurantProductSaleStatistical(String memberId,Date startDate,Date  endDate);
	
}
