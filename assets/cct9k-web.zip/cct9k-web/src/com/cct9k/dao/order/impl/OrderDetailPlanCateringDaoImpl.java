package com.cct9k.dao.order.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.OrderDetailPlanCateringDao;
import com.cct9k.entity.order.OrderDetailPlan;
import com.cct9k.entity.order.OrderDetailPlanCatering;
import com.cct9k.entity.reseller.Visitor;
import com.cct9k.util.common.StringUtil;
@Repository
public class OrderDetailPlanCateringDaoImpl extends BaseDaoImpl<OrderDetailPlanCatering, String> implements OrderDetailPlanCateringDao{

	@Override
    public List<OrderDetailPlanCatering> getDetailCateringsByOrderId(String orderId,String routestopid,String detailId) {
        Finder r = Finder.create("from OrderDetailPlanCatering model where 1=1");

        if (!StringUtil.isEmpty(orderId)) {
            r.append(" and model.order.orderId = :orderId  ");
            r.setParam("orderId", orderId);
        }
        
        if (!StringUtil.isEmpty(routestopid)) {
            r.append("  and model.routestop.stopid = :stopid  ");
            r.setParam("stopid", routestopid);
        }
        
        if (!StringUtil.isEmpty(detailId)) {
            r.append(" and model.orderdetailplan.detailId = :detailId ");
            r.setParam("detailId", detailId);
        }

        r.append(" order by model.detailplancateringid desc");

        return find(r);
    }

	@Override
	public List<OrderDetailPlanCatering> getDetailCateringsByOrderIdAndStopId(
			String orderId, String routestopid) {
		List result = new ArrayList();
        String hql = (" select o from  OrderDetailPlanCatering o where o.order.orderId='"+orderId+"' and o.routestop.stopid='"+routestopid+"'");
        List<OrderDetailPlanCatering> list = getListByHql(hql);
        if (list != null && list.size() > 0) {
        	result = list;
        }  
   
		return result;
	}
}
