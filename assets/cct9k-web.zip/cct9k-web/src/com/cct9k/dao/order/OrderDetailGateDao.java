package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Scenery;
import com.cct9k.entity.order.OrderDetailGate;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:35
 */
public interface OrderDetailGateDao extends BaseDao<OrderDetailGate, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public List<OrderDetailGate> getDetailsByOrderId(String orderId);
    
    public boolean deleteOrderDetailGate(String sourceId);
    
    public boolean deleteGateOrderByOrderId(String orderId);
    /**
     * 根据订单id查询景点  已去重复
     * @param orderId
     * @return
     */
    public List<Scenery> getSceneryByOrderId(String orderId);
    
    /**
     * 根据计划id查询绑定生成的景点订单
     * 
     * @param planId
     * @return
     */
    public List<?> getGateOrdersByPlanId(String planId);

}
