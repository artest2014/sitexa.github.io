package com.cct9k.dao.order.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.OrderDetailPlanShowDao;
import com.cct9k.entity.order.OrderDetailPlanShow;
import com.cct9k.entity.order.OrderDetailPlanTransport;
import com.cct9k.util.common.StringUtil;
@Repository
public class OrderDetailPlanShowDaoImpl extends BaseDaoImpl<OrderDetailPlanShow, String> implements OrderDetailPlanShowDao{
  
	@Override
    public List<OrderDetailPlanShow> getDetailShowByOrderId(String orderId,String routestopid,String detailId,String showId) {
        Finder r = Finder.create("from OrderDetailPlanShow model where 1=1");

        if (!StringUtil.isEmpty(orderId)) {
            r.append(" and model.order.orderId = :orderId ");
            r.setParam("orderId", orderId);
        }
        
        if (!StringUtil.isEmpty(routestopid)) {
            r.append("  and model.routestop.stopid = :stopid  ");
            r.setParam("stopid", routestopid);
        }
        
        if (!StringUtil.isEmpty(detailId)) {
            r.append(" and model.orderdetailplan.detailId = :detailId ");
            r.setParam("detailId", detailId);
        }
        
        if (!StringUtil.isEmpty(showId)) {
            r.append(" and model.customer.customerid = :showId ");
            r.setParam("showId", showId);
        }
        
        r.append(" order by model.orderdetailplanshowid desc");

        return find(r);
    }

}
