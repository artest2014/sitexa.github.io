package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.OrderDetailPlanHotel;

public interface OrderDetailPlanHotelDao extends BaseDao<OrderDetailPlanHotel, String> {
	 public List<OrderDetailPlanHotel> getOrderDetailPlanHotelList(String orderId,String routestopid,String detailId);
}
