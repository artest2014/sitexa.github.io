package com.cct9k.dao.order.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.OrderDetailPlanGateDao;
import com.cct9k.entity.order.OrderDetailPlanGate;
import com.cct9k.entity.order.OrderDetailPlanShow;
import com.cct9k.util.common.StringUtil;
@Repository
public class OrderDetailPlanGateDaoImpl extends BaseDaoImpl<OrderDetailPlanGate, String> implements OrderDetailPlanGateDao{

	@Override
    public List<OrderDetailPlanGate> getDetailGateByOrderId(String orderId,String routestopid,String detailId,String gateId) {
        Finder r = Finder.create("from OrderDetailPlanGate model where 1=1");

        if (!StringUtil.isEmpty(orderId)) {
            r.append(" and model.order.orderId = :orderId ");
            r.setParam("orderId", orderId);
        }
        
        if (!StringUtil.isEmpty(routestopid)) {
            r.append("  and model.routestop.stopid = :stopid  ");
            r.setParam("stopid", routestopid);
        }
        
        if (!StringUtil.isEmpty(detailId)) {
            r.append(" and model.orderdetailplan.detailId = :detailId ");
            r.setParam("detailId", detailId);
        }
        
        if (!StringUtil.isEmpty(gateId)) {
            r.append(" and model.customer.customerid = :gateId ");
            r.setParam("gateId", gateId);
        }

        r.append(" order by model.orderdetailplangateid desc");

        return find(r);
    }

}
