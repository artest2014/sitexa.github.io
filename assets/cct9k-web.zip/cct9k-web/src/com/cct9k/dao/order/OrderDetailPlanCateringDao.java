package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.OrderDetailPlanCatering;

public interface OrderDetailPlanCateringDao extends BaseDao<OrderDetailPlanCatering, String> {
	
	public List<OrderDetailPlanCatering> getDetailCateringsByOrderId(String orderId,String routestopid,String detailId);
	public List<OrderDetailPlanCatering> getDetailCateringsByOrderIdAndStopId(String orderId,String routestopid);
}
