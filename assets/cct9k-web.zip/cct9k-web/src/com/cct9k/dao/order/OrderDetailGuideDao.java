package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.OrderDetailGuide;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:36
 */
public interface OrderDetailGuideDao extends BaseDao<OrderDetailGuide, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public List<OrderDetailGuide> getDetailsByOrderId(String orderId);
    
    public boolean deleteOrderDetailGuide(String sourceId);
    
    public boolean deleteGuideOrderByOrderId(String orderId);

}
