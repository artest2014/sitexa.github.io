package com.cct9k.dao.order;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.GenericOrder;

import java.util.Date;
import java.util.List;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午9:54
 */
public interface GenericOrderDao extends BaseDao<GenericOrder, String> {

    public Pagination getPage(int pageNo, int pageSize, String orderName, String sallerId,String orderTyle ,String orderStyle);

    public Pagination getListPage(Dictionary objectType, String memberid, String startTime, String endTime, Dictionary orderStatus, Dictionary estimateStatus, int pageNo, int pageSize);

    public List<GenericOrder> getListByObjectType(Dictionary objectType, String memberid);

    public List<GenericOrder> getListByBuyer(Member member);

    public Pagination getPaginationPurchaseOrder(int pageNo, int pageSize, String orderName, String planId,String buyId,String objectTypeid);

    public boolean deleteGenericOrder(String sourceId);

    public Pagination searchByBuyer(Member buyer, String orderid, String name, String ordertype, Date orderdate, int pageNo, int pageSize);

    public Pagination searchByMember(Member member, String orderid, String ordername, String ordertype, Date orderdate, int pageNo, Integer pageSize);
    
    public Pagination getPage(int pageNo, int pageSize);
    
    public Pagination getHotelOrderFinanceListPage(String memberid,String membername,
			 String statetime, String endtime, String objecttype,String quotatype,String grouptype,int pageNo,
			int pageSize) ;
    
    public List getTotalHotelOrderFinanceList(String memberid,String membername,
			String statetime, String endtime, String objecttype,String quotatype,String grouptype) ;
    
    public List getHotelOrderFinanceListexportExcel(String memberid,String membername,
			String statetime, String endtime, String objecttype,
			String quotatype,String grouptype) ;
    
    public Pagination getTransactionFinanceListPage(String memberid,String membername,
			String statetime, String endtime, String objecttype,String quotatype,String paytyep,String billtype, int pageNo,
			int pageSize);
    
	public List getTotalTransactionFinanceList(String memberid,String membername,
			String statetime, String endtime, String objecttype,
			String quotatype, String paytyep, String billtype) ;
	
	public List getTransactionFinanceListexportExcel(String memberid,String membername,
			String statetime, String endtime, String objecttype,
			String quotatype, String paytyep, String billtype);

	public List<GenericOrder> getListByBuyer(String buyer);

	
	public Pagination getListByBuyerFinanceOrder(String buyer,
			 String statetime, String endtime,String objecttype, int pageNo, int pageSize);
	
	public String getObjectIdByOrderId(String orderId,String orderStyle);
	
	public Pagination searchOrderBySeller(Member member, String orderid,
			String ordername, String ordertype, Date orderdate, int pageNo,
			Integer pageSize);

	public boolean orderIsOverdue(String orderId);

	public String saveGenericOrder(Member seller, Member buyer,
			String orederName, String description,String remark, Dictionary objectType,
			Dictionary orderType);
	
	public List<GenericOrder> getGenericOrder(String memberId,String dictid1,String dictid2);
	
	public List getPaymentStatus(String planId,String dictId);
}
