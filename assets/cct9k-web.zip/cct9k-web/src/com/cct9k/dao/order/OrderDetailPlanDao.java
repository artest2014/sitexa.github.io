package com.cct9k.dao.order;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.OrderDetailPlan;
import com.cct9k.entity.reseller.Visitor;

import java.util.Date;
import java.util.List;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:38
 */
public interface OrderDetailPlanDao extends BaseDao<OrderDetailPlan, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public List<OrderDetailPlan> getDetailsByOrderId(String orderId);

    public Pagination searchOrderWithOnsaleByResellerAndBuyer(Member reseller, String buyer, Date start, Date end, int pageNo, int pageSize);
	/**
	 * 描述: 获取买线路的人数
	 * @return
	 * @author    yangkun
	 */
    public String getVisitCoutByRoute(String routeid);
    
    /**
     * 描述: .通过身份证和线路产品ID判断游客是否唯一
     * @param onsaleid
     * @param identityNo
     * @return
     * @author     chp
     * <p>Sample: 该方法使用样例</p>
     * date        2013-11-20
     * -----------------------------------------------------------
     * 修改人                                             修改日期                                   修改描述
     * chp                2013-11-20               创建
     * -----------------------------------------------------------
     * @Version  Ver1.0
     */
    public List<OrderDetailPlan> getVisitorListByOnsaleIdAndIdentityNo(String identityNo);
    
    List<Visitor> getAllVisitorByOnsaleId(String onsaleId);
    
}
