package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Restaurant;
import com.cct9k.entity.order.OrderDetailRestaurant;

/**
 * Author: oscar peng <xnpeng@hotmail.com> Date: 13-7-22 Time: 上午9:38
 */
public interface OrderDetailRestaurantDao extends BaseDao<OrderDetailRestaurant, String>
{

	public Pagination getPage(int pageNo, int pageSize);

	public List<OrderDetailRestaurant> getDetailsByOrderId(String orderId);

	public boolean deleteOrderDetailRestaurant(String sourceId);

	public boolean deleteRestaurantOrderByOrderId(String orderId);

	/**
	 * 根据订单di查询 餐饮店铺，已去重复
	 * 
	 * @param orderId
	 * @return
	 */
	List<Restaurant> getRestaurantByOrderId(String orderId);

	/**
	 * 根据计划ID查询餐饮订单列表
	 * 
	 * @param planId
	 * @return
	 */
	public List<?> getRestaurantOrdersByPlanId(String planId);

}
