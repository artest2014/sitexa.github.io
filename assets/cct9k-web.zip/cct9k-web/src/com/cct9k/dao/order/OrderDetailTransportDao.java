package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Transport;
import com.cct9k.entity.order.OrderDetailTransport;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:40
 */
public interface OrderDetailTransportDao extends BaseDao<OrderDetailTransport, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public List<OrderDetailTransport> getDetailsByOrderId(String orderId);
    
    public boolean deleteOrderDetailTransport(String sourceId);
    
    public boolean deleteTransportOrderByOrderId(String orderId);
    /**
     * 根据订单id查询交通公司  已经去重复
     * @param orderId
     * @return
     */
    public List<Transport> getTransportByOrderId(String orderId);
    
    /**
     * 根据计划id查询已绑定生成的交通订单列表
     * 
     * @param planId
     * @return
     */
    public List<?> getTransportOrdersByPlanId(String planId);

}
