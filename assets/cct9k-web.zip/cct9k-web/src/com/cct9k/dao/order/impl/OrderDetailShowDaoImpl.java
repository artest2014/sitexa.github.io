package com.cct9k.dao.order.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.EntertainmentDao;
import com.cct9k.dao.order.OrderDetailShowDao;
import com.cct9k.entity.main.Entertainment;
import com.cct9k.entity.order.OrderDetailShow;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:39
 */
@Repository
public class OrderDetailShowDaoImpl extends BaseDaoImpl<OrderDetailShow, String> implements OrderDetailShowDao {

	@Resource
	private EntertainmentDao entertainmentDao;
    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from ... model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }
    
    @Override
    public List<OrderDetailShow> getDetailsByOrderId(String orderId) {
        String sql="select t.* from t_order_detail_show t where 1=1 ";
        if (!StringUtil.isEmpty(orderId)) {
            sql+=" and t.orderid = '"+orderId+"' ";
        }
        sql+=" order by t.detailid desc";
        Query query = this.getSession().createSQLQuery(sql).addEntity(OrderDetailShow.class);
		List<OrderDetailShow> resultList = query.list();
		if (resultList != null && resultList.size() > 0) {
			return resultList;
		} else {
			return null;
		}
    }
    
    @Override
    public List<Entertainment> getEntertainmentByOrderId(String orderId) {
        String sql="SELECT DISTINCT(ENTERTAINMENTID),SUM(T.AMOUNT) AS AMOUNT  FROM T_ORDER_DETAIL_SHOW T WHERE 1=1 ";
        if (!StringUtil.isEmpty(orderId)) {
            sql+=" AND T.ORDERID = '"+orderId+"' ";
        }
        sql+=" GROUP BY T.ENTERTAINMENTID ";
        Query query = this.getSession().createSQLQuery(sql);
		List<Object[]> resultList = query.list();
		List<Entertainment> list=null;
		if (resultList != null && resultList.size() > 0) {
			list =new ArrayList<Entertainment>();
			 for(Object[] value : resultList){
				 Entertainment entertainment=entertainmentDao.get(value[0]==null?"":value[0].toString());
				 entertainment.setEntertainmentOrderDetailAmout(value[1]==null?"":value[1].toString());
				 list.add(entertainment);
			 }
			return list;
		} else {
			return null;
		}
    }
    
    public boolean deleteOrderDetailShow(String sourceId) {
        String sql = "delete from t_order_detail_show where orderid in( select t.orderid  from t_generic_order t where t.sourceid=?)";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, sourceId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public boolean deleteShowOrderByOrderId(String orderId){
    	String sql = "delete from t_order_detail_show where orderid =?";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, orderId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

}
