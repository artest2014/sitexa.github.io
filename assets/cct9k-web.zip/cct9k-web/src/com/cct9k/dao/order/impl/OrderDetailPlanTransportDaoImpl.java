package com.cct9k.dao.order.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.OrderDetailPlanTransportDao;
import com.cct9k.entity.order.OrderDetailPlanCatering;
import com.cct9k.entity.order.OrderDetailPlanTransport;
import com.cct9k.util.common.StringUtil;
@Repository
public class OrderDetailPlanTransportDaoImpl extends BaseDaoImpl<OrderDetailPlanTransport, String> implements OrderDetailPlanTransportDao{

	@Override
    public List<OrderDetailPlanTransport> getDetailTransportByOrderId(String orderId,String routestopid,String detailId) {
        Finder r = Finder.create("from OrderDetailPlanTransport model where 1=1");

        if (!StringUtil.isEmpty(orderId)) {
            r.append(" and model.order.orderId = :orderId ");
            r.setParam("orderId", orderId);
        }
        
        if (!StringUtil.isEmpty(routestopid)) {
            r.append("  and model.routestop.stopid = :stopid  ");
            r.setParam("stopid", routestopid);
        }
        
        if (!StringUtil.isEmpty(detailId)) {
            r.append(" and model.orderdetailplan.detailId = :detailId ");
            r.setParam("detailId", detailId);
        }

        r.append(" order by model.orderdetailplantransportid desc");

        return find(r);
    }
}
