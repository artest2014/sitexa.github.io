package com.cct9k.dao.order.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.TransportDao;
import com.cct9k.dao.order.OrderDetailTransportDao;
import com.cct9k.entity.main.Entertainment;
import com.cct9k.entity.main.Transport;
import com.cct9k.entity.order.OrderDetailTransport;
import com.cct9k.util.common.StringUtil;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:40
 */
@Repository
public class OrderDetailTransportDaoImpl extends BaseDaoImpl<OrderDetailTransport, String> implements OrderDetailTransportDao {
    @Resource
    private TransportDao transportDao;
    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from ... model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }
    
    @Override
    public List<OrderDetailTransport> getDetailsByOrderId(String orderId) {
        String sql="select t.* from t_order_detail_transport t where 1=1 ";
        if (!StringUtil.isEmpty(orderId)) {
            sql+=" and t.orderid = '"+orderId+"' ";
        }
        sql+=" order by t.detailid desc";
        Query query = this.getSession().createSQLQuery(sql).addEntity(OrderDetailTransport.class);
		List<OrderDetailTransport> resultList = query.list();
		if (resultList != null && resultList.size() > 0) {
			return resultList;
		} else {
			return null;
		}
    }
    
    @Override
    public List<Transport> getTransportByOrderId(String orderId) {
        String sql="SELECT DISTINCT(TRANSPORTID),SUM(T.AMOUNT) AS AMOUNT FROM T_ORDER_DETAIL_TRANSPORT T WHERE 1=1 ";
        if (!StringUtil.isEmpty(orderId)) {
            sql+=" AND T.ORDERID = '"+orderId+"' ";
        }
        sql+=" GROUP BY T.TRANSPORTID ";
        Query query = this.getSession().createSQLQuery(sql);
		List<Object[]> resultList = query.list();
		List<Transport> list=null;
		if (resultList != null && resultList.size() > 0) {
			list=new ArrayList<Transport>();
			 for(Object[] value : resultList){
				 Transport transport=transportDao.get(value[0]==null?"":value[0].toString());
				 transport.setTransportOrderDetailAmout(value[1]==null?"":value[1].toString());
				 list.add(transport);
			 }
			return list;
		} else {
			return null;
		}
    }
    
    public boolean deleteOrderDetailTransport(String sourceId) {
        String sql = "delete from t_order_detail_transport where orderid in( select t.orderid  from t_generic_order t where t.sourceid=?)";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, sourceId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public boolean deleteTransportOrderByOrderId(String orderId){
    	String sql = "delete from t_order_detail_transport where orderid =?";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, orderId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

	@Override
	public List<?> getTransportOrdersByPlanId(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append("select a.sourceid,                                                                       ");
		querySql.append("       a.orderid,                                                                        ");
		querySql.append("       '平台交易' as customersource,                                                     ");
		querySql.append("       a.name as ordername,                                                              ");
		querySql.append("       d.productname,                                                                    ");
		querySql.append("       c.companyname,                                                                    ");
		querySql.append("       a.orderdate,                                                                      ");
		querySql.append("       b.quantity,                                                                       ");
		querySql.append("       b.amount,                                                                         ");
		querySql.append("       (select typename from t_dictionary where dictid = a.orderstatus) orderstatus,     ");
		querySql.append("       decode(a.paymentstatus, 0, '未付款', 1, '已付款', 2, '部分付款') paymentstatus,   ");
		querySql.append("       (select typename from t_dictionary where dictid = a.estimatestatus) estimatestatus");
		querySql.append("  from t_generic_order          a,                                                       ");
		querySql.append("       t_order_detail_transport b,                                                       ");
		querySql.append("       t_transport              c,                                                       ");
		querySql.append("       t_transport_product      d                                                        ");
		querySql.append(" where a.orderid = b.orderid                                                             ");
		querySql.append("   and b.transportid = c.transportid                                                     ");
		querySql.append("   and b.productid = d.productid                                                         ");
		querySql.append("   and a.sourceid = :planid                                                              ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);
		
        return query.list();
	}

}
