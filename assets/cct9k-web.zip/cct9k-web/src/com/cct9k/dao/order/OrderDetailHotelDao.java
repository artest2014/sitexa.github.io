package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.order.OrderDetailHotel;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:37
 */
public interface OrderDetailHotelDao extends BaseDao<OrderDetailHotel, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public List<OrderDetailHotel> getDetailsByOrderId(String orderId);
    
    public boolean deleteOrderDetailHotel(String sourceId);
    
    public boolean deleteHotelOrderByOrderId(String orderId);
    /**
     * 根据订单id 查询该订单的 酒店列表，去重复
     * @param orderId
     * @return
     */
    public List<Hotel> getHotelByOrderId(String orderId);
    
    /**
     * 根据行程计划id 查询已绑定生成的住房订单
     * @param planId 
     * @return
     */
    public List<?> getHotelOrdersByPlanId(String planId);

}
