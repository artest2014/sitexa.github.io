package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.OrderDetailPlanTransport;

public interface OrderDetailPlanTransportDao extends BaseDao<OrderDetailPlanTransport, String> {
	
	public List<OrderDetailPlanTransport> getDetailTransportByOrderId(String orderId,String routestopid,String detailId);
}
