package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.OrderDetailPlanShow;

public interface OrderDetailPlanShowDao extends BaseDao<OrderDetailPlanShow, String> {
	
	public List<OrderDetailPlanShow> getDetailShowByOrderId(String orderId,String routestopid,String detailId,String showId);
}
