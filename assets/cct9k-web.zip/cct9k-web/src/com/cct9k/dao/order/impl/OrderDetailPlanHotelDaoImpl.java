package com.cct9k.dao.order.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.OrderDetailPlanHotelDao;
import com.cct9k.entity.order.OrderDetailPlanHotel;
import com.cct9k.util.common.StringUtil;
@Repository
public class OrderDetailPlanHotelDaoImpl extends BaseDaoImpl<OrderDetailPlanHotel, String> implements OrderDetailPlanHotelDao{

	@Override 
    public List<OrderDetailPlanHotel> getOrderDetailPlanHotelList(String orderId,String routestopid,String detailId){
    	Finder r = Finder.create("from OrderDetailPlanHotel model where 1=1");

        if (!StringUtil.isEmpty(orderId)) {
            r.append(" and model.order.orderId = :orderId ");
            r.setParam("orderId", orderId);
        }
        
        if (!StringUtil.isEmpty(routestopid)) {
            r.append("  and model.routestop.stopid = :stopid  ");
            r.setParam("stopid", routestopid);
        }
        
        if (!StringUtil.isEmpty(detailId)) {
            r.append(" and model.orderdetailplan.detailId = :detailId ");
            r.setParam("detailId", detailId);
        }

        r.append(" order by model.orderdetailplanhotelid desc");

        return find(r);
    }

}
