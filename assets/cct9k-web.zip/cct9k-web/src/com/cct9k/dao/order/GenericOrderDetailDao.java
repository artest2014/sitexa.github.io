package com.cct9k.dao.order;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.GenericOrderDetail;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:32
 */
public interface GenericOrderDetailDao extends BaseDao<GenericOrderDetail, String> {

    public Pagination getPage(int pageNo, int pageSize);

}
