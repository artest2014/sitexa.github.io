package com.cct9k.dao.order.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.GenericOrderDao;
import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.allinpay.PersonMemberInfo;
import com.cct9k.entity.finance.RefoundRule;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.GenericOrder;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;
import com.cct9k.web.core.MemberThread;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Author: oscar peng <xnpeng@hotmail.com> Date: 13-7-22 Time: 上午9:27
 */
@Repository
public class GenericOrderDaoImpl extends BaseDaoImpl<GenericOrder, String>
		implements GenericOrderDao {

	@Override
	public Pagination getPage(int pageNo, int pageSize, String orderName,
			String sellerId, String orderType, String orderStyle) {

		Finder r = Finder.create("from GenericOrder model where 1=1");
		if (!StringUtil.isEmpty(orderName)) {
			r.append(" and model.name like '%'||:ORDERNAME||'%'");
			r.setParam("ORDERNAME", orderName);
		}
		if (!StringUtil.isEmpty(sellerId)) {
			r.append(" and model.seller.memberid =:SELLERID");
			r.setParam("SELLERID", sellerId);
		}
		if (!StringUtil.isEmpty(orderStyle)) {//订单类型
			r.append("  and model.objectType.typeid=:ORDERSTYLE");
			r.setParam("ORDERSTYLE", orderStyle);
		}
		if (!StringUtil.isEmpty(orderType)) {//下单单类型 
			r.append("  and model.orderType.typeid=:ORDERTYPE ");
			r.setParam("ORDERTYPE", orderType);
		}
		r.append(" order  by model.orderDate desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public Pagination getPaginationPurchaseOrder(int pageNo, int pageSize, String orderName,
			String planId,String buyId ,String objectTypeId) {
		Finder r = Finder.create("from GenericOrder model where 1=1 ");
		if (!StringUtil.isEmpty(orderName)) {
			r.append(" and model.name like '%'||:ORDERNAME||'%'");
			r.setParam("ORDERNAME", orderName);
		}
		if (!StringUtil.isEmpty(planId)) {
			r.append(" and model.sourceId =:PLANID");
			r.setParam("PLANID", planId);
		}
		if (!StringUtil.isEmpty(buyId)) {
			r.append(" and model.buyer.memberid =:BUYID ");
			r.setParam("BUYID", buyId);
		}
		if (!StringUtil.isEmpty(objectTypeId)) {
			r.append(" and model.objectType.dictid =:OBJECTTYPEID ");
			r.setParam("OBJECTTYPEID", objectTypeId);
		}
		//and model.objectType.dictid<>12889 and model.sourceId is not null
		r.append("    order by model.orderDate desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public String getSeqn() {
		String sql = " select S_ORDER.nextval from dual";
		Query query = getSession().createSQLQuery(sql);
		BigDecimal b = (BigDecimal) query.uniqueResult();
		return b.toString();
	}

	@Override
	public Pagination getListPage(Dictionary objectType, String memberid,
			String startTime, String endTime, Dictionary orderStatus,
			Dictionary estimateStatus, int pageNo, int pageSize) {
		String sql = "from GenericOrder g where g.buyer='" + memberid + "' and ( g.orderType.typeid='1' or g.orderType.typeid='3'  or (g.orderType.typeid='2' and  g.orderStatus.typeid !='1'   )  ) ";
		Finder r = Finder.create(sql);

		if (objectType != null) {
			r.append(" and g.objectType.dictid='" + objectType.getDictid()
					+ "'");
		}

		if (estimateStatus != null) {
			if (estimateStatus.getTypeid().equals("1")) {
				r.append(" and g.estimateStatus.dictid='"
						+ estimateStatus.getDictid()+ "' and g.orderStatus.typeid='4' ");
			} else {
				r.append(" and g.estimateStatus.dictid='"
						+ estimateStatus.getDictid() + "' ");
			}
		}
		if (!StringUtil.isEmpty(startTime)) {
			r.append(" and g.orderDate >=to_date('" + startTime
					+ "','yyyy-MM-dd HH24:mi:ss') ");
		}
		if (!StringUtil.isEmpty(endTime)) {
			r.append(" and g.orderDate <=to_date('" + endTime
					+ "','yyyy-MM-dd HH24:mi:ss') ");
		}

		if (orderStatus != null) {
			r.append(" and g.orderStatus.dictid='" + orderStatus.getDictid()
					+ "'");
		}
		r.append("  order by g.orderId desc ");
		return find(r, pageNo, pageSize);
	}

	@Override
	public List<GenericOrder> getListByObjectType(Dictionary objectType,
			String memberid) {
		String sql = "from GenericOrder g where g.buyer='" + memberid
				+ "' and g.objectType.dictid='" + objectType.getDictid() + "'";
		return getSession().createQuery(sql).list();
	}

	@Override
	public List<GenericOrder> getListByBuyer(Member member) {

		String sql = "from GenericOrder g where g.buyer='"
				+ member.getMemberid() + "' and ( g.orderType.typeid='1' or (g.orderType.typeid='2'  and g.orderStatus.typeid !='1' ) ) ";
		return getSession().createQuery(sql).list();
	}

	public boolean deleteGenericOrder(String sourceId) {
		String sql = "delete from t_generic_order t where t.sourceid=?";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, sourceId);
		int result = query.executeUpdate();
		return result > 0;
	}

	@Override
	public Pagination searchByBuyer(Member buyer, String orderid, String name,
			String ordertype, Date orderdate, int pageNo, int pageSize) {
		Finder f = Finder.create(" from GenericOrder model where 1=1 ");

		if (!StringUtil.isEmpty(orderid)) {
			f.append(" and model.orderId = :orderid ");
			f.setParam("orderid", orderid);
		} else {
			if (!StringUtil.isEmpty(name)) {
				f.append(" and name like '%'||:name||'%' ");
				f.setParam("name", name);
			}

			if (orderdate != null) {
				Date enddate = DateUtil.addDaysToDate(orderdate, 1);
				f.append(" and name orderDate >= :orderdate and orderDate < :enddate ");
				f.setParam("orderdate", orderdate);
				f.setParam("enddate", enddate);
			}

			if (buyer != null) {
				f.append(" and model.buyer.memberid=:memberid ");
				f.setParam("memberid", buyer.getMemberid());
			}

			if (!StringUtil.isEmpty(ordertype)) {
				// todo...
			}
		}

		if (buyer != null) {
			f.append(" and model.buyer.memberid=:memberid ");
			f.setParam("memberid", buyer.getMemberid());
		}
		f.append(" order by orderDate desc ");

		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination searchByMember(Member member, String orderid,
			String ordername, String ordertype, Date orderdate, int pageNo,
			Integer pageSize) {
		Finder f = Finder.create(" from GenericOrder model where 1=1 ");

		if (!StringUtil.isEmpty(orderid)) {
			f.append(" and model.orderId = :orderid ");
			f.setParam("orderid", orderid);
		} else {
			if (!StringUtil.isEmpty(ordername)) {
				f.append(" and model.name like '%'||:name||'%' ");
				f.setParam("name", ordername);
			}

			if (orderdate != null) {
				Date enddate = DateUtil.addDaysToDate(orderdate, 1);
				f.append(" and model.orderDate >= :orderdate and model.orderDate < :enddate ");
				f.setParam("orderdate", orderdate);
				f.setParam("enddate", enddate);
			}

			if (!StringUtil.isEmpty(ordertype)) {
				f.append(" and model.objectType.typeid='" + ordertype + "'");
			}

		}

		if (member != null) {
			f.append(" and model.seller.memberid=:memberid  ");
			f.setParam("memberid", member.getMemberid());
		}

		f.append(" order by model.orderDate desc ");

		return find(f, pageNo, pageSize);
	}
	
	@Override
	public Pagination searchOrderBySeller(Member member, String orderid,
			String ordername, String ordertype, Date orderdate, int pageNo,
			Integer pageSize) {
		Finder f = Finder.create(" from GenericOrder model where 1=1 ");

		if (!StringUtil.isEmpty(orderid)) {
			f.append(" and model.orderId = :orderid ");
			f.setParam("orderid", orderid);
		} else {
			if (!StringUtil.isEmpty(ordername)) {
				f.append(" and model.name like '%'||:name||'%' ");
				f.setParam("name", ordername);
			}

			if (orderdate != null) {
				Date enddate = DateUtil.addDaysToDate(orderdate, 1);
				f.append(" and model.orderDate >= :orderdate and model.orderDate < :enddate ");
				f.setParam("orderdate", orderdate);
				f.setParam("enddate", enddate);
			}

			if (!StringUtil.isEmpty(ordertype)) {
				f.append(" and model.objectType.typeid='" + ordertype + "'");
			}

		}

		if (member != null) {
			f.append(" and model.seller.memberid=:memberid  ");
			f.setParam("memberid", member.getMemberid());
		}

		f.append(" order by model.orderDate desc ");

		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination getPage(int pageNo, int pageSize) {

		Finder r = Finder.create("from GenericOrder model where 1=1");

		r.append(" order by model.orderDate desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public Pagination getHotelOrderFinanceListPage(String memberid,
			String membername, String statetime, String endtime,
			String objecttype, String quotatype, String grouptype, int pageNo,
			int pageSize) {
		String sql = "select distinct  ";
		sql += " Buyer, ";
		sql += " membername,";
		sql += " realname, ";
		sql += " orgname,";
		sql += " round(max(totalAmount),4) totalAmount,";
		sql += " round(max(factAmout),4) factAmout,";

		sql += " round(max(linefactamount),4) linefactamount,";
		sql += " round(max(downfactamount),4) downfactamount,";
		sql += " round(max(amount),4) amount,";
		sql += " round(max(lineamount),4) lineamount,";
		sql += " round(max(downamount),4) downamount,";

		sql += " round(max(quota),4) quota,";
		sql += " round(max(quotaused),4) quotaused,";
		sql += " case when max(damount) >0 then round(max(damount),4)  else 0 end damount, ";
		sql += " round(max(dtotalamount),4) dtotalamount,";
		sql += " seller";

		sql += " from";
		sql += " (";

		sql += " select g.Buyer Buyer,";
		sql += " g.membername,";
		sql += " (select p.realname from t_member_person p where p.memberid =g.buyer) realname,";
		sql += " (select o.orgname from t_member_organ o where o.memberid =g.buyer) orgname,";
		sql += " sum(g.totalAmount) totalAmount ,";
		sql += " sum(g.factamount) factAmout,";

		sql += " case when g.paymentmethod='81' and g.billtype ='payOnLine'  and g.billtypecate='billType' then sum(g.factamount) else 0 end linefactamount,";
		sql += " case when g.paymentmethod='80' and g.billtype ='payLinetrading'  and g.billtypecate='billType' then sum(g.factamount) else 0 end downfactamount,";
		sql += " sum(ddamount) amount ,";
		sql += " case when g.paymentmethod='81' and g.billtype ='payOnLine' and g.billtypecate='billType' then sum(g.amount) else 0 end lineamount,";
		sql += " case when g.paymentmethod='80' and g.billtype ='payLinetrading'  and g.billtypecate='billType' then sum(g.amount) else 0 end downamount,";

		sql += " (select sum(gm.quota) from t_group_member gm where g.buyer =gm.memberid and gm.quotatype='"
				+ quotatype
				+ "'  and gm.groupid in (select vg.groupid from t_vip_group vg where g.seller=vg.reseller and vg.grouptype='"
				+ grouptype + "'))quota,";
		sql += " (select sum(gm.quotaused) from t_group_member gm where g.buyer =gm.memberid and gm.quotatype='"
				+ quotatype
				+ "'  and gm.groupid in (select vg.groupid from t_vip_group vg where g.seller=vg.reseller and vg.grouptype='"
				+ grouptype + "'))quotaused,";
		sql += " sum(g.damount) damount,";
		sql += " sum(g.dtotalamount) dtotalamount,";
		sql += " g.seller ";
		sql += " from(select distinct m.*,b.*,g.*,case when mqd.amount>0 then mqd.amount else 0 end dtotalamount ,";
		sql += " (select sum(bl.amount) from t_bill bl where bl.orderid= g.orderid and bl.billtype in ('creditRepayment', 'payOnLine', ";
		sql += " 'payLinetrading', 'payLinetradingCash', ";
		sql += " 'onlinetracash')) ddamount,";
		sql += " (select sum(bl.amount) from t_bill bl where bl.orderid= g.orderid and bl.billtype in ('creditRepayment', 'payOnLine', ";
		sql += " 'payLinetrading', 'payLinetradingCash', ";
		sql += " 'onlinetracash'))damount";
		sql += " from t_member m,t_bill b ,t_Generic_Order g";
		sql += " left join t_member_quota_detail mqd on mqd.objecttype='"
				+ quotatype + "' and mqd.member = g.buyer";

		sql += " where 1=1";
		sql += " and g.orderid =b.orderid";
		sql += " and g.buyer =m.memberid  and g.objecttype =b.objecttype ";
		sql += " and g.seller ='" + memberid + "'";
		sql += " and b.billtype in ('credit', 'payOnLine','payLinetrading', 'payLinetradingCash','onlinetracash')";

		if (!StringUtil.isEmpty(membername)) {
			sql += " and m.membername like '%" + membername + "%'";
		}

		if (!StringUtil.isEmpty(statetime)) {
			sql += " and  to_date(to_char(b.paymentdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') >="
					+ "to_date(to_char('" + statetime + "'),'yyyy-mm-dd')";
		}
		if (!StringUtil.isEmpty(endtime)) {
			sql += " and  to_date(to_char(b.paymentdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') <="
					+ "to_date(to_char('" + endtime + "'),'yyyy-mm-dd')";
		}
		sql += " and g.objecttype='" + objecttype + "'";

		sql += " )g";
		sql += " group by g.Buyer,g.membername,g.mobileno,g.seller,g.paymentmethod,g.billtypecate,g.billtype";
		sql += " )a  group by Buyer,membername,realname,orgname,seller ";
		return this.findSql(sql, pageNo, pageSize);
	}

	@Override
	public List getHotelOrderFinanceListexportExcel(String memberid,
			String membername, String statetime, String endtime,
			String objecttype, String quotatype, String grouptype) {
		String sql = "select distinct  ";
		sql += " Buyer, ";
		sql += " membername,";
		sql += " realname, ";
		sql += " orgname,";
		sql += " round(max(totalAmount),4) totalAmount,";
		sql += " round(max(factAmout),4) factAmout,";

		sql += " round(max(linefactamount),4) linefactamount,";
		sql += " round(max(downfactamount),4) downfactamount,";
		sql += " round(max(amount),4) amount,";
		sql += " round(max(lineamount),4) lineamount,";
		sql += " round(max(downamount),4) downamount,";

		sql += " round(max(quota),4) quota,";
		sql += " round(max(quotaused),4) quotaused,";
		sql += " case when max(damount) >0 then round(max(damount),4)  else 0 end damount, ";
		sql += " round(max(dtotalamount),4) dtotalamount,";
		sql += " seller";

		sql += " from";
		sql += " (";

		sql += " select g.Buyer Buyer,";
		sql += " g.membername,";
		sql += " (select p.realname from t_member_person p where p.memberid =g.buyer) realname,";
		sql += " (select o.orgname from t_member_organ o where o.memberid =g.buyer) orgname,";
		sql += " sum(g.totalAmount) totalAmount ,";
		sql += " sum(g.factamount) factAmout,";

		sql += " case when g.paymentmethod='81' and g.billtype ='payOnLine'  and g.billtypecate='billType' then sum(g.factamount)  else 0  end linefactamount,";
		sql += " case when g.paymentmethod='80' and g.billtype ='payLinetrading'  and g.billtypecate='billType' then sum(g.factamount)  else 0 end downfactamount,";
		sql += " sum(ddamount) amount ,";
		sql += " case when g.paymentmethod='81' and g.billtype ='payOnLine' and g.billtypecate='billType' then sum(g.amount)  else 0  end lineamount,";
		sql += " case when g.paymentmethod='80' and g.billtype ='payLinetrading'  and g.billtypecate='billType' then sum(g.amount)  else 0  end downamount,";

		sql += " (select sum(gm.quota) from t_group_member gm where g.buyer =gm.memberid and gm.quotatype='"
				+ quotatype
				+ "' and gm.groupid in (select vg.groupid from t_vip_group vg where g.seller=vg.reseller and vg.grouptype='"
				+ grouptype + "'))quota,";
		sql += " (select sum(gm.quotaused) from t_group_member gm where g.buyer =gm.memberid and gm.quotatype='"
				+ quotatype
				+ "' and gm.groupid in (select vg.groupid from t_vip_group vg where g.seller=vg.reseller and vg.grouptype='"
				+ grouptype + "'))quotaused,";
		sql += " sum(g.damount) damount,";
		sql += " sum(g.dtotalamount) dtotalamount,";
		sql += " g.seller ";
		sql += " from(select distinct m.*,b.*,g.*,case when mqd.amount>0 then mqd.amount else 0 end dtotalamount ,";
		sql += " (select sum(bl.amount) from t_bill bl where bl.orderid= g.orderid and bl.billtype in ('creditRepayment', 'payOnLine', ";
		sql += " 'payLinetrading', 'payLinetradingCash', ";
		sql += " 'onlinetracash')) ddamount,";
		sql += " (select sum(bl.amount) from t_bill bl where bl.orderid= g.orderid and bl.billtype in ('creditRepayment', 'payOnLine', ";
		sql += " 'payLinetrading', 'payLinetradingCash', ";
		sql += " 'onlinetracash'))damount";
		sql += " from t_member m,t_bill b ,t_Generic_Order g";
		sql += " left join t_member_quota_detail mqd on mqd.objecttype='"
				+ quotatype + "' and mqd.member = g.buyer";

		sql += " where 1=1";
		sql += " and g.orderid =b.orderid";
		sql += " and g.buyer =m.memberid  and g.objecttype =b.objecttype ";
		sql += "  and g.seller ='" + memberid + "'";
		sql += " and b.billtype in ('credit', 'payOnLine','payLinetrading', 'payLinetradingCash','onlinetracash')";

		if (!StringUtil.isEmpty(membername)) {
			sql += " and m.membername like '%" + membername + "%'";
		}

		if (!StringUtil.isEmpty(statetime)) {
			sql += " and  to_date(to_char(b.paymentdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') >="
					+ "to_date(to_char('" + statetime + "'),'yyyy-mm-dd')";
		}
		if (!StringUtil.isEmpty(endtime)) {
			sql += " and  to_date(to_char(b.paymentdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') <="
					+ "to_date(to_char('" + endtime + "'),'yyyy-mm-dd')";
		}
		sql += " and g.objecttype='" + objecttype + "'";

		sql += " )g";
		sql += " group by g.Buyer,g.membername,g.mobileno,g.seller,g.paymentmethod,g.billtypecate,g.billtype";
		sql += " )a  group by Buyer,membername,realname,orgname,seller ";
		return getSession().createSQLQuery(sql).list();
	}

	@Override
	public List getTransactionFinanceListexportExcel(String memberid,
			String membername, String statetime, String endtime,
			String objecttype, String quotatype, String paytyep, String billtype) {
		String sql = " select c.*, ";
		sql += " case ";
		sql += " when qkamount > 0 then ";
		sql += " ljfkamount ";
		sql += " else ";
		sql += " 0 ";
		sql += " end ljysramount ";
		sql += " from (select b.*, (factamount - ljfkamount) qkamount";
		sql += " from (select a.*, ";
		sql += " (select round(sum(bl.amount),4) ";
		sql += " from t_bill bl ";
		sql += " where a.orderid = bl.orderid  and bl.billtype in('creditRepayment','payOnLine','onlinetracash') and bl.billtypecate='billType' ) ljfkamount, ";
		sql += "  case when factamount =amount then (((amount - sfamount) - sxfamount) - yjamount) else 0 end jsramount ";
		sql += " from (select m.memberid, ";
		sql += " m.membername, ";
		sql += " (select p.realname ";
		sql += " from t_member_person p ";
		sql += " where p.memberid = g.buyer) realname, ";
		sql += " (select o.orgname ";
		sql += " from t_member_organ o ";
		sql += " where o.memberid = g.buyer) orgname, ";
		sql += " (select case when td.dictid in(81,82) then '线上交易' else '线下交易' end ";
		sql += " from t_dictionary td ";
		sql += " where b.paymentmethod = td.dictid) payname, ";
		sql += " b.paymentdate, ";
		sql += " b.transactionid, ";
		sql += " (select td.typename ";
		sql += " from t_dictionary td ";
		sql += " where b.paymentmethod = td.dictid) billname, ";
		sql += " round((g.factamount),4) factamount, ";

		sql += " (select round(sum(bl.amount), 4) ";
		sql += " from t_bill bl ";
		sql += " where g.orderid = bl.orderid ";
		sql += " and bl.billtype in ";
		sql += " ('creditRepayment', 'payOnLine', 'onlinetracash') ";
		sql += " and bl.billtypecate = 'billType') amount, ";
		sql += " case ";
		sql += " when  b.billtype = 'transactionTax' and b.billtypecate='billType' then ";
		sql += " round(b.amount,4) else 0 ";
		sql += " end sfamount, ";
		sql += " case ";
		sql += " when b.billtype = 'transactionFees' and b.billtypecate='billType' then ";
		sql += " round(b.amount,4) else 0 ";
		sql += " end sxfamount, ";
		sql += " case when  (select tc.amount ";
		sql += " from t_commission tc ";
		sql += " where b.billid = tc.billid and b.billtype='extendCommision' and b.billtypecate='billType') >0 then (select round(tc.amount,4) ";
		sql += " from t_commission tc ";
		sql += " where b.billid = tc.billid and b.billtype='extendCommision' and b.billtypecate='billType')else 0 end yjamount, ";
		sql += " g.orderid orderid ";
		sql += " from t_member m, t_Generic_Order g, t_bill b ";
		sql += " left join t_commission tc on b.billid = tc.billid ";
		sql += " where 1 = 1 ";
		sql += " and g.orderid = b.orderid ";
		sql += " and g.buyer = m.memberid ";
		sql += "  and g.seller ='" + memberid + "'";
		sql += "  and b.billtype in('credit','payOnLine','onlinetracash') and b.billtypecate='billType'";

		if (!StringUtil.isEmpty(membername)) {
			sql += " and m.membername like '%" + membername + "%'";
		}

		if (!StringUtil.isEmpty(paytyep)) {
			if (paytyep == "15369") {
				sql += " and b.paymentmethod in(81,82,83)";
			} else {

			}
		}

		if (!StringUtil.isEmpty(billtype)) {
			sql += " and b.billtype='" + billtype + "'";
		}

		if (!StringUtil.isEmpty(statetime)) {
			sql += " and  b.paymentdate >=" + "to_date(to_char('" + statetime
					+ "'),'yyyy-mm-dd')";
		}
		if (!StringUtil.isEmpty(endtime)) {
			sql += " and  b.paymentdate <=" + "to_date(to_char('" + endtime
					+ "'),'yyyy-mm-dd')";
		}
		sql += " and g.objecttype='" + objecttype + "'";

		sql += " ) a ";
		sql += " ) b ";
		sql += " ) c ";
		return getSession().createSQLQuery(sql).list();
	}

	@Override
	public Pagination getTransactionFinanceListPage(String memberid,
			String membername, String statetime, String endtime,
			String objecttype, String quotatype, String paytyep,
			String billtype, int pageNo, int pageSize) {
		String sql = " select c.*, ";
		sql += " case ";
		sql += " when qkamount > 0 then ";
		sql += " ljfkamount ";
		sql += " else ";
		sql += " 0 ";
		sql += " end ljysramount ";
		sql += " from (select b.*, (factamount - ljfkamount) qkamount";
		sql += " from (select a.*, ";
		sql += " (select round(sum(bl.amount),4) ";
		sql += " from t_bill bl ";
		sql += " where a.orderid = bl.orderid  and bl.billtype in('creditRepayment','payOnLine','onlinetracash') and bl.billtypecate='billType' ) ljfkamount, ";
		sql += "  case when factamount =amount then (((amount - sfamount) - sxfamount) - yjamount) else 0 end jsramount ";
		sql += " from (select m.memberid, ";
		sql += " m.membername, ";
		sql += " (select p.realname ";
		sql += " from t_member_person p ";
		sql += " where p.memberid = g.buyer) realname, ";
		sql += " (select o.orgname ";
		sql += " from t_member_organ o ";
		sql += " where o.memberid = g.buyer) orgname, ";
		sql += " (select case when td.dictid in(81,82) then '线上交易' else '线下交易' end ";
		sql += " from t_dictionary td ";
		sql += " where b.paymentmethod = td.dictid) payname, ";
		sql += " b.paymentdate, ";
		sql += " b.transactionid, ";
		sql += " (select td.typename ";
		sql += " from t_dictionary td ";
		sql += " where b.paymentmethod = td.dictid) billname, ";
		sql += " round((g.factamount),4) factamount, ";

		sql += " (select round(sum(bl.amount), 4) ";
		sql += " from t_bill bl ";
		sql += " where g.orderid = bl.orderid ";
		sql += " and bl.billtype in ";
		sql += " ('creditRepayment', 'payOnLine', 'onlinetracash') ";
		sql += " and bl.billtypecate = 'billType') amount, ";
		sql += " case ";
		sql += " when  b.billtype = 'transactionTax' and b.billtypecate='billType' then ";
		sql += " round(b.amount,4) else 0 ";
		sql += " end sfamount, ";
		sql += " case ";
		sql += " when b.billtype = 'transactionFees' and b.billtypecate='billType' then ";
		sql += " round(b.amount,4) else 0 ";
		sql += " end sxfamount, ";
		sql += " case when  (select round(tc.amount,4) ";
		sql += " from t_commission tc ";
		sql += " where b.billid = tc.billid and b.billtype='extendCommision' and b.billtypecate='billType') >0 then (select round(tc.amount,4) ";
		sql += " from t_commission tc ";
		sql += " where b.billid = tc.billid and b.billtype='extendCommision' and b.billtypecate='billType')else 0 end yjamount, ";
		sql += " g.orderid orderid ";
		sql += " from t_member m, t_Generic_Order g, t_bill b ";
		sql += " left join t_commission tc on b.billid = tc.billid ";
		sql += " where 1 = 1 ";
		sql += " and g.orderid = b.orderid ";
		sql += " and g.buyer = m.memberid ";
		sql += "  and g.seller ='" + memberid + "'";
		sql += "  and b.billtype in('credit','payOnLine','onlinetracash') and b.billtypecate='billType'";

		if (!StringUtil.isEmpty(membername)) {
			sql += " and m.membername like '%" + membername + "%'";
		}

		if (!StringUtil.isEmpty(paytyep)) {
			if (paytyep == "15369") {
				sql += " and b.paymentmethod in(81,82,83)";
			} else {

			}
		}

		if (!StringUtil.isEmpty(billtype)) {
			sql += " and b.billtype='" + billtype + "'";
		}

		if (!StringUtil.isEmpty(statetime)) {
			sql += " and  b.paymentdate >=" + "to_date(to_char('" + statetime
					+ "'),'yyyy-mm-dd')";
		}
		if (!StringUtil.isEmpty(endtime)) {
			sql += " and  b.paymentdate <=" + "to_date(to_char('" + endtime
					+ "'),'yyyy-mm-dd')";
		}
		sql += " and g.objecttype='" + objecttype + "'";

		sql += " ) a ";
		sql += " ) b ";
		sql += " ) c ";

		return this.findSql(sql, pageNo, pageSize);
	}

	@Override
	public List getTotalTransactionFinanceList(String memberid,
			String membername, String statetime, String endtime,
			String objecttype, String quotatype, String paytyep, String billtype) {
		String sql = " select sum(amount), ";
		sql += " sum((sfamount+sxfamount+yjamount)), ";
		sql += " sum(jsramount) ";
		sql += " from( ";
		sql += " select c.*, ";
		sql += " case ";
		sql += " when qkamount > 0 then ";
		sql += " ljfkamount ";
		sql += " else ";
		sql += " 0 ";
		sql += " end ljysramount ";
		sql += " from (select b.*, (factamount - ljfkamount) qkamount";
		sql += " from (select a.*, ";
		sql += " (select round(sum(bl.amount),4) ";
		sql += " from t_bill bl ";
		sql += " where a.orderid = bl.orderid  and bl.billtype in('creditRepayment','payOnLine','onlinetracash') and bl.billtypecate='billType' ) ljfkamount, ";
		sql += "  case when factamount =amount then (((amount - sfamount) - sxfamount) - yjamount) else 0 end jsramount ";
		sql += " from (select m.memberid, ";
		sql += " m.membername, ";
		sql += " (select p.realname ";
		sql += " from t_member_person p ";
		sql += " where p.memberid = g.buyer) realname, ";
		sql += " (select o.orgname ";
		sql += " from t_member_organ o ";
		sql += " where o.memberid = g.buyer) orgname, ";
		sql += " (select case when td.dictid in(81,82) then '线上交易' else '线下交易' end ";
		sql += " from t_dictionary td ";
		sql += " where b.paymentmethod = td.dictid) payname, ";
		sql += " b.paymentdate, ";
		sql += " b.transactionid, ";
		sql += " (select td.typename ";
		sql += " from t_dictionary td ";
		sql += " where b.paymentmethod = td.dictid) billname, ";
		sql += " round((g.factamount),4) factamount, ";

		sql += " (select round(sum(bl.amount), 4) ";
		sql += " from t_bill bl ";
		sql += " where g.orderid = bl.orderid ";
		sql += " and bl.billtype in ";
		sql += " ('creditRepayment', 'payOnLine', 'onlinetracash') ";
		sql += " and bl.billtypecate = 'billType') amount, ";
		sql += " case ";
		sql += " when  b.billtype = 'transactionTax' and b.billtypecate='billType' then ";
		sql += " round(b.amount,4) else 0 ";
		sql += " end sfamount, ";
		sql += " case ";
		sql += " when b.billtype = 'transactionFees' and b.billtypecate='billType' then ";
		sql += " round(b.amount,4) else 0 ";
		sql += " end sxfamount, ";
		sql += " case when  (select tc.amount ";
		sql += " from t_commission tc ";
		sql += " where b.billid = tc.billid and b.billtype='extendCommision' and b.billtypecate='billType') >0 then (select round(tc.amount,4) ";
		sql += " from t_commission tc ";
		sql += " where b.billid = tc.billid and b.billtype='extendCommision' and b.billtypecate='billType')else 0 end yjamount, ";
		sql += " g.orderid orderid ";
		sql += " from t_member m, t_Generic_Order g, t_bill b ";
		sql += " left join t_commission tc on b.billid = tc.billid ";
		sql += " where 1 = 1 ";
		sql += " and g.orderid = b.orderid ";
		sql += " and g.buyer = m.memberid ";
		sql += "  and g.seller ='" + memberid + "'";
		sql += "  and b.billtype in('credit','payOnLine','onlinetracash') and b.billtypecate='billType'";

		if (!StringUtil.isEmpty(membername)) {
			sql += " and m.membername like '%" + membername + "%'";
		}

		if (!StringUtil.isEmpty(paytyep)) {
			if (paytyep == "15369") {
				sql += " and b.paymentmethod in(81,82,83)";
			} else {

			}
		}

		if (!StringUtil.isEmpty(billtype)) {
			sql += " and b.billtype='" + billtype + "'";
		}

		if (!StringUtil.isEmpty(statetime)) {
			sql += " and  b.paymentdate >=" + "to_date(to_char('" + statetime
					+ "'),'yyyy-mm-dd')";
		}
		if (!StringUtil.isEmpty(endtime)) {
			sql += " and  b.paymentdate <=" + "to_date(to_char('" + endtime
					+ "'),'yyyy-mm-dd')";
		}
		sql += " and g.objecttype='" + objecttype + "'";

		sql += " ) a ";
		sql += " ) b ";
		sql += " ) c ";
		sql += " ) d ";
		return getSession().createSQLQuery(sql).list();

	}

	@Override
	public List getTotalHotelOrderFinanceList(String memberid,
			String membername, String statetime, String endtime,
			String objecttype, String quotatype, String grouptype) {
		String sql = "select case when sum(totalAmount)>0 then round(sum(totalAmount),4) else 0 end totalAmount,";
		sql += " case when sum(factAmout)>0 then round(sum(factAmout),4) else 0 end  factAmout,";

		sql += " case when sum(linefactamount)>0 then round(sum(linefactamount),4) else 0 end  linefactamount,";
		sql += " case when sum(downfactamount)>0 then round(sum(downfactamount),4) else 0 end downfactamount,";
		sql += " case when sum(amount)>0 then round(sum(amount),4) else 0 end amount,";
		sql += " case when sum(lineamount)>0 then round(sum(lineamount),4) else 0 end lineamount,";
		sql += " case when sum(downamount)>0 then round(sum(downamount),4) else 0 end downamount,";

		sql += "  round(sum(quota),4) quota,";
		sql += "  round(sum(quotaused),4) quotaused,";
		sql += " case when sum(damount) >0 then round(sum(damount),4) else 0 end damount,";
		sql += " case when sum(dtotalamount)>0 then round(sum(dtotalamount),4) else 0 end dtotalamount";
		sql += " from";
		sql += " ( ";
		sql += "select distinct  ";
		sql += " Buyer, ";
		sql += " membername,";
		sql += " realname, ";
		sql += " orgname,";
		sql += " max(totalAmount) totalAmount,";
		sql += " max(factAmout) factAmout,";

		sql += " max(linefactamount) linefactamount,";
		sql += " max(downfactamount) downfactamount,";
		sql += " max(amount) amount,";
		sql += " max(lineamount) lineamount,";
		sql += " max(downamount) downamount,";

		sql += " max(quota) quota,";
		sql += " max(quotaused) quotaused,";
		sql += " case when max(damount) >0 then max(damount)  else 0 end damount, ";
		sql += " max(dtotalamount) dtotalamount,";
		sql += " seller";

		sql += " from";
		sql += " (";

		sql += " select g.Buyer Buyer,";
		sql += " g.membername,";
		sql += " (select p.realname from t_member_person p where p.memberid =g.buyer) realname,";
		sql += " (select o.orgname from t_member_organ o where o.memberid =g.buyer) orgname,";
		sql += " sum(g.totalAmount) totalAmount ,";
		sql += " sum(g.factamount) factAmout,";

		sql += " case when g.paymentmethod='81' and g.billtype ='payOnLine'  and g.billtypecate='billType' then sum(g.factamount) else 0 end linefactamount,";
		sql += " case when g.paymentmethod='80' and g.billtype ='payLinetrading'  and g.billtypecate='billType' then sum(g.factamount) else 0 end downfactamount,";
		sql += " sum(ddamount) amount ,";
		sql += " case when g.paymentmethod='81' and g.billtype ='payOnLine' and g.billtypecate='billType' then sum(g.amount) else 0 end lineamount,";
		sql += " case when g.paymentmethod='80' and g.billtype ='payLinetrading'  and g.billtypecate='billType' then sum(g.amount) else 0 end downamount,";

		sql += " (select sum(gm.quota) from t_group_member gm where g.buyer =gm.memberid and gm.quotatype='"
				+ quotatype
				+ "'  and gm.groupid in (select vg.groupid from t_vip_group vg where g.seller=vg.reseller and vg.grouptype='"
				+ grouptype + "'))quota,";
		sql += " (select sum(gm.quotaused) from t_group_member gm where g.buyer =gm.memberid and gm.quotatype='"
				+ quotatype
				+ "'  and gm.groupid in (select vg.groupid from t_vip_group vg where g.seller=vg.reseller and vg.grouptype='"
				+ grouptype + "'))quotaused,";
		sql += " sum(g.damount) damount,";
		sql += " sum(g.dtotalamount) dtotalamount,";
		sql += " g.seller ";
		sql += " from(select distinct m.*,b.*,g.*,case when mqd.amount>0 then mqd.amount else 0 end dtotalamount ,";
		sql += " (select sum(bl.amount) from t_bill bl where bl.orderid= g.orderid and bl.billtype in ('creditRepayment', 'payOnLine', ";
		sql += " 'payLinetrading', 'payLinetradingCash', ";
		sql += " 'onlinetracash')) ddamount,";
		sql += " (select sum(bl.amount) from t_bill bl where bl.orderid= g.orderid and bl.billtype in ('creditRepayment', 'payOnLine', ";
		sql += " 'payLinetrading', 'payLinetradingCash', ";
		sql += " 'onlinetracash'))damount";
		sql += " from t_member m,t_bill b ,t_Generic_Order g";
		sql += " left join t_member_quota_detail mqd on mqd.objecttype='"
				+ quotatype + "' and mqd.member = g.buyer";

		sql += " where 1=1";
		sql += " and g.orderid =b.orderid";
		sql += " and g.buyer =m.memberid  and g.objecttype =b.objecttype ";
		sql += "  and g.seller ='" + memberid + "'";
		sql += " and b.billtype in ('credit', 'payOnLine','payLinetrading', 'payLinetradingCash','onlinetracash')";

		if (!StringUtil.isEmpty(membername)) {
			sql += " and m.membername like '%" + membername + "%'";
		}

		if (!StringUtil.isEmpty(statetime)) {
			sql += " and  to_date(to_char(b.paymentdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') >="
					+ "to_date(to_char('" + statetime + "'),'yyyy-mm-dd')";
		}
		if (!StringUtil.isEmpty(endtime)) {
			sql += " and  to_date(to_char(b.paymentdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') <="
					+ "to_date(to_char('" + endtime + "'),'yyyy-mm-dd')";
		}
		sql += " and g.objecttype='" + objecttype + "'";

		sql += " )g";
		sql += " group by g.Buyer,g.membername,g.mobileno,g.seller,g.paymentmethod,g.billtypecate,g.billtype";
		sql += " )a  group by Buyer,membername,realname,orgname,seller)";
		return getSession().createSQLQuery(sql).list();
	}

	@Override
	public Pagination getListByBuyerFinanceOrder(String buyer,
			String statetime, String endtime, String objecttype, int pageNo,
			int pageSize) {
		String sql = "select distinct g.*, (select p.realname from t_member_person p where p.memberid =g.buyer) realname,  ";
		sql += "  (select o.orgname from t_member_organ o where o.memberid =g.buyer) orgname , ";
		sql += " (select m.mobileno from t_member m where m.memberid = g.buyer) mobileno ";
		sql += " from t_generic_order g,t_bill b where g.orderid =b.orderid and g.buyer ="
				+ buyer;

		if (!StringUtil.isEmpty(statetime)) {
			sql += " and g.orderDate >=to_date('" + statetime
					+ "','yyyy-MM-dd') ";
		}
		if (!StringUtil.isEmpty(endtime)) {
			sql += " and g.orderDate <=to_date('" + endtime
					+ "','yyyy-MM-dd') ";
		}
		sql += "  and g.objectType ='" + objecttype + "'";
		sql += " order by g.orderId desc";
		return this.findSql(sql, pageNo, pageSize);
	}

	@Override
	public List<GenericOrder> getListByBuyer(String buyer) {
		String hql = "from GenericOrder g where g.buyer =" + buyer;
		return getSession().createQuery(hql).list();
	}
	
	@Override
    public String getObjectIdByOrderId(String orderId,String orderStyle){
		//2酒店订单 3餐饮 4景点 5娱乐 6旅运 7导游
    	  String sql2= "select b.hotelid from t_generic_order a,t_order_detail_hotel b " +
    	  	      	   " where a.orderid=b.orderid and a.orderid='"+orderId+"' and rownum<=1 ";
    	  
    	  String sql3= "select b.restaurantid from t_generic_order a,t_order_detail_restaurant b " +
    	  		       " where a.orderid=b.orderid and a.orderid='"+orderId+"' and rownum<=1 ";
    	  
    	  String sql4= "select b.sceneryid from t_generic_order a,t_order_detail_gate b " +
    	  		       " where a.orderid=b.orderid and a.orderid='"+orderId+"' and rownum<=1 ";
    	  
    	  String sql5= "select b.entertainmentid from t_generic_order a,t_order_detail_show b" +
    	  		       " where a.orderid=b.orderid and a.orderid='"+orderId+"' and rownum<=1 ";
    	  
    	  String sql6= "select b.transportid from t_generic_order a,t_order_detail_transport b" +
    	  		       " where a.orderid=b.orderid and a.orderid='"+orderId+"' and rownum<=1 ";
    	  
    	  String sql7= " select b.guideid from t_generic_order a,t_order_detail_guide b" +
    	  		       " where a.orderid=b.orderid and a.orderid='"+orderId+"' and rownum<=1"; 
    	  
    	  
    	  int flag = Integer.parseInt(orderStyle);
    	  String sql = "";
    	  switch(flag){
    	     case 2:
    	    	 sql = sql2;
    	    	 break;
    	     case 3:
    	    	 sql = sql3;
    	    	 break;
    	     case 4:
    	    	 sql = sql4;
    	    	 break;
    	     case 5:
    	    	 sql = sql5;
    	    	 break;
    	     case 6:
    	    	 sql = sql6;
    	    	 break;
    	     case 7:
    	    	 sql = sql7;
    	    	 break;
    	  }
    	  
    	  String objectId = "";
    	  if(!StringUtil.isEmpty(sql)){
	    	  Query query =  getSession().createSQLQuery(sql);
	    	  List list = query.list();
	    	  
	    	  if(list!=null&&list.size()>0){
	    		  Object object = (Object)list.get(0);
	    		  objectId = object.toString();  
	    	  }
    	  }
    	  return objectId;
    }

	@Override
	public boolean orderIsOverdue(String orderId) {
		
		String sql="select  count(*)  from (select orderid ,STARTDATE as time from t_order_detail_gate " +
				"  union all select orderid,CHECKIN as time from t_order_detail_hotel " +
				" union all select orderid,STARTDATE  as time from t_order_detail_guide  " +
				" union all select orderid,STARTDATE  as time from t_order_detail_show  " +
				" union all select orderid,STARTTIME as time  from t_order_detail_restaurant  " +
				" union all select orderid,STARTDATE  as time from t_order_detail_transport)  a " +
				"where orderid='"+orderId+"' and time<(Sysdate-1) ";
		String count =getSession().createSQLQuery(sql).list().get(0).toString();
		int result=Integer.parseInt(count);
		if(result>0){
			return true;
		}
		return false;
	}

	@Override
	public String saveGenericOrder(Member seller, Member buyer,
			String orederName, String description,String remark, Dictionary objectType,
			Dictionary orderType) {
		    GenericOrder genericOrder =  new GenericOrder();
	        genericOrder.setOrderId(this.getSeqn());
	        genericOrder.setBuyer(buyer);
	        genericOrder.setSeller(seller);
	        genericOrder.setSales(MemberThread.get());
	        genericOrder.setDescription(description);
	        genericOrder.setName(orederName);
	        genericOrder.setObjectType(objectType);//订单类型
	        genericOrder.setOrderDate(DateUtil.getSystemTimestamp());
	        genericOrder.setOrderStatus(new Dictionary("12000"));
	        
	        genericOrder.setOrderType(orderType);//代理下单or客户下单
	        genericOrder.setEstimateStatus(new Dictionary("12909"));
	        genericOrder.setRemark(remark);
	        genericOrder.setPaymentstatus("0");
	        genericOrder.setRefundstatus("0");
		return this.save(genericOrder);
	}
	
	@Override
	public List<GenericOrder> getGenericOrder(String memberId,String dictid1,String dictid2){
		String sql = "select * from t_generic_order t where (t.seller='"+memberId+"' or t.buyer='"+memberId+"' or t.sales='"+memberId+"')"
				+ " and t.orderstatus !='"+dictid1+"' and t.orderstatus !='"+dictid2+"' " ;
        List<GenericOrder> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(GenericOrder.class).list();
        return resultList;
	}
	
	public List getPaymentStatus(String planId,String dictId){
		String sql = "select decode(t.paymentstatus,'0','未付款','1','已付款','2','部分付款') ,t.orderid "
				+ " from t_generic_order t where t.objecttype='"+dictId+"' and t.sourceid='"+planId+"'";
		List list = this.getSession().createSQLQuery(sql).list();
		return list;
	}

}
