package com.cct9k.dao.order.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.OrderDetailPlanDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.OrderDetailPlan;
import com.cct9k.entity.reseller.Visitor;
import com.cct9k.util.common.StringUtil;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:38
 */
@Repository
public class OrderDetailPlanDaoImpl extends BaseDaoImpl<OrderDetailPlan, String> implements OrderDetailPlanDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from OrderDetailPlan model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public List<OrderDetailPlan> getDetailsByOrderId(String orderId) {
        Finder r = Finder.create("from OrderDetailPlan model where 1=1");

        if (!StringUtil.isEmpty(orderId)) {
            r.append(" and model.order.orderId = :orderId ");
            r.setParam("orderId", orderId);
        }

        r.append(" order by model.detailId desc");

        return find(r);
    }
    
    @Override
    public Pagination searchOrderWithOnsaleByResellerAndBuyer(Member reseller, String buyer, Date start, Date end, int pageNo, int pageSize) {
        Finder r = Finder.create("from OrderDetailPlan model where 1=1");

        if (reseller != null) {
            r.append(" and model.order.seller.memberid = :memberid ");
            r.setParam("memberid", reseller.getMemberid());
        }

        if (!StringUtil.isEmpty(buyer)) {
            r.append(" and model.order.buyer.memberPerson.realname like '%'||:buyer||'%' or model.order.buyer.memberOrgan.orgname like '%'||:buyer||'%'");
            r.setParam("buyer", buyer);
        }

        if (start != null) {
            r.append(" and model.onsale.starttime >=:start ");
            r.setParam("start", start);
        }

        if (end != null) {
            r.append(" and model.onsale.starttime <=:end ");
            r.setParam("end", end);
        }

        r.append(" order by model.detailId desc");

        return find(r, pageNo, pageSize);
    }
    @Override
    public String getVisitCoutByRoute(String routeid){
		String sql="select count(v.visitorid) from t_visitor v left join t_order_detail_plan p  on  v.orderid=p.orderid where  p.routeid='"+routeid+"'";
	   String Visitcount =this.getSession().createSQLQuery(sql).list().get(0).toString();
		return Visitcount;
		
	}
    
    
    public List<OrderDetailPlan> getVisitorListByOnsaleIdAndIdentityNo(String identityNo) {
        String sql ="select a.* from t_order_detail_plan a,t_visitor b,t_customer c where a.orderid=b.orderid  and " +
        		    " b.customerid=c.customerid and c.identityno='"+identityNo+"'";
        
        List<OrderDetailPlan> resultList = this.getSession().createSQLQuery(sql).addEntity(OrderDetailPlan.class).list();
        
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        } else {
            return null;
        }
    }
    
    @Override
	public List<Visitor> getAllVisitorByOnsaleId(String onsaleId) {
		String sql = "SELECT V.* FROM T_ORDER_DETAIL_PLAN P, T_VISITOR V WHERE P.ONSALEID=:onsaleId AND P.ORDERID = V.ORDERID";
		SQLQuery query = this.getSession().createSQLQuery(sql);
		return query.addEntity(Visitor.class).setParameter("onsaleId", onsaleId).list();
	}
    
}
