package com.cct9k.dao.order.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.member.MemberDao;
import com.cct9k.dao.order.OrderEstimateInfoDao;
import com.cct9k.entity.order.OrderEstimateInfo;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-9
 * Time: 下午5:29
 */
@Repository
public class OrderEstimateInfoDaoImpl extends BaseDaoImpl<OrderEstimateInfo, String> implements OrderEstimateInfoDao {

	 @Resource
     private MemberDao dao;
	 @Override
		public String getSeqn() {
			String sql = " select S_ORDER.nextval from dual";
			Query query = getSession().createSQLQuery(sql);
			BigDecimal b = (BigDecimal) query.uniqueResult();
			return b.toString();
		}
	
    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from OrderEstimateInfo model where 1=1");

        r.append(" order by evaluatetime desc");

        return find(r, pageNo, pageSize);
    }
  
	

}
