package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.OrderDetailPlanGate;

public interface OrderDetailPlanGateDao extends BaseDao<OrderDetailPlanGate, String> {
	
	public List<OrderDetailPlanGate> getDetailGateByOrderId(String orderId,String routestopid,String detailId,String gateId) ;
}
