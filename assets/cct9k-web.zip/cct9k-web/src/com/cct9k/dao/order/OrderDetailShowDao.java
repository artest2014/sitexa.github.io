package com.cct9k.dao.order;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Entertainment;
import com.cct9k.entity.order.OrderDetailShow;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:39
 */
public interface OrderDetailShowDao extends BaseDao<OrderDetailShow, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public List<OrderDetailShow> getDetailsByOrderId(String orderId);
    
    public boolean deleteOrderDetailShow(String sourceId);
    
    public boolean deleteShowOrderByOrderId(String orderId);
    /**
     * 根据订单id查询景点。已去重复
     * @param orderId
     * @return
     */
    public List<Entertainment> getEntertainmentByOrderId(String orderId);

}
