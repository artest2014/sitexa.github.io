package com.cct9k.dao.order.impl;

import java.util.List;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.OrderDetailGuideDao;
import com.cct9k.entity.order.OrderDetailGuide;
import com.cct9k.entity.order.OrderDetailShow;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-22
 * Time: 上午9:36
 */
@Repository
public class OrderDetailGuideDaoImpl extends BaseDaoImpl<OrderDetailGuide, String> implements OrderDetailGuideDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from ... model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }
    
    @Override
    public List<OrderDetailGuide> getDetailsByOrderId(String orderId) {
        String sql="select t.* from t_order_detail_guide t where 1=1 ";
        if (!StringUtil.isEmpty(orderId)) {
            sql+=" and t.orderid = '"+orderId+"' ";
        }
        sql+=" order by t.detailid desc";
        Query query = this.getSession().createSQLQuery(sql).addEntity(OrderDetailGuide.class);
		List<OrderDetailGuide> resultList = query.list();
		if (resultList != null && resultList.size() > 0) {
			return resultList;
		} else {
			return null;
		}
    }
    
    public boolean deleteOrderDetailGuide(String sourceId) {
        String sql = "delete from t_order_detail_guide where orderid in( select t.orderid  from t_generic_order t where t.sourceid=?)";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, sourceId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public boolean deleteGuideOrderByOrderId(String orderId){
    	String sql = "delete from t_order_detail_guide where orderid =?";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, orderId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

}
