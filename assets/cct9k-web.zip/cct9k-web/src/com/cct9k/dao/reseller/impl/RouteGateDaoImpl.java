package com.cct9k.dao.reseller.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.RouteGateDao;
import com.cct9k.entity.customer.Customer;
import com.cct9k.entity.reseller.RouteGate;
import com.cct9k.entity.reseller.RouteStop;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:10
 */
@Repository
public class RouteGateDaoImpl extends BaseDaoImpl<RouteGate, String> implements RouteGateDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from RouteGate model where 1=1");

        r.append(" order by gate desc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public List<RouteGate> findByStopAndScenery(RouteStop routestop, Customer customer) {
        Finder f = Finder.create("from RouteGate model where model.routestop.stopid=:stopid and model.customer.customerid=:sceneryid order by routegateid asc ");
        f.setParam("stopid", routestop.getStopid()).setParam("sceneryid", customer.getCustomerid());
        return find(f);
    }

}
