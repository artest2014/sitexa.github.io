package com.cct9k.dao.reseller;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.RouteHotel;

public interface RouteHotelDao extends BaseDao<RouteHotel, String> {
	
	void deleteByStopId(String stopId);
	
}
