package com.cct9k.dao.reseller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanGateDao;
import com.cct9k.entity.reseller.PlanGate;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com> Date: 13-8-10 Time: 下午1:51
 */
@Repository
public class PlanGateDaoImpl extends BaseDaoImpl<PlanGate, String> implements PlanGateDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PlanGate model where 1=1");

        r.append(" order by gate asc");

        return find(r, pageNo, pageSize);
    }

    /*
     * 
     * <p>Title: queryPlanGateResources</p> <p>Description: </p>
     * 
     * @param planId
     * 
     * @return
     * 
     * @see
     * com.cct9k.dao.reseller.PlanGateDao#queryPlanGateResources(java.lang.String
     * )
     */
    @Override
    public List<Map<String, Object>> queryPlanGateResources(String planId) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("PLANID", planId);
        sql.append(" SELECT PS.STOPID AS PLANSTOPID, TT.STOPID ROUTESTOPID, TT.STOPNAME, TT.GATEID, TT.CUSTOMERNAME,  T.ADULTQUANTITY, T.CHILDRENQUANTITY FROM ");
        sql.append(" (SELECT MAX(VSPR.PLANID) PLANID, MAX(VSPR.VISITORID) VISITORID,  SUM(CASE WHEN V.ISCHILD = 0 THEN 1 ELSE 0 END) AS CHILDRENQUANTITY,");
        sql.append(" SUM(CASE WHEN V.ISCHILD = 1 THEN 1 ELSE 0 END) AS ADULTQUANTITY,  MAX(VSPR.ONSALEID) ONSALEID, MAX(VSPR.ORDERID) ORDERID,");
        sql.append(" VSPR.DEPARTURESITE, VSPR.DESTINATIONSITE FROM (SELECT  T1.*, T2.DEPARTURESITE, T2.DESTINATIONSITE FROM T_VISITOR_STOP_PLAN_REL T1");
        sql.append(" INNER JOIN T_ROUTE_STOP T2 ON T1.ROUTESTOPID=T2.STOPID WHERE T1.PLANID =:PLANID) VSPR");
        sql.append(" INNER JOIN T_VISITOR V ON VSPR.VISITORID = V.VISITORID");
        sql.append(" GROUP BY VSPR.DEPARTURESITE, VSPR.DESTINATIONSITE) T");
        sql.append(" INNER JOIN (SELECT RS.*, RG.GATEID, C.CUSTOMERNAME FROM T_ROUTE_STOP RS ");
        sql.append(" INNER JOIN T_PLAN P ON RS.ROUTEID=P.ROUTEID ");
        sql.append(" INNER JOIN T_ROUTE_GATE RG ON RS.STOPID=RG.STOPID");
        sql.append(" INNER JOIN T_CUSTOMER C ON RG.GATEID = C.CUSTOMERID WHERE P.PLANID=:PLANID) TT");
        sql.append(" ON T.DEPARTURESITE=TT.DEPARTURESITE AND T.DESTINATIONSITE=TT.DESTINATIONSITE");
        sql.append(" LEFT JOIN  T_PLAN_STOP  PS ON PS.DEPARTURESITE=TT.DEPARTURESITE AND PS.DESTINATIONSITE=TT.DESTINATIONSITE AND  PS.PLANID=:PLANID");
        return this.simpleSpringJdbcTemplate.queryForMap(sql, paramMap);
    }

    /*
     * 
    * <p>Title: getStopGateRecourcesExists</p>
    * <p>Description: </p>
    * @param stopid
    * @param string
    * @return
    * @see com.cct9k.dao.reseller.PlanGateDao#getStopGateRecourcesExists(java.lang.String, java.lang.String)
     */
    @Override
    public Boolean getStopGateRecourcesExists(String stopid, String string) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("stopid", stopid);
        paramMap.put("sceneryid",string);
        sql.append(" select * from t_plan_gate tpg where tpg.stopid = :stopid and tpg.sceneryid = :sceneryid ");
        return this.simpleSpringJdbcTemplate.isDataExists(sql, paramMap);
    }

    /*
     * 
    * <p>Title: queryPlanShowSourceOrderDetail</p>
    * <p>Description: </p>
    * @param planId
    * @param planStopId
    * @param customerId
    * @return
    * @see com.cct9k.dao.reseller.PlanGateDao#queryPlanShowSourceOrderDetail(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public List<Map<String, Object>> queryPlanGateSourceOrderDetail(String planId, String planStopId, String customerId) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("planId", planId);
        paramMap.put("planStopId", planStopId);
        paramMap.put("customerId", customerId);
        
        sql.append("select rs.planid, rs.stopname, rs.orderid, tgo.name, tc.customername, rs.adultquantity, rs.childrenquantity  from ( ");
        sql.append("select planid, stopid, stopname, routestopid, sum(adultquantity) adultquantity, sum(childrenquantity) childrenquantity, orderid,  gateid from( ");
        sql.append("select distinct tps.planid, tps.stopid, tps.stopname, tps.routestopid,  tv.visitorid, tv.orderid, tgo.name, sign(todpg.adultquantity) adultquantity, sign(todpg.childrenquantity) childrenquantity, todpg.gateid from ");
        sql.append("t_plan_stop tps , t_visitor_stop_plan_rel tvspr,  t_visitor tv, t_generic_order tgo, t_order_detail_plan_gate todpg ");
        sql.append("where tps.planid = :planId and tps.stopid = :planStopId and todpg.gateid = :customerId ");
        sql.append("and tvspr.routestopid in (select trs1.stopid from t_route_stop trs, t_route_stop trs1 where trs.stopid = tps.ROUTESTOPID and trs1.destinationsite = trs.destinationsite and trs1.departuresite = trs.departuresite ) ");
        sql.append("and tps.planid = tvspr.planid ");
        sql.append("and tvspr.visitorid = tv.visitorid ");
        sql.append(" and tv.orderid = tgo.orderid ");
        sql.append("and todpg.orderid = tgo.orderid ");
        sql.append(" and tvspr.routestopid = todpg.routestopid ");
        sql.append(") rs group by planid, stopid, stopname, routestopid, orderid, gateid ");
        sql.append(") rs , t_generic_order tgo , t_customer tc ");
        sql.append("where rs.gateid = tc.customerid ");
        sql.append("and rs.orderid = tgo.orderid ");
        
        return this.simpleSpringJdbcTemplate.queryForMap(sql, paramMap);
    }

	@Override
	public List<?> getPlanGateOrders(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select a.planid,                                                    ");
		querySql.append("        null as orderid,                                             ");
		querySql.append("        '自维护客户' as customersource,                              ");
		querySql.append("        null as ordername,                                           ");
		querySql.append("        d.productname,                                               ");
		querySql.append("        c.customername,                                              ");
		querySql.append("        null as orderdate,                                           ");
		querySql.append("        b.totalquantity,                                             ");
		querySql.append("        b.amount,                                                    ");
		querySql.append("        null as orderstatus,                                         ");
		querySql.append("        null as paymentstatus,                                       ");
		querySql.append("        null as estimatestatus                                       ");
		querySql.append("   from t_plan a, t_plan_gate b, t_customer c, t_customer_product d  ");
		querySql.append("  where a.planid = b.planid                                          ");
		querySql.append("    and b.sceneryid = c.customerid                                   ");
		querySql.append("    and b.product = d.productid(+)                                   ");
		querySql.append("    and a.planid = :planid                                           ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);
		
        return query.list();
	}
}
