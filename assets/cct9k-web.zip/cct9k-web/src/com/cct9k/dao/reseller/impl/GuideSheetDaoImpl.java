package com.cct9k.dao.reseller.impl;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.GuideSheetDao;
import com.cct9k.entity.finance.CheckSheet;

@Repository
public class GuideSheetDaoImpl extends BaseDaoImpl<CheckSheet, String> implements GuideSheetDao {
	
	protected Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Override
	public Pagination getSelectablePlan(String guiderId,String startTime,String planName, String resellerName,int pageNo, int pageSize) {
		
		/*
		 * zouyang update 2014-3-10
		 * 业务逻辑更改为每个团由带团导游创建提交一次报帐批次，仅能创建提交一次，再次创建须删除之后创建
		 * 以导游为条件查询出团队表中的团队记录然后减去在报帐批次表中已经存在的团队记录，剩下的即为当前导游帐号还可以创建报帐批次的团队记录
		 */
		
//		 String sql="select a.planid,a.starttime,a.planname,case when c.orgname is not null ";
//		 sql+="then c.orgname else d.realname end,e.membername from t_plan a,t_route b,t_member_organ c,t_member_person d ,t_member e ";
//		 sql+=" where a.routeid=b.routeid and a.reseller=c.memberid(+) and a.reseller=d.memberid(+) and a.reseller=e.memberid and a.guide="+guiderId;
//		 
//		 Calendar cal = Calendar.getInstance(); 
//		 DateFormat d1 = DateFormat.getDateTimeInstance(); 
//		 String str1 = d1.format(cal.getTime());
//		 sql+=" and a.starttime<=to_date('"+str1+"','yyyy-mm-dd hh24:mi:ss')";
		
		Map<String, Object> m = new HashMap<String,Object>();
		
		 StringBuffer sql = new StringBuffer("select a.planid,a.starttime,a.planname,case when c.orgname is not null then c.orgname else d.realname end,e.membername ");
		 sql.append("from t_plan a,t_member_organ c,t_member_person d ,t_member e ");
		 sql.append( "where a.reseller=c.memberid(+) and a.reseller=d.memberid(+) and a.reseller=e.memberid and a.guide=");
		 sql.append(":guideid ");
		 
		 m.put("guideid", guiderId);
		 
		 if(!StringUtils.isEmpty(startTime)){
//	    	 sql+=" and a.starttime>=to_date('"+startTime+" 00:00:00','yyyy-mm-dd hh24:mi:ss') and a.starttime<=to_date('"+startTime+" 23:59:59','yyyy-mm-dd hh24:mi:ss')";
			 
			 sql.append(" and a.starttime>=to_date(:starttime_1,'yyyy-mm-dd hh24:mi:ss') and a.starttime<=to_date(:starttime_2,'yyyy-mm-dd hh24:mi:ss')");
			 
			 m.put("starttime_1", startTime + " 00:00:00");
			 m.put("starttime_2", startTime + " 23.59.59");
	    	
//		     try {
//		    	 
//		    	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//				 Date date = new java.sql.Date(sdf.parse(startTime).getTime());         // 日期转化失败，则进catch块，下面代码不执行
//				 
//				 sql.append(" and a.starttime = :starttime ");   //如果日期转化失败，此句不执行
//				 m.put("starttime", date);                     //如果日期转化失败，此句不执行
//				
//			} catch (ParseException e) {
//				e.printStackTrace();
//				log.debug("日期类型转化失败，日期条件被忽略。");
//			}
		     
	     }
	     if(!StringUtils.isEmpty(planName)){
//	    	 sql+=" and a.planname like '%"+planName+"%'";
	    	 sql.append("  and a.planname like :planname ");
	    	 planName = "%"+planName+"%";
	    	 m.put("planname", planName);
	     }
	     if(!StringUtils.isEmpty(resellerName)){
//	    	 sql+=" and (c.orgname like '%"+resellerName+"%' or d.realname like '%"+resellerName+"%') ";
	    	 sql.append("and ( c.orgname like :resellername or d.realname like :resellername) ");
	    	 resellerName = "%"+resellerName+"%";
	    	 m.put("resellername", resellerName);
	     }
	     
	     sql.append(" and a.planid not in (select tcs.planid from t_check_sheet tcs where tcs.memberid = :guideid)");
		
	     return findSql(sql.toString(),null,m, pageNo, pageSize);
	     
	 }
	
	@Override
	public Pagination getSheetInfoList(String guiderId,String startTime,String planName,String sheetStatus,String resellerName,int pageNo, int pageSize){
		String sql="select a.planid,b.starttime,b.planname,a.invoicenum,a.status,a.sheetid, ";
		sql+="case when d.orgname is not null then d.orgname else e.realname end ";
		sql+="from t_check_sheet a,t_plan b,t_route c,t_member_organ d,t_member_person e ";
		sql+="where a.planid=b.planid and b.routeid=c.routeid and b.reseller=d.memberid(+) and b.reseller=e.memberid(+) ";
		sql+=" and b.guide="+guiderId;
		if(!StringUtils.isEmpty(startTime)){
	    	 sql+=" and b.starttime>=to_date('"+startTime+" 00:00:00','yyyy-mm-dd hh24:mi:ss') and b.starttime<=to_date('"+startTime+" 23:59:59','yyyy-mm-dd hh24:mi:ss')";
	     }
		if(!StringUtils.isEmpty(planName)){
	    	 sql+=" and b.planname like '%"+planName+"%'";
	     }
		if(!StringUtils.isEmpty(resellerName)){
	    	 sql+=" and (d.orgname like '%"+resellerName+"%' or e.realname like '%"+resellerName+"%') ";
	     }
		if(!StringUtils.isEmpty(sheetStatus)){
	    	 sql+=" and a.status='"+sheetStatus+"'";
	     }
//		System.out.println("B:"+sql);
		return findSql(sql, pageNo, pageSize);
	}
	@Override
	public Pagination getSelectableObj(String sheetId,String tableId,String objName,int pageNo, int pageSize){
		Map<String, Object> params = new HashMap<String, Object>();
		StringBuffer sql = new StringBuffer("SELECT  C.CUSTOMERID,C.CUSTOMERNAME FROM T_CHECK_SHEET CS,T_PLAN P,T_CUSTOMER C WHERE CS.PLANID = P.PLANID AND P.RESELLER = C.OWNERID AND C.CUSTOMERTYPE =:TABLEID AND CS.SHEETID =:SHEETID ");
//		String sql1="select distinct c.customerid,c.customername from t_check_sheet a,t_plan_restaurant b,t_customer c where a.planid=b.planid and b.restaurant=c.customerid and a.sheetid="+sheetId;
////		String sql2="select distinct c.customerid,c.customername from t_check_sheet a,t_plan_hotel b,t_customer c where a.planid=b.planid and b.hotel=c.customerid and a.sheetid="+sheetId;
//		String sql2="select distinct c.customerid,c.customername from t_check_sheet cs,t_plan p,t_customer c where cs.planid = p.planid and p.reseller = c.ownerid and c.customertype =: and cs.sheetid =:sheetId ";   //查出团队所属旅行社所签约的所有宾馆酒店供应商，14324为宾馆酒店的供应商类型  zouyang update in 2014-3-6  update 2014-3-13
//	    String sql3="select distinct c.customerid,c.customername from t_check_sheet a,t_plan_transport b,t_customer c where a.planid=b.planid and b.transport=c.customerid and a.sheetid="+sheetId;
//	    String sql4="select distinct c.customerid,c.customername from t_check_sheet a,t_plan_gate b,t_customer c where a.planid=b.planid and b.sceneryid=c.customerid and a.sheetid="+sheetId;
//	    String sql5="select distinct c.customerid,c.customername from t_check_sheet a,t_plan_shop b,t_customer c where a.planid=b.planid and b.shop=c.customerid and a.sheetid="+sheetId;
//	    String sql6="select distinct c.customerid,c.customername from t_check_sheet a,t_plan_show b,t_customer c where a.planid=b.planid and b.entertainment=c.customerid and a.sheetid="+sheetId;
		params.put("SHEETID", sheetId);
		params.put("TABLEID", tableId);
		return findSql(sql.toString(),null,params, pageNo, pageSize);
	}
	
	

	@Override
	public Pagination checkSheetInfoList(String guiderId, String startTime,
			String routeName, String sheetStatus, int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String sql="select a.planid,b.starttime,c.routename,b.guide,a.status,a.sheetid from t_check_sheet a ";
		sql+="inner join t_plan b on a.planid=b.planid inner join t_route c on b.routeid=c.routeid ";
		sql+=" where b.guide="+guiderId;
		if(!StringUtils.isEmpty(startTime)){
	    	 sql+=" and b.starttime>=to_date('"+startTime+" 00:00:00','yyyy-mm-dd hh24:mi:ss') and b.starttime<=to_date('"+startTime+" 23:59:59','yyyy-mm-dd hh24:mi:ss')";
	     }
		if(!StringUtils.isEmpty(routeName)){
	    	 sql+=" and c.routename like '%"+routeName+"%'";
	     }
		if(!StringUtils.isEmpty(sheetStatus)){
	    	 sql+=" and a.status='"+sheetStatus+"'";
	     }
		return findSql(sql, pageNo, pageSize);
	}
	
}
