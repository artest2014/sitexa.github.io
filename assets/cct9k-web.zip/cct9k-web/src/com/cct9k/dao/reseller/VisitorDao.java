package com.cct9k.dao.reseller;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.GenericOrder;
import com.cct9k.entity.reseller.Plan;
import com.cct9k.entity.reseller.Visitor;

import java.util.List;
import java.util.Map;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:18
 */
public interface VisitorDao extends BaseDao<Visitor, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public String getVisitorSeq();

    public List<Map<String, Object>> getVisitorList(String orderId);

    public boolean isExistVisitorByIdentityNo(String orderId, String identityNo, String ownerId, String customerType,String visitorId,String identityType);

    public List<Visitor> getVisitorListByOrderId(String orderId);

    public int getChildNum(String orderId);

    public int getAdultNum(String orderId);

    public int getNotShareRoomNum(String orderId);

    public List<Visitor> getByOrders(List<GenericOrder> orders);

    public List<Visitor> getByOrders(String[] ids);

    public List<Visitor> getByPlan(Plan plan);
    
    public int getNotTeamVisitorNum(String orderId);
    
    public List<Visitor> getByPlanAndStop(String stopId,String PlanId);
    
    public int getNotShareRoomChildNum(String orderId);
    
    public int getNotShareRoomAdultNum(String orderId);
    
    /**
     * 根据planid获取要被代收费用的游客信息
     * @param planId
     * @return
     */
    public List<Map<String,Object>> getCollectVisitorInfomation(String planId);

}
