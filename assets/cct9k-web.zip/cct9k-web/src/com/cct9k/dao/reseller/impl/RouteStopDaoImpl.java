package com.cct9k.dao.reseller.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.RouteStopDao;
import com.cct9k.entity.reseller.Route;
import com.cct9k.entity.reseller.RouteStop;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:13
 */
@Repository
public class RouteStopDaoImpl extends BaseDaoImpl<RouteStop, String> implements RouteStopDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from RouteStop model where 1=1");

        r.append(" order by starttime asc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public List<RouteStop> getListByStop(Route route) {
        String hql = "from RouteStop model where model.route.routeid=:routeid order by stopname ";
        return getSession().createQuery(hql).setParameter("routeid", route.getRouteid()).list();
    }

}
