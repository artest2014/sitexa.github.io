package com.cct9k.dao.reseller;

import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Guide;

public interface GuiderDao extends BaseDao<Guide,String>{
	/**
	 * 分页查询导游信息
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination getGuiderList(Map<String,Object> paraMap,int pageNo, int pageSize);
}
