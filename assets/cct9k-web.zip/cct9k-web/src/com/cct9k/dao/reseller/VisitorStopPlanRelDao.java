package com.cct9k.dao.reseller;

import java.util.Date;
import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.Plan;
import com.cct9k.entity.reseller.VisitorStopPlanRel;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:18
 */
public interface VisitorStopPlanRelDao extends BaseDao<VisitorStopPlanRel, String> {

	public List<VisitorStopPlanRel> getByPlanAndStop(String planId,String stopId);
	
	/**
	 *@param isJoinTeam 等于 0 查找所有游客。等于1查找尚未入团的游客，等于2查找已入团的游客 
	 *@param 在isJoinTeam条件的基础上，数据是属于planId的。
	 **/
	Pagination findByStopSite(String departuresite, String destinationsite, String planId, int isJoinTeam, Date starttime, String transportclass, int pageNo, int pageSize);
	/**
	 * [0]=ORDERID,[1]=STOPID,[2]=DEPARTURESITE,[3]=DESTINATIONSITE,[4]=TRANSPORTCLASS,[5]=ONSALEID,[6]=NAME,[7]=COUNTS
	 *@param isJoinTeam 等于 0 查找所有游客。等于1查找尚未入团的游客，等于2查找已入团的游客 
	 *@param 在isJoinTeam条件的基础上，数据是属于planId的。
	 **/
	Pagination findRelatedOrderByStopSite(String departuresite, String destinationsite, String planId, int isJoinTeam, Date starttime, String transportclass, int pageNo, int pageSize);
	
	void updateVisitorPlan(String planId, String visitorId, String stopId);
	
	void updateOrderVisitorPlan(String planId, String orderId);
	
	List<VisitorStopPlanRel> getVisitorBySite(String planId, String departuresite, String destinationsite);
	
	List<VisitorStopPlanRel> findByStopId(String stopId, String onsaleId);
	
	public List<String> getPlanVisitorNum(String planId);
	
	/**
	 * 根据游客id查询团队，按团队id升序排列
	 * @param visitorId
	 * @return
	 */
	public List<String> getPlanByVisitorId(String visitorId);
	
	/**
	 * 根据团队id查询游客id
	 * @param planId
	 * @return
	 */
	public List<String> getVistorIdByPlanId(String planId);
	
	/**
	 * 根据visitorId查询VisitorStopPlanRel，按id的升序排列
	 * @param visitorId
	 * @return
	 */
	public List<VisitorStopPlanRel> getVisitorStopPlanRelListByVisitorId(String visitorId);
}
