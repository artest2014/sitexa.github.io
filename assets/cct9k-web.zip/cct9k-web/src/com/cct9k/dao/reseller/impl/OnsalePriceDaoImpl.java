package com.cct9k.dao.reseller.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.OnsalePriceDao;
import com.cct9k.entity.reseller.Onsale;
import com.cct9k.entity.reseller.OnsalePrice;

@Repository
public class OnsalePriceDaoImpl extends BaseDaoImpl<OnsalePrice, String> implements
		OnsalePriceDao {

	@Override
	public List<Map<String, Object>> findMap(String onSaleId) {
		String sql = "SELECT * FROM T_ONSALE_PRICE WHERE ENABLEFLAG=1 AND ONSALEID=:ONSALEID";
		Query query = getSession().createSQLQuery(sql).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ONSALEID", onSaleId);
		return query.list();
	}

	@Override
	public void deleteByOnsale(Onsale onsale) {
		List<OnsalePrice> oldPriceList = getList("onsale", onsale);
		for(OnsalePrice price:oldPriceList){
			price.setEnableFlag("2");
			update(price);
		}
	}

	@Override
	public List<OnsalePrice> getListByOnsaleId(String onsaleId) {
		
		String hql = "from OnsalePrice t where t.onsale.onsaleid=:ONSALEID and t.enableFlag=1 "; 
		List<OnsalePrice> oldPriceList =getSession().createQuery(hql).setParameter("ONSALEID", onsaleId).list();
		return oldPriceList;
	}
}
