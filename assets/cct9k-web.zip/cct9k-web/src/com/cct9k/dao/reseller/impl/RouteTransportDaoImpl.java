package com.cct9k.dao.reseller.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.RouteTransportDao;
import com.cct9k.entity.reseller.RouteTransport;

@Repository
public class RouteTransportDaoImpl extends BaseDaoImpl<RouteTransport, String> implements
		RouteTransportDao {

}
