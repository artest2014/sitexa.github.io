package com.cct9k.dao.reseller;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.OnsaleStop;

public interface OnsaleStopDao extends BaseDao<OnsaleStop, String> {

	
	
}
