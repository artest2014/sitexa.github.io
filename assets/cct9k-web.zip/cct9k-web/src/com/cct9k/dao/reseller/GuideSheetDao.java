package com.cct9k.dao.reseller;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.CheckSheet;
import com.cct9k.entity.member.Member;

public interface GuideSheetDao extends BaseDao<CheckSheet, String> {
      public Pagination getSelectablePlan(String guiderId,String startTime,String planName, String resellerName,int pageNo, int pageSize);

      public Pagination getSheetInfoList(String guiderId,String startTime,String planName,String sheetStatus,String resellerName,int pageNo, int pageSize);
      
      public Pagination getSelectableObj(String sheetId,String tableId,String objName,int pageNo, int pageSize);
      
      //报账单计调审核
      public Pagination checkSheetInfoList(String guiderId,String startTime,String routeName,String sheetStatus,int pageNo, int pageSize);
   
}
