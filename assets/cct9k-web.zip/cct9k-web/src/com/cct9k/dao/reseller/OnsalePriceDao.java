package com.cct9k.dao.reseller;

import java.util.List;
import java.util.Map;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.Onsale;
import com.cct9k.entity.reseller.OnsalePrice;

public interface OnsalePriceDao extends BaseDao<OnsalePrice, String> {

	List<Map<String, Object>> findMap(String onSaleId);
	
	void deleteByOnsale(Onsale onsale);

	List<OnsalePrice> getListByOnsaleId(String onsaleId);
}
