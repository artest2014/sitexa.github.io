package com.cct9k.dao.reseller.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Plan;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:50
 */
@Repository
public class PlanDaoImpl extends BaseDaoImpl<Plan, String> implements PlanDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from Plan model where 1=1");

        r.append(" order by createtime desc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public Pagination getPlanByReseller(Member reseller, int pageNo, int pageSize) {
        if (reseller == null) return null;
        Finder f = Finder.create("from Plan p where p.reseller.memberid=:memberid order by p.starttime desc ");
        f.setParam("memberid", reseller.getMemberid());
        return find(f, pageNo, pageSize);
    }
    
    @Override
    public Pagination getPlanByStatus(Member reseller, int pageNo, int pageSize) {
        if (reseller == null) return null;
        Finder f = Finder.create("from Plan p where p.reseller.memberid=:memberid and p.planstatus.typeid = '2' order by p.starttime desc ");
        f.setParam("memberid", reseller.getMemberid());
        return find(f, pageNo, pageSize);
    }

    @Override
    public Pagination searchByReseller(Member reseller, String planid, String planname, String routename, Date starttime, int pageNo, int pageSize) {
        if (reseller == null) return null;
        Finder f = Finder.create("from Plan p where p.reseller.memberid=:memberid  ");
        f.setParam("memberid", reseller.getMemberid());

        if (!StringUtil.isEmpty(planid)) {
            f.append(" and p.planid=:planid ");
            f.setParam("planid", planid);
        }

        if (!StringUtil.isEmpty(planname)) {
            f.append(" and p.planname like '%'||:planname||'%' ");
            f.setParam("planname", planname);
        }

        if (!StringUtil.isEmpty(routename)) {
            f.append(" and p.route.routename like '%'||:routename||'%' ");
            f.setParam("routename", routename);
        }

        if (starttime != null) {
            Date endtime = DateUtil.addDaysToDate(starttime, 1);
            f.append(" and p.starttime >=:starttime and p.starttime <=:endtime ");
            f.setParam("starttime", starttime).setParam("endtime", endtime);
        }

        f.append(" order by p.starttime desc ");

        return find(f, pageNo, pageSize);
    }
    
    @Override
    public Pagination searchByReseller(String name, String planid, String planname, String startTime, String endTime,int pageNo, int pageSize,String guide) {
    	Map<String, Object> param = new HashMap<String, Object>();
		StringBuffer sql = new StringBuffer("select p.* ");
		sql.append("  from T_PLAN          p,");
		sql.append("  T_MEMBER        member1_,");
		sql.append("  T_MEMBER_PERSON memberpers2_,");
		sql.append("  T_MEMBER_ORGAN  memberorga4_");
		sql.append("  where p.reseller = member1_.memberid");
		sql.append("  and member1_.memberid = memberpers2_.memberid(+)");
		sql.append("  and member1_.memberid = memberorga4_.memberid(+)");
		sql.append("  and 1 = 1");
		
        if (!StringUtil.isEmpty(name)) {
        	sql.append(" and (memberpers2_.realname like '%' ||:name|| '%' or memberorga4_.orgname like '%' ||:name|| '%') ");
        	param.put("name", name);
        }

        if (!StringUtil.isEmpty(planid)) {
        	sql.append(" and p.planid=:planid ");
            param.put("planid", planid);
        }
        
        if (!StringUtil.isEmpty(guide)) {
        	sql.append(" and p.guide=:guide ");
            param.put("guide", guide);
        }

        if (!StringUtil.isEmpty(planname)) {
        	sql.append(" and p.planname like '%'||:planname||'%' ");
        	param.put("planname", planname);
        }

        if (!StringUtil.isEmpty(startTime)) {
        	sql.append(" and to_date(to_char(p.starttime,'yyyy-MM-dd'),'yyyy-MM-dd') >=to_date('" + startTime
					+ "','yyyy-MM-dd') ");
		}
		if (!StringUtil.isEmpty(endTime)) {
			sql.append(" and to_date(to_char(p.starttime,'yyyy-MM-dd'),'yyyy-MM-dd') <=to_date('" + endTime
					+ "','yyyy-MM-dd') ");
		}

		sql.append(" order by p.starttime desc ");

		return findSql(sql.toString(), Plan.class, param, pageNo, pageSize);
    }

    @Override
    public Pagination searchPlan(Member reseller, String planid, String planname, String routename, Date starttime, int pageNo, int pageSize) {
        Finder f = Finder.create("from Plan p where 1=1  ");


        if (reseller != null) {
            f.append(" and p.reseller.memberid=:memberid ");
            f.setParam("memberid", reseller.getMemberid());
        }

        if (!StringUtil.isEmpty(planid)) {
            f.append(" and p.planid=:planid ");
            f.setParam("planid", planid);
        }

        if (!StringUtil.isEmpty(planname)) {
            f.append(" and p.planname like '%'||:planname||'%' ");
            f.setParam("planname", planname);
        }

        if (!StringUtil.isEmpty(routename)) {
            f.append(" and p.route.routename like '%'||:routename||'%' ");
            f.setParam("routename", routename);
        }

        if (starttime != null) {
            Date endtime = DateUtil.addDaysToDate(starttime, 1);
            f.append(" and p.starttime >=:starttime and p.starttime <=:endtime ");
            f.setParam("starttime", starttime).setParam("endtime", endtime);
        }

        f.append(" order by p.starttime desc ");

        return find(f, pageNo, pageSize);
    }
    public Pagination getFinancePage(String teamNo, String routeName,
			String startTime, String status, String memberId, int pageNo,
			int pageSize) {
		Finder f = Finder
				.create("from Plan model where 1=1 and model.planstatus.typeid = '2' and model.reseller.memberid = '"
						+ memberId + "' ");
		if (!StringUtil.isEmpty(teamNo)) {
			f.append(" and model.planid like '%'||:teamNo||'%' ");
			f.setParam("teamNo", teamNo);
		}
		if (!StringUtil.isEmpty(routeName)) {
			f.append(" and model.route.routename like '%'||:routeName||'%' ");
			f.setParam("routeName", routeName);
		}
		if (!StringUtil.isEmpty(startTime)) {
			f.append(" and to_char(model.starttime,'yyyy-mm-dd') = :startTime ");
			f.setParam("startTime", startTime);
		}

		f.append(" order by model.starttime desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination getPlanListByReseller(Member reseller,String planName,Date startDate,  int pageNo,
			int pageSize) {
		// TODO Auto-generated method stub
		if (reseller == null) return null;
		String hql = "from Plan p where p.reseller.memberid=:memberid  ";
		
		if(!StringUtil.isEmpty(planName)){
			hql = hql + " and p.planname like '%'||:planName||'%'";
		}
		if(startDate!=null){
			hql = hql + " and p.starttime>=:startDate";
		}
		
		hql = hql + "  order by p.starttime desc";
		
        Finder f = Finder.create(hql);
        f.setParam("memberid", reseller.getMemberid());
        if(!StringUtil.isEmpty(planName)){
        	f.setParam("planName", planName);
		}
        if(startDate!=null){
        	f.setParam("startDate", startDate);
		}
        return find(f, pageNo, pageSize);
	}
	
	 public List<Plan>   getPlanList(){
 	    String sql = "select t.* from t_plan t " ;
         List<Plan> resultList = null;
 	     resultList = this.getSession().createSQLQuery(sql).addEntity(Plan.class).list();
         if (resultList != null && resultList.size() > 0) {
             return resultList;
         }else{
         	return null;
         }
    }
}
