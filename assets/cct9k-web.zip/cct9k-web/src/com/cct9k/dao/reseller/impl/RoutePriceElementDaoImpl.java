package com.cct9k.dao.reseller.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.RoutePriceElementDao;
import com.cct9k.entity.reseller.RoutePriceElement;

@Repository
public class RoutePriceElementDaoImpl extends BaseDaoImpl<RoutePriceElement, String> implements
		RoutePriceElementDao {

}
