package com.cct9k.dao.reseller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanRestaurantDao;
import com.cct9k.entity.reseller.PlanRestaurant;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:56
 */
@Repository
public class PlanRestaurantDaoImpl extends BaseDaoImpl<PlanRestaurant, String> implements PlanRestaurantDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PlanRestaurant model where 1=1");

        r.append(" order by quantity desc");

        return find(r, pageNo, pageSize);
    }

    @Override
	public List<Map<String, Object>> getResultList(String planId) {
		// TODO Auto-generated method stub
		String sql_="select t_temp.planid, "+
				  "t_temp.stopid,  "+
				  "sum(t_temp.quantity * t_temp.breakfastprice) b_total_price,  "+
				  "sum(case breakfast  "+
						  "when '20' then "+
						  "quantity   "+
						  "end) b_person_no,  "+
						  "sum(t_temp.quantity * t_temp.lunchprice) l_total_price,  "+
						  "sum(case lunch  "+
								  "when '21' then  "+
								  "quantity  "+
								  "when '' then  "+
								 " 0  "+
								  "end) l_person_no,  "+
								  "sum(t_temp.quantity * t_temp.dinnerprice) d_total_price,  "+
								  "sum(case dinner  "+
								  "when '22' then  "+
								  "quantity  "+
								  "end) d_person_no  "+
								  "from (select topc.detailplancateringid,  "+
										 " topc.detailid,  "+
										 " topc.orderid,  "+ 
										 " topc.breakfast,  "+
										 " topc.breakfastprice,  "+
										 " topc.lunch,  "+
										 " topc.lunchprice,  "+
										"  topc.dinner,  "+
										 " topc.dinnerprice,  "+
										 " topc.price,  "+
										 " b.person_no quantity,  "+
										 " (b.person_no * topc.price) amount,  "+
										 " topc.routestopid,  "+
										 " tps.stopid,  "+
										 " tps.stopname,  "+
										 " b.planid,  "+
										 " topc.routecateringid  "+
										 " from t_order_detail_plan_catering topc,  "+
										 " (select tv.orderid,  "+
												"  tvr.routestopid,  "+
												 " tvr.planid,  "+
												 " count(tv.orderid) person_no  "+
												 " from T_VISITOR_STOP_PLAN_REL tvr, t_visitor tv  "+
												"  where tvr.visitorid = tv.visitorid  "+
												 " and tvr.planid = :planId  "+
												 " group by tv.orderid, tvr.routestopid, tvr.planid) b,  "+
												 " t_plan_stop tps  "+ 
												 " where topc.orderid = b.orderid  "+
												 " and topc.routestopid = b.routestopid  "+
												 " and tps.routestopid = topc.routestopid  "+
												  "and tps.planid = b.planid) t_temp "+ 
												  "group by t_temp.planid, t_temp.stopid ";
		StringBuffer sql = new StringBuffer(sql_);
		Map<String, Object> paramMap = new HashMap<>();
	    paramMap.put("planId", planId);
		List<Map<String, Object>> list = this.getSimpleSpringJdbcTemplate().queryForMap(sql, paramMap);
													  
		return list;
	}

	@Override
	public List<Map<String, Object>> getOrederMealPersonNo(String planId,
			String routeStopId) {
		// TODO Auto-generated method stub
		String sql_ = "select c.orderid, "
				+ "t.name, "
				+ " (c.breakfast * c.p_count) b_person_no, "
				+ " (c.lunch * c.p_count) l_person_no, "
				+ "  (c.dinner * c.p_count) d_person_no "
				+ "from (select b.orderid, "
				+ " case "
				+ " when replace(tc.breakfast, ' ', null) is null then "
				+ "  0 "
				+ " when tc.breakfast is not null then "
				+ "   1 "
				+ " end breakfast, "
				+ " case "
				+ "  when replace(tc.lunch, ' ', null) is null then "
				+ "   0 "
				+ "  when tc.lunch is not null then "
				+ "    1 "
				+ " end lunch, "
				+ " case "
				+ "   when replace(tc.dinner, ' ', null) is null then "
				+ "     0 "
				+ "    when tc.dinner is not null then "
				+ "      1 "
				+ "    end dinner,  "
				+ "     b.p_count "
				+ " from t_order_detail_plan_catering tc, "
				+ " (select tv.orderid, "
				+ "        k.stopid routestopid, "
				+ "       count(tv.visitorid) p_count "
				+ "  from t_visitor tv, "
				+ "       (select m.planid, m.visitorid, m.stopid "
				+ "        from (select t_temp.planid, "
				+ "                    tr_stop.stopid, "
				+ "                    t_temp.visitorid, "
				+ "                    tr_stop.destinationsite, "
				+ "                    tr_stop.departuresite "
				+ "               from t_route_stop tr_stop, "
				+ "                    (select tvr.planid, "
				+ "                            tvr.routestopid, "
				+ "                             tvr.visitorid "
				+ "                         from t_visitor_stop_plan_rel tvr "
				+ "                        where tvr.planid =:planId) t_temp "
				+ "                  where tr_stop.stopid = t_temp.routestopid) m, "
				+ "                (select trs.destinationsite, trs.departuresite "
				+ "                    from t_route_stop trs "
				+ "                   where trs.stopid =:routeStopId) n "
				+ "             where m.destinationsite = n.destinationsite "
				+ "                and m.departuresite = n.departuresite) k "
				+ "       where tv.visitorid = k.visitorid "
				+ "         group by tv.orderid, k.stopid) b "
				+ "  where b.orderid = tc.orderid "
				+ "      and tc.routestopid = b.routestopid) c, "
				+ "   t_generic_order t " + "where c.orderid = t.orderid  ";
		StringBuffer sql = new StringBuffer(sql_);
		Map<String, Object> paramMap = new HashMap<>();
	    paramMap.put("planId", planId);
	    paramMap.put("routeStopId", routeStopId);
	    List<Map<String, Object>> list = this.getSimpleSpringJdbcTemplate().queryForMap(sql, paramMap);
		return list;
	}

	@Override
	public List<?> getPlanRestaurantOrders(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select a.planid,                                                    ");
		querySql.append("        null as orderid,                                             ");
		querySql.append("        '自维护客户' as customersource,                              ");
		querySql.append("        null as ordername,                                           ");
		querySql.append("        d.productname,                                               ");
		querySql.append("        c.customername,                                              ");
		querySql.append("        null as orderdate,                                           ");
		querySql.append("        b.quantity,                                                  ");
		querySql.append("        b.amount,                                                    ");
		querySql.append("        null as orderstatus,                                         ");
		querySql.append("        null as paymentstatus,                                       ");
		querySql.append("        null as estimatestatus                                       ");
		querySql.append("   from t_plan a, t_plan_restaurant b, t_customer c, t_customer_product d ");
		querySql.append("  where a.planid = b.planid                                          ");
		querySql.append("    and b.restaurant = c.customerid                                  ");
		querySql.append("    and b.product = d.productid                                      ");
		querySql.append("    and a.planid = :planid                                           ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);
		
        return query.list();
	}
}
