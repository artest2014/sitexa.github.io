package com.cct9k.dao.reseller.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.RoutePricePackageDao;
import com.cct9k.entity.reseller.RoutePricePackage;
import com.cct9k.entity.reseller.RouteStop;

@Repository
public class RoutePricePackageDaoImpl extends BaseDaoImpl<RoutePricePackage, String> implements
		RoutePricePackageDao {

	@Override
	public List<Map<String, Object>> findRouteTransportElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.TYPENAME AS TRANSPORTTYPENAME, T2.TYPENAME AS TRANSPORTCLASSNAME FROM ");
		sql.append("(SELECT TRT.ROUTETRANSPORTID, TRT.TRANSPORTTYPE, TRT.TRANSPORTCLASS, TRP.ELEMENTID, TRP.ELEMENTPRICE, ");
		sql.append("TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM T_ROUTE_TRANSPORT TRT ");
		sql.append("LEFT JOIN T_ROUTE_PRICE_ELEMENT TRP ON TRT.ROUTETRANSPORTID = TRP.ELEMENTOBJECTID AND TRP.ROUTEPRICEPACKAGEID");
		sql.append("=:ROUTEPRICEPACKAGEID WHERE TRT.STOPID=:STOPID) T, T_DICTIONARY T1, T_DICTIONARY T2 WHERE T.TRANSPORTTYPE=");
		sql.append("T1.DICTID AND T.TRANSPORTCLASS=T2.DICTID");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}
	
	@Override
	public List<Map<String, Object>> findTransportElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.TYPENAME AS TRANSPORTTYPENAME, T2.TYPENAME AS TRANSPORTCLASSNAME FROM ");
		sql.append("(SELECT TRT.ROUTETRANSPORTID, TRT.TRANSPORTTYPE, TRT.TRANSPORTCLASS, TRP.ELEMENTID, TRP.ELEMENTPRICE, ");
		sql.append("TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM T_ROUTE_TRANSPORT TRT ");
		sql.append("LEFT JOIN T_ROUTE_PRICE_ELEMENT TRP ON TRT.ROUTETRANSPORTID = TRP.ELEMENTOBJECTID WHERE TRT.STOPID=:STOPID AND ");
		sql.append("TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID ) T, T_DICTIONARY T1, T_DICTIONARY T2 WHERE T.TRANSPORTTYPE=");
		sql.append("T1.DICTID AND T.TRANSPORTCLASS=T2.DICTID");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}

	@Override
	public List<Map<String, Object>> findRouteCateringElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.TYPENAME AS CLASSNAME FROM (SELECT TRC.ROUTECATERINGID, TRC.CLASS, ");
		sql.append("TRC.TYPE, TRP.ELEMENTID, TRP.ELEMENTPRICE, TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM ( ");
		sql.append("SELECT ROUTECATERINGID, STOPID, BREAKFAST AS CLASS, '78387' AS TYPE FROM T_ROUTE_CATERING WHERE STOPID=:STOPID ");
		sql.append("AND (BREAKFAST IS NOT NULL OR BREAKFAST!='') UNION ALL SELECT ROUTECATERINGID, STOPID, LUNCH, '78388' FROM T_ROUTE_CATERING ");
		sql.append("WHERE STOPID=:STOPID AND (LUNCH IS NOT NULL OR LUNCH!='') UNION ALL SELECT ROUTECATERINGID, STOPID, DINNER, '78389' FROM ");
		sql.append("T_ROUTE_CATERING WHERE STOPID=:STOPID AND (DINNER IS NOT NULL OR DINNER!='') ) TRC LEFT JOIN T_ROUTE_PRICE_ELEMENT TRP ON ");
		sql.append("TRC.ROUTECATERINGID=TRP.ELEMENTOBJECTID AND TRC.TYPE=TRP.ELEMENTOBJECTTYPE AND TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID WHERE ");
		sql.append("TRC.STOPID=:STOPID ) T, T_DICTIONARY T1 WHERE T.CLASS=T1.DICTID ORDER BY TO_NUMBER(T.CLASS)");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}
	
	@Override
	public List<Map<String, Object>> findCateringElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.TYPENAME AS CLASSNAME FROM (SELECT TRC.ROUTECATERINGID, TRC.CLASS, ");
		sql.append("TRC.TYPE, TRP.ELEMENTID, TRP.ELEMENTPRICE, TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM ( ");
		sql.append("SELECT ROUTECATERINGID, STOPID, BREAKFAST AS CLASS, '78387' AS TYPE FROM T_ROUTE_CATERING WHERE STOPID=:STOPID ");
		sql.append("AND (BREAKFAST IS NOT NULL OR BREAKFAST!='') UNION ALL SELECT ROUTECATERINGID, STOPID, LUNCH, '78388' FROM T_ROUTE_CATERING ");
		sql.append("WHERE STOPID=:STOPID AND (LUNCH IS NOT NULL OR LUNCH!='') UNION ALL SELECT ROUTECATERINGID, STOPID, DINNER, '78389' FROM ");
		sql.append("T_ROUTE_CATERING WHERE STOPID=:STOPID AND (DINNER IS NOT NULL OR DINNER!='') ) TRC LEFT JOIN T_ROUTE_PRICE_ELEMENT TRP ON ");
		sql.append("TRC.ROUTECATERINGID=TRP.ELEMENTOBJECTID AND TRC.TYPE=TRP.ELEMENTOBJECTTYPE WHERE ");
		sql.append("TRC.STOPID=:STOPID AND TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID) T, T_DICTIONARY T1 WHERE T.CLASS=T1.DICTID ORDER BY TO_NUMBER(T.CLASS)");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}

	@Override
	public List<Map<String, Object>> findRouteHotelElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.TYPENAME AS HOTELCLASSNAME FROM (SELECT TRH.ROUTEHOTELID, TRH.HOTELCLASS, TRP.ELEMENTID, ");
		sql.append("TRP.ELEMENTPRICE, TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM T_ROUTE_HOTEL TRH LEFT JOIN T_ROUTE_PRICE_ELEMENT ");
		sql.append("TRP ON TRH.ROUTEHOTELID=TRP.ELEMENTOBJECTID AND TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID WHERE TRH.STOPID=:STOPID ) T, T_DICTIONARY ");
		sql.append("T1 WHERE T.HOTELCLASS=T1.DICTID  ORDER BY TO_NUMBER(T.HOTELCLASS)");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}
	
	@Override
	public List<Map<String, Object>> findHotelElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.TYPENAME AS HOTELCLASSNAME FROM (SELECT TRH.ROUTEHOTELID, TRH.HOTELCLASS, TRP.ELEMENTID, ");
		sql.append("TRP.ELEMENTPRICE, TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM T_ROUTE_HOTEL TRH LEFT JOIN T_ROUTE_PRICE_ELEMENT ");
		sql.append("TRP ON TRH.ROUTEHOTELID=TRP.ELEMENTOBJECTID WHERE TRH.STOPID=:STOPID AND TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID) T, T_DICTIONARY ");
		sql.append("T1 WHERE T.HOTELCLASS=T1.DICTID  ORDER BY TO_NUMBER(T.HOTELCLASS)");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}

	@Override
	public List<Map<String, Object>> findRouteShowElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.CUSTOMERNAME AS SHOWNAME FROM (SELECT TRS.ROUTESHOWID, TRS.SHOW, TRP.ELEMENTID, ");
		sql.append("TRP.ELEMENTPRICE, TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM T_ROUTE_SHOW TRS LEFT JOIN T_ROUTE_PRICE_ELEMENT ");
		sql.append("TRP ON TRS.ROUTESHOWID=TRP.ELEMENTOBJECTID AND TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID WHERE TRS.STOPID=:STOPID ) T, T_CUSTOMER T1 ");
		sql.append("WHERE T.SHOW=T1.CUSTOMERID ORDER BY TO_NUMBER(T.SHOW)");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}
	
	@Override
	public List<Map<String, Object>> findShowElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.CUSTOMERNAME AS SHOWNAME FROM (SELECT TRS.ROUTESHOWID, TRS.SHOW, TRP.ELEMENTID, ");
		sql.append("TRP.ELEMENTPRICE, TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM T_ROUTE_SHOW TRS LEFT JOIN T_ROUTE_PRICE_ELEMENT ");
		sql.append("TRP ON TRS.ROUTESHOWID=TRP.ELEMENTOBJECTID WHERE TRS.STOPID=:STOPID AND TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID ) T, T_CUSTOMER T1 ");
		sql.append("WHERE T.SHOW=T1.CUSTOMERID ORDER BY TO_NUMBER(T.SHOW)");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}
	
	@Override
	public List<Map<String, Object>> findRouteGateElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.CUSTOMERNAME AS GATENAME FROM (SELECT TRG.ROUTEGATEID, TRG.GATEID, TRP.ELEMENTID, ");
		sql.append("TRP.ELEMENTPRICE, TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM T_ROUTE_GATE TRG LEFT JOIN T_ROUTE_PRICE_ELEMENT ");
		sql.append("TRP ON TRG.ROUTEGATEID=TRP.ELEMENTOBJECTID AND TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID WHERE TRG.STOPID=:STOPID) T, T_CUSTOMER T1 ");
		sql.append("WHERE T.GATEID=T1.CUSTOMERID  ORDER BY TO_NUMBER(T.GATEID)");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}


	@Override
	public List<Map<String, Object>> findGateElement(RouteStop stop,
			RoutePricePackage pricePackage) {
		StringBuffer sql = new StringBuffer("SELECT T.*, T1.CUSTOMERNAME AS GATENAME FROM (SELECT TRG.ROUTEGATEID, TRG.GATEID, TRP.ELEMENTID, ");
		sql.append("TRP.ELEMENTPRICE, TRP.CHILDRENPRICE, TRP.ROOMCOMPENSATION, TRP.ELEMENTOBJECTTYPE FROM T_ROUTE_GATE TRG LEFT JOIN T_ROUTE_PRICE_ELEMENT ");
		sql.append("TRP ON TRG.ROUTEGATEID=TRP.ELEMENTOBJECTID WHERE TRG.STOPID=:STOPID AND TRP.ROUTEPRICEPACKAGEID=:ROUTEPRICEPACKAGEID) T, T_CUSTOMER T1 ");
		sql.append("WHERE T.GATEID=T1.CUSTOMERID  ORDER BY TO_NUMBER(T.GATEID)");
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		query.setParameter("ROUTEPRICEPACKAGEID", pricePackage==null?"0000":pricePackage.getRoutePricePackageId());
		query.setParameter("STOPID", stop.getStopid());
		return query.list();
	}

}
