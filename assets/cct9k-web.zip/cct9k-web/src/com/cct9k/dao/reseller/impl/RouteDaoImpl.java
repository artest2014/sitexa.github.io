package com.cct9k.dao.reseller.impl;

import com.cct9k.common.ExpandSimpleJdbcTemplate;
import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.RouteDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Route;
import com.cct9k.util.common.StringUtil;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:09
 */
@Repository
public class RouteDaoImpl extends BaseDaoImpl<Route, String> implements RouteDao {

	@Override
    public String createId() {
        String sql = " select s_public.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }

    @Override
    public Pagination getPage(Member reseller, int pageNo, int pageSize) {
        Finder r = Finder.create("from Route model where model.reseller.memberid=:memberid order by createdate desc");
        r.setParam("memberid", reseller.getMemberid());
        return find(r, pageNo, pageSize);
    }
    
    @Override
    public Pagination searchRoute(String province, String city,String county,int pageNo, int pageSize) {

        Finder f = Finder.create("select r from Route r  where 1=1 ");

        f.append(" and r.routestatus='1'  ");

        if (!StringUtil.isEmpty(province)) {
            f.append(" and r.destinationsite.state =:province ");
            f.setParam("province", province);
        }

        if (!StringUtil.isEmpty(city)) {
            f.append(" and r.destinationsite.city =:city ");
            f.setParam("city", city);
        }
        
        if (!StringUtil.isEmpty(county)) {
            f.append(" and r.destinationsite.county =:county ");
            f.setParam("county", county);
        }

        f.append(" order by r.createdate desc ");

        return find(f, pageNo, pageSize);
    }

    @Override
    public Pagination search(String routename, String departure, String destination, int pageNo, int pageSize) {
        Finder r = Finder.create("from Route model where 1=1");

        if (routename != null) {
            r.append(" and model.routename like '%'||:routename||'%' ");
            r.setParam("routename", routename);
        }

        if (departure != null) {
            r.append(" and model.departure like '%'||:departure||'%'");
            r.setParam("departure", departure);
        }

        if (departure != null) {
            r.append(" and model.destination like '%'||:destination||'%'");
            r.setParam("destination", destination);
        }

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public Pagination getOnsaleRouteByReseller(Member reseller, int pageNo, int pageSize) {
        Finder f = Finder.create("from Route where reseller.memberid=:memberid and routestatus='1' order by createdate desc");
        f.setParam("memberid", reseller.getMemberid());
        return find(f, pageNo, pageSize);
    }

    @Override
    public Pagination searchRoute(Member reseller, String routename, String departure, String destination, int pageNo, int pageSize) {
        Finder f = Finder.create("from Route r where 1=1 ");
        if (reseller != null) {
            f.append(" and r.reseller.memberid=:memberid ");
            f.setParam("memberid", reseller.getMemberid());
        }

        if (!StringUtil.isEmpty(routename)) {
            f.append(" and r.routename like '%'||:routename||'%' ");
            f.setParam("routename", routename);
        }

        if (!StringUtil.isEmpty(departure)) {
            f.append(" and r.departure like '%'||:departure||'%' ");
            f.setParam("departure", departure);
        }

        if (!StringUtil.isEmpty(destination)) {
            f.append(" and r.destination like '%'||:destination||'%' ");
            f.setParam("destination", destination);
        }
        f.append(" order by r.createdate asc ");
        return find(f, pageNo, pageSize);
    }
    
    @Override
    public Pagination getRouList(String seller,String routeName, int pageNo,
			int pageSize) {
		String sql = "select t.routeid,t.routename,t.routestatus From t_route t where 1=1 and t.routestatus!=0";
		if (!StringUtil.isEmpty(seller)) {
			sql += " and t.reseller='" + seller + "' ";
		}
		if (!StringUtil.isEmpty(routeName)) {
			sql += " and t.routename like '%" + routeName + "%' ";
		}
		sql += " order by t.CREATEDATE desc";
		return this.findSql(sql, pageNo, pageSize);
	}


	@Override
	public Pagination getRouteList(Map<String, Object> paraMap, int pageNo,
			int pageSize) {
//		StringBuffer sql = new StringBuffer(" from Route r   ");
//	      	Finder f = Finder.create(sql.toString());
//	    	if (param != null) {
//				if(!StringUtil.isNullOrEmpty(param.get("keyword")==null?"":param.get("keyword").toString())){
//					f.append(" inner join fetch r.objectSearchKeyword e  where  r.routestatus='1' and e.objecttypetypeid='route' and  e.objecttypecateid='objecttype'");
//					//给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
//					String keywordstr=StringUtil.deleteExtraSpace(param.get("keyword").toString());
//					
//					//以空格为分隔符  把keywordstr分隔成数组
//					  String[] str = keywordstr.split(" ");
//					  
//					  //循环数组 and条件查询
//					for(int i=0;i<str.length;i++){
//						f.append("and  e.searchkeyword like  '%"+str[i]+"%' ");
//					}
//				}else{
//					f.append(" where r.routestatus='1'");
//				}
//				
//			}
//		 f.append(" order by r.createdate desc");
        StringBuffer sql = new StringBuffer("select a .routeid,") ;
        sql.append("a .routename,");
        sql.append("a .createdate,");
        sql.append("b.picurl,");
        sql.append("a .duration,a.Introduction,a.minprice,");
        sql.append("a .departure,");
        sql.append("dd.starttime,");
        sql.append(" case");
        sql.append(" when e.conmentCount is null then ");
        sql.append(" 0 ");
        sql.append("else ");
        sql.append(" e.conmentCount ");
        sql.append("end as comentCount, ");
        sql.append("case ");
        sql.append("when f.visitCount is null then ");
        sql.append(" 0 ");
        sql.append("else ");
        sql.append(" f.visitCount ");
        sql.append("end as visitCount, ");
        sql.append("m.memberimg, ");
        sql.append("m.membername ,m.memberid  ");
        sql.append("from t_route a ");
        sql.append("left join (select * ");
        sql.append("from (select c.picurl, ");
        sql.append(" c.routeid, ");
      	sql.append("row_number() over(partition by c.routeid order by c.picid asc) sn ");
      	sql.append("from t_route_picture c) ");
      	sql.append("where sn = 1) b on a.routeid = b.routeid ");
      	sql.append("  left join (select wm_concat(to_char(d.starttime, 'yyyy-mm-dd hh24:mi:ss')) as starttime, ");
      	sql.append(" d .routeid ");
      	sql.append("from t_onsale d ");
      	sql.append(" where d.starttime > (sysdate - 1)  ");
      	sql.append("group by d.routeid  ) dd on dd.routeid = a.routeid ");
      	sql.append("left JOIN (select count(id) as conmentCount, objectid ");
      	sql.append("  from T_COMMENT ");
      	sql.append(" where objecttype = 'route' ");
      	sql.append("group by objectid) e on e.objectid = a.routeid ");
      	sql.append("left join (select count(v.visitorid) as visitCount, routeid ");
      	sql.append("  from t_visitor v ");
      	sql.append("  left join t_order_detail_plan p on v.orderid = p.orderid ");
        sql.append(" group by p.routeid) f on f.routeid = a.routeid ");
      	sql.append("inner join T_MEMBER m on M.memberid = A.creator ");
		if (paraMap != null && paraMap.size() > 0) {
			
			//关联 对象关键字表
			if (paraMap.get("keyword") != null){
				sql.append(" inner join t_object_search_keyword k on k.objectid=a.routeid ");
			}
		}
		sql.append(" where    a.routestatus='1' ");
		if (paraMap != null && paraMap.size() > 0) {
			if (!StringUtil.isEmpty((String) paraMap.get("keyword"))) {
				// 给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
				String keywordstr = StringUtil.deleteExtraSpace(paraMap.get(
						"keyword").toString());
				
				// 以空格为分隔符 把keywordstr分隔成数组
				String[] str = keywordstr.split(" ");
				sql.append(" and(");
				// 循环数组 and条件查询
				for (int i = 0; i < str.length; i++) {
					if (i == 0){
						sql.append(" k.searchkeyword like '%" + str[i] + "%' ");
					}
					else{
						sql.append(" or k.searchkeyword like '%" + str[i] + "%' ");
					}
					if (i == str.length-1){
						sql.append(")");
					}
					
				}
				sql.append(" and k.objecttypetypeid='route' and  k.objecttypecateid='objecttype' ");
			}
			if (!StringUtil.isEmpty((String) paraMap.get("conmentCountSort"))|| !StringUtil.isEmpty((String) paraMap.get("visitCountSort")) ||!StringUtil.isEmpty((String) paraMap.get("priceSort"))){
				sql.append(" order by ");
			}
			if (!StringUtil.isEmpty((String) paraMap.get("conmentCountSort"))){
				if ("asc".equals(paraMap.get("conmentCountSort"))){
					sql.append("  comentCount asc");
				}
				else if ("desc".equals(paraMap.get("conmentCountSort"))){
					sql.append("  comentCount desc ");
				}
			}
			
			if (!StringUtil.isEmpty((String) paraMap.get("visitCountSort"))){
				if(!StringUtil.isEmpty((String) paraMap.get("conmentCountSort")))
				sql.append(",");
				if ("asc".equals(paraMap.get("visitCountSort"))){
					sql.append(" visitCount asc");
				}
				else if ("desc".equals(paraMap.get("visitCountSort"))){
					sql.append("  visitCount desc ");
				}
			}
			if (!StringUtil.isEmpty((String) paraMap.get("priceSort"))){
				if(!StringUtil.isEmpty((String) paraMap.get("conmentCountSort")) || !StringUtil.isEmpty((String) paraMap.get("visitCountSort")))
					sql.append(",");
				if ("asc".equals(paraMap.get("priceSort"))){
					sql.append("  a.minprice asc");
				}
				else if ("desc".equals(paraMap.get("priceSort"))){
					sql.append(" a.minprice desc ");
				}
			}
		}else{
			sql.append(" order by a.createdate desc ");
		}
  
     	Pagination pagination = new Pagination(); 
     	pagination.setPageNo(pageNo); 
     	pagination.setPageSize(pageSize);
      ExpandSimpleJdbcTemplate jdbcTemplate = this.getSimpleSpringJdbcTemplate();
      return jdbcTemplate.queryForPaginationMap(sql, pagination, null);
	}
	
	/**
     * 查询最热门十条线路
     * @return
     */
    public List<Route> getHotRoute(){
    	StringBuffer sql = new StringBuffer();
    	sql.append("select a.*  from t_route a");
    	sql.append(" inner join v_route_visitor_num v on a.routeid=v.routeid");
    	SQLQuery query = this.getSession().createSQLQuery(sql.toString());
    	 query.addEntity(Route.class);
    	List<Route> result = query.list();
    	return result;
    }
}
