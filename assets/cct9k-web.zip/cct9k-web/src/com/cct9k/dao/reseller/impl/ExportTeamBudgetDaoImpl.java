package com.cct9k.dao.reseller.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.criterion.CriteriaSpecification;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.ExportTeamBudgetDao;
import com.cct9k.entity.order.GenericOrder;

@Repository
public class ExportTeamBudgetDaoImpl extends BaseDaoImpl<GenericOrder, String> implements ExportTeamBudgetDao
{

	@Override
	public List<?> getHotelBudget(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select null as orderdate,                                  ");
		querySql.append("        c.customername,                                     ");
		querySql.append("        d.productname,                                      ");
		querySql.append("        b.quantity,                                         ");
		querySql.append("        round(b.amount / b.quantity, 2) price,              ");
		querySql.append("        b.amount,                                           ");
		querySql.append("        null as paymentmethod                         		 ");
		querySql.append("   from t_plan_hotel b, t_customer c, t_customer_product d  ");
		querySql.append("  where b.hotel = c.customerid                              ");
		querySql.append("    and b.product = d.productid                             ");
		querySql.append("    and b.planid = :planid                                  ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);
		return query.list();
	}

	@Override
	public List<?> getRestaurantBudget(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select null as orderdate,                                       ");
		querySql.append("        c.customername,                                          ");
		querySql.append("        d.productname,                                           ");
		querySql.append("        b.quantity,                                              ");
		querySql.append("        round(b.amount / b.quantity, 2) price,                   ");
		querySql.append("        b.amount,                                                ");
		querySql.append("        null as paymentmethod                                    ");
		querySql.append("   from t_plan_restaurant b, t_customer c, t_customer_product d  ");
		querySql.append("  where b.restaurant = c.customerid                              ");
		querySql.append("    and b.product = d.productid                                  ");
		querySql.append("    and b.planid = :planid                                       ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);

		return query.list();
	}

	@Override
	public List<?> getGateBudget(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select null as orderdate,                                   ");
		querySql.append("        c.customername || '-' || d.productname customername, ");
		querySql.append("        decode(b.ptype, 0, '成人', 1, '儿童') productname,   ");
		querySql.append("        b.quantity,                                          ");
		querySql.append("        b.price,                                             ");
		querySql.append("        b.amount,                                            ");
		querySql.append("        null as paymentmethod                          	  ");
		querySql.append("   from (select planid,                                      ");
		querySql.append("                product,                                     ");
		querySql.append("                sceneryid,                                   ");
		querySql.append("                0 as ptype,                                  ");
		querySql.append("                adultquantity quantity,                      ");
		querySql.append("                adultprice price,                            ");
		querySql.append("                adultprice * adultquantity amount            ");
		querySql.append("           from t_plan_gate                                  ");
		querySql.append("          where planid = :planid                             ");
		querySql.append("            and adultquantity <> 0                           ");
		querySql.append("         union all                                           ");
		querySql.append("         select planid,                                      ");
		querySql.append("                product,                                     ");
		querySql.append("                sceneryid,                                   ");
		querySql.append("                1 as ptype,                                  ");
		querySql.append("                childrenquantity,                            ");
		querySql.append("                childrenprice,                               ");
		querySql.append("                childrenprice * childrenquantity             ");
		querySql.append("           from t_plan_gate                                  ");
		querySql.append("          where planid = :planid                             ");
		querySql.append("            and childrenquantity <> 0) b,                    ");
		querySql.append("        t_customer c,                                        ");
		querySql.append("        t_customer_product d                                 ");
		querySql.append("  where b.sceneryid = c.customerid                           ");
		querySql.append("    and b.product = d.productid(+)                           ");
		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);

		return query.list();
	}

	@Override
	public List<?> getTransportBudget(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select null as orderdate,                                                              ");
		querySql.append("        c.customername,                                                                 ");
		querySql.append("        d.productname || '-' ||                                                         ");
		querySql.append("        (select typename from t_dictionary where dictid = b.transportclass) productname,");
		querySql.append("        b.quantity,                                                                     ");
		querySql.append("        b.amount / b.quantity price,                                                    ");
		querySql.append("        b.amount,                                                                       ");
		querySql.append("        null as paymentmethod                                                           ");
		querySql.append("   from t_plan_transport b, t_customer c, t_customer_product d                          ");
		querySql.append("  where b.transport = c.customerid                                                      ");
		querySql.append("    and b.product = d.productid                                                         ");
		querySql.append("    and b.planid = :planid                                                              ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);

		return query.list();
	}

	@Override
	public List<?> getGuideBudget(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append("select null as orderdate,                              ");
		querySql.append("       b.realname,                                     ");
		querySql.append("       c.serviceproductname,                           ");
		querySql.append("       1 as quantity,                                  ");
		querySql.append("       a.guidefee,                                     ");
		querySql.append("       a.guidefee,                                     ");
		querySql.append("       null as paymentmethod                           ");
		querySql.append("  from t_plan a, t_member_person b, t_guide_product c  ");
		querySql.append(" where a.guide = b.memberid                            ");
		querySql.append("   and a.guideproduct = c.serviceid                    ");
		querySql.append("   and a.planid = :planid                              ");
		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);

		return query.list();
	}

	@Override
	public List<?> getAgencyDetail(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select c.customername, b.collectamount                      ");
		querySql.append("   from (select b.visitorid, b.orderid, b.planid             ");
		querySql.append("           from t_generic_order a, t_visitor_stop_plan_rel b ");
		querySql.append("          where a.orderid = b.orderid                        ");
		querySql.append("            and b.planid = :planid                           ");
		querySql.append("          group by b.visitorid, b.orderid, b.planid) a,      ");
		querySql.append("        t_visitor b,                                         ");
		querySql.append("        t_customer c                                         ");
		querySql.append("  where a.visitorid = b.visitorid                            ");
		querySql.append("    and b.customerid = c.customerid                          ");
		querySql.append("    and collectamount > 0                                    ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);

		return query.list();
	}

	@Override
	public Float getAdvanceAmount(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append("select amount             ");
		querySql.append("  from t_account          ");
		querySql.append(" where itemid = '6401001' ");
		querySql.append("   and sourceid = :planid ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setResultTransformer(CriteriaSpecification.ALIAS_TO_ENTITY_MAP);
		query.setParameter("planid", planId);

		List<?> list = query.list();
		if (list != null && list.size() > 0)
		{
			Object o = query.list().get(0);
			if (o != null)
			{
				@SuppressWarnings("unchecked")
				Map<String, Object> map = (Map<String, Object>) o;
				return (Float) map.get("AMOUNT");
			}
		}
		return 0f;
	}

}
