package com.cct9k.dao.reseller.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanShopDao;
import com.cct9k.entity.reseller.PlanShop;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:58
 */
@Repository
public class PlanShopDaoImpl extends BaseDaoImpl<PlanShop, String> implements PlanShopDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PlanShop model where 1=1");

        r.append(" order by store desc");

        return find(r, pageNo, pageSize);
    }

}
