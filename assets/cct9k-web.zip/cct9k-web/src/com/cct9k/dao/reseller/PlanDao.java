package com.cct9k.dao.reseller;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Plan;

import java.util.Date;
import java.util.List;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:49
 */
public interface PlanDao extends BaseDao<Plan, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public Pagination getPlanByReseller(Member reseller, int pageNo, int pageSize);

    public Pagination searchByReseller(Member reseller, String planid, String planname, String routename, Date starttime, int pageNo, int pageSize);

    public Pagination searchPlan(Member reseller,String planid, String planname, String routename, Date starttime, int pageNo, int pageSize);
    
    public Pagination getFinancePage(String teamNo, String routeName,
			String startTime, String status, String memberId, int pageNo,
			int pageSize);
    
    public Pagination getPlanByStatus(Member reseller, int pageNo, int pageSize);
    
    public Pagination searchByReseller(String name, String planid, String planname, String starttime, String endtime,int pageNo, int pageSize,String guide);
    
    /**
     * 根据卖家获取团队信息 
     * @param reseller
     * @param pageNo
     * @param pageSize
     * @return
     */
    public Pagination getPlanListByReseller(Member reseller,String planName,Date startDate, int pageNo, int pageSize);
    
    public List<Plan>   getPlanList();
}
