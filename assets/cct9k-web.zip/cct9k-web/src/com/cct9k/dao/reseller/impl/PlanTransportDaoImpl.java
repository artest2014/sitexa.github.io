package com.cct9k.dao.reseller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanTransportDao;
import com.cct9k.entity.reseller.PlanTransport;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:01
 */
@Repository
public class PlanTransportDaoImpl extends BaseDaoImpl<PlanTransport, String> implements PlanTransportDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PlanTransport model where 1=1");

        r.append(" order by transport desc");

        return find(r, pageNo, pageSize);
    }

    /*
     * 
    * <p>Title: queryPlanTransportResources</p>
    * <p>Description: </p>
    * @param planId
    * @return
    * @see com.cct9k.dao.reseller.PlanTransportDao#queryPlanTransportResources(java.lang.String)
     */
    @Override
    public List<Map<String, Object>> queryPlanTransportResources(String planId) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("planid", planId);
        //--begin(#6)获取行程名称，获取旅运项目名称
        sql.append("select tps.stopname, rs.planstopid stopid, td.dictid, td.typename,td.typeid, rs.transportclass,  rs.quantity from ( ");
        //--begin(#5)根据行程，娱乐项目分组统计
        sql.append("select rs.stopid, rs.transporttype, rs.transportclass, rs.planstopid, sum(rs.quantity) quantity from ( ");
        //--begin(#4)获取创建订单时选择的当前行程的资源
        sql.append("select go.*, todpt.transporttype, todpt.transportclass, todpt.price, sign(todpt.quantity) quantity from ( ");
       // --begin(#3)
        sql.append("select gv.*, tgo.name, tgo.totalquantity from ( ");
        //--begin(#2)获取游客信息
        sql.append(" select rov.*, tv.orderid, tv.ischild, tv.shareroom, tv.gender ");
        sql.append(" from( ");
        //--begin(#1)获取线路所有的行程计划及其所包含的团队游客
        sql.append(" select trs.stopid, tps.stopid planstopid, tps.stopname, tvspr.planid, tvspr.visitorid, tvspr.routestopid from t_plan_stop tps ");
        sql.append(" left join  ");
        sql.append(" t_route_stop trs ");
        sql.append(" on tps.routestopid = trs.stopid ");
        sql.append("left join ");
        sql.append("t_visitor_stop_plan_rel tvspr ");
       //团队中的游客可能来自于不同的线路行程，那么就要获取该团队中所有游客的来源线路行程并且该行程需要与主线路行程一致
        sql.append(" on exists(select stopid from t_route_stop trs1 where trs1.destinationsite = trs.destinationsite and trs1.departuresite = trs.departuresite and trs1.stopid = tvspr.routestopid and tvspr.planid = :planid) ");
        sql.append("and tps.planid = tvspr.planid ");
        sql.append("where  tps.planid = :planid ");
        //--end(#1)
        sql.append(") rov ");
        sql.append("left join  ");
        sql.append("t_visitor tv ");
        sql.append("on rov.visitorid = tv.visitorid ");
        //--end(#2)
        sql.append(" ) gv ");
        sql.append("left join ");
        sql.append("t_generic_order tgo ");
        sql.append("on tgo.orderid = gv.orderid ");
        //--end(#3)
        sql.append(") go ");
        sql.append("left join ");
        sql.append(" t_order_detail_plan_transport todpt ");
        sql.append(" on todpt.orderid = go.orderid and todpt.routestopid = go.routestopid ");
        //--end(#4)
        sql.append(") rs group by rs.stopid, rs.transporttype, rs.transportclass, rs.planstopid ");
        //--end(#5)
        sql.append(") rs ");
        sql.append("left join ");
        sql.append("t_plan_stop tps ");
        sql.append("on tps.stopid =  rs.planstopid ");
        sql.append("left join t_dictionary td ");
        sql.append(" on rs.transporttype = td.dictid and td.cateid = 'transporttype' ");
        sql.append("where rs.transporttype is not null and rs.transportclass is not null order by tps.stopname ");
       // --end(#6)
        return this.simpleSpringJdbcTemplate.queryForMap(sql, paramMap);
    }

    /*
     * 
    * <p>Title: getStopTransportRecourcesExists</p>
    * <p>Description: </p>
    * @param stopid
    * @param string
    * @return
    * @see com.cct9k.dao.reseller.PlanTransportDao#getStopTransportRecourcesExists(java.lang.String, java.lang.String)
     */
    @Override
    public Boolean getStopTransportRecourcesExists(String stopid ) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("stopid", stopid);
        sql.append(" select * from T_Plan_Transport tpt where tpt.stopid = :stopid  ");
        return this.simpleSpringJdbcTemplate.isDataExists(sql, paramMap);
    }

    /*
     * 
    * <p>Title: queryPlanTransportSourceOrderDetail</p>
    * <p>Description: </p>
    * @param planId
    * @param planStopId
    * @return
    * @see com.cct9k.dao.reseller.PlanTransportDao#queryPlanTransportSourceOrderDetail(java.lang.String, java.lang.String)
     */
    @Override
    public List<Map<String, Object>> queryPlanTransportSourceOrderDetail(String planId, String planStopId, String transportType, String transportclass) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("planId", planId);
        paramMap.put("planStopId", planStopId);
        paramMap.put("transportType", transportType);
        paramMap.put("transportclass", transportclass);
        
        sql.append("select rs.planid, rs.stopname, rs.orderid, tgo.name, td.typename, rs.quantity, td1.typename typenameclass  from ( ");
        sql.append("select planid, stopid, stopname, routestopid, sum(quantity) quantity, orderid,  transporttype, transportclass from( ");
        sql.append("select distinct tps.planid, tps.stopid, tps.stopname, tps.routestopid,  tv.visitorid, tv.orderid, tgo.name, sign(todpt.quantity) quantity,  todpt.transporttype, todpt.transportclass from ");
        sql.append("t_plan_stop tps , t_visitor_stop_plan_rel tvspr,  t_visitor tv, t_generic_order tgo, t_order_detail_plan_transport todpt ");
        sql.append("where tps.planid = :planId and tps.stopid = :planStopId and todpt.transportType = :transportType and todpt.transportclass = :transportclass ");
        sql.append("and tvspr.routestopid in (select trs1.stopid from t_route_stop trs, t_route_stop trs1 where trs.stopid = tps.ROUTESTOPID and trs1.destinationsite = trs.destinationsite and trs1.departuresite = trs.departuresite ) ");
        sql.append("and tps.planid = tvspr.planid ");
        sql.append("and tvspr.visitorid = tv.visitorid ");
        sql.append(" and tv.orderid = tgo.orderid ");
        sql.append("and todpt.orderid = tgo.orderid ");
        sql.append(") rs group by planid, stopid, stopname, routestopid, orderid,  transporttype, transportclass ");
        sql.append(") rs , t_generic_order tgo , t_dictionary td, t_dictionary td1  ");
        sql.append("where rs.transporttype = td.dictid and td.cateid = 'transporttype' ");
        sql.append(" and rs.transportclass = td1.dictid ");
        sql.append(" and td1.cateid       = rs.transporttype ");
        sql.append("and rs.orderid = tgo.orderid ");
        
        return this.simpleSpringJdbcTemplate.queryForMap(sql, paramMap);
    }

	@Override
	public List<?> getPlanTransportOrders(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select a.planid,                                                    ");
		querySql.append("        null as orderid,                                             ");
		querySql.append("        '自维护客户' as customersource,                              ");
		querySql.append("        null as ordername,                                           ");
		querySql.append("        d.productname,                                               ");
		querySql.append("        c.customername,                                              ");
		querySql.append("        null as orderdate,                                           ");
		querySql.append("        b.quantity,                                                  ");
		querySql.append("        b.amount,                                                    ");
		querySql.append("        null as orderstatus,                                         ");
		querySql.append("        null as paymentstatus,                                       ");
		querySql.append("        null as estimatestatus                                       ");
		querySql.append("   from t_plan a, t_plan_transport b, t_customer c, t_customer_product d  ");
		querySql.append("  where a.planid = b.planid                                          ");
		querySql.append("    and b.transport = c.customerid                                   ");
		querySql.append("    and b.product = d.productid                                      ");
		querySql.append("    and a.planid = :planid                                           ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);
		
        return query.list();
	}
}
