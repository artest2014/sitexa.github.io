package com.cct9k.dao.reseller.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Repository;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.GuiderDao;
import com.cct9k.entity.main.Guide;
import com.cct9k.entity.main.GuiderPage;


/**
 * 导游首页service
 * @author Administrator
 *
 */
@Repository
public class GuiderDaoImpl extends BaseDaoImpl<Guide, String> implements GuiderDao{
	
	/**
	 * 分页查询导游信息
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination getGuiderList(Map<String,Object> paraMap,int pageNo, int pageSize){
		StringBuffer sql = new StringBuffer();
		sql.append("select * from ");
		sql.append("((");
		sql.append("select a.MEMBERID,c.REALNAME,a.PERSONDESC,");
		sql.append(" b.PICURL");
		sql.append(" from T_GUIDE a");
		sql.append(" left join t_picture b on a.MEMBERID=b.OBJECTID");
		sql.append(" and b.objecttype='14370'");
		sql.append(" left join t_member_person c on a.MEMBERID=c.MEMBERID");
		if (paraMap != null){
			if (paraMap.get("labels") != null && !"".equals(paraMap.get("labels"))){
				sql.append(" inner join T_OBJ_LABEL_REF d on a.MEMBERID=d.OBJID");
				sql.append(" inner join T_PRODUCT_LABEL_INFO e on d.LABELID=e.LABELID");
			}
		}
		sql.append(" where 1=1");
		sql.append(" and a.ENABLEFLAG='1'");
		if (paraMap != null){
			Set<String> paraSet = paraMap.keySet();
			Iterator<String> iter = paraSet.iterator();
			while(iter.hasNext()){
				String key = (String) iter.next();
				// 地区递归查询检索
				if ("site".equals(key)){
					//sql.append(" and a.siteid in(").append(paraMap.get(key)).append(")");
					sql.append(" and exists");
					sql.append(" (select gg.siteid from (select ff.siteid from t_site ff start with ff.siteid ='").append(paraMap.get(key)).append("'");
					sql.append(" Connect by Prior ff.siteid=ff.parentid) gg").append(" where c.SITEID=gg.siteid").append(")");
				}
				else if ("labels".equals(key)){
					//sql.append(" and e.labelid in(").append(paraMap.get(key)).append(")");
					Map<String,Object> m = (Map<String,Object>)paraMap.get(key);
					Set<String> s = m.keySet();
					Iterator<String> it = s.iterator();
					while (it.hasNext()){
						sql.append(" and g.labelid in (").append(m.get(it.next())).append(")");
					}
				}
				else if ("sort".equals(key)){
					if ("asc".equals(paraMap.get(key))){
						sql.append("order by v.minprice asc");
					}
					else if ("desc".equals(paraMap.get(key))){
						sql.append("order by v.minprice desc");
					}
				}
			}
		}
		sql.append(") a1");
		sql.append(" left join");
		sql.append("(select a.memberid, min(a.DAYPRICE) as dayprice from T_GUIDE_PRODUCT a group by a.memberid) a2");
		sql.append(" on a1.MEMBERID=a2.memberid");
		sql.append(")");
		
		
		
		
		// 获取数据
		Pagination p = findSql(sql.toString(), pageNo, pageSize);
		List<Object[]> result = (List<Object[]>) p.getList();
		List rstlist = null;
		if (result != null){
			GuiderPage guider = null;
			rstlist = new ArrayList();
			for (Object[] arr : result){
				if (arr != null && arr.length > 0){
					guider = new GuiderPage();
					guider.setMemberid(arr[0]!=null?(String)arr[0]:"");
					guider.setRealname(arr[1]!=null?(String)arr[1]:"");
					guider.setPersondesc(arr[2]!=null?(String)arr[2]:"");
					guider.setPicurl(arr[3]!=null?(String)arr[3]:"");
					guider.setDayprice(arr[5]!=null?(BigDecimal)arr[5]:null);
					rstlist.add(guider);
				}
			}
		}
		p.setList(rstlist);
		return p;
	}
}
