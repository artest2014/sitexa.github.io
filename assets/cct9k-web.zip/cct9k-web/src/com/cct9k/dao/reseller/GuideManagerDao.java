package com.cct9k.dao.reseller;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;

import java.util.List;

/**
 * <p>Class Name: GuideManagerDao.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: caimao</p>
 * <p>Date: 2013-7-19</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
public interface GuideManagerDao extends BaseDao<Member, String> {

    public Pagination getPage(String resllerId, String guideName, String registTime, int pageNo, int pageSize);
    
    public Pagination getFreeGuidePage(String resellerid,String guideName, String guideAccount, int pageNo, int pageSize);

    public Pagination getSelectedGuidePage(String resellerid,String guideName, String guideAccount, int pageNo, int pageSize);

    public void deleteGuiderById(String id);
    
    public void deleteSelectedGuideById(String resellerId,String guideId);

    public void addGuide(String resellerID, String guideID);
    
    public void addGuides(String resellerId,List<String> guideIdList);

    public List<String> getAllGuideByResellerId(String id);
}
