package com.cct9k.dao.reseller;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.PlanHotel;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:53
 */
public interface PlanHotelDao extends BaseDao<PlanHotel, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public List<Map<String,Object>> getOrderHotelNo(String planId,String stopId);

    /**
     * 根据行程计划id 查询未绑定会员的客户自维护的住房计划
     * @param planId 
     * @return
     */
    public List<?> getPlanHotelOrders(String planId);
}
