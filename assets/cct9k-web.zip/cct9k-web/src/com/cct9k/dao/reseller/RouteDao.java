package com.cct9k.dao.reseller;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Route;



/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:09
 */
public interface RouteDao extends BaseDao<Route, String> {

	public String createId();

    public Pagination getPage(Member reseller, int pageNo, int pageSize);

    public Pagination search(String routename, String departure, String destination, int pageNo, int pageSize);

    public Pagination getOnsaleRouteByReseller(Member reseller, int pageNo, int pageSize);

    public Pagination searchRoute(Member reseller, String routename, String departure, String destination, int pageNo, int pageSize);
    
    public Pagination searchRoute(String province, String city,String county,int pageNo, int pageSize);
    
    public Pagination getRouList(String seller,String routeName, int pageNo,
			int pageSize);
    /**
     * 
     * 描述: 前台查询线路
     * @param param 条件值
     * @param pageNo
     * @param pageSize
     */
    public Pagination getRouteList(Map<String,Object> param,int pageNo, int pageSize);
    
    /**
     * 查询最热门十条线路
     * @return
     */
    public List<Route> getHotRoute();
}
