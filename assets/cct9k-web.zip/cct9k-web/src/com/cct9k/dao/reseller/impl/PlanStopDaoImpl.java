package com.cct9k.dao.reseller.impl;

import java.util.List;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanStopDao;
import com.cct9k.entity.reseller.Plan;
import com.cct9k.entity.reseller.PlanStop;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:00
 */
@Repository
public class PlanStopDaoImpl extends BaseDaoImpl<PlanStop, String> implements PlanStopDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PlanStop model where 1=1");

        r.append(" order by starttime asc");

        return find(r, pageNo, pageSize);
    }

	@Override
	public List<PlanStop> getListByStop(Plan plan) {
		// TODO Auto-generated method stub
		String hql = "from PlanStop model where model.plan.planid=:planid order by to_number(stopname) ";
        return getSession().createQuery(hql).setParameter("planid", plan.getPlanid()).list();
	}

}
