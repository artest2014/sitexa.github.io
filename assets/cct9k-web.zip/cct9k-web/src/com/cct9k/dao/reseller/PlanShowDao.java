package com.cct9k.dao.reseller;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.PlanShow;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:59
 */
public interface PlanShowDao extends BaseDao<PlanShow, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    
    /**
     * 
    * @Title: queryPlanShowResources
    * @Description: 获取团队娱乐计划所需资源信息，团队中的游客有可能来之于多个线路，但是行程计划只能按照主线路的行程计划制定
    * @param mainRouteId 主线路ID
    * @param planId 团队ID
    * @return     
    * @throws
     */
    List<Map<String, Object>> queryPlanShowResources(String mainRouteId, String planId); 

    /**
     * 
    * @Title: stopShowRecourcesExists
    * @Description: 获得行程娱乐资源是否存在。
    * @param stopId 行程编号
    * @param customerId 娱乐点编号
    * @return     
    * @throws
     */
    Boolean getStopShowRecourcesExists(String stopId, String customerId);
    
    
    /**
     * 
    * @Title: queryPlanShowSourceOrderDetail
    * @Description: 查询团队娱乐来源订单详细
    * @param planId 团队ID
    * @param planStopId 团队行程ID
    * @param customerId 娱乐点ID
    * @return     
    * @throws
     */
    List<Map<String, Object>> queryPlanShowSourceOrderDetail(String planId, String planStopId, String customerId);
}
