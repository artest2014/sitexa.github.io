package com.cct9k.dao.reseller;

import java.util.List;
import java.util.Map;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.RoutePricePackage;
import com.cct9k.entity.reseller.RouteStop;

public interface RoutePricePackageDao extends BaseDao<RoutePricePackage, String> {
	/**
	 * 包含没选的线路属性
	 **/
	List<Map<String, Object>> findRouteTransportElement(RouteStop stop, RoutePricePackage pricePackage);
	/**
	 * 包含没选的线路属性
	 **/
	List<Map<String, Object>> findRouteCateringElement(RouteStop stop, RoutePricePackage pricePackage);
	/**
	 * 包含没选的线路属性
	 **/
	List<Map<String, Object>> findRouteHotelElement(RouteStop stop, RoutePricePackage pricePackage);
	/**
	 * 包含没选的线路属性
	 **/
	List<Map<String, Object>> findRouteShowElement(RouteStop stop, RoutePricePackage pricePackage);
	/**
	 * 包含没选的线路属性
	 **/
	List<Map<String, Object>> findRouteGateElement(RouteStop stop, RoutePricePackage pricePackage);
	
	
	
	/**
	 * 包含只选了的线路属性
	 **/
	List<Map<String, Object>> findTransportElement(RouteStop stop, RoutePricePackage pricePackage);
	/**
	 * 包含只选了的线路属性
	 **/
	List<Map<String, Object>> findCateringElement(RouteStop stop, RoutePricePackage pricePackage);
	/**
	 * 包含只选了的线路属性
	 **/
	List<Map<String, Object>> findHotelElement(RouteStop stop, RoutePricePackage pricePackage);
	/**
	 * 包含只选了的线路属性
	 **/
	List<Map<String, Object>> findShowElement(RouteStop stop, RoutePricePackage pricePackage);
	/**
	 * 包含只选了的线路属性
	 **/
	List<Map<String, Object>> findGateElement(RouteStop stop, RoutePricePackage pricePackage);
}
