package com.cct9k.dao.reseller;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Onsale;
import com.cct9k.entity.reseller.Route;

import java.util.Date;
import java.util.List;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:45
 */
public interface OnsaleDao extends BaseDao<Onsale, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public List getOnsaleRouteList(String keyword, String reseller);

    public Pagination getOnsaleByReseller(Member member, int pageNo, int pageSize);

    public List<Route> getRouteByReseller(Member reseller);

    public Onsale getByRouteAndStarttime(String routeid, Date starttime);

    public Pagination getOnsaleWithOrderByReseller(Member reseller, int pageNo, int pageSize);

    public Pagination getOnsaleWithOrderByReseller(Member reseller, String routename, Date start, Date end, String status, int pageNo, int pageSize);
    
    public List<Onsale> getOnsaleListByRouteId(String routeId);
    
    List<Onsale> findByRouteId(Member reseller, String routeId, Date start, Date end, String status);
    
    public List<Onsale>  getOnsaleByRouteId(String routeid) ;
    
	public void deleteByOnsale(Onsale entity);
}
