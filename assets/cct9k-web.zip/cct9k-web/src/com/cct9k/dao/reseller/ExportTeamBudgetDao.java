package com.cct9k.dao.reseller;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.order.GenericOrder;

public interface ExportTeamBudgetDao extends BaseDao<GenericOrder, String>
{
	/**
	 * 根据行程计划id 查询酒店预算清单
	 * 
	 * @param planId
	 * @return
	 */
	public List<?> getHotelBudget(String planId);

	/**
	 * 根据行程计划id 查询餐饮预算清单
	 * 
	 * @param planId
	 * @return
	 */
	public List<?> getRestaurantBudget(String planId);

	/**
	 * 根据行程计划id 查询门票预算清单
	 * 
	 * @param planId
	 * @return
	 */
	public List<?> getGateBudget(String planId);

	/**
	 * 根据行程计划id 查询交通预算清单
	 * 
	 * @param planId
	 * @return
	 */
	public List<?> getTransportBudget(String planId);

	/**
	 * 根据行程计划id 查询导服预算清单
	 * 
	 * @param planId
	 * @return
	 */
	public List<?> getGuideBudget(String planId);

	/**
	 * 根据行程计划id 查询导游代收款明细
	 * 
	 * @param planId
	 * @return
	 */
	public List<?> getAgencyDetail(String planId);

	/**
	 * 根据行程计划id 查询导服预支团款
	 * 
	 * @param planId
	 * @return
	 */
	public Float getAdvanceAmount(String planId);
}
