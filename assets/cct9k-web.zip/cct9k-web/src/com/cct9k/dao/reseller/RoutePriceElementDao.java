package com.cct9k.dao.reseller;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.RoutePriceElement;

public interface RoutePriceElementDao extends BaseDao<RoutePriceElement, String> {

}
