package com.cct9k.dao.reseller.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.RouteShowDao;
import com.cct9k.entity.reseller.RouteShow;

@Repository
public class RouteShowDaoImpl extends BaseDaoImpl<RouteShow, String> implements
		RouteShowDao {

}
