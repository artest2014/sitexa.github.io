package com.cct9k.dao.reseller;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.PlanRestaurant;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:56
 */
public interface PlanRestaurantDao extends BaseDao<PlanRestaurant, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public List<Map<String,Object>> getResultList(String planId);
    
    public List<Map<String,Object>> getOrederMealPersonNo(String planId,String routeStopId);
    
    /**
     * 根据行程计划id 查询未绑定会员的客户自维护的餐饮计划
     * @param planId 
     * @return
     */
    public List<?> getPlanRestaurantOrders(String planId);
}
