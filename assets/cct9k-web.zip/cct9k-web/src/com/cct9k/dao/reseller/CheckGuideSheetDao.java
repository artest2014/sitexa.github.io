package com.cct9k.dao.reseller;

import java.util.Date;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.CheckSheet;
import com.cct9k.entity.member.Member;

public interface CheckGuideSheetDao extends BaseDao<CheckSheet, String> {

      //报账单审核
      public Pagination sheetInfoList(String memberid, String startTime,String endTime,String commitStartTime,String commitEndTime,
    			String routeName, String sheetStatus, int pageNo, int pageSize);
}
