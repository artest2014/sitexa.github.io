package com.cct9k.dao.reseller.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.RouteHotelDao;
import com.cct9k.entity.reseller.RouteHotel;

@Repository
public class RouteHotelDaoImpl extends BaseDaoImpl<RouteHotel, String> implements
		RouteHotelDao {

	@Override
	public void deleteByStopId(String stopId) {
		String hql = "delete RouteHotel rh where rh.routestop.stopid = :stopId";
		getSession().createQuery(hql).setParameter("stopId", stopId).executeUpdate();
		
	}
}
