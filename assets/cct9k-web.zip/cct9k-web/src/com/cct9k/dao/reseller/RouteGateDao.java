package com.cct9k.dao.reseller;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.Customer;
import com.cct9k.entity.main.Scenery;
import com.cct9k.entity.reseller.RouteGate;
import com.cct9k.entity.reseller.RouteStop;

import java.util.List;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:09
 */
public interface RouteGateDao extends BaseDao<RouteGate, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public List<RouteGate> findByStopAndScenery(RouteStop routestop, Customer customer);
}
