package com.cct9k.dao.reseller.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.VisitorDao;
import com.cct9k.entity.order.GenericOrder;
import com.cct9k.entity.reseller.Plan;
import com.cct9k.entity.reseller.Visitor;
import com.cct9k.util.common.StringUtil;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:18
 */
@Repository
@SuppressWarnings("unchecked")
public class VisitorDaoImpl extends BaseDaoImpl<Visitor, String> implements VisitorDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from Visitor model where 1=1");

        r.append(" order by memberid asc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public String getVisitorSeq() {
        String sql = " select S_VISITOR.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }

    public List<Visitor> getVisitorListByOrderId(String orderId) {

        String hql = ("From Visitor v where v.orderid='" + orderId + "'");
        List<Visitor> list = getListByHql(hql);
        if (list != null && list.size() > 0) {
            return list;
        } else {
            return null;
        }
    }
    
    /**
     * 根据订单号查询游客
     * @author qlg
     * @param VISITORID			游客id
     * @param CUSTOMERID 		客户id
     * @param KEEPER 			(监护人)id
     * @param CUSTOMERNAME 		游客名称
     * @param GENDER 			性别 	 	0：女，1：男
     * @param SHAREROOM 		是否共房 	0：否，1：是
     * @param ISCHILD			是否小孩	0：是，1：否
     * @param KEEPERNAME		监护人(小孩有)
     * @param MOBILE			手机号
     * @param IDENTITYTYPENAME	证件类型
     * @param IDENTITYNO		证件号
     * @param EMAIL				邮箱
     * 
     */
    public List<Map<String, Object>> getVisitorList(String orderId) {
    	StringBuffer sql = new StringBuffer(" SELECT TV.VISITORID, TC.CUSTOMERID,TV.KEEPER,TC.CUSTOMERNAME,TC.GENDER,TV.SHAREROOM,TV.ISCHILD,");
    	sql.append(" CASE WHEN TV.ISCHILD='0' THEN(SELECT TT.CUSTOMERNAME || '[' || TT.IDENTITYNO || ']' FROM T_CUSTOMER TT  WHERE TT.CUSTOMERID=TV.KEEPER) ELSE ''  END AS KEEPERNAME ,");
    	sql.append(" TC.MOBILE,TD.TYPENAME AS IDENTITYTYPENAME,TC.IDENTITYNO,TC.EMAIL");
    	sql.append(" FROM T_VISITOR TV");
    	sql.append(" LEFT JOIN T_CUSTOMER TC ON TV.CUSTOMERID = TC.CUSTOMERID");
    	sql.append(" LEFT JOIN T_DICTIONARY TD ON TD.DICTID=TC.IDENTITYTYPE");
    	sql.append(" WHERE TV.ORDERID =:ORDERID");
    	Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
    	query.setParameter("ORDERID", orderId);
        return query.list();
    }

    public boolean isExistVisitorByIdentityNo(String orderId, String identityNo, String ownerId, String customerType, String visitorId,String identityType) {
        String sql = " select v.* from t_visitor v,t_customer t  where v.CUSTOMERID=t.customerid";
        if (!StringUtil.isEmpty(orderId)) {
            sql += " and v.orderid='" + orderId + "'";
        }
        if (!StringUtil.isEmpty(identityNo)) {
            sql += " and t.identityno='" + identityNo + "'";
        }
        if (!StringUtil.isEmpty(identityType)) {
        	sql += " and t.identityType='" + identityType + "'";
        }
        if (!StringUtil.isEmpty(ownerId)) {
            sql += " and t.ownerid='" + ownerId + "'";
        }
        if (!StringUtil.isEmpty(customerType)) {
            sql += " and t.customertype='" + customerType + "'";
        }
        if (!StringUtil.isEmpty(visitorId)) {
            sql += " and v.visitorid !='" + visitorId + "'";
        }
        Query query = this.getSession().createSQLQuery(sql);
        List resultList = query.list();
        if (resultList != null && resultList.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public int getChildNum(String orderId) {
        String sql = " select count(t.orderid) from t_visitor t  where t.orderid=? and t.ischild='0'";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, orderId);
        List<String> resultList = query.list();
        Object num = null;
        if (resultList != null && resultList.size() > 0) {
            num = (Object) resultList.get(0);
            return Integer.parseInt(num.toString());
        } else {
            return 0;
        }
    }

    public int getAdultNum(String orderId) {
        String sql = " select count(t.orderid) from t_visitor t  where t.orderid=? and t.ischild='1'";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, orderId);
        List<String> resultList = query.list();
        Object num = null;
        if (resultList != null && resultList.size() > 0) {
            num = (Object) resultList.get(0);
            return Integer.parseInt(num.toString());
        } else {
            return 0;
        }
    }

    public int getNotShareRoomNum(String orderId) {
        String sql = " select count(t.orderid) from t_visitor t  where t.orderid=? and t.shareroom='1'";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, orderId);
        List<String> resultList = query.list();
        Object num = null;
        if (resultList != null && resultList.size() > 0) {
            num = (Object) resultList.get(0);
            return Integer.parseInt(num.toString());
        } else {
            return 0;
        }
    }
    
    public int getNotShareRoomChildNum(String orderId) {
        String sql = " select count(t.orderid) from t_visitor t  where t.orderid=? and t.shareroom='1' and t.ischild='0' ";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, orderId);
        List<String> resultList = query.list();
        Object num = null;
        if (resultList != null && resultList.size() > 0) {
            num = (Object) resultList.get(0);
            return Integer.parseInt(num.toString());
        } else {
            return 0;
        }
    }
    
    public int getNotShareRoomAdultNum(String orderId) {
        String sql = " select count(t.orderid) from t_visitor t  where t.orderid=? and t.shareroom='1' and t.ischild='1' ";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, orderId);
        List<String> resultList = query.list();
        Object num = null;
        if (resultList != null && resultList.size() > 0) {
            num = (Object) resultList.get(0);
            return Integer.parseInt(num.toString());
        } else {
            return 0;
        }
    }
    
    public int getNotTeamVisitorNum(String orderId){
      String sql = "select count(visitorid) from t_visitor where orderid='"+orderId+"' and planid is null";
      Query query = this.getSession().createSQLQuery(sql);
      List<String> resultList = query.list();
      Object num = null;
      if (resultList != null && resultList.size() > 0) {
          num = (Object) resultList.get(0);
          return Integer.parseInt(num.toString());
      } else {
          return 0;
      }
    }

    @Override
    public List<Visitor> getByOrders(List<GenericOrder> orders) {
        String ids = "";
        for (int i = 0; i < orders.size(); i++) {
            GenericOrder order = orders.get(i);
            if (i == 0) ids += order.getOrderId();
            else ids += "," + order.getOrderId();
        }
        if (ids.length() == 0) return new ArrayList<Visitor>();
        String sql = "from Visitor where orderid in (" + ids + ") order by visitorid asc ";
        return getListByHql(sql);
    }

    @Override
    public List<Visitor> getByOrders(String[] ids) {
        String idstring = "";
        for (int i = 0; i < ids.length; i++) {
            String id = ids[i];
            if (i == 0) idstring += id;
            else idstring += "," + id;
        }
        if (idstring.length() == 0) return new ArrayList<Visitor>();
        String sql = "from Visitor where orderid in (" + idstring + ") order by visitorid asc ";
        return getListByHql(sql);
    }

    @Override
    public List<Visitor> getByPlan(Plan plan) {
        String hql = "select tv from Visitor tv ,( select vr.visitor.visitorid from VisitorStopPlanRel vr where vr.plan.planid='" + plan.getPlanid() + "'  group by vr.visitor.visitorid) b_ where tv.visitorid=b_.visitorid ";
        return getListByHql(hql);
    }

	@Override
	public List<Visitor> getByPlanAndStop(String stopId, String PlanId) {
		// TODO Auto-generated method stub
			List result = new ArrayList();
	        String hql = ("select v From Visitor v,VisitorStopPlanRel vsr where v.visitorid=vsr.visitor.visitorid and vsr.plan.planid='" + PlanId + "' and vsr.routestop.stopid='"+stopId+"'");
	        List<Visitor> list = getListByHql(hql);
	        if (list != null && list.size() > 0) {
	        	result = list;
	        }  
	   
		return result;
	}

	@Override
	public List<Map<String, Object>> getCollectVisitorInfomation(String planId) {
		// TODO Auto-generated method stub
		Map<String,String> paraMap = new HashMap<String,String>();
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT TC.*, TV.* ");
        sb.append("FROM T_VISITOR TV ");
        sb.append("INNER JOIN (SELECT TEL.PLANID, TEL.VISITORID ");
        sb.append("FROM T_VISITOR_STOP_PLAN_REL TEL ");
        sb.append("WHERE TEL.PLANID = :planid ");
        sb.append("GROUP BY TEL.VISITORID, TEL.PLANID) TEL_TMP ON TV.VISITORID = ");
        sb.append("TEL_TMP.VISITORID ");
        sb.append("INNER JOIN T_CUSTOMER TC ON TV.CUSTOMERID = TC.CUSTOMERID ");
        sb.append("WHERE TV.COLLECTAMOUNT > 0 ");
        paraMap.put("planid", planId);
        List<Map<String, Object>> list = this.getSimpleSpringJdbcTemplate().queryForMap(sb, paraMap);
		return list;
	}

}
