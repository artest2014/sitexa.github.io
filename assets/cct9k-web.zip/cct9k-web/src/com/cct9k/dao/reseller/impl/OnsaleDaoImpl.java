package com.cct9k.dao.reseller.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.OnsaleDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Onsale;
import com.cct9k.entity.reseller.Route;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:46
 */
@Repository
public class OnsaleDaoImpl extends BaseDaoImpl<Onsale, String> implements OnsaleDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from Onsale model where 1=1");

        r.append(" order by starttime asc");

        return find(r, pageNo, pageSize);
    }

    public List getOnsaleRouteList(String keyword, String reseller) {
        String sql = "select t.routename,t.routeid,os.onsaleid,t.groupsize,t.departure,t.destination," +
                "t.maxprice,t.minprice,t.duration, to_char(os.starttime,'yyyy-MM-dd HH24:mi') from t_route t,t_onsale os " +
                "where t.routeid=os.routeid and os.status='1' " +
                " and (os.starttime >= SYSDATE and (os.starttime - SYSDATE) * 24 > os.endtime)";
        if (!StringUtil.isEmpty(keyword)) {
            sql += " and t.routename like '%" + keyword + "%'";
        }
        if (!StringUtil.isEmpty(reseller)) {
            sql += " and os.reseller='" + reseller + "' ";
        }
        Query query = this.getSession().createSQLQuery(sql);
        List resultList = query.list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        } else {
            return null;
        }
    }

    @Override
    public Pagination getOnsaleByReseller(Member member, int pageNo, int pageSize) {
        Finder f = Finder.create("from Onsale model where model.reseller.memberid=:memberid and model.status<>'3'  order by model.route.routeid, model.starttime desc ");
        f.setParam("memberid", member.getMemberid());
        return find(f, pageNo, pageSize);
    }

    @Override
    public List<Route> getRouteByReseller(Member reseller) {
        String sql = "select distinct routeid from t_onsale  where reseller=:memberid order by routeid ";

        List<String> routes = getSession().createSQLQuery(sql).setParameter("memberid", reseller.getMemberid()).list();
        String ids = "(";
        for (int i = 0; i < routes.size(); i++) {
            String id = routes.get(i);
            if (i == 0) ids += "'" + id + "'";
            else ids += ",'" + id + "'";
        }
        ids += ")";

        String hql = "select * from t_onsale where routeid in " + ids + " order by starttime asc ";
        return getSession().createSQLQuery(hql).list();
    }

    @Override
    public Onsale getByRouteAndStarttime(String routeid, Date starttime) {
        String sql = "from Onsale model where model.route.routeid=:routeid and model.starttime=:starttime ";
        return (Onsale) getSession().createQuery(sql).setParameter("routeid", routeid).setParameter("starttime", starttime).uniqueResult();
    }

    @Override
    public Pagination getOnsaleWithOrderByReseller(Member reseller, int pageNo, int pageSize) {
        //String sql = "select s from Onsale s,OrderDetailPlan d,GenericOrder o where s.onsaleid = d.onsale.onsaleid and d.order.orderId = o.orderId and s.reseller.memberid=:memberid order by s.starttime asc ";
        String sql = "select s from Onsale s where s.reseller.memberid=:memberid order by s.starttime asc ";
        //return getSession().createQuery(sql).setParameter("memberid", reseller.getMemberid()).list();

        Finder f = Finder.create(sql);
        f.setParam("memberid", reseller.getMemberid());

        return find(f, pageNo, pageSize);

    }

    @Override
    public Pagination getOnsaleWithOrderByReseller(Member reseller, String routename, Date start, Date end, String status, int pageNo, int pageSize) {
    	Map<String, Object> params = new HashMap<String, Object>();
    	StringBuffer sql = new StringBuffer("select r.routeid, r.routename, o.minStartTime, o.maxStartTime, o.counts, r.groupsize from t_route r ");
    	sql.append("inner join (select count(onsaleid) as counts, min(starttime) as minStartTime, max(starttime) as maxStartTime, routeid from t_Onsale where 1=1 ");
    	if (reseller != null) {
            sql.append("and reseller=:reseller ");
            params.put("reseller", reseller.getMemberid());
        }
    	if (start != null) {
            sql.append("and starttime >= :start ");
            params.put("start", start);
        }
    	if (end != null) {
            sql.append("and starttime <= :end ");
            params.put("end", end);
        }
    	if(status!=null){
			sql.append("and status = :status ");
			params.put("status", status);
		}
    	sql.append("group by routeid) o on r.routeid = o.routeid where r.routestatus=1 ");
    	if (!StringUtil.isEmpty(routename)) {
            sql.append("and r.routename like '%'||:routename||'%' ");
            params.put("routename", routename);
        }
    	return findSql(sql.toString(), null, params, pageNo, pageSize);
    	
    	/*String sql = "select s from Onsale s where 1=1 ";

        Finder f = Finder.create(sql);

        if (reseller != null) {
            f.append(" and s.reseller.memberid=:memberid ");
            f.setParam("memberid", reseller.getMemberid());
        }

        if (!StringUtil.isEmpty(routename)) {
            f.append(" and s.route.routename like '%'||:routename||'%' ");
            f.setParam("routename", routename);
        }

        if (start != null) {
            f.append(" and s.starttime >= :start ");
            f.setParam("start", start);
        }

        if (end != null) {
            f.append(" and s.starttime <= :end ");
            f.setParam("end", end);
        }

        f.append(" order by s.starttime asc ");

        return find(f, pageNo, pageSize);
*/
    }
    
    public List<Onsale> getOnsaleListByRouteId(String routeId){
    	String sql=" select os from Route r,Onsale os where 1=1 and r=os.route  and (os.starttime >= SYSDATE and (os.starttime - SYSDATE) * 24 > os.endtime) "
    			  +" and r.routestatus='1' and r.routeid=:routeId  and model.status<>'3' ";
    	Query query = this.getSession().createQuery(sql).setParameter("routeId", routeId);
    	List<Onsale> resultList = query.list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        } else {
            return null;
        }
    }

	@Override
	public List<Onsale> findByRouteId(Member reseller, String routeId,
			Date start, Date end, String status) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("memberid", reseller.getMemberid());
		params.put("routeid", routeId);
		StringBuffer sql = new StringBuffer("from Onsale model where model.reseller.memberid=:memberid and model.route.routeid=:routeid ");
		if (start != null) {
            sql.append("and model.starttime >= :start ");
            params.put("start", start);
        }
    	if (end != null) {
            sql.append("and model.starttime <= :end ");
            params.put("end", end);
        }
    	if(status!=null){
    		 sql.append("and model.status = :status ");
    		 params.put("status", status);
    	}
    	Query query = this.getSession().createQuery(sql.toString());
    	if(params!=null && !params.isEmpty()){
			for (Entry<String, Object> entry : params.entrySet()) {
				query.setParameter(entry.getKey(), entry.getValue());
	        }
		}
		return query.list();
	}
	
    public List<Onsale>  getOnsaleByRouteId(String routeid) {
       StringBuffer hql=new StringBuffer(" from Onsale model where model.starttime>(sysdate - 1) and model.route.routeid='"+routeid+"' and model.status<>'3'  order by  model.starttime asc ");
       List<Onsale> onsaleList=this.getListByHql(hql.toString());
       if(onsaleList!=null)
    	   return onsaleList;
       else
    	return null;

    }

	@Override
	public void deleteByOnsale(Onsale onsale) {
	    onsale.setStatus("3");
		update(onsale);
	}
}
