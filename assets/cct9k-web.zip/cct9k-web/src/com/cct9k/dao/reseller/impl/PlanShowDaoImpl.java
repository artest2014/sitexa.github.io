package com.cct9k.dao.reseller.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanShowDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.PlanShow;
import com.cct9k.util.common.StringUtil;

import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com> Date: 13-8-10 Time: 下午1:59
 */
@Repository
public class PlanShowDaoImpl extends BaseDaoImpl<PlanShow, String> implements PlanShowDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PlanShow model where 1=1");
        r.append(" order by showname desc");
        return find(r, pageNo, pageSize);
    }

    /*
     * 
     * <p>Title: queryPlanShowResources</p> <p>Description: </p>
     * 
     * @param mainRouteId
     * 
     * @param planId
     * 
     * @return
     * 
     * @see
     * com.cct9k.dao.reseller.PlanShowDao#queryPlanShowResources(java.lang.String
     * , java.lang.String)
     */
    @Override
    public List<Map<String, Object>> queryPlanShowResources(String mainRouteId, String planId) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("PLANID", planId);
        sql.append(" SELECT PS.STOPID AS PLANSTOPID, TT.STOPID ROUTESTOPID, TT.STOPNAME,TT.SHOWID, TT.CUSTOMERNAME,T.ADULTQUANTITY,T.CHILDRENQUANTITY ");
        sql.append(" FROM (SELECT MAX(VSPR.PLANID) PLANID, MAX(VSPR.VISITORID) VISITORID, SUM(CASE  WHEN V.ISCHILD = 0 THEN 1 ELSE  0 END) AS CHILDRENQUANTITY,");
        sql.append(" SUM(CASE WHEN V.ISCHILD = 1 THEN 1  ELSE  0 END) AS ADULTQUANTITY, MAX(VSPR.ONSALEID) ONSALEID,");
        sql.append(" MAX(VSPR.ORDERID) ORDERID, VSPR.DEPARTURESITE, VSPR.DESTINATIONSITE");
        sql.append(" FROM (SELECT T1.*, T2.DEPARTURESITE, T2.DESTINATIONSITE  FROM T_VISITOR_STOP_PLAN_REL T1");
        sql.append(" INNER JOIN T_ROUTE_STOP T2 ON T1.ROUTESTOPID = T2.STOPID WHERE T1.PLANID =:PLANID) VSPR");
        sql.append(" INNER JOIN T_VISITOR V ON VSPR.VISITORID = V.VISITORID");
        sql.append(" GROUP BY VSPR.DEPARTURESITE, VSPR.DESTINATIONSITE) T");
        sql.append(" INNER JOIN (SELECT RS.*, RE.SHOW SHOWID, C.CUSTOMERNAME");
        sql.append(" FROM T_ROUTE_STOP RS");
        sql.append(" INNER JOIN T_PLAN P ON RS.ROUTEID = P.ROUTEID");
        sql.append(" INNER JOIN T_ROUTE_SHOW RE ON RS.STOPID = RE.STOPID");
        sql.append(" INNER JOIN T_CUSTOMER C ON RE.SHOW = C.CUSTOMERID");
        sql.append(" WHERE P.PLANID =:PLANID) TT ON T.DEPARTURESITE = TT.DEPARTURESITE");
        sql.append(" AND T.DESTINATIONSITE = TT.DESTINATIONSITE");
        sql.append(" LEFT JOIN T_PLAN_STOP PS ON PS.DEPARTURESITE = TT.DEPARTURESITE  AND PS.DESTINATIONSITE = TT.DESTINATIONSITE AND PS.PLANID =:PLANID");
        return this.simpleSpringJdbcTemplate.queryForMap(sql, paramMap);
    }

    /*
     * 
     * <p>Title: getStopShowRecourcesExists</p> <p>Description: </p>
     * 
     * @param stopId
     * 
     * @param customerId
     * 
     * @return
     * 
     * @see
     * com.cct9k.dao.reseller.PlanShowDao#getStopShowRecourcesExists(java.lang
     * .String, java.lang.String)
     */
    @Override
    public Boolean getStopShowRecourcesExists(String stopId, String customerId) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("stopid", stopId);
        paramMap.put("entertainment", customerId);
        sql.append(" select * from t_plan_show tps where tps.stopid = :stopid and tps.entertainment = :entertainment ");
        return this.simpleSpringJdbcTemplate.isDataExists(sql, paramMap);
    }

    /*
     * 
     * <p>Title: queryPlanShowSourceOrderDetail</p> <p>Description: </p>
     * 
     * @param planId
     * 
     * @param planStopId
     * 
     * @param customerId
     * 
     * @return
     * 
     * @see
     * com.cct9k.dao.reseller.PlanShowDao#queryPlanShowSourceOrderDetail(java
     * .lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public List<Map<String, Object>> queryPlanShowSourceOrderDetail(String planId, String planStopId, String customerId) {
        StringBuffer sql = new StringBuffer();
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("planId", planId);
        paramMap.put("planStopId", planStopId);
        paramMap.put("customerId", customerId);
        sql.append("select rs.planid, rs.stopname, rs.orderid, tgo.name, tc.customername, rs.adultquantity, rs.childrenquantity  from ( ");
        sql.append("select planid, stopid, stopname, routestopid, sum(adultquantity) adultquantity, sum(childrenquantity) childrenquantity, orderid,  showid from( ");
        sql.append("select distinct tps.planid, tps.stopid, tps.stopname, tps.routestopid,  tv.visitorid, tv.orderid, tgo.name, sign(todps.adultquantity) adultquantity, sign(todps.childrenquantity) childrenquantity, todps.showid from ");
        sql.append("t_plan_stop tps , t_visitor_stop_plan_rel tvspr,  t_visitor tv, t_generic_order tgo, t_order_detail_plan_show todps ");
        sql.append("where tps.planid = :planId and tps.stopid = :planStopId and todps.showid = :customerId ");
        sql.append("and tvspr.routestopid in (select trs1.stopid from t_route_stop trs, t_route_stop trs1 where trs.stopid = tps.ROUTESTOPID and trs1.destinationsite = trs.destinationsite and trs1.departuresite = trs.departuresite ) ");
        sql.append("and tps.planid = tvspr.planid ");
        sql.append("and tvspr.visitorid = tv.visitorid ");
        sql.append(" and tv.orderid = tgo.orderid ");
        sql.append("and todps.orderid = tgo.orderid ");
        sql.append(" and tvspr.routestopid = todps.routestopid ");
        sql.append(") rs group by planid, stopid, stopname, routestopid, orderid, showid ");
        sql.append(") rs , t_generic_order tgo , t_customer tc ");
        sql.append("where rs.showid = tc.customerid ");
        sql.append("and rs.orderid = tgo.orderid ");
        return this.simpleSpringJdbcTemplate.queryForMap(sql, paramMap);
    }

}
