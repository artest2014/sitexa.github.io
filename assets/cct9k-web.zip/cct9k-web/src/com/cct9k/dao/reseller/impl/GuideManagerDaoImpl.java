package com.cct9k.dao.reseller.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.GuideManagerDao;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.StringUtil;

@Repository
public class GuideManagerDaoImpl extends BaseDaoImpl<Member, String> implements GuideManagerDao {

    @Override
    public List<Member> getListByHql(String hql) {
        return super.getListByHql(hql);
    }

    @Override
    public Pagination getPage(String resllerId, String guideName, String registTime, int pageNo, int pageSize) {
        String sql = "select tm.memberid,tm.membername, tm.memberstate from t_reseller_guide trg,t_member tm where trg.resellerid=" + resllerId + " and tm.memberid=trg.guideid";
        if (!StringUtil.isEmpty(guideName)) {
            sql += "  and tm.membername  like '%" + guideName + "%'";
        }
        return findSql(sql, pageNo, pageSize);
    }
    
    @Override
    public Pagination getFreeGuidePage(String resellerid,String guideName, String guideAccount, int pageNo, int pageSize){
    	StringBuffer sql=new StringBuffer("select distinct c.realname,b.membername,c.address,a.memberid ");
    	sql.append("from t_guide a inner join t_member b on a.memberid=b.memberid ");
    	sql.append("inner join t_member_person c on a.memberid=c.memberid ");
    	sql.append("where 1=1 and a.tourguidestatuscatid = '1'and a.enableflag = '1' ");
    	sql.append("and a.memberid not in (select distinct guideid from t_reseller_guide where resellerid="+resellerid+") ");
    	if(!StringUtils.isEmpty(guideName)){
    		sql.append("and c.realname='"+guideName.trim()+"' ");
    	}
    	if(!StringUtils.isEmpty(guideAccount)){
    		sql.append(" and b.membername='"+guideAccount.trim()+"' ");
    	}
        return findSql(sql.toString(),pageNo,pageSize);
    	
    }
    
    /*
     * BUG #346 【外网】客户经理子帐号看不到父账号的导游
     * 
     * 使用decode判断该登陆用户是否有parentid，如果有则去parentid的值。
     * 如果没有parentid那么就获取当前登陆者的memberid。
     * 关联t_reseller_guide表获取导游与分销商之间的从属关系。
     * resellerid只会保存旅行社的memberid，导游只会与其关联。
     * resellerid:当前登陆用户的ID，guideName:导游姓名(这里要求使用全称),guideAccount：导游账号(这里要求使用全称)
     * @author yanwei_clear
     */
    @Override
    public Pagination getSelectedGuidePage(String resellerid,String guideName, String guideAccount, int pageNo, int pageSize){
//      StringBuffer sql=new StringBuffer("select distinct c.realname,b.membername,c.address,a.memberid ");
//      sql.append("from t_guide a inner join t_member b on a.memberid=b.memberid ");
//      sql.append("inner join t_member_person c on a.memberid=c.memberid ");
//      sql.append("where 1=1 and a.memberid  in (select distinct guideid from t_reseller_guide where resellerid="+resellerid+") ");
//      if(!StringUtils.isEmpty(guideName)){
//          sql.append("and c.realname='"+guideName.trim()+"' ");
//      }
//      if(!StringUtils.isEmpty(guideAccount)){
//          sql.append(" and b.membername='"+guideAccount.trim()+"' ");
//      }
        
        StringBuilder sql = new StringBuilder();
        sql.append("select tmp.realname, tm.membername, tmp.address, tg.memberid from ");
        sql.append("t_guide tg, t_member_person tmp, t_member tm ");
        sql.append("where  ");
        sql.append("tg.memberid = tmp.memberid and tg.memberid = tm.memberid ");
        if (!StringUtils.isEmpty(guideName)) {
            sql.append("and tmp.realname='" + guideName.trim() + "' ");
        }
        if (!StringUtils.isEmpty(guideAccount)) {
            sql.append(" and tm.membername='" + guideAccount.trim() + "' ");
        }
        sql.append("and exists ");
        sql.append("( ");
        sql.append("select guideid from ");
        sql.append("t_reseller_guide trg ");
        sql.append("where ");
        sql.append("resellerid in ");
        sql.append("( ");
        sql.append("select decode(tm.parentid, null, tm.memberid, tm.parentid) from t_member tm ");
        sql.append("where ");
        sql.append("tm.memberid ").append(" = ").append(resellerid);
        sql.append(") ");
        sql.append("and tm.memberid = trg.guideid) ");
        
        return findSql(sql.toString(),pageNo,pageSize);
    }

    @Override
    public void deleteGuiderById(String id) {
        String sql = "delete from t_reseller_guide t where t.guideid=" + id;
        getSession().createSQLQuery(sql).executeUpdate();
    }

    @Override
    public void deleteSelectedGuideById(String resellerId,String guideId){
    	String sql="delete from t_reseller_guide t where t.resellerid=? and t.guideid=?";
    	getSession().createSQLQuery(sql).setString(0, resellerId).setString(1, guideId).executeUpdate();
    }
    
    @Override
    public void addGuide(String resellerID, String guideID) {
        String sql = "insert into t_reseller_guide values(?,?)";
        getSession().createSQLQuery(sql).setParameter(0, resellerID).setParameter(1, guideID).executeUpdate();
    }

    @Override
	public void addGuides(String resellerId, List<String> guideIdList) {
		String sql = "insert into t_reseller_guide values(?,?)";
		Iterator itera = guideIdList.iterator();
		Session s = null;
		s = getSession();
		while (itera.hasNext()) {
			s.createSQLQuery(sql).setParameter(0, resellerId)
					.setParameter(1, itera.next().toString()).executeUpdate();
		}
	}
    
    @Override
    public List<String> getAllGuideByResellerId(String id) {
        String sql = "select trg.guideid from t_reseller_guide trg where resellerid=" + id;
        @SuppressWarnings("unchecked") List<String> list = getSession().createSQLQuery(sql).list();
        return list;
    }


}
