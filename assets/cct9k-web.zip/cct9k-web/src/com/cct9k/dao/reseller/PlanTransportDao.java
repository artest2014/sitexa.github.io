package com.cct9k.dao.reseller;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.PlanTransport;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:01
 */
public interface PlanTransportDao extends BaseDao<PlanTransport, String> {

    public Pagination getPage(int pageNo, int pageSize);

    /**
     * 
    * @Title: queryPlanShowResources
    * @Description: 获取团队旅运计划所需资源信息，团队中的游客有可能来之于多个线路，但是行程计划只能按照主线路的行程计划制定
    * @param mainRouteId 主线路ID
    * @param planId 团队ID
    * @return     
    * @throws
     */
    List<Map<String, Object>> queryPlanTransportResources(String planId);

    /**
     * 
    * @Title: getStopGateRecourcesExists
    * @Description: 获得行程旅运资源是否存在，旅运的话只需要看该段行程是否已经预定交通。
    * @param stopId 行程编号
    * @return     
    * @throws
     */
    public Boolean getStopTransportRecourcesExists(String stopid);
    
    
    /**
     * 
    * @Title: queryPlanShowSourceOrderDetail
    * @Description: 查询团队旅运来源订单详细
    * @param planId 团队ID
    * @param planStopId 团队行程ID
    * @return     
    * @throws
     */
    List<Map<String, Object>> queryPlanTransportSourceOrderDetail(String planId, String planStopId, String transportType, String transportclass);
    
    /**
     * 根据计划id查询未绑定的交通订单
     * 
     * @param planId
     * @return
     */
    public List<?> getPlanTransportOrders(String planId);
}
