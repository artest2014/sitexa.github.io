package com.cct9k.dao.reseller;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.RouteShow;

public interface RouteShowDao extends BaseDao<RouteShow, String> {

}
