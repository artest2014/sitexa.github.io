package com.cct9k.dao.reseller.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.VisitorStopPlanRelDao;
import com.cct9k.entity.reseller.Plan;
import com.cct9k.entity.reseller.VisitorStopPlanRel;
import com.cct9k.util.common.DateUtil;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:18
 */
@Repository
@SuppressWarnings("unchecked")
public class VisitorStopPlanRelDaoImpl extends BaseDaoImpl<VisitorStopPlanRel, String> implements VisitorStopPlanRelDao {

	@Override
	public List<VisitorStopPlanRel> getByPlanAndStop(String planId, String stopId) {
	        String hql = "from VisitorStopPlanRel vsp where  vsp.plan.planid='"+planId+"' and vsp.routestop.stopid='"+stopId+"' ";
	        Query q = getSession().createQuery(hql);
	        List<VisitorStopPlanRel> list =q.list();
	        return list;
	}

	@Override
	public Pagination findByStopSite(String departuresite,
			String destinationsite, String planId, int isJoinTeam, Date starttime, String transportclass, int pageNo, int pageSize) {
		Map<String, Object> param = new HashMap<String, Object>();
		StringBuffer sql = new StringBuffer("SELECT TPR.* FROM(SELECT PR.* FROM T_VISITOR_STOP_PLAN_REL ");
		sql.append("PR INNER JOIN (SELECT * FROM T_ONSALE_STOP WHERE 1=1 ");
		if(departuresite!=null && !departuresite.trim().isEmpty()){
			sql.append("AND DEPARTURESITE=:departuresite ");
			param.put("departuresite", departuresite);
		}
		if(destinationsite!=null && !destinationsite.trim().isEmpty()){
			sql.append("AND DESTINATIONSITE=:destinationsite ");
			param.put("destinationsite", destinationsite);
		}
		if(starttime!=null){
			sql.append("AND TO_CHAR(STARTTIME, 'yyyy-MM-dd')=:starttime ");
			param.put("starttime", DateUtil.convertDateToString("yyyy-MM-dd", starttime));
		}
		if(transportclass!=null && !transportclass.trim().isEmpty()){
			sql.append("AND TRANSPORTCLASS=:transportclass ");
			param.put("transportclass", transportclass);
		}
		sql.append(") OS ON PR.ROUTESTOPID = OS.STOPID WHERE PR.ONSALEID = OS.ONSALEID ");
		if(isJoinTeam==1){
			sql.append("AND (PR.PLANID IS NULL OR PR.PLANID='') ");
		}else if(isJoinTeam==2){
			sql.append("AND (PR.PLANID IS NOT NULL AND PR.PLANID!='') ");
		}
		if(planId!=null && !planId.trim().isEmpty() && isJoinTeam!=1){
			sql.append("AND PR.PLANID=:planId ");
			param.put("planId", planId);
		}
		sql.append(") TPR INNER JOIN T_GENERIC_ORDER TGO ON TPR.ORDERID = TGO.ORDERID WHERE TGO.PAYMENTSTATUS=1 OR TGO.PAYMENTSTATUS=2");
		return findSql(sql.toString(), VisitorStopPlanRel.class, param, pageNo, pageSize);
	}

	@Override
	public Pagination findRelatedOrderByStopSite(String departuresite,
			String destinationsite, String planId, int isJoinTeam,
			Date starttime, String transportclass, int pageNo, int pageSize) {
		Map<String, Object> param = new HashMap<String, Object>();
		StringBuffer sql = new StringBuffer("SELECT T1.ORDERID, T1.STOPID, T1.DEPARTURESITE, T1.DESTINATIONSITE, ");
		sql.append("T1.TRANSPORTCLASS, T1.ONSALEID, T1.NAME, T2.COUNTS FROM (");
		StringBuffer sonSql = new StringBuffer("SELECT * FROM V_ORDER_STOP WHERE 1=1 ");
		if(departuresite!=null && !departuresite.trim().isEmpty()){
			sonSql.append("AND DEPARTURESITE=:departuresite ");
			param.put("departuresite", departuresite);
		}
		if(destinationsite!=null && !destinationsite.trim().isEmpty()){
			sonSql.append("AND DESTINATIONSITE=:destinationsite ");
			param.put("destinationsite", destinationsite);
		}
		if(starttime!=null){
			sonSql.append("AND TO_CHAR(STARTTIME, 'yyyy-MM-dd')=:starttime ");
			param.put("starttime", DateUtil.convertDateToString("yyyy-MM-dd", starttime));
		}
		if(transportclass!=null && !transportclass.trim().isEmpty()){
			sonSql.append("AND TRANSPORTCLASS=:transportclass ");
			param.put("transportclass", transportclass);
		}
		sonSql.append(" AND PAYMENTSTATUS=1 OR PAYMENTSTATUS=2");
		sql.append(sonSql);
		sql.append(") T1 INNER JOIN (SELECT OS.ORDERID, PR.ROUTESTOPID, PR.ONSALEID, COUNT(OS.ORDERID) COUNTS ");
		sql.append("FROM T_VISITOR_STOP_PLAN_REL PR INNER JOIN (");
		sql.append(sonSql);
		sql.append(") OS ON PR.ROUTESTOPID = OS.STOPID WHERE PR.ORDERID=OS.ORDERID AND PR.ONSALEID = OS.ONSALEID AND ");
		sql.append("(PR.PLANID IS NULL OR PR.PLANID='') GROUP BY OS.ORDERID, PR.ROUTESTOPID, PR.ONSALEID) T2 ON ");
		sql.append("T1.ORDERID=T2.ORDERID AND T1.STOPID=T2.ROUTESTOPID AND T1.ONSALEID=T2.ONSALEID WHERE COUNTS>0");
		return findSql(sql.toString(), null, param, pageNo, pageSize);
	}
	
	@Override
	public void updateVisitorPlan(String planId, String visitorId, String stopId) {
		String sql = "UPDATE T_VISITOR_STOP_PLAN_REL SET PLANID=:planId WHERE 1=1 ";
		if(stopId!=null && !stopId.trim().isEmpty()){
			sql += "AND ROUTESTOPID=:stopId";
		}
		if(visitorId!=null && !visitorId.trim().isEmpty()){
			sql += " AND VISITORID=:visitorId";
		}
		SQLQuery query = getSession().createSQLQuery(sql);
		query.setParameter("planId", planId);
		if(stopId!=null && !stopId.trim().isEmpty())
			query.setParameter("stopId", stopId);
		if(visitorId!=null && !visitorId.trim().isEmpty())
			query.setParameter("visitorId", visitorId);
		query.executeUpdate();
	}

	@Override
	public List<VisitorStopPlanRel> getVisitorBySite(String planId,
			String departuresite, String destinationsite) {
		StringBuffer sql = new StringBuffer("SELECT TPR.* FROM (SELECT PR.* FROM T_VISITOR_STOP_PLAN_REL PR INNER JOIN (SELECT ");
		sql.append("STOPID FROM T_ROUTE_STOP WHERE DESTINATIONSITE=:destinationsite AND DEPARTURESITE=:departuresite) RS ON ");
		sql.append("PR.ROUTESTOPID = RS.STOPID WHERE PR.PLANID=:planId)TPR INNER JOIN T_GENERIC_ORDER TGO ON ");
		sql.append("TPR.ORDERID=TGO.ORDERID WHERE TGO.PAYMENTSTATUS=1 OR TGO.PAYMENTSTATUS=2");
		SQLQuery query = getSession().createSQLQuery(sql.toString());
		query.addEntity(VisitorStopPlanRel.class);
		query.setParameter("planId", planId);
		query.setParameter("departuresite", departuresite);
		query.setParameter("destinationsite", destinationsite);
		return query.list();
	}

	@Override
	public void updateOrderVisitorPlan(String planId, String orderId) {
		String sql = "UPDATE T_VISITOR_STOP_PLAN_REL SET PLANID=:planId WHERE ORDERID=:orderId AND (PLANID IS NULL OR PLANID='')";
		SQLQuery query = getSession().createSQLQuery(sql);
		query.setParameter("planId", planId);
		query.setParameter("orderId", orderId);
		query.executeUpdate();
	}

	@Override
	public List<VisitorStopPlanRel> findByStopId(String stopId, String onsaleId) {
		String sql = "SELECT TPR.* FROM T_VISITOR_STOP_PLAN_REL TPR INNER JOIN T_GENERIC_ORDER TGO ON TPR.ORDERID = TGO.ORDERID WHERE TPR.ROUTESTOPID=:stopId AND TPR.ONSALEID=:onsaleId AND (TPR.PLANID IS NULL OR TPR.PLANID='') AND TGO.PAYMENTSTATUS=1 OR TGO.PAYMENTSTATUS=2";
		SQLQuery query = getSession().createSQLQuery(sql);
		query.setParameter("onsaleId", onsaleId);
		query.setParameter("stopId", stopId);
		query.addEntity(VisitorStopPlanRel.class);
		return query.list();
	}
	
	public List<String> getPlanVisitorNum(String planId) {
        String sql = " SELECT DISTINCT(T.VISITORID) FROM (" +
        		" SELECT TPR.*  FROM T_VISITOR_STOP_PLAN_REL TPR WHERE TPR.PLANID =:PLANID) T " +
        		" INNER JOIN T_GENERIC_ORDER TGO ON T.ORDERID = TGO.ORDERID " +
        		" WHERE  TGO.PAYMENTSTATUS = 1 OR TGO.PAYMENTSTATUS=2";
        SQLQuery query = this.getSession().createSQLQuery(sql);
        query.setParameter("PLANID", planId);
        return query.list();
    }

	@Override
	public List<String> getPlanByVisitorId(String visitorId) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM (SELECT T.PLANID FROM T_VISITOR_STOP_PLAN_REL T WHERE T.VISITORID=:visitorId GROUP BY T.PLANID) S ORDER BY S.PLANID ASC";
		SQLQuery query = this.getSession().createSQLQuery(sql);
        query.setParameter("visitorId", visitorId);
        List<String> planList = query.list();
		return planList;
	}

	@Override
	public List<String> getVistorIdByPlanId(String planId) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT T.VISITORID FROM T_VISITOR_STOP_PLAN_REL T WHERE T.PLANID=:planId GROUP BY  T.VISITORID ";
		SQLQuery query = this.getSession().createSQLQuery(sql);
        query.setParameter("planId", planId);
        List<String> visitorIdList = query.list();
		return visitorIdList;
	}

	@Override
	public List<VisitorStopPlanRel> getVisitorStopPlanRelListByVisitorId(
			String visitorId) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM T_VISITOR_STOP_PLAN_REL T WHERE T.VISITORID=:visitorId AND T.PLANID IS NOT NULL ORDER BY T.REFID ASC";
		SQLQuery query = this.getSession().createSQLQuery(sql);
		query.setParameter("visitorId", visitorId);
	    List<VisitorStopPlanRel> visitorStopPlanRelList = query.addEntity(VisitorStopPlanRel.class).list();
		return visitorStopPlanRelList;
	}

}
