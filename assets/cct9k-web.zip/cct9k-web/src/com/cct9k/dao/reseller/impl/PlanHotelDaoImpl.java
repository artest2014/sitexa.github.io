package com.cct9k.dao.reseller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanHotelDao;
import com.cct9k.entity.reseller.PlanHotel;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:53
 */
@Repository
public class PlanHotelDaoImpl extends BaseDaoImpl<PlanHotel, String> implements PlanHotelDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PlanHotel model where 1=1");

        r.append(" order by hotel desc");

        return find(r, pageNo, pageSize);
    }

	@Override
	public List<Map<String, Object>> getOrderHotelNo(String planId,
			String stopId) {

//		String sql_ = "     with tp  as (      "
//				+ "       select tv.*,k.stopid routestopid from t_visitor tv,( "
//				+ "select m.planid,m.visitorid,m.stopid from  (    "
//				+ "select t_temp.planid,tr_stop.stopid,t_temp.visitorid,tr_stop.destinationsite,tr_stop.departuresite from t_route_stop tr_stop ,(select tvr.planid,tvr.routestopid ,tvr.visitorid "
//				+ "from t_visitor_stop_plan_rel tvr  "
//				+ "where  tvr.planid =:planId ) t_temp where tr_stop.stopid=t_temp.routestopid  "
//				+ " ) m,(select trs.destinationsite,trs.departuresite from t_route_stop trs where  trs.stopid=:stopId) n where  m.destinationsite = n.destinationsite and m.departuresite=n.departuresite "
//				+ ") k where tv.visitorid=k.visitorid "
//				+ ")   "
//				+ "	   select distinct cd.orderid,cd.routestopid,tgo.name,td.typename,(cd.not_shareno+(cd.adult_no-cd.not_shareno)/2 ) hotel_no,(cd.not_shareno+(cd.adult_no-cd.not_shareno)/2 )*2 person_no  from ( "
//				+ "		select temp_table.orderid,temp_table.routestopid,temp_table.all_no,temp_table.adult_no,case when replace(c.not_shareno, ' ', null) is null then 0 when replace(c.not_shareno, '', null) is null then 0 when c.not_shareno is not null then c.not_shareno end not_shareno  from (  "
//				+ "		  select a.orderid,a.routestopid,a.adult_no,b.all_no　from    "
//				+ "		 (  "
//				+ "		       select tp.orderid,tp.routestopid,count(tp.ischild) adult_no from tp where tp.ischild=1 group by tp.orderid,tp.routestopid       "
//				+ "		 )a,  "
//				+ "		(  "
//				+ "		select tp.orderid,tp.routestopid,count(tp.orderid) all_no from tp group by tp.orderid,tp.routestopid  "
//				+ ")b  "
//				+ ") temp_table left join  "
//				+ " (  "
//				+ " select  tp.orderid,tp.routestopid,count(tp.shareroom) not_shareno from tp where tp.shareroom=1   group by  tp.orderid,tp.routestopid "
//				+ " ) c on  c.orderid= temp_table.orderid and c.routestopid=temp_table.routestopid  "
//				+ " ) cd ,t_order_detail_plan_hotel sb,t_dictionary td,t_generic_order tgo where sb.routestopid=cd.routestopid and sb.orderid=cd.orderid   and td.dictid = sb.hotelclass   and tgo.orderid=cd.orderid "
//
//		;
		StringBuffer sql = new StringBuffer();
		sql.append("with tp  as ( select tv.*,k.stopid routestopid from t_visitor tv,(  select m.planid,m.visitorid,m.stopid from  (    ");
		sql.append("select t_temp.planid,tr_stop.stopid,t_temp.visitorid,tr_stop.destinationsite,tr_stop.departuresite from t_route_stop tr_stop ,");
		sql.append("(select tvr.planid,tvr.routestopid ,tvr.visitorid  from t_visitor_stop_plan_rel tvr  where  tvr.planid =:planId) t_temp where tr_stop.stopid=t_temp.routestopid  ) m,");
		sql.append("(select trs.destinationsite,trs.departuresite from t_route_stop trs where  trs.stopid=:stopId ) n where  m.destinationsite = n.destinationsite and m.departuresite=n.departuresite");
		sql.append(") k where tv.visitorid=k.visitorid )  select distinct cd.orderid,cd.routestopid,tgo.name,td.typename,td.typeid,(cd.not_shareno+(cd.all_no-cd.not_shareno)/2 ) hotel_no,cd.all_no person_no,cd.not_shareno,(cd.all_no-cd.not_shareno) shareno  from (");
		sql.append("select temp_table.orderid,temp_table.routestopid,temp_table.all_no,temp_table.adult_no,");
		sql.append("case when replace(c.not_shareno, ' ', null) is null then 0 when replace(c.not_shareno, '', null) is null then 0 when c.not_shareno is not null then c.not_shareno end not_shareno  from (");
		sql.append("select a.orderid,a.routestopid,a.adult_no,b.all_no　from (select tp.orderid,tp.routestopid,count(tp.ischild) adult_no from tp where tp.ischild=1 group by tp.orderid,tp.routestopid )a,");
		sql.append("(select tp.orderid,tp.routestopid,count(tp.orderid) all_no   from tp group by tp.orderid,tp.routestopid  )b   where a.orderid =b.orderid  and a.routestopid=b.routestopid ) temp_table left join");
		sql.append("(select  tp.orderid,tp.routestopid,count(tp.shareroom) not_shareno from tp where tp.shareroom=1   group by  tp.orderid,tp.routestopid ) c on  c.orderid= temp_table.orderid and c.routestopid=temp_table.routestopid");
		sql.append(") cd ,t_order_detail_plan_hotel sb,t_dictionary td,t_generic_order tgo where sb.routestopid=cd.routestopid and sb.orderid=cd.orderid   and td.dictid = sb.hotelclass   and tgo.orderid=cd.orderid");
		
		Map<String, Object> paramMap = new HashMap<>();
	    paramMap.put("planId", planId);
	    paramMap.put("stopId", stopId);
	    List<Map<String, Object>> list = this.getSimpleSpringJdbcTemplate().queryForMap(sql, paramMap);
		return list;
	}

	@Override
	public List<?> getPlanHotelOrders(String planId)
	{
		StringBuffer querySql = new StringBuffer();
		querySql.append(" select a.planid,                                                    ");
		querySql.append("        null as orderid,                                             ");
		querySql.append("        '自维护客户' as customersource,                              ");
		querySql.append("        null as ordername,                                           ");
		querySql.append("        d.productname,                                               ");
		querySql.append("        c.customername,                                              ");
		querySql.append("        null as orderdate,                                           ");
		querySql.append("        b.quantity,                                                  ");
		querySql.append("        b.amount,                                                    ");
		querySql.append("        null as orderstatus,                                         ");
		querySql.append("        null as paymentstatus,                                       ");
		querySql.append("        null as estimatestatus                                       ");
		querySql.append("   from t_plan a, t_plan_hotel b, t_customer c, t_customer_product d ");
		querySql.append("  where a.planid = b.planid                                          ");
		querySql.append("    and b.hotel = c.customerid                                       ");
		querySql.append("    and b.product = d.productid                                      ");
		querySql.append("    and a.planid = :planid                                           ");

		Query query = this.getSession().createSQLQuery(querySql.toString());
		query.setParameter("planid", planId);
		//query.setResultTransformer(CriteriaSpecification.ALIAS_TO_ENTITY_MAP);
        return query.list();
	}
}
