package com.cct9k.dao.reseller.impl;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.CheckGuideSheetDao;
import com.cct9k.entity.finance.CheckSheet;

@Repository
public class CheckGuideSheetDaoImpl extends BaseDaoImpl<CheckSheet, String> implements CheckGuideSheetDao {
	
	public Pagination sheetInfoList(String memberid, String startTime,String endTime,String commitStartTime,String commitEndTime,
			String routeName, String sheetStatus, int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String sql="select a.planid,a.starttime, b.routename, e.realname, c.status, c.sheetid ,c.commitdate ";
		sql+="from t_plan a,t_route b,t_check_sheet c , t_member d ,t_member_person e";
		sql+=" where c.status in (37，38,45)  and  a.planid = c.planid and d.memberid= a.guide and d.memberid= e.memberid and a.routeid = b.routeid and a.reseller= "+memberid+" ";
		if(!StringUtils.isEmpty(startTime)){
	    	 sql+=" and a.starttime>=to_date('"+startTime+" 00:00:00','yyyy-mm-dd hh24:mi:ss') ";
	     }
		if(!StringUtils.isEmpty(endTime)){
	    	 sql+=" and a.starttime<=to_date('"+endTime+" 00:00:00','yyyy-mm-dd hh24:mi:ss') ";
	     }
		if(!StringUtils.isEmpty(commitStartTime)){
	    	 sql+=" and c.commitdate>=to_date('"+commitStartTime+" 00:00:00','yyyy-mm-dd hh24:mi:ss') ";
	     }
		if(!StringUtils.isEmpty(commitEndTime)){
	    	 sql+=" and c.commitdate<=to_date('"+commitEndTime+" 00:00:00','yyyy-mm-dd hh24:mi:ss') ";
	     }
		if(!StringUtils.isEmpty(routeName)){
	    	 sql+=" and b.routename like '%"+routeName+"%'";
	     }
		if(!StringUtils.isEmpty(sheetStatus)){
	    	 sql+=" and c.status='"+sheetStatus+"'";
	     }
		return findSql(sql, pageNo, pageSize);
	}

}
