package com.cct9k.dao.reseller.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.reseller.PlanTransportTicketDao;
import com.cct9k.entity.reseller.PlanTransportTicket;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:02
 */
@Repository
public class PlanTransportTicketDaoImpl extends BaseDaoImpl<PlanTransportTicket, String> implements PlanTransportTicketDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PlanTransportTicket model where 1=1");

        r.append(" order by seatno desc");

        return find(r, pageNo, pageSize);
    }

}
