package com.cct9k.dao.estimate.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.order.GenericOrder;

@Repository
public class TGenericOrderDaoImpl extends BaseDaoImpl<GenericOrder,String> implements com.cct9k.dao.estimate.TGenericOrderDao {
	
	public GenericOrder load(String id){
		
		return super.load(id); //记录一定存在时使用load方法
		
	}

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> execSQL(String sql, Map<String, Object> params) {
		
		Query q = getSession().createSQLQuery(sql).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);   //以list里放map的格式返回记录
		
		if(params!=null && !params.isEmpty()){
			for (Entry<String, Object> entry : params.entrySet()) {
				q.setParameter(entry.getKey(), entry.getValue());
	        }
		}
		
		return q.list();
		
	}
	
	public Map<String, Object> simpleLoad(String orderId){     
		
		String sql = "select * from t_generic_order where orderid = :orderId";
		
		Map<String, Object> m = new HashMap<String, Object>();
		
		m.put("orderId", orderId);
		
		List<Map<String, Object>> list = this.execSQL(sql,m);
		
		if(list.isEmpty()){     //订单ID不存在，返回空值
			
			return null;
		}else{
			
			return list.get(0);
		}
	}
}
