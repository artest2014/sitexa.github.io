package com.cct9k.dao.estimate.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.order.GenericOrder;
import com.cct9k.entity.order.OrderEstimateInfo;

@Repository
public class TOrderEstimateInfoDaoImpl extends BaseDaoImpl<OrderEstimateInfo,String> implements com.cct9k.dao.estimate.TOrderEstimateInfoDao {

	@Override
	public void saveOrUpdate(List<OrderEstimateInfo> list) {
		
		for(int i = 0;i<list.size();i++){
			
			this.save(list.get(i));
		}
		
	}

	@Override
	public void saveOrUpdate(GenericOrder go) {
		
		this.getSession().saveOrUpdate(go);
		
	}
	
}
