package com.cct9k.dao.estimate;

import java.util.List;

public interface DpDefinedDao {

	public List<Object> getOrderDetails(String orderId,String orderType);
}
