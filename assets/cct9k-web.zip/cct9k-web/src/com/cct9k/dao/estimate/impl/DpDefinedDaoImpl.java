package com.cct9k.dao.estimate.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.estimate.DpDefinedDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.order.GenericOrder;

/*
 * 自定义dao，主要为避免查多张表时需要建多个dao的麻烦
 */

@Repository
public class DpDefinedDaoImpl extends BaseDaoImpl<Object,String> implements DpDefinedDao {
	
	
	public List<Object> getOrderDetails(String orderId,String orderType){  //获取订单商品明细
		
		/*
		 * 线路订单     12889          T_Order_Detail_Plan
		 * 酒店订单     12890          T_Order_Detail_Hotel
		 * 餐饮订单     12891          T_Order_Detail_Restaurant
		 * 景点订单     12892          T_Order_Detail_Gate
		 * 娱乐订单     12893          T_Order_Detail_Show
		 * 旅运订单     12894          T_Order_Detail_Transport
		 * 导游订单     12274          T_Order_Detail_Guide
		 * 
		 */
		
		StringBuffer sb = new StringBuffer("select * from ");
		
		String tableName = "";
		
		switch(orderType){     //jdk 7支持String
		
		case "12890":{
			sb.append("T_Order_Detail_Hotel");
			tableName = "com.cct9k.entity.order.OrderDetailHotel";
			break;
		}
		
		case "12891":{
			sb.append("T_Order_Detail_Restaurant");
			tableName = "com.cct9k.entity.order.OrderDetailRestaurant";
			break;
		}

		case "12892":{
			sb.append("T_Order_Detail_Gate");
			tableName = "com.cct9k.entity.order.OrderDetailGate";
			break;
		}

		case "12893":{
			sb.append("T_Order_Detail_Show");
			tableName = "com.cct9k.entity.order.OrderDetailShow";
			break;
		}

		case "12894":{
			sb.append("T_Order_Detail_Transport");
			tableName = "com.cct9k.entity.order.OrderDetailTransport";
			break;
		}

		case "12274":{
			sb.append("T_Order_Detail_Guide");
			tableName = "com.cct9k.entity.order.OrderDetailGuide";
			break;
		}
		
		default:{  //默认为12889，即线路商品
			sb.append("T_Order_Detail_Plan");
			tableName = "com.cct9k.entity.order.OrderDetailPlan";
		}
		
		}
		
		sb.append(" where orderid = :orderid");
		
		List list = null;
		
		try {
			
//			System.out.println("SQL : "+sb.toString());
			
			SQLQuery query = getSession().createSQLQuery(sb.toString()).addEntity(Class.forName(tableName));
			
			query.setParameter("orderid", orderId);
			
			list = query.list();
			
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
}
