package com.cct9k.dao.estimate;

import java.util.List;
import java.util.Map;

import com.cct9k.entity.order.GenericOrder;

public interface TGenericOrderDao {
	
	public GenericOrder load(String id);

	public List<Map<String, Object>> execSQL(String sql,Map<String, Object> params);
	
	public Map<String,Object> simpleLoad(String orderId);
}
