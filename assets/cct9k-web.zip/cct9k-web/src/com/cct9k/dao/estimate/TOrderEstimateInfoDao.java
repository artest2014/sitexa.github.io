package com.cct9k.dao.estimate;

import java.util.List;

import com.cct9k.entity.order.GenericOrder;
import com.cct9k.entity.order.OrderEstimateInfo;

public interface TOrderEstimateInfoDao {

	void saveOrUpdate(List<OrderEstimateInfo> list);

	void saveOrUpdate(GenericOrder go);
	
}
