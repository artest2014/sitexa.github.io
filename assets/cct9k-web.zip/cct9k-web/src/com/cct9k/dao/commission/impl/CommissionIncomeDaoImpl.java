package com.cct9k.dao.commission.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.commission.CommissionIncomeDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.commission.CommissionRate;
import com.cct9k.util.common.StringUtil;

@Repository
public class CommissionIncomeDaoImpl extends BaseDaoImpl<CommissionRate, String> implements CommissionIncomeDao {

	//业类卡片类型ID
	public static final String CARD_TYPE_ID_YN="101";
	
	@Override
	public Pagination findCommissionIncome(String memberId, String incomeType, Date startTime, Date endTime, int pageNo,
			int pageSize) {
		StringBuffer sql = new StringBuffer();

		Map<String, Object> params = new HashMap<String, Object>();
		
		if (incomeType == null || incomeType.equals("") || incomeType.equals("1")) {
			sql.append("SELECT '游客卡收入',ic.cardno,'',sum(IC.AMOUNT),ic.sellerid FROM T_INDUSTRYCOMMISSION ic ");
			sql.append("WHERE IC.MEMBERID=:memberId AND IC.SELLERID=:sellerId ");
			sql.append("AND IC.TRADETIME BETWEEN :startTime  AND :endTime ");
			sql.append("GROUP BY ic.cardno,ic.sellerid ");
			params.put("memberId", memberId);
			params.put("sellerId", memberId);
			params.put("startTime", startTime);
			params.put("endTime", endTime);
		}

		if (incomeType == null || incomeType.equals("")) {
			sql.append("UNION ALL ");
		}

		if (incomeType == null || incomeType.equals("") || incomeType.equals("2")) {
			sql.append("SELECT '分成收入',tl.bankno ,TP.REALNAME ,sum(IC.AMOUNT),ic.sellerid FROM T_INDUSTRYCOMMISSION ic ");
			sql.append("LEFT JOIN T_MEMBER_PERSON tp  ON ic.SELLERID=tp.MEMBERID ");
			sql.append("LEFT JOIN T_TuneLink_Member tm on ic.SELLERID=tm.memberId ");
			sql.append("LEFT JOIN T_TuneLink tl on tm.cardId=tl.cardId  and tm.CARDTYPE = :cardType ");
			sql.append("WHERE IC.MEMBERID=:smemberId AND IC.SELLERID !=:ssellerId ");
			sql.append("AND IC.TRADETIME BETWEEN :sstartTime  AND :sendTime ");
			sql.append("GROUP BY ic.sellerid,tl.bankno,TP.REALNAME ");
			
			params.put("cardType", CARD_TYPE_ID_YN);
			params.put("smemberId", memberId);
			params.put("ssellerId", memberId);
			params.put("sendTime", endTime);
			params.put("sstartTime", startTime);
		}
		
		Pagination pagination = findSql(sql.toString(), null, params, pageNo, pageSize);

		return pagination;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public String findCommissionIncomeTotal(String memberId, String incomeType, Date startTime, Date endTime) {
			StringBuffer sql = new StringBuffer();
			Map<String, Object> params = new HashMap<String, Object>();
			
			sql.append("SELECT sum(amount) from (");
			
		if (incomeType == null || incomeType.equals("") || incomeType.equals("1")) {
			sql.append("SELECT sum(IC.AMOUNT) amount FROM T_INDUSTRYCOMMISSION ic ");
			sql.append("WHERE IC.MEMBERID=:memberId AND IC.SELLERID=:sellerId ");
			sql.append("AND IC.TRADETIME BETWEEN :startTime  AND :endTime ");
			sql.append("GROUP BY ic.cardno ");
			
			params.put("memberId", memberId);
			params.put("sellerId", memberId);
			params.put("startTime", startTime);
			params.put("endTime", endTime);
			
		}

		if (incomeType == null || incomeType.equals("")) {
			sql.append("UNION ALL ");
		}

		if (incomeType == null || incomeType.equals("") || incomeType.equals("2")) {
			sql.append("SELECT sum(IC.AMOUNT) amount FROM T_INDUSTRYCOMMISSION ic ");
			sql.append("LEFT JOIN T_MEMBER_PERSON tp  ON ic.SELLERID=tp.MEMBERID ");
			sql.append("LEFT JOIN T_TuneLink_Member tm on ic.SELLERID=tm.memberId ");
			sql.append("LEFT JOIN T_TuneLink tl on tm.cardId=tl.cardId  and tm.CARDTYPE = :cardType ");
			sql.append("WHERE IC.MEMBERID=:smemberId AND IC.SELLERID !=:ssellerId ");
			sql.append("AND IC.TRADETIME BETWEEN :sstartTime  AND :sendTime ");
			sql.append("GROUP BY ic.sellerid,tl.bankno,TP.REALNAME ");
			
			params.put("cardType", CARD_TYPE_ID_YN);
			params.put("smemberId", memberId);
			params.put("ssellerId", memberId);
			params.put("sendTime", endTime);
			params.put("sstartTime", startTime);
		}
		
		sql.append(")");
		
		
		SQLQuery query = getSession().createSQLQuery(sql.toString());
		if(params!=null && !params.isEmpty()){
			for (Entry<String, Object> entry : params.entrySet()) {
				query.setParameter(entry.getKey(), entry.getValue());
	        }
		}
		List reslut=query.list();
		if(reslut!=null && reslut.size()!=0 && reslut.get(0)!=null){
			return reslut.get(0).toString();
		}else{
			return "0";
		}
	}

	@Override
	public Pagination findParticular(String cardNo,String shopName, Date startTime, Date endTime,int pageNo,int pageSize) {
		Map<String, Object> params = new HashMap<String, Object>();
		
			StringBuffer sql=new StringBuffer();
			sql.append("SELECT pa.SHOPNAME,TCL.TRADESQUENCE,TCL.TRADEAMOUNT,TCL.PAYMETHOD,IC.AMOUNT FROM T_IndustryCOMMISSION  IC ");
			sql.append("LEFT JOIN T_TOURISTCARD_CONSUME_LOG TCL ON IC.CONSUMPTIONLOGID=TCL.CONSUMPTIONLOGID ");
			sql.append("LEFT JOIN T_SHOP_COMMISSION sc  ON SC.COUNT_ID=IC.COUNT_ID ");
			sql.append("LEFT JOIN T_POSAPPLY pa on pa.ASSOCIATEOBJECTID=SC.OBJECTID ");
			sql.append("WHERE IC.CARDNO=:cardNo ");
			sql.append("AND IC.TRADETIME BETWEEN  :startTime AND :endTime ");
			
			if(!StringUtil.isEmpty(shopName)){
	        	sql.append("and pa.SHOPNAME like :shopName ");
	        	params.put("shopName", "%"+shopName+"%");
	        }
			
			params.put("cardNo", cardNo);
			params.put("startTime", startTime);
			params.put("endTime", endTime);
			
		return findSql(sql.toString(), null, params, pageNo, pageSize);
	}
	
	public Pagination findShopParticular(String memberId,String sellerId,Date startTime, Date endTime,int pageNo,int pageSize){
			StringBuffer sql=new StringBuffer();
			
			sql.append("select ntime, wm_concat(to_char(rate, 'fm9999999990.00')),AMOUNT rates from ( ");
			sql.append("select rownum rn, t2.ntime,t2.sellerid, crl.rate,T2.AMOUNT from ( ");
			sql.append("SELECT  T1.ntime,SELLERID, sum(AMOUNT) amount FROM ( ");
			sql.append("SELECT SELLERID,to_char(TRADETIME,'yyyy-MM-dd') ntime,AMOUNT FROM T_IndustryCOMMISSION ic ");
			sql.append("WHERE IC.MEMBERID=:memberId AND IC.SELLERID =:sellerId AND TRADETIME BETWEEN :startTime AND :endTime)  t1 ");
			sql.append("GROUP BY T1.ntime,SELLERID ) t2  ");
			sql.append("LEFT JOIN T_COMMISSION_RATE cr on T2.SELLERID=CR.APPLYID  ");
			sql.append("AND to_timestamp(t2.NTIME,'yyyy-mm-dd') >= to_timestamp(to_char(CR.BEGINTIME,'yyyy-mm-dd'),'yyyy-mm-dd') ");
			sql.append("AND to_timestamp(t2.NTIME,'yyyy-mm-dd') <= to_timestamp(to_char(CR.ENDTIME,'yyyy-mm-dd'),'yyyy-mm-dd') ");
			sql.append("left join t_commission_relate crl on cr.rate_id=crl.rate_id and crl.member_id=:smemberId ");
			sql.append(")  group by  ntime, sellerid,amount ");
					
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("memberId", memberId);
			params.put("sellerId", sellerId);
			params.put("smemberId", memberId);
			params.put("startTime", startTime);
			params.put("endTime", endTime);
			
			return findSql(sql.toString(), null, params, pageNo, pageSize);
			
	
	}

	@Override
	public Pagination viweExpenditure(String memberId, String shopId, Date startTime, Date endTime, int pageNo, int pageSize) {
		
		Map<String, Object> params = new HashMap<String, Object>();
		
		StringBuffer sql=new StringBuffer();
		
		sql.append("SELECT pa.SHOPNAME,sc.TRADESQUENCE,SC.TRADETIME,SC.TRADEAMOUNT,tcl.payMethod,SC.AMOUNT FROM T_SHOP_COMMISSION sc ");
		sql.append("LEFT JOIN T_POSApply pa on SC.OBJECTID=PA.ASSOCIATEOBJECTID ");
		sql.append("LEFT JOIN T_TOURISTCARD_CONSUME_LOG tcl on tcl.consumptionLogId=sc.ConsumptionLogID ");
		sql.append("WHERE SC.MEMBERID=:memberId AND (SC.TRADETIME BETWEEN :startTime  AND :endTime) ");
		
		if(!StringUtil.isEmpty(shopId)){
			sql.append("AND pa.APPLYID = :shopId ");
			params.put("shopId", shopId);
		}
		params.put("memberId", memberId);
		params.put("startTime", startTime);
		params.put("endTime", endTime);
		
		return findSql(sql.toString(), null, params, pageNo, pageSize);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Object[] viweExpenditureTotal(String memberId, String shopId,Date startTime, Date endTime) {
		
		Map<String, Object> params = new HashMap<String, Object>();
		StringBuffer sql=new StringBuffer();
		sql.append("SELECT SUM(SC.TRADEAMOUNT),SUM(SC.AMOUNT) FROM T_SHOP_COMMISSION sc ");
		sql.append("LEFT JOIN T_POSApply pa on SC.OBJECTID=PA.ASSOCIATEOBJECTID ");
		sql.append("LEFT JOIN T_TOURISTCARD_CONSUME_LOG tcl on tcl.consumptionLogId=sc.ConsumptionLogID ");
		sql.append("WHERE SC.MEMBERID=:memberId  AND (SC.TRADETIME BETWEEN :startTime  AND :endTime) ");
		if(!StringUtil.isEmpty(shopId)){
			sql.append("AND pa.APPLYID = :shopId ");
			params.put("shopId", shopId);
		}
		params.put("memberId", memberId);
		params.put("startTime", startTime);
		params.put("endTime", endTime);
		
		SQLQuery query = getSession().createSQLQuery(sql.toString());
		if(params!=null && !params.isEmpty()){
			for (Entry<String, Object> entry : params.entrySet()) {
				query.setParameter(entry.getKey(), entry.getValue());
	        }
		}
		List reslut=query.list();
		if(reslut!=null && reslut.size()!=0 && reslut.get(0)!=null){
			return (Object[])reslut.get(0);
		}else{
			return new Object[]{"0","0"};
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> findShops(String memberId) {
			StringBuffer sql=new StringBuffer();
			sql.append("SELECT APPLYID,SHOPNAME FROM T_POSApply WHERE MEMBERID=:memberId ");
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("memberId", memberId);
			
			SQLQuery query = getSession().createSQLQuery(sql.toString());
			if(params!=null && !params.isEmpty()){
				for (Entry<String, Object> entry : params.entrySet()) {
					query.setParameter(entry.getKey(), entry.getValue());
		        }
			}
		return query.list();
	}			
				
				
				
				
	}
	
