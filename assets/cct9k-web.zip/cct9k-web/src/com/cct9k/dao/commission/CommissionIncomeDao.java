package com.cct9k.dao.commission;

import java.util.Date;
import java.util.List;

import com.cct9k.common.Pagination;

public interface CommissionIncomeDao {

	public Pagination findCommissionIncome(String memberid,String incomeType, Date startDate, Date endDate, int pageNo, int pageSize);

	public String findCommissionIncomeTotal(String memberId, String incomeType, Date startDate, Date endDate);

	public Pagination findParticular(String cardNo,String shopName, Date startTime, Date endTime,int pageNo,int pageSize);
	
	public Pagination findShopParticular(String memberId,String sellerId,Date startTime, Date endTime,int pageNo,int pageSize);

	public Pagination viweExpenditure(String memberId, String shopId, Date startDate, Date endDate, int pageNo, int pageSize);

	public Object[] viweExpenditureTotal(String memberId, String shopId,Date startTime, Date endTime);

	public List<Object[]> findShops(String memberId);
}
