package com.cct9k.dao.commission;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.commission.CommissionRelate;
/**
 * 
* @ClassName: CommissionRelateDao
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-2-26 下午2:39:08
*
 */
public interface CommissionRelateDao extends BaseDao<CommissionRelate, String>{
	
	public Pagination getPage(String applyid, String membername,String begintime, String endtime,String applyname,int pageNo, int pageSize);

}
