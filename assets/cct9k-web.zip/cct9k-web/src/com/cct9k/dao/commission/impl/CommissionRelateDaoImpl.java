package com.cct9k.dao.commission.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.commission.CommissionRelateDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.commission.CommissionRelate;
import com.cct9k.util.common.StringUtil;
/**
 * 
* @ClassName: CommissionRelateDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-2-26 下午2:41:48
*
 */
@Repository
public class CommissionRelateDaoImpl extends BaseDaoImpl<CommissionRelate, String> implements CommissionRelateDao{

	@Override
	public Pagination getPage(String applyid, String membername,
			String begintime, String endtime, String applyname, int pageNo,
			int pageSize) {
		Finder f = Finder.create("from CommissionRelate commissionrelate where commissionrelate.commissionrate.statues='1' and commissionrelate.commissionrate.member.memberid = '"+applyid + "'");
		if(!StringUtil.isEmpty(applyname)){
			f.append(" and commissionrelate.commissionrate.applyname like '%'||:applyName||'%' ");
			f.setParam("applyName", applyname);
		}
		if(!StringUtil.isEmpty(membername)){
			f.append(" and commissionrelate.member_name like '%'||:memberName||'%' ");
			f.setParam("memberName", membername);
		}
		if(!StringUtil.isEmpty(begintime)){
			f.append(" and commissionrelate.commissionrate.begintime >=:beginTime ");
			f.setParam("beginTime", java.sql.Date.valueOf(begintime));
		}
		if(!StringUtil.isEmpty(endtime)){
			f.append(" and commissionrelate.commissionrate.endtime <=:endtime ");
			f.setParam("endtime", java.sql.Date.valueOf(endtime));
		}
		f.append(" order by commissionrelate.commissionrate.updatetime desc");
		return find(f, pageNo, pageSize);
	}

}
