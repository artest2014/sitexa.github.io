package com.cct9k.dao.commission;


import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.commission.ShopCommissionAdd;
/**
 * 
* @ClassName: ShopCommissionAddDao
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-3-7 上午10:25:18
*
 */
public interface ShopCommissionAddDao extends BaseDao<ShopCommissionAdd, String>{
	
	//追缴预警专用查询
	public Pagination ShopCommissionAdd(String membername,int times,Float amount,int pageNo,int pageSize);

}
