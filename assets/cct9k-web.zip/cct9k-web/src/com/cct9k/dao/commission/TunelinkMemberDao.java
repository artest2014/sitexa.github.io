package com.cct9k.dao.commission;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.commission.TunelinkMember;
/**
 * 
* @ClassName: TunelinkMemberDao
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-2-26 下午2:35:50
*
 */
public interface TunelinkMemberDao extends BaseDao<TunelinkMember, String>{
	
	public TunelinkMember getByMemberid(String memberid);

}
