package com.cct9k.dao.commission.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.commission.CommissionRateDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.commission.CommissionRate;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;
/**
 * 
* @ClassName: CommissionRateDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-2-26 下午2:33:44
*
 */
@Repository
public class CommissionRateDaoImpl extends BaseDaoImpl<CommissionRate, String> implements CommissionRateDao{

	
	//查找当前用户相关的分成
	@Override
	public Pagination findMemberCommissions(String memberId,String memberName, String startTime,String endTime, int pageNo, int pageSize) {
		
		 StringBuffer sql=new StringBuffer();
		 sql.append("SELECT tt.ACCOUNTNAME,RA.APPLYNAME,RA.BEGINTIME,RA.ENDTIME,RE.RATE,RA.STATUES,RA.UPDATETIME FROM T_COMMISSION_RELATE re ");
		 sql.append("LEFT JOIN T_COMMISSION_RATE  ra  ON RA.RATE_ID=RE.RATE_ID ");
		 sql.append("LEFT JOIN T_TUNELINK_MEMBER tm on tm.memberid=ra.applyid ");
		 sql.append("LEFT JOIN T_TUNELINK tt on TM.CARDID=TT.CARDID AND TM.CARDTYPE='101' ");
		 sql.append("WHERE RE.MEMBER_ID=:memberId ");
		 	
		 Map<String,Object> params=new HashMap<String,Object>();
		 params.put("memberId", memberId);
		 
	        if(!StringUtil.isEmpty(memberName)){
	        	sql.append("and tt.ACCOUNTNAME like :memberName ");
	        	params.put("memberName", "%"+memberName+"%");
	        }
	        if(!StringUtil.isEmpty(startTime)){
	        	sql.append("and ra.begintime >= :startTime ");
	        	params.put("startTime",DateUtil.toDate(startTime, "yyyy-MM-dd"));
	        }
	        if(!StringUtil.isEmpty(endTime)){
	        	sql.append("and ra.endtime <= :endTime ");
	        	Date endDate=DateUtil.toDate(endTime, "yyyy-MM-dd");
	        	Calendar calendar=Calendar.getInstance();
	    		calendar.setTime(endDate);
	    		calendar.set(Calendar.HOUR_OF_DAY, 23);
	    		calendar.set(Calendar.SECOND,59);
	    		calendar.set(Calendar.MINUTE,59);
	    		endDate=calendar.getTime();
	        	params.put("endTime", endDate);
	        }
	        
	        return findSql(sql.toString(), null, params, pageNo, pageSize);
	}
	
	
}
