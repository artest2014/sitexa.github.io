package com.cct9k.dao.commission.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.commission.ShopCommissionAddDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.commission.ShopCommissionAdd;
import com.cct9k.util.common.StringUtil;

/**
 * 
* @ClassName: ShopCommissionAddDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-3-7 上午10:27:17
*
 */
@Repository
public class ShopCommissionAddDaoImpl extends BaseDaoImpl<ShopCommissionAdd, String> implements ShopCommissionAddDao{

	@Override
	public Pagination ShopCommissionAdd(String membername,int times,Float amount,int pageNo,int pageSize) {
		Map<String, Object> params = new HashMap<String, Object>();
		StringBuffer sql = new StringBuffer("SELECT C.MEMBERNAME,B.MEMBERNUM,A.AMOUNT,C.EMAIL,C.MOBILENO FROM T_SHOP_COMMISSION_ADD A,");
		sql.append("(SELECT T.MEMBERID,COUNT(CASE WHEN T.IFPAY <> '101' THEN 1 ELSE NULL END) MEMBERNUM,MAX(T.BATCH) BATCH FROM T_SHOP_COMMISSION_ADD T GROUP BY T.MEMBERID) B,");
		sql.append("T_MEMBER C WHERE A.MEMBERID = B.MEMBERID AND A.BATCH=B.BATCH AND C.MEMBERID=B.MEMBERID AND B.MEMBERNUM > '"+times+"'");
		if(!StringUtil.isEmpty(membername)){
			sql.append("AND C.MEMBERNAME LIKE '%"+membername+"%' ");
		}
		if(amount!=null){
			amount=0-amount;
			sql.append("AND A.AMOUNT< '"+amount+"'");
		}
		return findSql(sql.toString(), null, params, pageNo, pageSize);
	}

}
