package com.cct9k.dao.commission.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.commission.TunelinkMemberDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.commission.TunelinkMember;
/**
 * 
* @ClassName: TunelinkMemberDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-2-26 下午2:37:15
*
 */

@Repository
public class TunelinkMemberDaoImpl extends BaseDaoImpl<TunelinkMember, String> implements TunelinkMemberDao{

	@Override
	public TunelinkMember getByMemberid(String memberid) {
		String hql="from TunelinkMember t where t.member.memberid='"+memberid+"' ";
		return (TunelinkMember) getSession().createQuery(hql).uniqueResult();
	}

}
