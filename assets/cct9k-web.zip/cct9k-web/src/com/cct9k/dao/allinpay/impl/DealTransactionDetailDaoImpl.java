package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.DealTransactionDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.DealTransactionDetail;

@Repository
public class DealTransactionDetailDaoImpl extends BaseDaoImpl<DealTransactionDetail,String> implements DealTransactionDetailDao{

	public List<DealTransactionDetail>   getDealTransactionDetailList(String dataDate){
	    String sql = "select t.* from t_tl_deal_transaction_detail t where t.tradedate='"+dataDate+"' " ;
        List<DealTransactionDetail> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(DealTransactionDetail.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
   }
}
