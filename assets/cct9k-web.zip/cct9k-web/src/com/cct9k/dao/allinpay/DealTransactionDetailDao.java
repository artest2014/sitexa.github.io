package com.cct9k.dao.allinpay;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.DealTransactionDetail;

public interface DealTransactionDetailDao extends BaseDao<DealTransactionDetail,String> {
	
	public List<DealTransactionDetail>   getDealTransactionDetailList(String dataDate);
}
