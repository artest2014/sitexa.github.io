package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.RefundApplyDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.RefundApplyDetail;
import com.cct9k.entity.finance.RefundBillDetailRel;

@Repository
public class RefundApplyDetailDaoImpl extends BaseDaoImpl<RefundApplyDetail,String> implements RefundApplyDetailDao{

	@Override
	public int judgeOrderIsRefundingOrNot(String orderId){
		List<RefundApplyDetail> list=this.getList("orderid", orderId);
		for(RefundApplyDetail item:list){
			String auditStatus=item.getAuditstatus();
			if(auditStatus.equals("1")){
				return 1;
			}
		}
		return 0;
	}
	
	public List<RefundApplyDetail>   getRefundApplyDetailList(String orderId){
	    String sql = "select t.* from t_refund_apply_detail t where t.orderid='"+orderId+"' " ;
        List<RefundApplyDetail> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(RefundApplyDetail.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
    }
	
	@Override
	public String getAuditStatusByOrderIdAndDetailId(String orderId,String detailId){
		String sql="select a.auditstatus from t_refund_apply_detail a,t_refund_order_detail_rel b where a.refundid=b.refundid and a.orderid=? and b.detailid=? ";
		return (String)this.getSession().createSQLQuery(sql).setParameter(0, orderId).setParameter(1, detailId).uniqueResult();
	}
}
