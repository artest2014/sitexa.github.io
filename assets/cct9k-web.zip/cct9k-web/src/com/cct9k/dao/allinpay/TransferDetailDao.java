package com.cct9k.dao.allinpay;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.TransferDetail;

public interface TransferDetailDao extends BaseDao<TransferDetail,String> {
	public Pagination getPage(String startTime,String endTime ,String parentMemberId,int pageNo, int pageSize);
}
