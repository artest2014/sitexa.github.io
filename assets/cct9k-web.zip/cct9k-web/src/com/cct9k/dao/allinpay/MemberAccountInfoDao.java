package com.cct9k.dao.allinpay;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.MemberAccountInfo;

public interface MemberAccountInfoDao extends BaseDao<MemberAccountInfo,String> {

	public List<MemberAccountInfo>   getMemberAccountInfoList(String memberId,String accountType);
	
	public MemberAccountInfo getMemberAccountInfo(String accountId);
	
	public List<MemberAccountInfo>   getAllAccountList();
	
	public List<MemberAccountInfo>   getAccountListByDate(String dataDate);
	
	public List<MemberAccountInfo>   getMemberAccountInfoList(String memberId);
}
