package com.cct9k.dao.allinpay;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.WithdrawApplyDetail;

public interface WithdrawApplyDetailDao extends BaseDao<WithdrawApplyDetail,String> {
	public WithdrawApplyDetail getWithdrawApplyDetail(String applyCode,String serialId);
	
	public List<WithdrawApplyDetail>   getWithdrawApplyDetailList(String dataDate);
	
	public Pagination getPage(String startTime,String endTime ,String parentMemberId,int pageNo, int pageSize);
}
