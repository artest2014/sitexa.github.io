package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.FreezeThrawDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.FreezeThrawDetail;

@Repository
public class FreezeThrawDetailDaoImpl extends BaseDaoImpl<FreezeThrawDetail,String> implements FreezeThrawDetailDao{
	public FreezeThrawDetail getFreezeThrawDetail(String orderId){
		   String hql = "From FreezeThrawDetail t where  t.bargaincode='"+orderId+"'";
		   FreezeThrawDetail mai = null;
		   List<FreezeThrawDetail> list = getListByHql(hql);
		   if(list!=null&&list.size()>0){
			   mai = list.get(0);
		   }
		   return mai;
	   }
	
	public List<FreezeThrawDetail>   getFreezeThrawDetailList(String dataDate){
	    String sql = "select t.* from t_tl_freeze_thraw_detail t where t.tradedate='"+dataDate+"' " ;
        List<FreezeThrawDetail> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(FreezeThrawDetail.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
   }

}
