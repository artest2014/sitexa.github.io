package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.allinpay.WithdrawApplyDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.DepositApplyDetail;
import com.cct9k.entity.allinpay.WithdrawApplyDetail;
import com.cct9k.util.common.StringUtil;

@Repository
public class WithdrawApplyDetailDaoImpl extends BaseDaoImpl<WithdrawApplyDetail,String> implements WithdrawApplyDetailDao{
  
	public WithdrawApplyDetail getWithdrawApplyDetail(String applyCode,String serialId){
		   String hql = "From WithdrawApplyDetail t where 1=1 ";
		   if(!StringUtil.isEmpty(serialId)){
			   hql+=" and t.serialid='"+serialId+"'";
		   }
		   if(!StringUtil.isEmpty(applyCode)){
			   hql+=" and t.applycode='"+applyCode+"'";
		   }
		   WithdrawApplyDetail mai = null;
		   List<WithdrawApplyDetail> list = getListByHql(hql);
		   if(list!=null&&list.size()>0){
			   mai = list.get(0);
		   }
		   return mai;
    }
	
	public List<WithdrawApplyDetail>   getWithdrawApplyDetailList(String dataDate){
	    String sql = "select t.* from t_tl_withdraw_apply_detail t where t.tradedate='"+dataDate+"' " ;
        List<WithdrawApplyDetail> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(WithdrawApplyDetail.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
    }
	
	@Override
	public Pagination getPage(String startTime,String endTime ,String parentMemberId,int pageNo, int pageSize) {
		StringBuffer sb = new StringBuffer();
		
		sb.append("select t.* from t_tl_withdraw_apply_detail t where 1=1 ");
		
		if(!StringUtil.isEmpty(startTime)){
			sb.append(" and to_date(to_char(t.operatetime,'yyyy-MM-dd'),'yyyy-MM-dd')>=to_date('"+startTime+"','yyyy-MM-dd')");
		}
		
		if(!StringUtil.isEmpty(endTime)){
			sb.append(" and to_date(to_char(t.operatetime,'yyyy-MM-dd'),'yyyy-MM-dd')<=to_date('"+endTime+"','yyyy-MM-dd')");
		}
		
		if(!StringUtil.isEmpty(parentMemberId)){
			sb.append(" and t.memberid ='"+parentMemberId+"'");
		}
		
		sb.append(" order by t.operatetime desc");
		
		return findSql(sb.toString(),WithdrawApplyDetail.class,null,pageNo, pageSize);
		
	}

}