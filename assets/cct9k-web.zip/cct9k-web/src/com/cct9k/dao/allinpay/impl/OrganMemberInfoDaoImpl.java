package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.OrganMemberInfoDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.DealTransactionDetail;
import com.cct9k.entity.allinpay.OrganMemberInfo;
import com.cct9k.entity.allinpay.PersonMemberInfo;

@Repository
public class OrganMemberInfoDaoImpl extends BaseDaoImpl<OrganMemberInfo,String> implements OrganMemberInfoDao{
	
	@Override
	public OrganMemberInfo get(String id){
		String sql = "select t.* From t_tl_organ_member_info t where t.enableflag='1' and t.memberid='"+id+"' " ;
        List<OrganMemberInfo> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(OrganMemberInfo.class).list();
	    OrganMemberInfo pmi =null;
        if (resultList != null && resultList.size() > 0) {
        	pmi =  resultList.get(0);
        }
        return pmi;
	}
	
	@Override
	public OrganMemberInfo getDeleteObj(String id){
		String sql = "select t.* From t_tl_organ_member_info t where t.enableflag='0' and t.memberid='"+id+"' " ;
        List<OrganMemberInfo> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(OrganMemberInfo.class).list();
	    OrganMemberInfo pmi =null;
        if (resultList != null && resultList.size() > 0) {
        	pmi =  resultList.get(0);
        }
        return pmi;
	}
	
	//得到对账当天之前的所有有效企业会员信息
	public List<OrganMemberInfo>   getAllOrganListBeforeDate(String dataDate){
	    String sql = "select t.* From t_tl_organ_member_info t where " +
	    		" to_char(t.createtime+1,'yyyymmdd')<='"+dataDate+"' and t.enableflag='1' " ;
        List<OrganMemberInfo> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(OrganMemberInfo.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
   }
	
	//得到对账当天新增的有效企业会员信息
	public List<OrganMemberInfo>   getAddOrganListByDate(String dataDate){
	    String sql = "select t.* From t_tl_organ_member_info t where t.lastupdatetime is null " +
	    		" and to_char(t.createtime,'yyyymmdd')='"+dataDate+"' and t.enableflag='1' " ;
        List<OrganMemberInfo> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(OrganMemberInfo.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
   }
	
	//得到对账当天修改的有效企业会员信息
	public List<OrganMemberInfo>   getModifyOrganListByDate(String dataDate){
	    String sql = "select t.* From t_tl_organ_member_info t where t.lastupdatetime is not null and " +
	    		"to_char(t.lastupdatetime,'yyyymmdd')='"+dataDate+"' and t.enableflag='1' " ;
        List<OrganMemberInfo> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(OrganMemberInfo.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
   }
	
	//得到对账当天删除的有效企业会员信息
	public List<OrganMemberInfo>   getDeleteOrganListByDate(String dataDate){
	    String sql = "select t.* From t_tl_organ_member_info t where t.lastupdatetime is not null and " +
	    		"to_char(t.lastupdatetime,'yyyymmdd')='"+dataDate+"' and t.enableflag='0' " ;
        List<OrganMemberInfo> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(OrganMemberInfo.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
   }
}