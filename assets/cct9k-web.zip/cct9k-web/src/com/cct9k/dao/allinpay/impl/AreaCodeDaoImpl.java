package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.AreaCodeDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.AreaCode;

@Repository
public class AreaCodeDaoImpl extends BaseDaoImpl<AreaCode,String> implements AreaCodeDao{
    
	@Override
	public List<AreaCode> getAreaCodeList() {

        String hql = ("From AreaCode ac where ac.status='1' ");
        List<AreaCode> list = getListByHql(hql);
        if (list != null && list.size() > 0) {
            return list;
        } else {
            return null;
        }
    }
	
	public AreaCode getAreaCode(String areacode){
		return this.get("areacode", areacode);
	}
}
