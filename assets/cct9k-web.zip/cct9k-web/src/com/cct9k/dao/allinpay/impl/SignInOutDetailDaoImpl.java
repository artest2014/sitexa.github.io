package com.cct9k.dao.allinpay.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.SignInOutDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.SignInOutDetail;

@Repository
public class SignInOutDetailDaoImpl extends BaseDaoImpl<SignInOutDetail,String> implements SignInOutDetailDao{


}
