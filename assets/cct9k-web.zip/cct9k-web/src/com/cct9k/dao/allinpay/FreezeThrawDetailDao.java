package com.cct9k.dao.allinpay;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.FreezeThrawDetail;

public interface FreezeThrawDetailDao extends BaseDao<FreezeThrawDetail,String> {
	public FreezeThrawDetail getFreezeThrawDetail(String orderId);
	
	public List<FreezeThrawDetail>   getFreezeThrawDetailList(String dataDate);
}
