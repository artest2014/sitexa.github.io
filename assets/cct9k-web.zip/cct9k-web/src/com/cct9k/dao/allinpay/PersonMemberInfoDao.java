package com.cct9k.dao.allinpay;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.PersonMemberInfo;

public interface PersonMemberInfoDao extends BaseDao<PersonMemberInfo,String> {
	public List getMemberBalanceList();
	
    public List<PersonMemberInfo>   getAllPersonListBeforeDate(String dataDate);
	
	public List<PersonMemberInfo>   getAddPersonListByDate(String dataDate);
	
	public List<PersonMemberInfo>   getModifyPersonListByDate(String dataDate);
	
	public List<PersonMemberInfo>   getDeletePersonListByDate(String dataDate);
	
	public PersonMemberInfo getDeleteObj(String id);
}
