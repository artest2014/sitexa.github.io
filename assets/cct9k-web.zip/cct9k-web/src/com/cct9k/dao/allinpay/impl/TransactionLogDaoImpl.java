package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.TransactionLogDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.TransactionLog;

@Repository
public class TransactionLogDaoImpl extends BaseDaoImpl<TransactionLog,String> implements TransactionLogDao{

	public TransactionLog getTransactionLog(String applyCode){
		   String hql = "From TransactionLog t where t.requestserialid='"+applyCode+"'";
		   TransactionLog mai = null;
		   List<TransactionLog> list = getListByHql(hql);
		   if(list!=null&&list.size()>0){
			   mai = list.get(0);
		   }
		   return mai;
	   }
}
