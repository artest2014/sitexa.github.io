package com.cct9k.dao.allinpay.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.RefundOrderDetailRelDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.RefundOrderDetailRel;

@Repository
public class RefundOrderDetailRelDaoImpl extends BaseDaoImpl<RefundOrderDetailRel,String> implements RefundOrderDetailRelDao {
            

}
