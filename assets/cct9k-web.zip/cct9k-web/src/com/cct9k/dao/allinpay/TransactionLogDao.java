package com.cct9k.dao.allinpay;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.TransactionLog;

public interface TransactionLogDao extends BaseDao<TransactionLog,String> {
	public TransactionLog getTransactionLog(String applyCode);
}
