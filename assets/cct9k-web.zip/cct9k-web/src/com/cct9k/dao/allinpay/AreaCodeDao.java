package com.cct9k.dao.allinpay;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.AreaCode;

public interface AreaCodeDao extends BaseDao<AreaCode,String> {
	public List<AreaCode> getAreaCodeList();
	
	public AreaCode getAreaCode(String areacode);
}
