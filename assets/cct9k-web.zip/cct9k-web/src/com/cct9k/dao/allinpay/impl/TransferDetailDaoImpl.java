package com.cct9k.dao.allinpay.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.allinpay.TransferDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.TransferDetail;
import com.cct9k.entity.allinpay.WithdrawApplyDetail;
import com.cct9k.util.common.StringUtil;

@Repository
public class TransferDetailDaoImpl extends BaseDaoImpl<TransferDetail,String> implements TransferDetailDao{

	@Override
	public Pagination getPage(String startTime,String endTime ,String parentMemberId,int pageNo, int pageSize) {
		StringBuffer sb = new StringBuffer();
		
		sb.append("select t.* from t_tl_transfer_detail t where 1=1 ");
		
		if(!StringUtil.isEmpty(startTime)){
			sb.append(" and to_date(to_char(t.operatetime,'yyyy-MM-dd'),'yyyy-MM-dd')>=to_date('"+startTime+"','yyyy-MM-dd')");
		}
		
		if(!StringUtil.isEmpty(endTime)){
			sb.append(" and to_date(to_char(t.operatetime,'yyyy-MM-dd'),'yyyy-MM-dd')<=to_date('"+endTime+"','yyyy-MM-dd')");
		}
		
		if(!StringUtil.isEmpty(parentMemberId)){
			sb.append(" and t.payer ='"+parentMemberId+"'");
		}
		
		sb.append(" order by t.operatetime desc");
		
		return findSql(sb.toString(),TransferDetail.class,null,pageNo, pageSize);
		
	}
}
