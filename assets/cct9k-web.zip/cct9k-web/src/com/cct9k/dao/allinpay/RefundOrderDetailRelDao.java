package com.cct9k.dao.allinpay;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.RefundOrderDetailRel;

public interface RefundOrderDetailRelDao extends BaseDao<RefundOrderDetailRel, String> {

}
