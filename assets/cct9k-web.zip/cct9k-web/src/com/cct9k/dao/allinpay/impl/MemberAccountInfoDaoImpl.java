package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.MemberAccountInfoDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.MemberAccountInfo;
import com.cct9k.util.common.StringUtil;

@Repository
public class MemberAccountInfoDaoImpl extends BaseDaoImpl<MemberAccountInfo,String> implements MemberAccountInfoDao{

   public List<MemberAccountInfo>   getMemberAccountInfoList(String memberId,String accountType){
	   String hql = "From MemberAccountInfo t where t.memberid='"+memberId+"' and t.enableflag='1' " ;
	   if(!StringUtil.isEmpty(accountType)){
		   hql+=" and accounttype!='"+accountType+"'";
	   }
	   List<MemberAccountInfo> list = null;
	   list = getListByHql(hql);
	   return list;
   }
   
   public List<MemberAccountInfo>   getMemberAccountInfoList(String memberId){
	   String hql = "From MemberAccountInfo t where t.memberid='"+memberId+"' and t.enableflag='1' " ;
	   List<MemberAccountInfo> list = null;
	   list = getListByHql(hql);
	   return list;
   }
   
   public MemberAccountInfo getMemberAccountInfo(String accountId){
	   String hql = "From MemberAccountInfo t where t.enableflag='1' and t.memberaccountid='"+accountId+"'";
	   MemberAccountInfo mai = null;
	   List<MemberAccountInfo> list = getListByHql(hql);
	   if(list!=null&&list.size()>0){
		   mai = list.get(0);
	   }
	   return mai;
   }
   
    //得到对账的所有有效账号信息
 	public List<MemberAccountInfo>   getAllAccountList(){
 	    String sql = "select t.* From t_tl_member_account_info t  " ;
         List<MemberAccountInfo> resultList = null;
 	     resultList = this.getSession().createSQLQuery(sql).addEntity(MemberAccountInfo.class).list();
         if (resultList != null && resultList.size() > 0) {
             return resultList;
         }else{
         	return null;
         }
    }
 	
 	//得到对账当天有效账号信息
 	public List<MemberAccountInfo>   getAccountListByDate(String dataDate){
 	    String sql = "select t.* From t_tl_member_account_info t where 1=1" +
 	    		" and to_char(t.createtime,'yyyymmdd')='"+dataDate+"' " ;
         List<MemberAccountInfo> resultList = null;
 	     resultList = this.getSession().createSQLQuery(sql).addEntity(MemberAccountInfo.class).list();
         if (resultList != null && resultList.size() > 0) {
             return resultList;
         }else{
         	return null;
         }
    }
 	
}