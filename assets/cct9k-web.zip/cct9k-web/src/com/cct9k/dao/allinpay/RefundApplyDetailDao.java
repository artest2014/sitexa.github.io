package com.cct9k.dao.allinpay;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.RefundApplyDetail;

public interface RefundApplyDetailDao extends BaseDao<RefundApplyDetail,String> {
   
	public int judgeOrderIsRefundingOrNot(String orderId);
	
	public String getAuditStatusByOrderIdAndDetailId(String orderId,String detailId);
	
	public List<RefundApplyDetail>   getRefundApplyDetailList(String orderId);
}
