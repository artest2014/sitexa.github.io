package com.cct9k.dao.allinpay;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.SignInOutDetail;

public interface SignInOutDetailDao extends BaseDao<SignInOutDetail,String> {

}
