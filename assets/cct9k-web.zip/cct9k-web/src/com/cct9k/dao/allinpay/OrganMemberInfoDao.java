package com.cct9k.dao.allinpay;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.allinpay.OrganMemberInfo;

public interface OrganMemberInfoDao extends BaseDao<OrganMemberInfo,String> {
	
	public List<OrganMemberInfo>   getAllOrganListBeforeDate(String dataDate);
	
	public List<OrganMemberInfo>   getAddOrganListByDate(String dataDate);
	
	public List<OrganMemberInfo>   getModifyOrganListByDate(String dataDate);
	
	public List<OrganMemberInfo>   getDeleteOrganListByDate(String dataDate);
	
	public OrganMemberInfo getDeleteObj(String id);
}
