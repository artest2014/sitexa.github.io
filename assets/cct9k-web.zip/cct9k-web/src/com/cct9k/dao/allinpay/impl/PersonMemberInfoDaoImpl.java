package com.cct9k.dao.allinpay.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.allinpay.PersonMemberInfoDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.PersonMemberInfo;

@Repository
public class PersonMemberInfoDaoImpl extends BaseDaoImpl<PersonMemberInfo,String> implements PersonMemberInfoDao{
	
	@Override
	public PersonMemberInfo get(String id){
		String sql = "select t.* From t_tl_person_member_info t where t.enableflag='1' and t.memberid='"+id+"' " ;
        List<PersonMemberInfo> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(PersonMemberInfo.class).list();
	    PersonMemberInfo pmi =null;
        if (resultList != null && resultList.size() > 0) {
        	pmi =  resultList.get(0);
        }
        return pmi;
	}
	
	@Override
	public PersonMemberInfo getDeleteObj(String id){
		String sql = "select t.* From t_tl_person_member_info t where t.enableflag='0' and t.memberid='"+id+"' " ;
        List<PersonMemberInfo> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(PersonMemberInfo.class).list();
	    PersonMemberInfo pmi =null;
        if (resultList != null && resultList.size() > 0) {
        	pmi =  resultList.get(0);
        }
        return pmi;
	}
	
	public List getMemberBalanceList() {
        String sql = "select a.memberid,a.accountusablebalance From t_tl_person_member_info a where a.enableflag='1'"
					+" union"
					+" select b.memberid,b.accountusablebalance From t_tl_organ_member_info b where b.enableflag='1' ";
        Query query = this.getSession().createSQLQuery(sql);
        List resultList = query.list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        } else {
            return null;
        }
    }
	
	//得到对账当天之前的所有有效个人会员信息
		public List<PersonMemberInfo>   getAllPersonListBeforeDate(String dataDate){
		    String sql = "select t.* From t_tl_person_member_info t where " +
		    		" to_char(t.createtime+1,'yyyymmdd')<='"+dataDate+"' and t.enableflag='1' " ;
	        List<PersonMemberInfo> resultList = null;
		    resultList = this.getSession().createSQLQuery(sql).addEntity(PersonMemberInfo.class).list();
	        if (resultList != null && resultList.size() > 0) {
	            return resultList;
	        }else{
	        	return null;
	        }
	   }
		
		//得到对账当天新增的有效个人会员信息
		public List<PersonMemberInfo>   getAddPersonListByDate(String dataDate){
		    String sql = "select t.* From t_tl_person_member_info t where t.lastupdatetime is null " +
		    		" and to_char(t.createtime,'yyyymmdd')='"+dataDate+"' and t.enableflag='1' " ;
	        List<PersonMemberInfo> resultList = null;
		    resultList = this.getSession().createSQLQuery(sql).addEntity(PersonMemberInfo.class).list();
	        if (resultList != null && resultList.size() > 0) {
	            return resultList;
	        }else{
	        	return null;
	        }
	   }
		
		//得到对账当天修改的有效个人会员信息
		public List<PersonMemberInfo>   getModifyPersonListByDate(String dataDate){
		    String sql = "select t.* From t_tl_person_member_info t where t.lastupdatetime is not null and " +
		    		"to_char(t.lastupdatetime,'yyyymmdd')='"+dataDate+"' and t.enableflag='1' " ;
	        List<PersonMemberInfo> resultList = null;
		    resultList = this.getSession().createSQLQuery(sql).addEntity(PersonMemberInfo.class).list();
	        if (resultList != null && resultList.size() > 0) {
	            return resultList;
	        }else{
	        	return null;
	        }
	   }
		
		//得到对账当天删除的有效个人会员信息
		public List<PersonMemberInfo>   getDeletePersonListByDate(String dataDate){
		    String sql = "select t.* From t_tl_person_member_info t where t.lastupdatetime is not null and " +
		    		"to_char(t.lastupdatetime,'yyyymmdd')='"+dataDate+"' and t.enableflag='0' " ;
	        List<PersonMemberInfo> resultList = null;
		    resultList = this.getSession().createSQLQuery(sql).addEntity(PersonMemberInfo.class).list();
	        if (resultList != null && resultList.size() > 0) {
	            return resultList;
	        }else{
	        	return null;
	        }
	   }
	
}