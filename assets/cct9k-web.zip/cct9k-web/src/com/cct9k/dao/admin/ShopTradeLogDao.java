package com.cct9k.dao.admin;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.ShopTradeLog;

public interface ShopTradeLogDao extends BaseDao<ShopTradeLog, String>{

}
