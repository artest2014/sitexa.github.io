package com.cct9k.dao.admin.impl;

import com.cct9k.dao.admin.SiteDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.Site;
import com.cct9k.entity.admin.SiteType;
import com.cct9k.web.vo.SiteVo;

import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import java.util.List;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class SiteDaoImpl extends BaseDaoImpl<Site, String> implements SiteDao {
    @Override
    @SuppressWarnings("unchecked")
    public List<Site> getListByType(SiteType type) {
        Assert.notNull(type, "value is required");
        String hql = "from " + Site.class.getName() + " as model where model.siteType = ? order by model.siteid asc ";
        return getSession().createQuery(hql).setParameter(0, type).list();
    }

	@Override
	public List<SiteVo> findVoAllById(String id) {
		Assert.notNull(id, "value is required");
		String sql = "select new com.cct9k.web.vo.SiteVo(siteid, name) from Site where parentid=(select parent.siteid from Site where siteid=?)";
		return getSession().createQuery(sql).setParameter(0, id).list();
		
	}

	@Override
	public Site get(String id) {
		return super.get(id);
	}
	
	
}
