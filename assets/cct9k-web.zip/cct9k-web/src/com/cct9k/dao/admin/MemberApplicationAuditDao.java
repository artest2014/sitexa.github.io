package com.cct9k.dao.admin;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.MemberApplicationAudit;

public interface MemberApplicationAuditDao extends BaseDao<MemberApplicationAudit, String> {
    //主键生成
    public String getSeqn();


	/**
	 * 描述: 
	 * @param memberName
	 * @param momberNo
	 * @param regDate
	 * @param pageNo
	 * @param i
	 * @return
	 */
		
	    



	public void updateMemberRole(String memberid, String roleid);

	public void delMemApplication(String memberid, String appid);


	List<MemberApplicationAudit> getMemberApplicationsByMemberId(String memberid);
	
	public MemberApplicationAudit getMemberApplicationAuditByAppId(String appid);
	
	public Pagination getPage(String memberName, String rolename,
			String auditstatus1, int pageNo, int pageSize);


	public MemberApplicationAudit getByAppIdAndMemberId(String appid,
			String memberid);

}
