package com.cct9k.dao.admin.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.MemberApplicationAuditDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.MemberApplicationAudit;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author yics 2013-04-08
 */
@Repository
public class MemberApplicationDaoImpl extends BaseDaoImpl<MemberApplicationAudit, String> implements MemberApplicationAuditDao {

	@Override
	public String getSeqn() {
		String sql = " select s_member.nextval from dual";
		Query query = getSession().createSQLQuery(sql);
		BigDecimal b = (BigDecimal) query.uniqueResult();
		return b.toString();
	}

	@Override
	public void updateMemberRole(String memberid, String roleid) {
		String sql = "insert into  t_member_role(memberid,roleid,status) values("
				+ memberid + "," + roleid + ",'0')";
		getSession().createSQLQuery(sql).executeUpdate();
	}

	  @Override
	    public void delMemApplication(String memberid, String appid) {
	        String sql = "delete from  t_member_application  where memberid='" + memberid + "' and appid='" + appid + "'";
	        String hql = "delete from  MemberApplicationAudit  where memberid='" + memberid + "' and appid='" + appid + "'";
	        String sql3 = "delete from t_member_role where  memberid='" + memberid + "' and roleid in (select a.roleid from t_role a where a.appid='" + appid + "')";
	        String sql2 = "delete  from t_audit t where t.auditid=(select a.auditid from t_member_application_audit a where memberid='" + memberid + "' and appid='" + appid + "')";
	        getSession().createQuery(hql).executeUpdate();
	        getSession().createSQLQuery(sql).executeUpdate();
	        getSession().createSQLQuery(sql2).executeUpdate();
	        getSession().createSQLQuery(sql3).executeUpdate();

	    }

	@Override
	@SuppressWarnings("unchecked")
	public List<MemberApplicationAudit> getMemberApplicationsByMemberId(String memberid) 

{
		String hql = " from MemberApplicationAudit m where m.member.memberid="+ 

memberid;
		return getSession().createQuery(hql).list();
	}

	@Override
	public MemberApplicationAudit getMemberApplicationAuditByAppId(String appid) {
		String hql = " from  MemberApplicationAudit as model where model.appid.appid = '"+ appid + "'";
		List<MemberApplicationAudit> list = getListByHql(hql);
		if (list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}
	}

	public Pagination getPage(String membername, String appname,
			String auditstatus1, int pageNo, int pageSize) {
		Finder r = Finder.create("from MemberApplicationAudit mra where 1=1");
		if (!StringUtil.isEmpty(membername)) {
			r.append(" and mra.member.membername like '%'||:membername||'%' ");
			r.setParam("membername", membername);
		}
		if (!StringUtil.isEmpty(appname)) {
			r.append(" and mra.appid.appname like '%'||:appname||'%' ");
			r.setParam("appname", appname);
		}
		if (!StringUtil.isEmpty(auditstatus1)) {
			r.append(" and mra.audit.auditstatus1.dictid =:auditstatus1");
			r.setParam("auditstatus1", auditstatus1);
		}
		return find(r, pageNo, pageSize);
	}

	@Override
	public MemberApplicationAudit getByAppIdAndMemberId(String appid,
			String memberid) {
		String hql=" from MemberApplicationAudit m where m.appid.appid='"+appid+"' and m.member.memberid='"+memberid+"' "; 
		return (MemberApplicationAudit) getSession().createQuery(hql).uniqueResult();
	}
}
