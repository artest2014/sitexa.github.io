package com.cct9k.dao.admin.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.admin.DepartmentDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.Department;
/**
 * @description: 部门dao实现
 * @author: caimao 328691091@qq.com
 * @createtime:2013年11月7日 下午2:00:34
 */
@SuppressWarnings("unchecked")
@Repository
public class DepartmentDaoImp extends BaseDaoImpl<Department, String> implements
		DepartmentDao {

	@Override
	public void deleteByOwneridAndAppid(String ownerid, String appid) {
		String hql = "delete from Department d where d.owner.memberid=? and d.objectType=?";
		getSession().createQuery(hql).setParameter(0, ownerid).setParameter(1, appid);
	}
	
	@Override
	public List<Department> findDeptsByOwneridAndAppid(String owerid,
			String appid) {
		//TODO cm其实这里可以通过父id取出所有的子部门，确定一下怎么写？？
		String hql = "from Department d where d.owner.memberid=? and d.objectType=?";
		return getSession().createQuery(hql).setParameter(0, owerid).setParameter(1, appid).list();
	}

	@Override
	public Department getParentByTypeidAndOwnid(String typeid, String ownid) {
		String hql = "from Department d where d.owner.memberid=? and d.objectType=? and d.parentDepartment.departmentId is null";
		return (Department) getSession().createQuery(hql).setParameter(0, ownid).setParameter(1, typeid).uniqueResult();
	}

	@Override
	public Department findDepetByObjectIdAndObjectTypeid(String objectId,
			String objectTypeId) {
		String hql = "from Department d where d.objectid=? and d.objectType=?";
		return (Department) getSession().createQuery(hql).setParameter(0, objectId).setParameter(1, objectTypeId).uniqueResult();
	}

}
