package com.cct9k.dao.admin.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.admin.MemberExpansionDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.member.MemberExpansion;

@Repository
public class MemberExpansionDaoImpl extends
		BaseDaoImpl<MemberExpansion, String> implements MemberExpansionDao {

}
