/**
 * <p>Class Name: RoleDao.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-4-25</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */

package com.cct9k.dao.admin;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Role;

import java.util.List;

/**
 *
 */
public interface RoleDao extends BaseDao<Role, String> {

	/**
	 * @param rolecontext
	 *            :角色名称
	 * @param rolename
	 *            :角色标志
	 * @param regDate
	 *            ;注册日期
	 * @param pageNo
	 *            ：当前页码
	 * @param pageSize
	 *            ：每页大小
	 * @return
	 */
	public Pagination getPage(String roletext, String rolename, String orgid, String appid,
			int pageNo, int pageSize);

	public List<Role> getRolesByName(String name);

	public String getSeqn();

	public Pagination getOrganRoleList(String memberId, String roleName,
			int pageNo, int pageSize);

	public List<String> getResourceIdsByRoleId(String roleid);

	public List<Role> getByappid(String appid);

	public Pagination getPagination(String rolename, String roletext,String appid, int pageNo, int pageSize);

	public void updateResources(Role role, String[] ids);

	boolean existResource(Role role, String resid);

	public void updateMembers(Role role, String[] ids);

	boolean existMember(Role role, String mid);

	public void deleteRoleByMemebrID(String id);

	public void saveByMemberIdAndRoleId(String roleId, String memberId);

	public void deleteByMemberIdAndRoleId(String roleId, String memberId);

	public List<String> getByMemberid(String memberid);
	
	public List<String> existMemberRole(String roleid, String mid);

    void deleteByResourceIdAndRoleId(String roleId, String resid);

	public List<Role> getRolesByRoleNameAndOrgid(String roleName, String orgid);
}
