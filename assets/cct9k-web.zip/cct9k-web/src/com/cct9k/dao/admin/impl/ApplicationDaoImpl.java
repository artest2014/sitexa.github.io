package com.cct9k.dao.admin.impl;

import com.cct9k.dao.admin.ApplicationDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.Application;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author
 * 
 */
@Repository
public class ApplicationDaoImpl extends BaseDaoImpl<Application, String>
		implements ApplicationDao {
	@Override
	public String getSeqn() {
		String sql = " select s_application.nextval from dual";
		Query query = getSession().createSQLQuery(sql);
		BigDecimal b = (BigDecimal) query.uniqueResult();
		return b.toString();
	}

	public List<Application> getAll() {
		return super.getAll();

	}

	public Application get(String appid) {

		return super.get(appid);
	}
}
