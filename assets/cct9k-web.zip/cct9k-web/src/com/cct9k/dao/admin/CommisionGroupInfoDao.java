package com.cct9k.dao.admin;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.CommissionGroupInfo;

public interface CommisionGroupInfoDao extends BaseDao<CommissionGroupInfo,String>{
	public Pagination getCommisionGroupInfos(String candelete,int pageNo,
			int pageSize);
}
