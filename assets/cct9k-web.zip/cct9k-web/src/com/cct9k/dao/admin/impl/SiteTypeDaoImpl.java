package com.cct9k.dao.admin.impl;

import com.cct9k.dao.admin.SiteTypeDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.SiteType;

import org.springframework.stereotype.Repository;

@Repository
public class SiteTypeDaoImpl extends BaseDaoImpl<SiteType, String> implements SiteTypeDao {

}
