package com.cct9k.dao.admin;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.DefaultRole;

public interface DefaultRoleDao extends BaseDao<DefaultRole, String> {

	Pagination getPage(String roletext, String rolename, String appid, int pageNo,
			int pageSize);
	
	/**
	 *根据appid取出所有的默认角色
	 * @param appid ： 应用id
	 * @return
	 */
	List<DefaultRole> findDefaultRoleByAppid(String appid);

	List<String> getResourceIdsByRoleId(String roleid);
	
	List<DefaultRole> findDefaultRoleByAppidAndRoletype(String appid, String roletype);

	
	
}
