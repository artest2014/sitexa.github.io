/**
 * <p>Class Name: ResourcesDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-4-23</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */

package com.cct9k.dao.admin.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.ResourcesDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.Resources;
import com.cct9k.util.common.StringUtil;

import org.apache.commons.beanutils.DynaBean;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
@SuppressWarnings("unchecked")
public class ResourcesDaoImpl extends BaseDaoImpl<Resources, String> implements ResourcesDao {

    @Override
    public String getSeqn() {
        String sql = " select s_public.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }

    @Override
    public Pagination getPage(String resourceName, String resurl, String regDate, int pageNo, int pageSize) {
        Finder f = Finder.create("from Resources res where 1=1 ");
        if (!StringUtil.isEmpty(resourceName)) {
            f.append(" and res.name like '%'||:resourceName||'%' ");
            f.setParam("resourceName", resourceName);
        }
        if (!StringUtil.isEmpty(resurl)) {
            f.append(" and res.resurl like '%'||:resurl||'%' ");
            f.setParam("resurl", resurl);
        }
        f.append(" and res.parent is null");
        f.append(" order by res.resurl desc");
        return find(f, pageNo, pageSize);
    }

    @Override
    public boolean addResource(Resources res) {
        String sql = " insert into t_resource (RESID, NAME, PARENTID, RESURL, TYPE, PRIORITY, DESCRIPTION, MENU)" + " values (?, ?, ?, ?, 1, ?, ?, 1)";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, getSeqn());
        query.setString(1, res.getName());
        if (null == res.getParent()) {
            query.setString(2, "");
        } else {
            query.setString(2, res.getParent().getResid());
        }
        query.setString(3, res.getResurl());
        query.setInteger(4, res.getPriority());
        query.setString(5, res.getDescription());
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean updateResource(String resName, String resPath, String resId, String ressort) {
        String sql = " update t_resource t set t.name=?,t.resurl=?,t.priority=? where t.resid=?";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, resName);
        query.setString(1, resPath);
        query.setString(2, ressort);
        query.setString(3, resId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean updateIsMenu(String menu, String resId) {
        String sql = " update t_resource t set t.menu=? where t.resid=?";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, menu);
        query.setString(1, resId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<Resources> getParentMenu() {
        String sql = "from Resources t where t.parent.resid=0 and t.menu=1";
        return getSession().createQuery(sql).list();
    }

    public List<Resources> getParentMenuBySQL() {
        String sql = "select t.* from t_resource t where t.resid=0 is null ";
        Query query = this.getSession().createSQLQuery(sql);
        List<Resources> menuList = query.list();
        return menuList;
    }

    @Override
    public List<Resources> getParentResource() {
        return getSession().createQuery("from Resources r where r.parent.resid=0").list();
    }

    @Override
    public Resources get(String id) {
        return super.get(id);
    }

    @Override
    public List<Resources> get(String[] ids) {
        return super.get(ids);
    }

    @Override
    public void delete(Resources entity) {
        super.delete(entity);
    }

    @Override
    public List<Resources> getResourcesByName(String resname) {
        String hql = null;
        if ("".equals(resname)) {
            hql = "";
        } else {
            hql = "select * from t_resource t where t.parentid is null " +
                    "and t.menu=1 and t.resid " +
                    "not in(select distinct(t_r.resid) " +
                    "from t_role_resource t_r where t_r.roleid=266)";
        }
        System.out.println(hql);
        return null;
    }

    @Override
    public Resources getResourceByUrl(String url) {
        return (Resources) getSession().createQuery("from Resources r where r.resurl = ?").setParameter(0, url).uniqueResult();
    }

    @Override
    public void update(Resources entity) {
        super.update(entity);
    }

    @Override
    public Pagination getPagination(String name, String code, String menu, int pageNo, int pageSize) {
        String sql = "from Resources model where 1=1 ";
        Finder f = Finder.create(sql);

        if (!StringUtil.isEmpty(name)) {
            f.append(" and model.name like '%'||:name||'%' ");
            f.setParam("name", name);
        }

        if (!StringUtil.isEmpty(code)) {
            f.append(" and model.code like :name||'%' ");
            f.setParam("code", code);
        }

        if (!StringUtil.isEmpty(menu)) {
            f.append(" and model.menu = :menu ");
            f.setParam("menu", menu);
        }

        f.append(" order by code asc ");

        return find(f, pageNo, pageSize);
    }

    @Override
    public List<Resources> getMenuResources() {
        String sql = " from Resources where menu = 1 order by code asc ";
        return getSession().createQuery(sql).list();
    }

    @Override
    public List<Resources> getAllResources() {
        String sql = " from Resources order by code asc ";
        return getSession().createQuery(sql).list();
    }

	@Override
	public List<DynaBean> getAllReResourceToDynaBean() {
		String sql = "select t.resid,t.name,t.parentid from t_resource t";
		return getListByJdbcSql(sql);
	}
	
	@Override
	public List<Resources> getChildResourceByParentid(String parentId) {
		return getSession().createQuery("from Resources where parentid=?").setParameter(0, parentId).list();
	}

	@Override
	public List<Resources> getLayerOneAndTwoResource() {
		return getSession().createQuery("from Resources where layer=1 or layer=2").list();
	}
}
