/**
 * <p>Class Name: ResourcesDao.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-4-23</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */

package com.cct9k.dao.admin;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Resources;

import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.DynaBean;

/**
 *
 */
public interface ResourcesDao extends BaseDao<Resources, String> {

	public String getSeqn();

	public List<Resources> getParentResource();

	public Pagination getPage(String resourceName, String resurl,
			String regDate, int pageNo, int pageSize);
	public List<Resources> getParentMenuBySQL();

	public boolean addResource(Resources res);

	public boolean updateResource(String resName, String resPath, String resId,
			String ressort);
	public boolean updateIsMenu(String menu, String resId);

	public List<Resources> getParentMenu();

	public List<Resources> getResourcesByName(String resname);

	public Resources getResourceByUrl(String url);

	public Pagination getPagination(String name, String code, String menu,
			int pageNo, int pageSize);

	public List<Resources> getMenuResources();

    public  List<Resources> getAllResources();

	public List<DynaBean> getAllReResourceToDynaBean();

	public List<Resources> getChildResourceByParentid(String parentId);

	public List<Resources> getLayerOneAndTwoResource();

}
