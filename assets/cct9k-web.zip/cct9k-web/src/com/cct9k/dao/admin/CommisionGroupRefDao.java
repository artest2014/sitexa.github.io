package com.cct9k.dao.admin;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.CommissionGroupRef;

public interface CommisionGroupRefDao extends BaseDao<CommissionGroupRef, String>{
 
	public Pagination getCommisionGroupRefs(String groupname,String groupid,int pageNo, int pageSize);
	
	public CommissionGroupRef getByobjectidAndObjecttypeid(String objectid,String objecttypeid);
	
	public Pagination getAllShopByType(String objecttype,int pageNo, int pageSize);
}
