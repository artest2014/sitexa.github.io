package com.cct9k.dao.admin.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.RoleDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.Resources;
import com.cct9k.entity.admin.Role;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

/**
 * <p>Class Name: RoleDaoImpl.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: caimao</p>
 * <p>Date: 2013-6-26</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
@SuppressWarnings({"unchecked"})
@Repository
public class RoleDaoImpl extends BaseDaoImpl<Role, String> implements RoleDao {

    //取得所有的Role
    @Override
    public List<Role> getAll() {
        String hql = "from Role r where r.enable=1 and r.orgid is null";
        List<Role> roles = getSession().createQuery(hql).list();
        return roles;
    }

    @Override
    public Pagination getPage(String roletext, String rolename, String orgid, String appid, int pageNo, int pageSize) {
        Finder f = Finder.create("from Role role where role.orgid='"+orgid+"' and role.application.appid='"+appid+"'");
        if (!StringUtil.isEmpty(roletext)) {
            f.append(" and role.roletext like '%'||:roletext||'%' ");
            f.setParam("roletext", roletext);
        }
        if (!StringUtil.isEmpty(rolename)) {
            f.append(" and role.rolename like '%'||:rolename||'%' ");
            f.setParam("rolename", rolename);
        }
        f.append(" order by role.department.departmentId");
        return find(f, pageNo, pageSize);
    }

    @Override
    public String save(Role r) {
        return super.save(r);
    }

    @Override
    public Role get(String id) {
        return super.get(id);
    }

    @Override
    public void update(Role r) {
        super.update(r);
    }

    @Override
    public void delete(String id) {
        super.delete(id);
    }

    @Override
    public Role get(String propertyName, Object value) {
        return super.get(propertyName, value);
    }

    @Override
    public List<Role> getRolesByName(String name) {
        String hql = "from Member m where m.membername like '%" + name + "%'";
        return getSession().createQuery(hql).list();
    }

    @Override
    public List<Role> get(String[] ids) {
        return super.get(ids);
    }

    @Override
    public void delete(String[] ids) {
        super.delete(ids);
    }

    public String getSeqn() {
        String sql = " select s_public.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }

    public Pagination getOrganRoleList(String memberId, String roleName, int pageNo, int pageSize) {
        String sql = "select t.*  from t_role t where 1=1  ";
        if (!StringUtil.isEmpty(memberId)) {
            sql += "  and t.orgid='" + memberId + "'";
        }
        if (!StringUtil.isEmpty(roleName)) {
            sql += "  and t.roletext  like '%" + roleName + "%'";
        }
        sql += " and t.orgid is not null";
        return this.findSql(sql, pageNo, pageSize);
    }

    @Override
    public List<String> getResourceIdsByRoleId(String roleid) {
        String sql = "select resid from t_role_resource tr where roleid=" + roleid;
        List<String> list = getSession().createSQLQuery(sql).list();
        return list;
    }

    @Override
    public List<Role> getByappid(String appid) {
        String hql = "select r from Role r where r.application.appid=?";
        return getSession().createQuery(hql).setParameter(0, appid).list();
    }

    @Override
    public void deleteRoleByMemebrID(String id) {
        String sql = "delete from t_member_role where memberid='" + id + "'";
        getSession().createSQLQuery(sql).executeUpdate();
    }

    @Override
    public Pagination getPagination(String rolename, String roletext, String appid, int pageNo, int pageSize) {
        Finder f = Finder.create("from Role where 1=1 ");

        if (!StringUtil.isEmpty(rolename)) {
            f.append(" and rolename=:rolename ");
            f.setParam("rolename", rolename);
        }
 
        
        
        if (!StringUtil.isEmpty(roletext)) {
            f.append(" and roletext like '%'||:roletext||'%' ");
            f.setParam("roletext", roletext);
        }

        if (!StringUtil.isEmpty(appid)) {
            f.append(" and application.appid=:appid ");
            f.setParam("appid", appid);
        }

        f.append(" order by orgid,roletext asc ");
        return find(f, pageNo, pageSize);
    }

    @Override
    public boolean existResource(Role role, String resid) {
        String sql = "select count(*) from t_role_resource where roleid=:roleid and resid=:resid ";
        Number count = (Number) getSession().createSQLQuery(sql).setParameter("roleid", role.getRoleid()).setParameter("resid", resid).uniqueResult();
        return count.intValue() > 0;
    }

    @Override
    public boolean existMember(Role role, String mid) {
        String sql = "select count(*) from t_member_role where roleid=:roleid and memberid=:mid ";
        Number count = (Number) getSession().createSQLQuery(sql).setParameter("roleid", role.getRoleid()).setParameter("mid", mid).uniqueResult();
        return count.intValue() > 0;
    }

    @Override
    public void updateMembers(Role role, String[] ids) {
        if (ids.length <= 0 || role == null) return;

        Set<Member> members = role.getMembers();
        for (Member member : members) {
            deleteByMemberIdAndRoleId(role.getRoleid(), member.getMemberid());
        }

        for (String id : ids) {
            String sql = " insert into t_member_role(roleid,memberid) values(:roleid,:memberid) ";
            getSession().createSQLQuery(sql).setParameter("roleid", role.getRoleid()).setParameter("memberid", id).executeUpdate();
        }
    }

    @Override
    public void updateResources(Role role, String[] ids) {
        if (ids.length <= 0 || role == null) return;

        Set<Resources> resourceses = role.getMenuResources();
        for (Resources res : resourceses) {
            deleteByResourceIdAndRoleId(role.getRoleid(), res.getResid());
        }

        for (String id : ids) {
            String sql = " insert into t_role_resource(roleid,resid) values(:roleid,:resid) ";
            getSession().createSQLQuery(sql).setParameter("roleid", role.getRoleid()).setParameter("resid", id).executeUpdate();
        }
    }

    @Override
    public void saveByMemberIdAndRoleId(String roleId, String memberId) {
        String sql = "insert into t_member_role(memberid,roleid) values(?,?)";
        getSession().createSQLQuery(sql).setParameter(0, memberId).setParameter(1, roleId).executeUpdate();
    }

    @Override
    public void deleteByMemberIdAndRoleId(String roleId, String memberId) {
        String sql = "delete from t_member_role where memberid=? and roleid=?";
        getSession().createSQLQuery(sql).setParameter(0, memberId).setParameter(1, roleId).executeUpdate();
    }

    @Override
    public void deleteByResourceIdAndRoleId(String roleId, String resid) {
        String sql = "delete from t_role_resource where resid=? and roleid=?";
        getSession().createSQLQuery(sql).setParameter(0, resid).setParameter(1, roleId).executeUpdate();
    }

    @Override
    public List<String> getByMemberid(String memberid) {
        String sql = "select roleid from t_member_role where memberid=?";
        return getSession().createSQLQuery(sql).setParameter(0, memberid).list();

    }

	@Override
    public List<String> existMemberRole(String roleid, String mid) {
        String sql = "select * from t_member_role where memberid=:mid and roleid=:roleid ";
        @SuppressWarnings("rawtypes")
		List list = getSession().createSQLQuery(sql).setParameter("roleid", roleid).setParameter("mid", mid).list();
        return list;
    }

	@Override
	public List<Role> getRolesByRoleNameAndOrgid(String roleName, String orgid) {
		String hql = "from Role where rolename=? and orgid=?";
		List<Role> roles = getSession().createQuery(hql).setParameter(0, roleName).setParameter(1, orgid).list();
		return roles;
	}
}
