package com.cct9k.dao.admin;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Application;

public interface ApplicationDao extends BaseDao<Application, String> {
    public String getSeqn();
     public List<Application> getAll();
}
