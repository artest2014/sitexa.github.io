package com.cct9k.dao.admin;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Site;
import com.cct9k.entity.admin.SiteType;
import com.cct9k.web.vo.SiteVo;

import java.util.List;

public interface SiteDao extends BaseDao<Site, String> {

    List<Site> getListByType(SiteType type);

    List<SiteVo> findVoAllById(String id);
    
    public Site get(String siteId);
    
    
    
}
