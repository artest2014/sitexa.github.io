package com.cct9k.dao.admin;


import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.National;

public interface NationalDao  extends BaseDao<National, String> {

	
}
