package com.cct9k.dao.admin;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Department;
/**
 * @description: 部门dao借口
 * @author: caimao 328691091@qq.com
 * @createtime:2013年11月7日 下午2:00:59
 */
public interface DepartmentDao extends BaseDao<Department, String> {
	/**
	 * 根据拥有者和应用类型id删除部门
	 * @param ownerid ： 拥有者id
	 * @param appid ： 应用类型id
	 */
	void deleteByOwneridAndAppid(String ownerid, String appid);
	
	/**
	 * 通过appid取得所有的部门
	 * @param appid ：应用id
	 * @return 所有的部门
	 */
	List<Department> findDeptsByOwneridAndAppid(String owerid, String appid);
	
	Department getParentByTypeidAndOwnid(String typeid, String ownid);

	Department findDepetByObjectIdAndObjectTypeid(String objectId,String objectTypeId);
}
