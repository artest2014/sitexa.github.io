package com.cct9k.dao.admin.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.admin.ShopTradeLogDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.ShopTradeLog;

@Repository
public class ShopTradeLogDaoImpl extends BaseDaoImpl<ShopTradeLog, String> implements
		ShopTradeLogDao {


}
