package com.cct9k.dao.admin.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.DictionaryDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.admin.DictionaryCategory;
import com.cct9k.util.common.StringUtil;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * Class Name: DictionaryDaoImpl.
 * </p>
 * <p>
 * Description: 类功能说明
 * </p>
 * <p>
 * Sample: 该类的典型使用方法和用例
 * </p>
 * <p>
 * Author: caimao
 * </p>
 * <p>
 * Date: 2013-6-18
 * </p>
 * <p>
 * Modified History: 修改记录，格式(Name) (Version) (Date) (Reason & Contents)
 * </p>
 */
@Repository
public class DictionaryDaoImpl extends BaseDaoImpl<Dictionary, String>
		implements DictionaryDao {

	@Override
	public Pagination getPage(String dictionaryname, String dictionarytypename,
			String regDate, int pageNo, int pageSize) {
		Finder f = Finder.create("from Dictionary dic where 1=1 ");
		if (!StringUtil.isEmpty(dictionaryname)) {
			f.append(" and dic.typename like '%" + dictionaryname + "%'");
		}
		if (!StringUtil.isEmpty(dictionarytypename)) {
			f.append(" and dic.category.cateid = '" + dictionarytypename + "'");
		}
		f.append(" order by to_number(dic.dictid) desc,dic.category.cateid desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public String getSeqn() {
		String sql = " select s_public.nextval from dual";
		Query query = getSession().createSQLQuery(sql);
		BigDecimal b = (BigDecimal) query.uniqueResult();
		return b.toString();
	}

	@Override
	public String save(Dictionary entity) {
		return super.save(entity);
	}

	@Override
	public Dictionary get(String id) {
		return super.get(id);
	}

	@Override
	public Dictionary get(DictionaryCategory category, String typeid) {
		return get(category.getCateid(), typeid);
	}

	@Override
	public void update(Dictionary entity) {
		super.update(entity);
	}

	@Override
	public void delete(String id) {
		super.delete(id);
	}

	@SuppressWarnings("unchecked")
	public List<Dictionary> getDictionaryByCategory(String cateid) {
		return getList(cateid);
	}

	@Override
	public void delete(Dictionary entity) {
		super.delete(entity);
	}

	public List<Dictionary> getBillType() {
		String hql = " from Dictionary d where d.category.cateid ='TransactionType'";
		
		return getSession().createQuery(hql).list();
	}

	@Override
	public Dictionary get(String cateid, String typeid) {
		String hql = " from Dictionary d where d.category.cateid=? and d.typeid=?";
		return (Dictionary) getSession().createQuery(hql).setString(0, cateid)
				.setString(1, typeid).uniqueResult();
	}

	@Override
	public List<Dictionary> getDictionaryByCategory(DictionaryCategory category) {
		return getList(category.getCateid());
	}

	@Override
	public Dictionary getByName(DictionaryCategory category, String typename) {
		String hql = "from Dictionary d where d.category.cateid=? and d.typename=? order by d.typeid asc";

		return (Dictionary) getSession().createQuery(hql)
				.setString(0, category.getCateid()).setString(1, typename)
				.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	private List<Dictionary> getList(String cateid) {
		String hql = "from Dictionary d where d.category.cateid=? order by d.typeid asc";
		return getSession().createQuery(hql).setString(0, cateid).list();
	}

}
