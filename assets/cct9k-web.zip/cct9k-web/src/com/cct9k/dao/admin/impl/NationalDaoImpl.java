package com.cct9k.dao.admin.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.admin.NationalDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.National;

@Repository
public class NationalDaoImpl extends BaseDaoImpl<National, String> implements NationalDao {

	@Override
	public National get(String id) {
		return super.get(id);
	}
	
}
