package com.cct9k.dao.admin;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.MemberExpansion;

public interface MemberExpansionDao extends BaseDao<MemberExpansion, String> {
	
}
