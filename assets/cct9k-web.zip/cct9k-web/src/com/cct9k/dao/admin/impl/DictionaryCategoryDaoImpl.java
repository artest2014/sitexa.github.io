package com.cct9k.dao.admin.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.DictionaryCategoryDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.DictionaryCategory;
import com.cct9k.util.common.StringUtil;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>Class Name: DictionaryCategoryDaoImpl.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: caimao</p>
 * <p>Date: 2013-6-18</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
@Repository
public class DictionaryCategoryDaoImpl extends BaseDaoImpl<DictionaryCategory, String> implements DictionaryCategoryDao {

    @Override
    public Pagination getPage(String dictionarycatename, String regDate, int pageNo, int pageSize) {
        Finder f = Finder.create("from DictionaryCategory dt where 1=1");
        if (!StringUtil.isEmpty(dictionarycatename)) {
            f.append(" and dt.catename like '%" + dictionarycatename + "%'");
        }
       // f.append(" order by dt.catename");
        return find(f, pageNo, pageSize);
    }

    @Override
    public String getSeqn() {
        String sql = " select s_member.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }

    @Override
    public DictionaryCategory get(String id) {
        return super.get(id);
    }

    @Override
    public String save(DictionaryCategory entity) {
        return super.save(entity);
    }

    @Override
    public void update(DictionaryCategory entity) {
        super.update(entity);
    }

    @Override
    public void delete(String id) {
        super.delete(id);
    }

    @Override
    public List<DictionaryCategory> getAll() {
        return super.getAll();
    }

    @Override
    public void delete(DictionaryCategory entity) {
        super.delete(entity);
    }
    @Override
    public Pagination search(String cateid, String catename, int pageNo, int pageSize) {
        Finder f = Finder.create("from DictionaryCategory dt where 1=1");
        if (!StringUtil.isEmpty(cateid)) {
            f.append(" and dt.cateid = '" + cateid + "'");
        }
        if (!StringUtil.isEmpty(catename)) {
            f.append(" and dt.catename like '%" + catename + "%'");
        }
        f.append(" order by cateid asc ");
        return find(f, pageNo, pageSize);
    }
}
