package com.cct9k.dao.admin.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.CommissionGroupRefLogDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.CommissionGroupRefLog;
import com.cct9k.util.common.StringUtil;

/**
 * 
* @ClassName: CommissionGroupRefLogDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-2-25 下午3:10:05
*
 */
@Repository
public class CommissionGroupRefLogDaoImpl extends BaseDaoImpl<CommissionGroupRefLog, String> implements CommissionGroupRefLogDao{

	@Override
	public Pagination getCommisionGroupRefLogs(String objectid, int pageNo,
			int pageSize) {
		Finder f = Finder.create("from CommissionGroupRefLog t where t.objectid='"+objectid+"'");
		return find(f, pageNo, pageSize);
	}

}
