package com.cct9k.dao.admin;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.DictionaryCategory;

public interface DictionaryCategoryDao
		extends
			BaseDao<DictionaryCategory, String> {
	public Pagination getPage(String dictionarycatename, String regDate,
			int pageNo, int pageSize);

	public String getSeqn();

	public Pagination search(String cateid, String catename, int pageNo,
			int pageSize);
}
