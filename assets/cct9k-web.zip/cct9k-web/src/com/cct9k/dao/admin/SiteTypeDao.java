package com.cct9k.dao.admin;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.SiteType;

public interface SiteTypeDao extends BaseDao<SiteType, String> {


}
