package com.cct9k.dao.admin.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.CommisionGroupRefDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.CommissionGroupRef;
import com.cct9k.util.common.StringUtil;

@Repository
public class CommisionGroupRefDaoImpl extends BaseDaoImpl<CommissionGroupRef, String> implements CommisionGroupRefDao{

	@Override
	public Pagination getCommisionGroupRefs(String groupname,String groupid,
			int pageNo, int pageSize) {
		Finder f = Finder.create("from CommissionGroupRef t where t.enableflag='1'");
		if(!StringUtil.isEmpty(groupname)){
			f.append(" and t.groupInfo.groupname like '%'||:groupname||'%' ");
			f.setParam("groupname", groupname);
		}
		if(!StringUtil.isEmpty(groupid)){
			f.append(" and t.groupInfo.groupid like '%'||:groupid||'%' ");
			f.setParam("groupid", groupid);
		}
		return find(f, pageNo, pageSize);
	}

	@Override
	public CommissionGroupRef getByobjectidAndObjecttypeid(String objectid,
			String objecttypeid) {
		String hql=" from CommissionGroupRef t where t.objectid='"+objectid+"' and t.objecttypeid='"+objecttypeid+"'";
		return (CommissionGroupRef) getSession().createQuery(hql).uniqueResult();
	}

	@Override
	public Pagination getAllShopByType(String objecttype, int pageNo,
			int pageSize) {
		Map<String, Object> params = new HashMap<String, Object>();
		StringBuffer sql =new StringBuffer( "SELECT V.OBJECTID, V.OBJECTNAME, M.MEMBERNAME, S.FULLNAME,");
		sql.append(" V.ADDRESS FROM V_ALL_SHOP_INFO V, T_MEMBER M,");
		sql.append(" T_SITE S WHERE V.OBJECTTYPE = '"+objecttype+"' AND V.MEMBERID = M.MEMBERID AND V.SITEID = S.SITEID");
		return findSql(sql.toString(), null, params, pageNo, pageSize);
	}

}
