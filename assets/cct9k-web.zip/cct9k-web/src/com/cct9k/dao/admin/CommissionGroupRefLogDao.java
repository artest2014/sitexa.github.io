package com.cct9k.dao.admin;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.CommissionGroupRefLog;

/**
 * 
* @ClassName: CommissionGroupRefLogDao
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-2-25 下午3:10:15
*
 */
public interface CommissionGroupRefLogDao extends BaseDao<CommissionGroupRefLog, String>{
	
	public Pagination getCommisionGroupRefLogs(String objectid,int pageNo, int pageSize);

}
