package com.cct9k.dao.admin.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.CommisionGroupInfoDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.CommissionGroupInfo;

@Repository
public class CommisionGroupInfoDaoImpl extends BaseDaoImpl<CommissionGroupInfo,String> implements CommisionGroupInfoDao{

	@Override
	public Pagination getCommisionGroupInfos(String candelete,int pageNo, int pageSize) {
		Finder f = Finder.create("from CommissionGroupInfo t where t.candelete='"+candelete+"' and t.enableflag='1'  order by t.createtime desc");
		return find(f, pageNo, pageSize);
	}

}
