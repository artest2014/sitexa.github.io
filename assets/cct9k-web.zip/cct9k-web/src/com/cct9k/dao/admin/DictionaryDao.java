package com.cct9k.dao.admin;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.admin.DictionaryCategory;

import java.util.List;

/**
 * <p>Class Name: DictionaryDao.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: caimao</p>
 * <p>Date: 2013-6-18</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
public interface DictionaryDao extends BaseDao<Dictionary, String> {

    public Pagination getPage(String dictionaryname, String dictionarytypename, String regDate, int pageNo, int pageSize);

    public String getSeqn();

    List<Dictionary> getDictionaryByCategory(String cateId);

    public List<Dictionary> getBillType();

    // added by oscar peng

    Dictionary get(String dictid);

    Dictionary get(DictionaryCategory category, String typeid);

    Dictionary get(String cateid, String typeid);

    List<Dictionary> getDictionaryByCategory(DictionaryCategory category);

    Dictionary getByName(DictionaryCategory category, String typename);
}
