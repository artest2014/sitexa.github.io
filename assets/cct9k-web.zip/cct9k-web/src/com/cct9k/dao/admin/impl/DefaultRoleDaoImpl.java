package com.cct9k.dao.admin.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.admin.DefaultRoleDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.admin.DefaultRole;
import com.cct9k.util.common.StringUtil;

@Repository
@SuppressWarnings("unchecked")
public class DefaultRoleDaoImpl extends BaseDaoImpl<DefaultRole, String>
		implements DefaultRoleDao {

	@Override
	public Pagination getPage(String roletext, String rolename, String appid,
			int pageNo, int pageSize) {
		Finder f = Finder.create("from DefaultRole dr where 1=1 ");
		if (!StringUtil.isEmpty(roletext)) {
			f.append(" and dr.roleText like '%'||:roletext||'%' ");
			f.setParam("roletext", roletext);
		}
		if (!StringUtil.isEmpty(rolename)) {
			f.append(" and dr.rolename like '%'||:rolename||'%' ");
			f.setParam("rolename", rolename);
		}
		f.append(" order by dr.roleId");
		return find(f, pageNo, pageSize);
	}
	
	@Override
	public List<DefaultRole> findDefaultRoleByAppid(String appid) {
		String hql = "from DefaultRole dr where dr.application.appid=?";
		return (List<DefaultRole>) getSession().createQuery(hql).setParameter(0, appid).list();
	}

	@Override
	public List<String> getResourceIdsByRoleId(String roleid) {
		String sql = "select resourceid from t_defaultrole_resource tr where defaultroleid=" + roleid;
        return getSession().createSQLQuery(sql).list();
	}

	@Override
	public List<DefaultRole> findDefaultRoleByAppidAndRoletype(String appid,
			String roletype) {
		String hql = "from DefaultRole dr where dr.application.appid=? and roletype=?";
		return (List<DefaultRole>) getSession().createQuery(hql).setParameter(0, appid).setParameter(1, roletype).list();
	}

	
}
