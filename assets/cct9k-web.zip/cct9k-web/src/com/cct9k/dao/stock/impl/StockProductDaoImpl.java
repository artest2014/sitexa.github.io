package com.cct9k.dao.stock.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.stock.StockProductDao;
import com.cct9k.entity.admin.Site;
import com.cct9k.entity.stock.StockProduct;
import com.cct9k.util.common.StringUtil;

@Repository
public class StockProductDaoImpl extends BaseDaoImpl<StockProduct, String> implements StockProductDao{

	@Override
	public Pagination getStockProductPage(String shopid,String productName, String seller, String typeid,
			Site site, int pageNo, int pageSize) {
		Finder f = Finder.create("from StockProduct stockProduct where  stockProduct.shopId='"+shopid+"'");
		if(!StringUtil.isEmpty(productName)){
			f.append(" and stockProduct.productName  like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if(!StringUtil.isEmpty(seller)){
			f.append(" and stockProduct.seller  like '%'||:seller||'%' ");
			f.setParam("seller", seller);
		}
		if(!StringUtil.isEmpty(typeid)){
			f.append(" and stockProduct.objecttype.typeid =:typeid ");
			f.setParam("typeid", typeid);
		}
		if(site!=null){
			f.append(" and stockProduct.site =:site ");
			f.setParam("site", site);
		}
		return find(f, pageNo, pageSize);
	}

}
