package com.cct9k.dao.stock.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.stock.StockUsedLogDao;
import com.cct9k.entity.stock.StockUsedLog;

/**
 * 
* @ClassName: StockUsedLogDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-1-14 下午8:55:51
*
 */

@Repository
public class StockUsedLogDaoImpl extends BaseDaoImpl<StockUsedLog, String> implements StockUsedLogDao{

	@Override
	public Pagination getStockUsedLogList(String stockId,int pageNo,int pageSize) {
		Finder f = Finder.create("from StockUsedLog stockUsedLog where  stockUsedLog.stock.stockId='"+stockId+"'");
		f.append(" order by stockUsedLog.consumeTime desc");
		return find(f, pageNo, pageSize);
	}

}
