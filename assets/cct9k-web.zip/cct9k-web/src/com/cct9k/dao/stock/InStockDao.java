package com.cct9k.dao.stock;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.stock.InStock;
/**
 * 
 * @author ty
 * Date 2014-1-12
 */
public interface InStockDao extends BaseDao<InStock, String>{

}
