package com.cct9k.dao.stock.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.stock.ProductStockDao;
import com.cct9k.entity.admin.Site;
import com.cct9k.entity.stock.ProductStock;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;


@Repository
public class ProductStockDaoImpl extends BaseDaoImpl<ProductStock, String> implements ProductStockDao{

	@Override
	public Pagination getProductStockpage(String shopid,String productName, String typeid,
			Site site, String statetime, String endtime, int pageNo,
			int pageSize) {
		Finder f = Finder.create("from ProductStock productStock where  productStock.stockProduct.shopId='"+shopid+"'");
		if(!StringUtil.isEmpty(productName)){
			f.append(" and productStock.stockProduct.productName  like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if(!StringUtil.isEmpty(typeid)){
			f.append(" and productStock.stockProduct.objecttype.typeid =:typeid ");
			f.setParam("typeid", typeid);
		}
		if(site!=null){
			f.append(" and productStock.stockProduct.site =:site ");
			f.setParam("site", site);
		}
		if(!StringUtil.isEmpty(statetime)){
			f.append(" and productStock.schedulesDate >=:statetime ");
			f.setParam("statetime", java.sql.Date.valueOf(statetime));
		}
		if(!StringUtil.isEmpty(endtime)){
			f.append(" and productStock.schedulesDate <=:endtime ");
			f.setParam("endtime", java.sql.Date.valueOf(endtime));
		}
		f.append(" order by productStock.schedulesDate desc,productStock.availableAmount desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination getProductStock(String shopid, String seller,
			String typeid, String siteid, Date starttime, Date endtime,
			int pageNo, int pageSize) {
		String sql = "SELECT TSP.STOCKPRODUCTID, TSP.PRODUCTNAME, TSP.SELLER, TSP.SHOPID, TPS.SCHEDULESDATE, TPS.USEDAMOUNT, TPS.AVAILABLEAMOUNT, TSP.SITEID, (SELECT FULLNAME AS SITEFULLNAME FROM T_SITE WHERE SITEID = TSP.SITEID), (SELECT UNITPRICE AS UNITPRICE FROM T_IN_STOCK WHERE INSTOCKSHEETID = TPS.INSTOCKSHEETID) FROM T_STOCK_PRODUCT TSP INNER JOIN T_PRODUCT_STOCK TPS ON TSP.STOCKPRODUCTID=TPS.STOCKPRODUCTID WHERE TPS.AVAILABLEAMOUNT>0";
        Map<String, Object> map = new HashMap<String, Object>();
        if (!StringUtil.isEmpty(seller)) {
            sql += " AND TSP.PRODUCTTYPE=:typeid";
            map.put("typeid", typeid);
        }
        if (!StringUtil.isEmpty(siteid)) {
            sql += " AND TSP.SITEID=:siteid";
            map.put("siteid", siteid);
        }
        if (!StringUtil.isEmpty(shopid)) {
            sql += " AND TSP.SHOPID=:shopid";
            map.put("shopid", shopid);
        }
		if (!StringUtil.isEmpty(seller)) {
            sql += " AND TSP.SELLER LIKE '%:seller%'";
            map.put("seller", seller);
        }
        if (starttime!=null) {
            sql += " AND TPS.SCHEDULESDATE >=to_date(:starttime, 'yyyy-MM-dd')";
            map.put("starttime", DateUtil.getDate(starttime, "yyyy-MM-dd"));
        }
        if (endtime!=null) {
            sql += " AND TPS.SCHEDULESDATE <=to_date(:endtime, 'yyyy-MM-dd')";
            map.put("endtime", DateUtil.getDate(endtime, "yyyy-MM-dd"));
        }
        return this.findSql(sql, null, map, pageNo, pageSize);
	}

}
