package com.cct9k.dao.stock;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Site;
import com.cct9k.entity.stock.StockProduct;

/**
 * 
 * @author ty
 * Date 2014-1-10
 */
public interface StockProductDao extends BaseDao<StockProduct, String>{
	
	public Pagination getStockProductPage(String shopid,String productName,String seller,String typeid,Site site,int pageNo, int pageSize);

}
