package com.cct9k.dao.stock;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.stock.StockUsedLog;

/**
 * 
* @ClassName: StockUsedLogDao
* @Description: TODO(库存使用日志)
* @author ty
* @date 2014-1-14 下午8:48:55
*
 */
public interface StockUsedLogDao  extends BaseDao<StockUsedLog, String>{
   public Pagination getStockUsedLogList(String stockId,int pageNo,int pageSize);
}
