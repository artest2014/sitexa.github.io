package com.cct9k.dao.stock.impl;


import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.stock.InStockDao;
import com.cct9k.entity.stock.InStock;

/**
 * 
 * @author ty
 * Date 2014-1-12
 */
@Repository
public class InStockDaoImpl extends BaseDaoImpl<InStock, String> implements InStockDao{

}
