package com.cct9k.dao.stock;

import java.util.Date;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Site;
import com.cct9k.entity.stock.ProductStock;

/**
 * 
 * @author ty
 * Date 2014-1-9
 */
public interface ProductStockDao extends BaseDao<ProductStock, String>{
   
	public Pagination getProductStockpage(String shopid,String productName,String typeid,Site site,String statetime,String endtime,int pageNo, int pageSize);
	
	public Pagination getProductStock(String shopid,String seller,String typeid,String siteid,Date starttime,Date endtime,int pageNo, int pageSize);
}
