package com.cct9k.dao.equipment;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.equipment.TravelTerminal;

public interface TravelTerminalDao extends BaseDao<TravelTerminal, String> {

    public Pagination getPage(String memberid,String installaddress, int pageNo, int pageSize);

	public void insertSQL(String[] sQLS);
}
