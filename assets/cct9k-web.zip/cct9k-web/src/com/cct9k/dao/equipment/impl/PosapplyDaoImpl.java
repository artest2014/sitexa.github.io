package com.cct9k.dao.equipment.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.equipment.PosapplyDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.equipment.Posapply;
import com.cct9k.util.common.StringUtil;
@Repository
public class PosapplyDaoImpl extends BaseDaoImpl<Posapply, String> implements PosapplyDao {

	@Override
	public Pagination getPage(String objectid, String associateobjectid, String applyStatu, int pageNo, int pageSize) {
		Finder f = Finder.create("from Posapply p where p.objecttypeid=:objectid and p.associateobjectid=:associateobjectid and p.objecttypecatid='objecttype'");
		if(!StringUtil.isEmpty(applyStatu)){
			f.append(" and p.status=:applyStatu");
			f.setParam("applyStatu", applyStatu);
		}
        f.setParam("objectid", objectid);
        f.setParam("associateobjectid", associateobjectid);
		return find(f, pageNo, pageSize);
	}

	@Override
	public List<Posapply> getByStatu(String objectid, String associateobjectid,Object[] applyStatu) {
		String hql = "from Posapply p where p.objecttypeid=:objectid and p.associateobjectid=:associateobjectid and p.status in(:applyStatu)";
//		String hql = "from Posapply p where p.status in(:applyStatu)";
		
//		return getSession().createQuery(hql).setParameterList("applyStatu",applyStatu).list();
		return getSession().createQuery(hql).setParameter("objectid", objectid).setParameter("associateobjectid", associateobjectid).setParameterList("applyStatu",applyStatu).list();
	}

	@Override
	public List<Object> checkIfMemberHaveTunlink(String memberid) {
		String sql = "select cardid from t_tunelink_member where memberid="+memberid;
		return getSession().createSQLQuery(sql).list();
	}

}
