package com.cct9k.dao.equipment.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.equipment.GateKeeperDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.equipment.GateKeeper;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-12
 * Time: 下午2:11
 */
@Repository
public class GateKeeperDaoImpl extends BaseDaoImpl<GateKeeper, String> implements GateKeeperDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from GateKeeper model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }

}
