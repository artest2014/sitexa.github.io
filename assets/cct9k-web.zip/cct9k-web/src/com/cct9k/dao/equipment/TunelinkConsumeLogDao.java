package com.cct9k.dao.equipment;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.equipment.TravelTerminal;
import com.cct9k.entity.equipment.Tunelink;
import com.cct9k.entity.equipment.TunelinkConsumeLog;
import com.cct9k.entity.member.Member;

public interface TunelinkConsumeLogDao extends BaseDao<TunelinkConsumeLog, String>{
	public Pagination getPage(String tradetime,String tradesquence,Tunelink tunelink,TravelTerminal terminal, int pageNo, int pageSize);
}
