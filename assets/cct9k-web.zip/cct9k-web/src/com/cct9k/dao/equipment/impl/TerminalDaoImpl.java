package com.cct9k.dao.equipment.impl;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.equipment.TerminalDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.equipment.TravelTerminal;
import com.cct9k.util.common.StringUtil;
@Repository
public class TerminalDaoImpl extends BaseDaoImpl<TravelTerminal, String> implements TerminalDao {

	@Override
	public List<TravelTerminal> getAll() {
		return super.getAll();
	}

	@Override
	public Pagination getPage(String selectname, String inputvalue,
			String regDate, int pageNo, int pageSize) {
		Finder f = Finder.create("from TravelTerminal t where 1=1 ");	
		if(!StringUtil.isEmpty(inputvalue)){
			f.append(" and t."+selectname+" like '%"+inputvalue+"%'");
		}
		f.append(" order by t.terminalid desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public void delete(String id) {
		super.delete(id);
	}

	@Override
	public TravelTerminal get(String id) {
		return super.get(id);
	}

	@Override
	public void update(TravelTerminal entity) {
		super.update(entity);
	}
	
}
