package com.cct9k.dao.equipment.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.equipment.TravelTerminalDao;
import com.cct9k.entity.equipment.TravelTerminal;
import com.cct9k.util.common.StringUtil;

import org.springframework.stereotype.Repository;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class TravelTerminalDaoImpl extends BaseDaoImpl<TravelTerminal, String> implements TravelTerminalDao {
    @Override
    public Pagination getPage(String memberid,String installaddress, int pageNo, int pageSize) {
        Finder r = Finder.create("from TravelTerminal model where 1=1");
        if (!StringUtil.isEmpty(memberid)) {
			r.append(" and model.memberid like '%" + memberid + "%'");
		}
        if (!StringUtil.isEmpty(installaddress)) {
			r.append(" and model.installaddress like '%" + installaddress + "%'");
		}
        r.append(" order by terminalid desc");

        return find(r, pageNo, pageSize);
    }
	public void insertSQL(String SQLS[]){
		for(int i=1;i<SQLS.length;i++){
			SQLS[i]=SQLS[i]+"'"+getSeqn()+"')";
			
			getSession().createSQLQuery(SQLS[i]).executeUpdate();
		}
	}
}
