package com.cct9k.dao.equipment;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.equipment.Posapply;

public interface PosapplyDao extends BaseDao<Posapply, String> {
	/**
	 * 和service中的一样
	 * @param objectid
	 * @param associateobjectid
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	Pagination getPage(String objectid, String associateobjectid, String applyStatu, int pageNo,int pageSize);

	List<Posapply> getByStatu(String objectid, String associateobjectid,Object[] applyStatu);

	List<Object> checkIfMemberHaveTunlink(String memberid);

}
