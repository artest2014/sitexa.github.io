package com.cct9k.dao.equipment.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.equipment.TunelinkConsumeLogDao;
import com.cct9k.dao.equipment.TunelinkOperLogDao;
import com.cct9k.entity.equipment.TravelTerminal;
import com.cct9k.entity.equipment.Tunelink;
import com.cct9k.entity.equipment.TunelinkConsumeLog;
import com.cct9k.entity.equipment.TunelinkOperLog;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.StringUtil;

import org.springframework.stereotype.Repository;

/**
 * @author 
 *         
 */
@Repository
public class TunelinkConsumeLogDaoImpl extends BaseDaoImpl<TunelinkConsumeLog, String> implements TunelinkConsumeLogDao {
    @Override
    public Pagination getPage(String tradetime,String tradesquence,Tunelink tunelink,TravelTerminal terminal, int pageNo, int pageSize) {
    	
    	Finder r = Finder.create("from TunelinkConsumeLog t where 1=1");
        if (!StringUtil.isEmpty(tradetime)) {
        	r.append(" and to_char(t.tradetime,'yyyy-MM-dd')='"+tradetime+"'" );
		}
        if (!StringUtil.isEmpty(tradesquence)) {
        	r.append(" and t.tradesquence='"+tradesquence+"'" );
        }
        if (tunelink!=null) {
        	r.append(" and t.tunelink.cardid='"+tunelink.getCardid()+"'");
		}
        if (terminal!=null) {
        	r.append(" and t.travelTerminal.terminalid='"+terminal.getTerminalid()+"'");
		}

        return find(r, pageNo, pageSize);
      
    }
}
