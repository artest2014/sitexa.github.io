package com.cct9k.dao.equipment.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.equipment.TunelinkOperLogDao;
import com.cct9k.entity.equipment.TravelTerminal;
import com.cct9k.entity.equipment.Tunelink;
import com.cct9k.entity.equipment.TunelinkOperLog;
import com.cct9k.util.common.StringUtil;

import org.springframework.stereotype.Repository;

/**
 * @author 
 *         
 */
@Repository
public class TunelinkOperLogDaoImpl extends BaseDaoImpl<TunelinkOperLog, String> implements TunelinkOperLogDao {
    @Override
    public Pagination getPage(String logtime,Tunelink tunelink,TravelTerminal terminal, int pageNo, int pageSize) {
    	
    	Finder r = Finder.create("from TunelinkOperLog t where 1=1");
        if (!StringUtil.isEmpty(logtime)) {
        	r.append(" and to_char(t.opertime,'yyyy-MM-dd')='"+logtime+"'" );
		}
        if (tunelink!=null) {
        	r.append(" and t.tunelink.cardid='"+tunelink.getCardid()+"'");
		}
        if (terminal!=null) {
        	r.append(" and t.travelTerminal.terminalid='"+terminal.getTerminalid()+"'");
		}

        return find(r, pageNo, pageSize);
      
    }
}
