package com.cct9k.dao.equipment;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.equipment.GateKeeper;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-12
 * Time: 下午2:11
 */
public interface GateKeeperDao extends BaseDao<GateKeeper, String> {

    public Pagination getPage(int pageNo, int pageSize);

}
