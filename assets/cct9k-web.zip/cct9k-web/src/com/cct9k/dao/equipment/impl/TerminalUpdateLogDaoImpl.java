package com.cct9k.dao.equipment.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.equipment.TerminalUpdateLogDao;
import com.cct9k.dao.equipment.TunelinkOperLogDao;
import com.cct9k.entity.equipment.TerminalUpdateLog;
import com.cct9k.entity.equipment.TravelTerminal;
import com.cct9k.entity.equipment.Tunelink;
import com.cct9k.entity.equipment.TunelinkOperLog;
import com.cct9k.util.common.StringUtil;

import org.springframework.stereotype.Repository;

/**
 * @author 
 *         
 */
@Repository
public class TerminalUpdateLogDaoImpl extends BaseDaoImpl<TerminalUpdateLog, String> implements TerminalUpdateLogDao {
    @Override
    public Pagination getPage(String updatetime,String updater,String objectid,TravelTerminal terminal, int pageNo, int pageSize) {
    	
    	Finder r = Finder.create("from TerminalUpdateLog t where 1=1");
        if (!StringUtil.isEmpty(updatetime)) {
        	r.append(" and to_char(t.updatetime,'yyyy-MM-dd')='"+updatetime+"'" );
		}
        if (!StringUtil.isEmpty(updater)) {
        	r.append(" and t.updater='"+updater+"'");
		}
        if (!StringUtil.isEmpty(objectid)) {
        	r.append(" and t.objectid='"+objectid+"'");
        }
        if (terminal!=null) {
        	r.append(" and t.terminal.terminalid='"+terminal.getTerminalid()+"'");
		}

        return find(r, pageNo, pageSize);
      
    }
}
