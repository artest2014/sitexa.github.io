package com.cct9k.dao.equipment;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.equipment.PosJet;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-12
 * Time: 下午2:11
 */
public interface PosJetDao extends BaseDao<PosJet, String> {

    public Pagination getPage(int pageNo, int pageSize);

}
