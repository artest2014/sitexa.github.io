package com.cct9k.dao.equipment;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.equipment.Tunelink;
/**
 * 
 * <p>
 * Class Name: TuneLinkDao.
 * </p>
 * <p>
 * Description: 类功能说明
 * </p>
 * <p>
 * Sample: 该类的典型使用方法和用例
 * </p>
 * <p>
 * Author: caimao
 * </p>
 * <p>
 * Date: 2013-6-25
 * </p>
 * <p>
 * Modified History: 修改记录，格式(Name) (Version) (Date) (Reason & Contents)
 * </p>
 */
public interface TunelinkDao extends BaseDao<Tunelink, String> {
	public Pagination getPage(String tunelinkno, String tunelinksate,
			String regDate, int pageNo, int pageSize);

	public void insertSQL(String SQLS[]);

	public Pagination getPagination(String tunelinkno, String tunelinksate,
			int pageNo, Integer pageSiz);

	public Tunelink findTunLink(String memberId);
	/**
	 *根据flag找出重复的身份证记录
	 * @param flag
	 * @return
	 */
	public List<String> findRepeatRecodeByFlag(String[] flags); 
	
	/**
	 * 像t_TuneLink_Member插入记录
	 * @param memberid ： 用户id
	 * @param cardtypeid ： 卡片类型id
	 * @param cardid ： 卡片id
	 * @param cateid ： 卡片cateid
	 */
	public void saveTuneLinkMember(String memberid, String cardtypeid,String cateid,String cardid);
	
	/**
	 * 更新cardid
	 * @param originalCardid:原来的cardid
	 * @param newCardid ： 新的cardid
	 */
	public void updateTuneLinkMember(String originalCardid,String newCardid);
	/**
	 * 根据cardid统计总数
	 * @param cardid ： 卡id
	 * @return
	 */
	public Object sumTotal(String cardid);  
	
	/**
	 * 根据身份证按时间降序查询所有的Tunelink
	 * @param 身份证
	 * @return
	 */
	public List<Tunelink> gettuTunelinksByIdEntiyAndOrderByTime(String identityid);
}
