package com.cct9k.dao.equipment.impl;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.equipment.TunelinkDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.commission.TunelinkMember;
import com.cct9k.entity.equipment.Tunelink;
import com.cct9k.util.common.StringUtil;
/**
 * 
 * <p>Class Name: TunelinkDaoImpl.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: caimao</p>
 * <p>Date: 2013-6-25</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
@Repository
public class TunelinkDaoImpl extends BaseDaoImpl<Tunelink, String> implements
		TunelinkDao {
	
	@Override
	public Pagination getPage(String tunelinkno, String tunelinksate,
			String regDate, int pageNo, int pageSize) {
		Finder f = Finder.create("from Tunelink t where 1=1");	
		if(!StringUtil.isEmpty(tunelinkno)){
			f.append(" and t.cardno like '%'||:tunelinkno||'%' ");
			f.setParam("tunelinkno", tunelinkno);
		}
		if(!StringUtil.isEmpty(tunelinksate)){
			f.append(" and t.cardstatus like '%'||:tunelinksate||'%' ");
			f.setParam("tunelinksate", tunelinksate);
		}
		f.append(" order by t.cardno desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public List<Tunelink> getAll() {
		return super.getAll();
	}
	
	  public void insertSQL(String SQLS[]) {
	        for (int i = 1; i < SQLS.length; i++) {
	            SQLS[i] = SQLS[i] + "'" + getSeqn() + "','membercardstatus','membercardtypes','fiscardtype')";

	            getSession().createSQLQuery(SQLS[i]).executeUpdate();
	        }
	 }
	@Override
	public Pagination getPagination(String tunelinkno, String tunelinksate,
			int pageNo, Integer pageSize) {
		Finder f = Finder.create("from Tunelink t where 1=1");	
		if(!StringUtil.isEmpty(tunelinkno)){
			f.append(" and t.cardno like '%'||:tunelinkno||'%' ");
			f.setParam("tunelinkno", tunelinkno);
		}
		if(!StringUtil.isEmpty(tunelinksate)){
			f.append(" and t.cardstatus like '%'||:tunelinksate||'%' ");
			f.setParam("tunelinksate", tunelinksate);
		}
		f.append(" order by t.cardno desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public Tunelink findTunLink(String memberId) {
		
		Finder f=Finder.create("select tl from Tunelink tl left join fetch tl.bankno,TunelinkMember tm where tm.member.memberid=:memberId and tm.cardId=tl.cardid");
		f.setParam("memberId", memberId);
		List<Tunelink> result=find(f);
		if(result!=null && result.size()!=0){
			return result.get(0);
		}else{
			return null;
		}
	}

	@Override
	public List<String> findRepeatRecodeByFlag(String[] flags) {
		String sql = "select t.identityid from t_tunelink t where t.enableflag in(:flags) group by t.identityid having count(t.identityid)>1";
		return getSession().createSQLQuery(sql).setParameterList("flags", flags).list();
	}

	@Override
	public void saveTuneLinkMember(String memberid, String cardtypeid,
			String cateid, String cardid) {
		String sql ="insert into t_tunelink_member(RELATEID,MEMBERID,CARDTYPE,CARDCATEID,CARDID) values(s_tunelink_member.nextval,"
				+ " '"+memberid+"',"
				+ " '"+cardtypeid+"',"
				+ " '"+cateid+"',"
				+ " '"+cardid+"')";
		getSession().createSQLQuery(sql).executeUpdate();
		
	}

	@Override
	public void updateTuneLinkMember(String originalCardid, String newCardid) {
		String sql ="update t_tunelink_member t set t.cardid='"+newCardid+"' where t.cardid='"+originalCardid+"'";
		getSession().createSQLQuery(sql).executeUpdate();
	}

	@Override
	public Object sumTotal(String cardid) {
		String sql ="select count(*) from t_tunelink_member t where t.cardid='"+cardid+"'";
		return getSession().createSQLQuery(sql).uniqueResult();
	}

	@Override
	public List<Tunelink> gettuTunelinksByIdEntiyAndOrderByTime(String identityid) {
		String hql = "from Tunelink  where identityid=? order by createdate desc";
		return getSession().createQuery(hql).setParameter(0, identityid).list();
	}
}
