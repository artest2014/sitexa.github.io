package com.cct9k.dao.product;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.EntertainmentProduct;

public interface EntertainmentProductDao
		extends
			BaseDao<EntertainmentProduct, String> {

	Pagination getPage(String productName, String productStatu, String deptNo,
			int pageNo, int pageSize);

	void updateProductStatusById(String id);

	void updateObjectIdByNewId(String originalId, String newId);

	public Pagination getPage(int pageNo, int pageSize);

	public List<EntertainmentProduct> getEntertainmentProductList(
			String entertainmentProductIds);

	public List getEntertainmentSaleProductList(String entertainmentId,
			String status);

	public List<Object[]> getEntertainmentSaleProductList(String objectType,
			String[] entertainmentids);
	
	public List<EntertainmentProduct> getEntertainmentProductByEntertainmentId(String EntertainmentId,String Status);
	

	public List<EntertainmentProduct> getOnSaleEntertainmentProductByEntertainmentId(String entertainmentId);

	public Pagination getListByEntertainmentProductId(String productName,
			String entertainmentId, int pageNo, int pageSize);
}
