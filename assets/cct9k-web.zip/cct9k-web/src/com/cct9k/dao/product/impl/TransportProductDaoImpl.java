package com.cct9k.dao.product.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.TransportProductDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.OrderEstimateInfo;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.ProductLabelInfo;
import com.cct9k.entity.product.TransportProduct;
import com.cct9k.entity.product.TransportProductExt;
import com.cct9k.entity.product.TransportRoutePrice;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

@Repository
public class TransportProductDaoImpl extends BaseDaoImpl<TransportProduct, String> implements TransportProductDao {

    @Override
    public Pagination getPage(String productName, String productStatu, String deptNo, int pageNo, int pageSize) {
    	if (StringUtil.isEmpty(deptNo)) {
    		return new Pagination();
    	}
    	Finder f = Finder.create("from TransportProduct tp where tp.productstatus<>13689 and tp.enableflag=1");
        if (!StringUtil.isEmpty(productName)) {
            f.append(" and tp.productname like '%'||:productName||'%' ");
            f.setParam("productName", productName);
        }
        if (!StringUtil.isEmpty(productStatu)) {
            f.append(" and tp.productstatus=" + productStatu);
        }
        f.append(" and tp.transport.transportid in(" + deptNo + ")");
        f.append(" order by to_number(tp.productid) desc");
        return find(f, pageNo, pageSize);
    }

    @Override
    public void updateProductStatusById(String id) {
        String hql = "update TransportProduct  tp set tp.productstatus=12850 where tp.productstatus=12849 and tp.transport.transportid=?";
        getSession().createQuery(hql).setParameter(0, id).executeUpdate();
    }

    @Override
    public void updateObjectIdByNewId(String originalId, String newId) {
        String hql = "update TransportProduct  tp set tp.transport.transportid=? where tp.transport.transportid=?";
        getSession().createQuery(hql).setParameter(0, newId).setParameter(1, originalId).executeUpdate();
    }

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from TransportProduct model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }

    public List<TransportProduct> getTransportProductList(String transportProductIds) {

        String hql = ("From TransportProduct sp where sp.productid in(" + transportProductIds + ")");
        List<TransportProduct> list = getListByHql(hql);
        if (list != null && list.size() > 0) {
            return list;
        } else {
            return null;
        }
    }

    @Override
    public List<Object[]> getTransportPics(String objectType, String[] transportids) {
        String str = "";
        if (transportids != null) {
            for (String s : transportids) {
                str += s + ",";
            }
            str = str.substring(0, str.length() - 1);
        }
        String sql = " select p.picUrl,p.picTitle,p.descriptions,t.productid,t.dateprice,t.productname" +
                "  from t_picture p, t_transport_product t where p.objectID=t.productid " +
                "  and p.objectType='" + objectType + "' and t.productid in (" + str + ")";
        List<Object[]> obj = getSession().createSQLQuery(sql).list();

        return obj;
    }

    /**
	 * 条件查询旅运产品信息
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
    public Pagination getTransportProductList(Map<String, Object> paraMap, int pageNo, int pageSize) {
        StringBuffer sql = new StringBuffer("select  a.productname,a.productid, b.companyname,b.transportid,a.dateprice,c.picurl,");
        sql.append("(CASE WHEN a.productStatus='12972' THEN '1002'");
		sql.append(" ELSE '1001' END) isValid");
        sql.append(" from t_transport_product a inner join t_transport b on a.transportid=b.transportid and a.productstatus='12849' and a.enableflag='1' ");
        sql.append(" inner join t_picture c on a.productid=c.objectid and c.objecttype='13849' ");
   
        if (paraMap != null) {
        	if (paraMap.get("labels") != null
					&& !"".equals(paraMap.get("labels"))) {
        		sql.append(" inner join t_obj_label_ref d on a.productid=d.objid and d.objtypecatid='36266' ");
                sql.append(" inner join t_product_label_info e on d.labelid=e.labelid");
			}
			if(paraMap.get("keyword")!=null && !"".equals(paraMap.get("keyword"))){
				sql.append(" inner join t_object_search_keyword f on a.productid=f.objectid and f.objecttypetypeid='transportProduct' ");
			}
            
            sql.append(" where 1=1");
            Set<String> paraSet = paraMap.keySet();
            Iterator<String> iter = paraSet.iterator();
            while (iter.hasNext()) {
                String key = (String) iter.next();

                if ("site".equals(key)) {
                    sql.append(" and b.siteid in(").append(paraMap.get(key)).append(")");
                }
                //else if("keyword".equals(key)){
                //sql.append(" and a.SEARCHKEYWORD like '%").append(paraMap.get(key)).append("%'");
                //}
                else if ("keyword".equals(key)) {
                    String keywordStr = (String) paraMap.get(key);
                    String[] keywordArr = keywordStr.split("\\s+");
                    sql.append(" and (");
                    for (int i = 0; i < keywordArr.length; i++) {
                        if (i == 0) {
                            sql.append("f.searchkeyword like '%" + keywordArr[i] + "%'");
                        } else {
                            sql.append(" or f.searchkeyword like '%" + keywordArr[i] + "%'");
                        }
                    }
                    sql.append(" )");
                } else if ("labels".equals(key)) {
					// sql.append(" and e.labelid in(").append(paraMap.get(key)).append(")");
					Map<String, Object> m = (Map<String, Object>) paraMap
							.get(key);
					Set<String> s = m.keySet();
					Iterator<String> it = s.iterator();
					String subSql=sql.toString();
					if(it.hasNext()){
						sql.append(" and e.labelid in (").append(m.get(it.next())).append(")");
					}					
					while (it.hasNext()) {
						sql.append("intersect ("+subSql+" and e.labelid in (")
								.append(m.get(it.next())).append("))");
					}
				} 

            }
        }

        Pagination p = findSql(sql.toString(), pageNo, pageSize);
        List<Object[]> rawList = (List<Object[]>) p.getList();
        List transProList = new ArrayList();
        TransportProductExt proExt = null;
        for (Object[] arr : rawList) {
            proExt = new TransportProductExt();
            proExt.setProductname(arr[0]!=null?(String) arr[0]:"");
            proExt.setProductid(arr[1]!=null?(String) arr[1]:"");
            proExt.setCompanyname(arr[2]!=null?(String) arr[2]:"");
            proExt.setTransportid(arr[3]!=null?(String) arr[3]:"");
            proExt.setDateprice(arr[4]!=null?(BigDecimal) arr[4]:null);
            proExt.setProfigpicurl(arr[5]!=null?(String) arr[5]:"");
            proExt.setIsValid(arr[6]!=null?(String)arr[6]:"");
            transProList.add(proExt);
        }
        p.setList(transProList);
        return p;
    }

    public TransportProductExt getTransProdByProdId(String productid) {
        StringBuffer sql = new StringBuffer("select distinct a.productname,a.productid,a.vehicletype,a.seatnum,a.passengerlimit,a.productdesc,a.carrentaldesc,");
        sql.append(" a.conditiondesc, b.companyname,b.transportid,a.dateprice,c.picurl,c.descriptions,b.detailaddress,b.telephone,b.longitude,b.latitude,b.transportdesc,b.qqno,c.objecttype ");
        sql.append(" from t_transport_product a inner join t_transport b on a.transportid=b.transportid");
        sql.append(" inner join t_picture c on a.productid=c.objectid and (c.objecttype='13850' or c.objecttype='13849') ");
        
        sql.append(" where a.productid=?");

        Query query = getSession().createSQLQuery(sql.toString());
        query.setString(0, productid);
        List<Object[]> rawlist = (List<Object[]>) query.list();
        TransportProductExt transprodext = null;
        Picture pic = null;
        List<Picture> picslist = new ArrayList();
        if (rawlist != null && rawlist.size() > 0) {
            for (Object[] arr : rawlist) {
                if (((String) arr[19]).equals("13850")) {
                    pic = new Picture();
                    pic.setPicUrl((String) arr[11]);
                    pic.setDescriptions((String) arr[12]);
                    picslist.add(pic);
                }

            }
            Object[] rawArr = null;
            int index = 0;


            for (int i = 0; i < rawlist.size(); i++) {
                if (((String) rawlist.get(i)[19]).equals("13849")) {
                    index = i;
                    break;
                }

            }
            rawArr = rawlist.get(index);
            transprodext = new TransportProductExt();
            transprodext.setProductname((String) rawArr[0]);
            transprodext.setProductid((String) rawArr[1]);
            transprodext.setVehicletype((String) rawArr[2]);
            transprodext.setSeatnum((BigDecimal) rawArr[3]);
            transprodext.setPassengerlimit((BigDecimal) rawArr[4]);
            transprodext.setProductdesc((String) rawArr[5]);
            transprodext.setCarrentaldesc((String) rawArr[6]);
            transprodext.setConditiondesc((String) rawArr[7]);
            transprodext.setCompanyname((String) rawArr[8]);
            transprodext.setTransportid((String) rawArr[9]);
            transprodext.setDateprice((BigDecimal) rawArr[10]);
            if (((String) rawArr[19]).equals("13849")) {
                transprodext.setProfigpicurl((String) rawArr[11]);
            } else transprodext.setProfigpicurl("");
            transprodext.setDetailaddress((String) rawArr[13]);
            transprodext.setTelephone((String) rawArr[14]);
            transprodext.setLongitude((BigDecimal) rawArr[15]);
            transprodext.setLatitude((BigDecimal) rawArr[16]);
            transprodext.setTransportdesc((String) rawArr[17]);
            transprodext.setQqno((String) rawArr[18]);
            transprodext.setIntropics(picslist);
		}
        
		return transprodext;
	}
	
	public List<TransportRoutePrice> getTransProdRouteListByProdId(String productid){
		StringBuffer sql=new StringBuffer("select routepriceid,routename,routeattractions,routeprice from t_transport_route_price");
		sql.append(" where productid="+productid);
		
		Query query=getSession().createSQLQuery(sql.toString());
		List<Object[]> rawlist=(List<Object[]>)query.list();
		List<TransportRoutePrice> returnList=new ArrayList();
		TransportRoutePrice route=null;
		if(rawlist!=null && rawlist.size()>0){
			for(Object[]arr:rawlist){
			  route=new TransportRoutePrice();
			  route.setRoutepriceid((String)arr[0]);
			  route.setRoutename((String)arr[1]);
			  route.setRouteattractions((String)arr[2]);
			  route.setRouteprice((BigDecimal)arr[3]);
			  returnList.add(route);
			}
		}
		
		return returnList;
	}
	
	public Pagination getTransProdListByTransportId(String transportid,int pageNo,int pageSize){
		StringBuffer sql=new StringBuffer("select a.productid,a.productname,a.dateprice,a.createdate,c.picurl ");
		sql.append(" from t_transport_product a inner join t_transport b on a.transportid=b.transportid and a.productstatus='12849' and a.enableflag='1' ");
		sql.append(" inner join t_picture c on a.productid=c.objectid and c.objecttype='13849' ");
		sql.append(" where b.transportid=?");
		
		Query query=getSession().createSQLQuery(sql.toString());
		query.setParameter(0,transportid);
		int totalCount=query.list().size();
		Pagination p=new Pagination(pageNo, pageSize, totalCount);
		if (totalCount < 1) {
			p.setList(new ArrayList());
			return p;
		}
		query.setFirstResult(p.getFirstResult());
		query.setMaxResults(p.getPageSize());
		List<Object[]> rawList=(List<Object[]>)query.list();
		List<TransportProductExt> resultList=new ArrayList();
		TransportProductExt transprod=null;
		if(rawList!=null&& rawList.size()>0){
			for(Object[]arr:rawList){
				transprod=new TransportProductExt();
				transprod.setProductid((String)arr[0]);
				transprod.setProductname((String)arr[1]);
				transprod.setDateprice((BigDecimal)arr[2]);
				Date createDate=(Date)arr[3];
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				String dateStr = sdf.format(createDate);
				transprod.setCreatedate(dateStr);
				transprod.setProfigpicurl((String)arr[4]);
				resultList.add(transprod);
			}
		}
		p.setList(resultList);
		return p;	
	}
	
	public ProductLabelInfo getTransProdLabelByProdIdAndParentId(String transProdutId,String parentLabelId){
		ProductLabelInfo result=new ProductLabelInfo();
		StringBuffer sql = new StringBuffer("select distinct e.labelname,e.labelid");
        sql.append(" from t_obj_label_ref d ");
        sql.append(" inner join t_product_label_info e on d.labelid=e.labelid and e.producttypecate='13869' ");
        sql.append(" where e.parentlabelid=" + parentLabelId);
        sql.append(" and d.objid="+transProdutId);
        Query query=getSession().createSQLQuery(sql.toString());
        List<Object[]> list=query.list();
        Object[] obj=null;
        if(list!=null && list.size()>0){
        	obj=list.get(0);
        	result.setLabelid((String)obj[1]);
        	result.setLabelname((String)obj[0]);
        }
        
		return result;
	}

	public List<TransportProduct> getTransportProductByTransportId(String transportid,String Status){
		
		String hql="from TransportProduct a where  a.transport.transportid='"+transportid+"' and a.productstatus='"+Status+"' and a.enableflag=1 ";
		Finder f = Finder.create(hql);
		return find(f);
	}

	@Override
	public Pagination getListByTransportId(String productName,
			String transportId, int pageNo, int pageSize) {
		Finder f = Finder.create("from TransportProduct tp where tp.productstatus='12849' and tp.enableflag=1");
		if (!StringUtil.isEmpty(productName)) {
			f.append(" and tp.productname like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if (!StringUtil.isEmpty(transportId)) {
			f.append(" and tp.transport.transportid=:transportId");
			f.setParam("transportId", transportId);
		}
		f.append(" order by to_number(tp.productid) desc");
		return find(f, pageNo, pageSize);
	}


	
}
