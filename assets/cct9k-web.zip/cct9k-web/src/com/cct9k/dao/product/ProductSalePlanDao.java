package com.cct9k.dao.product;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.SalePlan;

public interface ProductSalePlanDao extends BaseDao<SalePlan, String> {
	/**
	 * 描述: .根据产品的id删除所有的销售计划
	 * @param id
	 * @author:caimao
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-8-13
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 *caimao               2013-8-13            创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public void deleteAllSalePlanByProductId(String id);
	
	/**
	 * 
	 * 描述: 根据产品Id，时间 yyyy-mm-dd 查询可卖的产品数量
	 * @author    yangkun
	 * date        2013-9-11
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-9-11          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	public List<SalePlan> selectProductNum(String objtypecatid,String productid,String Time);
}
