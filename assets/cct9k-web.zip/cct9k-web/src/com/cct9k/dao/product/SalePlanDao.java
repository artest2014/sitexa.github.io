package com.cct9k.dao.product;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.SalePlan;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-9
 * Time: 下午5:34
 */
public interface SalePlanDao extends BaseDao<SalePlan, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public boolean updateSalePlanNum(int number,String productId,String objectId,String startTime,String endTime,String orderStyle,boolean flag);

    public int getSaleHotelNumByDate(String objectId,String productId,String startTime,String endTime,String orderStyle);
}
