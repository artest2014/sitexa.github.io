package com.cct9k.dao.product;
import java.util.List;
import java.util.Map;
import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.ProductLabelInfo;
import com.cct9k.entity.product.TransportProduct;
import com.cct9k.entity.product.TransportProductExt;
import com.cct9k.entity.product.TransportRoutePrice;

public interface TransportProductDao extends BaseDao<TransportProduct, String> {
	Pagination getPage(String productName, String productStatu, String detpNo,
			int pageNo, int pageSize);

	void updateProductStatusById(String id);
	
	/**
	 * 条件查询旅运产品信息
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination getTransportProductList(Map<String,Object> paraMap,int pageNo, int pageSize);
	
	public TransportProductExt getTransProdByProdId(String productid);
	
	public List<TransportRoutePrice> getTransProdRouteListByProdId(String productid);

	void updateObjectIdByNewId(String originalId, String newId);

	public Pagination getPage(int pageNo, int pageSize);

	public List<TransportProduct> getTransportProductList(
			String transportProductIds);

	public List<Object[]> getTransportPics(String objectType,
			String[] transportids);
	
	public Pagination getTransProdListByTransportId(String transportid,int pageNo,int pageSize);
	
	public ProductLabelInfo getTransProdLabelByProdIdAndParentId(String transProdutId,String parentLabelId);
	/**
	 * 
	 * 描述: 查询旅运产品 保存到 分销客户产品。
	 * @param restaurantid
	 * @param Status
	 * @return
	 */
	public List<TransportProduct> getTransportProductByTransportId(String transportid,String Status);

	public Pagination getListByTransportId(String productName, String transportId,
			int pageNo, int pageSize);
	

}
