package com.cct9k.dao.product;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.product.ShopGoods;

/**
 * @author yics 2013-08-15
 */
public interface ShopGoodsDao extends BaseDao<ShopGoods, String> {

	public Pagination getPage(String memberid,String shopid,String shopgoodsname, int pageNo, int pageSize) ;
	
	public List getshoplist(String shopid);
	
    public Pagination getPage(int pageNo, int pageSize);

	public List<Object[]> getGoodsPics(String objectType);
	
	public Pagination getPagination(Member member, String shopName,
			String shopgoodsName, int pageNo, int pageSize);
}
