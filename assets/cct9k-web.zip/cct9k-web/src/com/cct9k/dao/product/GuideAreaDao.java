package com.cct9k.dao.product;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.GuideArea;

public interface GuideAreaDao extends BaseDao<GuideArea, String> {

}
