package com.cct9k.dao.product.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.ProductLabelInfoDao;
import com.cct9k.entity.product.ProductLabelInfo;
import com.cct9k.util.common.StringUtil;

@Repository
public class ProductLabelInfoDaoImpl extends BaseDaoImpl<ProductLabelInfo, String> implements
		ProductLabelInfoDao {

	/**
	 * 初始化酒店产品标签数据
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ProductLabelInfo> initProductLabelInfo(String objecType) {
		Assert.notNull(objecType, "value is required");
		String hql = "from ProductLabelInfo as model where model.producttypecate=? and model.parentlabelid='-1' and model.belongareaid='999' order by model.labelid";
		return getSession().createQuery(hql).setParameter(0, objecType).list();
	}

	/**
	 * 根据父ID查找从属酒店产品标签数据
	 * @param parentLabelId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ProductLabelInfo> findProductLabelInfoByParent(
			String parentLabelId) {
		Assert.notNull(parentLabelId, "value is required");
		String hql = "from ProductLabelInfo as model where model.parentlabelid=? order by model.labelid";
		return getSession().createQuery(hql).setParameter(0, parentLabelId).list();
	}
	
	/**
	 * 根据对象ID查找各个模块下的标签信息
	 * @param objid 对象ID
	 * @param labelType 标签类型ID
	 * @param siteid 所属区域ID
	 * @return
	 */
	public List<ProductLabelInfo> findObjectLabelByObjId(String objid,String labelType,String siteid){
		StringBuffer sql = new StringBuffer();
		sql.append("select jj.labelname as plabelname,ldata.* from T_PRODUCT_LABEL_INFO jj");
		sql.append(" left join");
		sql.append("(");
		sql.append("select ff.*, l.labelname as parentName");
		sql.append(" from(");
		sql.append("select wmsys.wm_concat(sub.labelid) as labelid, wmsys.wm_concat(sub.labelname) as labelname,sub.parentlabelid");
		sql.append(" from(");
		sql.append("select a.labelid, a.labelname, a.parentlabelid,b.objid");
		sql.append(" from T_PRODUCT_LABEL_INFO a");
		sql.append(" inner join T_OBJ_LABEL_REF b on a.labelid = b.labelid and b.objid=?");
		sql.append(" where a.PRODUCTTYPECATE =?");
		sql.append(" order by a.parentlabelid) sub");
		sql.append(" group by sub.parentlabelid)ff");
		sql.append(" inner join T_PRODUCT_LABEL_INFO l on ff.parentlabelid = l.labelid");
		sql.append(") ldata");
		sql.append(" on jj.labelid=ldata.parentlabelid");
		sql.append(" where jj.PRODUCTTYPECATE=?");
		sql.append(" and jj.parentlabelid='-1'");
		if (!StringUtil.isEmpty(siteid)){
			sql.append(" and (jj.belongareaid='999' or jj.belongareaid=?)");
		}
		else{
			sql.append(" and (jj.belongareaid='999')");
		}
		
		Query query = this.getSession().createSQLQuery(sql.toString());
		query.setString(0, objid);
		query.setString(1, labelType);
		query.setString(2, labelType);
		if (!StringUtil.isEmpty(siteid)){
			query.setString(3, siteid);
		}
		List<Object[]> objList = query.list();
		List<ProductLabelInfo> result = new ArrayList<ProductLabelInfo>();
		ProductLabelInfo label = null;
		if (objList != null){
			for (Object[] arr : objList){
				label = new ProductLabelInfo();
				label.setLabelid(arr[1]!=null?(String)arr[1]:"");
				label.setLabelname(arr[2]!=null?(String)arr[2]:"");
				label.setParentlabelid(arr[3]!=null?(String)arr[3]:"");
				label.setParentLabelName(arr[0]!=null?(String)arr[0]:"");
				result.add(label);
			}
		}
		return result;
	}
	
	/**
	 * 查询某个酒店下对应的标签信息
	 * @param hotelid
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelByHotelId(String hotelid){
		StringBuffer buf = new StringBuffer();
		buf.append("select ff.*,l.labelname as parentName");
		buf.append(" from");
		buf.append("(");
		buf.append("select ");
		//buf.append(" wmsys.wm_concat(sub.hotelname) as hotelname,");
		buf.append(" wmsys.wm_concat(sub.labelid) as labelid,");
		buf.append(" wmsys.wm_concat(sub.labelname) as labelname,");
		buf.append(" sub.parentlabelid");
		buf.append(" from(");
		buf.append(" select c.labelid,c.labelname,c.parentlabelid");
		buf.append(" from");
		buf.append(" t_hotel a");
		buf.append(" inner join T_OBJ_LABEL_REF b on a.hotelid = b.objid");
		buf.append(" inner join T_PRODUCT_LABEL_INFO c on b.labelid = c.labelid and c.ENABLEFLAG='1'");
		buf.append(" where a.hotelid = ?");
		buf.append(" order by c.parentlabelid) sub"); 
		buf.append(" group by sub.parentlabelid) ff");
		buf.append(" inner join T_PRODUCT_LABEL_INFO l on ff.parentlabelid = l.labelid");
		Query query = this.getSession().createSQLQuery(buf.toString());
		query.setString(0, hotelid);
		List<Object[]> objList = query.list();
		List<ProductLabelInfo> result = new ArrayList<ProductLabelInfo>();
		ProductLabelInfo label = null;
		if (objList != null){
			for (Object[] arr : objList){
				label = new ProductLabelInfo();
				label.setLabelid((String)arr[0]);
				label.setLabelname((String)arr[1]);
				label.setParentlabelid((String)arr[2]);
				label.setParentLabelName((String)arr[3]);
				result.add(label);
			}
		}
		return result;
	}
	
	/**
	 * 查询某个导游对应的标签信息
	 * @param memberid
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelByGuiderId(String memberid){
		StringBuffer sql = new StringBuffer();
		sql.append("select c.labelid,c.labelname,c.parentlabelid from T_GUIDE a inner join T_OBJ_LABEL_REF b on a.memberid=b.objid");
		sql.append(" inner join T_PRODUCT_LABEL_INFO c on b.labelid=c.labelid and c.ENABLEFLAG='1'");
		sql.append(" where a.memberid=?");
		Query query = this.getSession().createSQLQuery(sql.toString());
		query.setString(0, memberid);
		List<Object[]> objList = query.list();
		List<ProductLabelInfo> result = new ArrayList<ProductLabelInfo>();
		if (objList != null){
			ProductLabelInfo label = null;
			for (Object[] arr : objList){
				label = new ProductLabelInfo();
				label.setLabelid((String)arr[0]);
				label.setLabelname((String)arr[1]);
				label.setParentlabelid((String)arr[2]);
				label.setParentLabelName((String)arr[3]);
				result.add(label);
			}	
		}
		return result;
	}
	
	/**
	 * 查询某个景点下对应的标签信息
	 * @param sceneryid
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelBySceneryId(String sceneryid){
		StringBuffer buf = new StringBuffer();
		buf.append("select ff.*,l.labelname as parentName");
		buf.append(" from");
		buf.append("(");
		buf.append("select ");
		//buf.append(" wmsys.wm_concat(sub.hotelname) as hotelname,");
		buf.append(" wmsys.wm_concat(sub.labelid) as labelid,");
		buf.append(" wmsys.wm_concat(sub.labelname) as labelname,");
		buf.append(" sub.parentlabelid");
		buf.append(" from(");
		buf.append(" select c.labelid,c.labelname,c.parentlabelid");
		buf.append(" from");
		buf.append(" t_scenery a");
		buf.append(" inner join T_OBJ_LABEL_REF b on a.sceneryid = b.objid");
		buf.append(" inner join T_PRODUCT_LABEL_INFO c on b.labelid = c.labelid and c.ENABLEFLAG='1'");
		buf.append(" where a.sceneryid = ?");
		buf.append(" order by c.parentlabelid) sub"); 
		buf.append(" group by sub.parentlabelid) ff");
		buf.append(" inner join T_PRODUCT_LABEL_INFO l on ff.parentlabelid = l.labelid");
		Query query = this.getSession().createSQLQuery(buf.toString());
		query.setString(0, sceneryid);
		@SuppressWarnings("unchecked")
		List<Object[]> objList = query.list();
		List<ProductLabelInfo> result = new ArrayList<ProductLabelInfo>();
		ProductLabelInfo label = null;
		if (objList != null){
			for (Object[] arr : objList){
				label = new ProductLabelInfo();
				label.setLabelid((String)arr[0]);
				label.setLabelname((String)arr[1]);
				label.setParentlabelid((String)arr[2]);
				label.setParentLabelName((String)arr[3]);
				result.add(label);
			}
		}
		return result;
	}
	
	/**
	 * 查询某个商场下对应的标签信息
	 * @param shopid
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelByShopId(String shopid){
		StringBuffer buf = new StringBuffer();
		buf.append("select ff.*,l.labelname as parentName");
		buf.append(" from");
		buf.append("(");
		buf.append("select ");
		//buf.append(" wmsys.wm_concat(sub.hotelname) as hotelname,");
		buf.append(" wmsys.wm_concat(sub.labelid) as labelid,");
		buf.append(" wmsys.wm_concat(sub.labelname) as labelname,");
		buf.append(" sub.parentlabelid");
		buf.append(" from(");
		buf.append(" select c.labelid,c.labelname,c.parentlabelid");
		buf.append(" from");
		buf.append(" t_shop a");
		buf.append(" inner join T_OBJ_LABEL_REF b on a.shopid = b.objid and b.objtypecatid='14829'");
		buf.append(" inner join T_PRODUCT_LABEL_INFO c on b.labelid = c.labelid and c.ENABLEFLAG='1'");
		buf.append(" where a.shopid = ?");
		buf.append(" order by c.parentlabelid) sub"); 
		buf.append(" group by sub.parentlabelid) ff");
		buf.append(" inner join T_PRODUCT_LABEL_INFO l on ff.parentlabelid = l.labelid");
		Query query = this.getSession().createSQLQuery(buf.toString());
		query.setString(0, shopid);
		@SuppressWarnings("unchecked")
		List<Object[]> objList = query.list();
		List<ProductLabelInfo> result = new ArrayList<ProductLabelInfo>();
		ProductLabelInfo label = null;
		if (objList != null){
			for (Object[] arr : objList){
				label = new ProductLabelInfo();
				label.setLabelid((String)arr[0]);
				label.setLabelname((String)arr[1]);
				label.setParentlabelid((String)arr[2]);
				label.setParentLabelName((String)arr[3]);
				result.add(label);
			}
		}
		return result;
	}
	
	@Override
	public List<ProductLabelInfo> findProductLabelByEntertainmentid(
			String entertainmentid) {
			StringBuffer buf = new StringBuffer();
			buf.append("select ff.*,l.labelname as parentName");
			buf.append(" from");
			buf.append("(");
			buf.append("select ");
			buf.append(" wmsys.wm_concat(sub.labelid) as labelid,");
			buf.append(" wmsys.wm_concat(sub.labelname) as labelname,");
			buf.append(" sub.parentlabelid");
			buf.append(" from(");
			buf.append(" select c.labelid,c.labelname,c.parentlabelid");
			buf.append(" from");
			buf.append(" t_entertainment a");
			buf.append(" inner join T_OBJ_LABEL_REF b on a.entertainmentid = b.objid");
			buf.append(" inner join T_PRODUCT_LABEL_INFO c on b.labelid = c.labelid and c.ENABLEFLAG='1'");
			buf.append(" where a.entertainmentid = ? and  c.producttypecate= 13297 ");
			buf.append(" order by c.parentlabelid) sub"); 
			buf.append(" group by sub.parentlabelid) ff");
			buf.append(" inner join T_PRODUCT_LABEL_INFO l on ff.parentlabelid = l.labelid");
			Query query = this.getSession().createSQLQuery(buf.toString());
			query.setString(0, entertainmentid);
			@SuppressWarnings("unchecked")
			List<Object[]> objList = query.list();
			List<ProductLabelInfo> result = new ArrayList<ProductLabelInfo>();
			ProductLabelInfo label = null;
			if (objList != null){
				for (Object[] arr : objList){
					label = new ProductLabelInfo();
					label.setLabelid((String)arr[0]);
					label.setLabelname((String)arr[1]);
					label.setParentlabelid((String)arr[2]);
					label.setParentLabelName((String)arr[3]);
					result.add(label);
				}
			}
			return result;
		}
	

	@SuppressWarnings("unchecked")
	@Override
	public List<ProductLabelInfo> findAllByArea(String[] area,
			String producttypecate) {
		Assert.notNull(producttypecate, "value is required");
		String areaSql = "";
		for(int i=0; i<area.length; i++){
			if(i>0) areaSql += " or ";
			areaSql += "m.belongareaid=:belongareaid"+i;
		}
		String hql = "from ProductLabelInfo as m where m.producttypecate=:producttypecate and ("+areaSql+")";
		Query query = getSession().createQuery(hql);
		query.setParameter("producttypecate", producttypecate);
		for(int i=0; i<area.length; i++){
			query.setParameter("belongareaid"+i, area[i]);
		}
		return query.list();
	}
	
	/**
	 * 查找某个餐馆下的所有标签
	 * @param restaurantId
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelByRestaurantId(String restaurantId){
		StringBuffer buf = new StringBuffer();
		buf.append("select ff.*,l.labelname as parentName");
		buf.append(" from");
		buf.append("(");
		buf.append("select ");
		//buf.append(" wmsys.wm_concat(sub.hotelname) as hotelname,");
		buf.append(" wmsys.wm_concat(sub.labelid) as labelid,");
		buf.append(" wmsys.wm_concat(sub.labelname) as labelname,");
		buf.append(" sub.parentlabelid");
		buf.append(" from(");
		buf.append(" select c.labelid,c.labelname,c.parentlabelid");
		buf.append(" from");
		buf.append(" T_RESTAURANT a");
		buf.append(" inner join T_OBJ_LABEL_REF b on a.RESTAURANTID = b.objid");
		buf.append(" inner join T_PRODUCT_LABEL_INFO c on b.labelid = c.labelid and c.ENABLEFLAG='1'");
		buf.append(" where a.RESTAURANTID = ?");
		buf.append(" order by c.parentlabelid) sub"); 
		buf.append(" group by sub.parentlabelid) ff");
		buf.append(" inner join T_PRODUCT_LABEL_INFO l on ff.parentlabelid = l.labelid");
		Query query = this.getSession().createSQLQuery(buf.toString());
		query.setString(0, restaurantId);
		List<Object[]> objList = query.list();
		List<ProductLabelInfo> result = new ArrayList<ProductLabelInfo>();
		ProductLabelInfo label = null;
		if (objList != null){
			for (Object[] arr : objList){
				label = new ProductLabelInfo();
				label.setLabelid((String)arr[0]);
				label.setLabelname((String)arr[1]);
				label.setParentlabelid((String)arr[2]);
				label.setParentLabelName((String)arr[3]);
				result.add(label);
			}
		}
		return result;
	}

	
	@Override
	public List<ProductLabelInfo> findCommonLabel(String producttypecate) {
		String hql=" from ProductLabelInfo where producttypecate=? and belongareaid='999' and enableflag=1 and parentlabelid='-1' ";
		Query query = getSession().createQuery(hql);
		query.setString(0, producttypecate);
		return query.list();
	}


	@Override
	public List<ProductLabelInfo> findAreaLabel(String producttypecate,
			String siteid) {
		
		String hql=" from ProductLabelInfo where producttypecate=? and belongareaid=? and enableflag=1  and  parentlabelid!=-1  ";
		Query query = getSession().createQuery(hql);
		query.setString(0, producttypecate);
		query.setString(1, siteid);
		return query.list();
	
	}
	
	

}
