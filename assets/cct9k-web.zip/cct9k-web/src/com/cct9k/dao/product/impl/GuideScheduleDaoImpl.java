package com.cct9k.dao.product.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.GuideScheduleDao;
import com.cct9k.entity.customer.GroupMember;
import com.cct9k.entity.customer.VipGroup;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.product.GuideSchedule;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;

@Repository
public class GuideScheduleDaoImpl extends BaseDaoImpl<GuideSchedule, String> implements
		GuideScheduleDao {

    public boolean isHaveSchedule(String guideid,String startDate,String endDate){
    	String sql = "select t.* "
					 +"   from t_guide_schedule t"
					 +"   where t.memberid = '"+guideid+"'"
					 +"   and ((t.schedulestartdate <= to_date('"+startDate+"', 'yyyy-mm-dd')"
					 +"   and t.scheduleenddate >= to_date('"+startDate+"', 'yyyy-mm-dd'))"
					 +"   or (t.schedulestartdate <= to_date('"+endDate+"', 'yyyy-MM-dd') "
					 +"   and t.scheduleenddate >= to_date('"+endDate+"', 'yyyy-MM-dd'))) "
					 +"   and t.ifhasplan = '1'";
    	Query query =  getSession().createSQLQuery(sql);
  	    List list = query.list();
  	    if(list!=null&&list.size()>0){
  	    	return true;
  	    }else{
  	    	return false;
  	    }
    }
    
    public GuideSchedule getGuideScheduleObject(String orderId){
  	    	
  	    List<GuideSchedule> list = null;
  	    GuideSchedule gs = null;
		
		if(!StringUtil.isEmpty(orderId)){
			String sql = "select t.* from t_guide_schedule t where t.relateddesc='"+orderId+"'";
			Query query = this.getSession().createSQLQuery(sql).addEntity(GuideSchedule.class);
			list = query.list();
		}
		
		if(list!=null&&list.size()>0){
			gs = list.get(0);
		}
		
		return gs;
    }
    

    public List<GuideSchedule> getGuideScheduleList(String guideId){
    	 List<GuideSchedule> list =null;
    	if(!StringUtil.isEmpty(guideId)){
    		String hql=" select g from  GuideSchedule g where g.guide.member.memberid='"+guideId+"' and g.schedulestartdate > (sysdate-1)   ";
    		list=this.getListByHql(hql);
    	}
    	return list;
    }
}
