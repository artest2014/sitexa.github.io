package com.cct9k.dao.product.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.HotelProductDao;
import com.cct9k.entity.product.HotelProduct;
import com.cct9k.util.common.StringUtil;

@Repository
public class HotelProductDaoImpl extends BaseDaoImpl<HotelProduct, String>
		implements HotelProductDao {

	@Override
	public Pagination getPage(String productName, String productStatu,
			String deptNo, int pageNo, int pageSize) {
		if (StringUtil.isEmpty(deptNo)) {
			return new Pagination();
		}
		Finder f = Finder.create("from HotelProduct hp where hp.status<>13689 and hp.enableflag=1");
		if (!StringUtil.isEmpty(productName)) {
			f.append(" and hp.productname like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if (!StringUtil.isEmpty(productStatu)) {
			f.append(" and hp.status=" + productStatu);
		}
		f.append(" and hp.hotel.hotelid in(" + deptNo + ")");
		f.append(" order by to_number(hp.productid) desc");
		return find(f, pageNo, pageSize);
	}
	

	@Override
	public String save(HotelProduct entity) {
		return super.save(entity);
	}

	@Override
	public HotelProduct get(String id) {
		return super.get(id);
	}

	@Override
	public void update(HotelProduct entity) {
		super.update(entity);
	}

	/**
	 * 根据酒店查询酒店产品
	 */
	@Override
	public List getHotelProductList(String HotelId) {
		String sql = "select ProductId,ProductName from T_HOTEL_PRODUCT where Hotelid=?  and   endtime>SYSDATE  and status=12849 and auditstatus=12871 ";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, HotelId);
		return query.list();

	}
    //1.1版本的
    public List<HotelProduct> getHotelProducEntitytList(String hotelProductIds) {

        String hql = ("From HotelProduct sp where sp.productid in("+hotelProductIds+")");
        List<HotelProduct> list = getListByHql(hql);
        if (list != null && list.size() > 0) {
            return list;
        } else {
            return null;
        }
    }


	@Override
	public void updateProductStatusById(String id) {
		String hql = "update HotelProduct  hp set hp.status=12850 where hp.status=12849 and hp.hotel.hotelid=?";
		getSession().createQuery(hql).setParameter(0, id).executeUpdate();
	}

	@Override
	public void updateObjectIdByNewId(String originalId, String newId) {
		String hql = "update HotelProduct  hp set hp.hotel.hotelid=? where hp.hotel.hotelid=?";
		getSession().createQuery(hql).setParameter(0, newId).setParameter(1, originalId).executeUpdate();
	}
	 @Override
	    public Pagination getPage(int pageNo, int pageSize) {
	        Finder r = Finder.create("from HotelProduct model where 1=1");

	        r.append(" order by createdate desc");

	        return find(r, pageNo, pageSize);
	    }
	    
	    public List getHotelSaleProductList(String hotelId,String status,String auditStatus){
			String sql="select a.productname,b.enablesalenum,b.plandate,"
	        +"         a.productid,a.starttime,a.endtime,"
	        +"        a.hotelid,"
	        +"            a.broadband,"
	        +"            a.broadbandprice,"
	        +"            a.publicprice,"
	        +"            a.memberprice,"
	        +"            a.status,"
	        +"            a.auditstatus"
	        +"      from T_HOTEL_PRODUCT a,T_SALE_PLAN b "
	        +"      where a.productid=b.objid and a.hotelid='"+hotelId+"' and b.plandate >sysdate-1 and b.enablesalenum>=1 and a.status = '"+status+"' and  a.auditstatus = '"+auditStatus+"' ";
			Query query = this.getSession().createSQLQuery(sql);
			List resultList = query.list();
			if (resultList != null && resultList.size() > 0) {
				return resultList;
			} else {
				return null;
			}
		}
	    
	    public List getHotelProductByProductId(String productId,String status,String auditStatus){
	    	String sql="select a.productname,a.hotelid,a.broadbandprice,a.memberprice,"
	    	        +"         a.productid,(case when"
	    	        +"      a.starttime<=sysdate then sysdate "
	    	        +"    else a.starttime"
	    	        +"    end) as starttime,a.endtime"
	    	        +"      from T_HOTEL_PRODUCT a "
	    	        +"      where a.productid='"+productId+"'  and a.status = '"+status+"' and  a.auditstatus = '"+auditStatus+"' ";
	    			Query query = this.getSession().createSQLQuery(sql);
	    			List resultList = query.list();
	    			if (resultList != null && resultList.size() > 0) {
	    				return resultList;
	    			} else {
	    				return null;
	    			}
	    }

		@Override
		public List<Object[]> getHotelPics(String objectType, String[] hotelids) {
			String str="";
			if(hotelids!=null){
			for (String s : hotelids) {
				str+=s+",";
			}
			str=str.substring(0,str.length()-1);
			}
			String sql=" select p.picUrl,p.picTitle,p.descriptions,h.productid,h.publicprice,h.productname " +
					"  from t_picture p, t_hotel_product h where p.objectID=h.productid " +
					"  and p.objectType='"+objectType+"' and h.productid in ("+str+")";
		      List<Object[]> obj =	getSession().createSQLQuery(sql).list();
			
			return obj;
			
			
		}


		public List<HotelProduct> getHotelProductByHotelId(String hotelid,String Status){
			
			String hql="from HotelProduct a where  a.hotel.hotelid="+hotelid+" and a.status="+Status+" and a.enableflag=1 and a.endtime >(SYSDATE-1)";
			Finder f = Finder.create(hql);
			return find(f);
		}

         
		@Override
		public Pagination getListByHotelId(String productName, String hotelId, int pageNo, int pageSize) {
			Finder f = Finder.create("from HotelProduct hp where hp.status='12849' and hp.enableflag=1");
			if (!StringUtil.isEmpty(productName)) {
				f.append(" and hp.productname like '%'||:productName||'%' ");
				f.setParam("productName", productName);
			}
			if (!StringUtil.isEmpty(hotelId)) {
				f.append(" and hp.hotel.hotelid=:hotelId");
				f.setParam("hotelId", hotelId);
			}
			f.append(" order by to_number(hp.productid) desc");
			return find(f, pageNo, pageSize);
		}
		
}
