package com.cct9k.dao.product;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.TransportRoutePrice;

public interface TransportRoutePriceDao extends
		BaseDao<TransportRoutePrice, String> {

}
