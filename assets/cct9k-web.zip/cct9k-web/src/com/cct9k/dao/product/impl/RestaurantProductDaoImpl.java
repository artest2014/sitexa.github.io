package com.cct9k.dao.product.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.RestaurantProductDao;
import com.cct9k.entity.product.RestaurantProduct;
import com.cct9k.util.common.StringUtil;
/**
 * <p>Class Name: RestaurantProductDaoImpl.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: caimao</p>
 * <p>Date: 2013-8-16</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
@Repository
public class RestaurantProductDaoImpl extends
		BaseDaoImpl<RestaurantProduct, String> implements RestaurantProductDao {

	@Override
	public Pagination getPage(String productName, String productStatu, String deptNo,
			int pageNo, int pageSize) {
		if(StringUtil.isEmpty(deptNo)){
			return new Pagination();		
		}
		Finder f = Finder.create("from RestaurantProduct rp where rp.enableflag=1");	
		if(!StringUtil.isEmpty(productName)){
			f.append(" and rp.restauproductname like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if(!StringUtil.isEmpty(productStatu)){
			f.append(" and productstatuscatid="+productStatu);
		}
		f.append(" and rp.restaurantid in("+deptNo+")");
		f.append(" order by to_number(rp.restaurantproductid) desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public void updateProductStatusById(String id) {
		String hql = "update RestaurantProduct  rp set rp.productstatuscatid=12850 where rp.productstatuscatid=12849 and rp.restaurantid=?";
		getSession().createQuery(hql).setParameter(0, id).executeUpdate();
	}

	@Override
	public void updateObjectIdByNewId(String originalId, String newId) {
		String hql = "update RestaurantProduct  rp set rp.restaurantid=? where rp.restaurantid=?";
		getSession().createQuery(hql).setParameter(0, newId).setParameter(1, originalId).executeUpdate();
	}
	 @Override
	    public Pagination getPage(int pageNo, int pageSize) {
	        Finder r = Finder.create("from RestaurantProduct model where 1=1");

	        r.append(" order by createdate desc");

	        return find(r, pageNo, pageSize);
	    }
	    
	    public List<RestaurantProduct> getRestaurantProductList(String restaurantProductIds) {

	        String hql = ("From RestaurantProduct sp where sp.restaurantproductid in("+restaurantProductIds+")");
	        List<RestaurantProduct> list = getListByHql(hql);
	        if (list != null && list.size() > 0) {
	            return list;
	        } else {
	            return null;
	        }
	    }
	    
	    public List getRestaurantSaleProductList(String restaurantId, String status) {
			String sql = "select a.restauproductname,b.enablesalenum,b.plandate,"
					+ "  a.restaurantproductid,a.productstarttime,a.productendtime,"
					+ "  a.restaurantid ,"
					+ "   a.memberprice"
					+ "  from t_restaurant_product a,T_SALE_PLAN b"
					+ "  where a.restaurantproductid=b.objid and a.restaurantid='"
					+ restaurantId
					+ "' and b.plandate >sysdate-1 and b.enablesalenum>=1 and a.productstatuscatid = '"
					+ status + "'";
			Query query = this.getSession().createSQLQuery(sql);
			List resultList = query.list();
			if (resultList != null && resultList.size() > 0) {
				return resultList;
			} else {
				return null;
			}
		}

		@Override
		public List<Object[]> getIndexPics(String objectType, String[] restaurantids) {
			String str="";
			if(restaurantids!=null){
			for (String s : restaurantids) {
				str+=s+",";
			}
			str=str.substring(0,str.length()-1);
			}
			
			String sql=" select p.picUrl,p.picTitle,p.descriptions ,r.restaurantproductid,r.marketprice , r.restauproductname" +
					"  from t_picture p, t_restaurant_product r where p.objectID=r.restaurantproductid " +
					"  and p.objectType='"+objectType+"' and r.restaurantproductid in ("+str+")";
		      List<Object[]> obj =	getSession().createSQLQuery(sql).list();
			return obj;
		}

		public List<RestaurantProduct> getRestaurantProductByRestaurantId(String restaurantid,String Status){
			String hql="from RestaurantProduct a where  a.restaurantid="+restaurantid+" and a.productstatuscatid="+Status+" and a.enableflag=1 and a.productendtime >(SYSDATE-1)";
			Finder f = Finder.create(hql);
			return find(f);
		}

		@Override
		public Pagination getListByRestaurantId(String productName,
				String restaurantId, int pageNo, int pageSize) {
			Finder f = Finder.create("from RestaurantProduct tp where tp.productstatuscatid='12849'  and tp.enableflag=1");
			if (!StringUtil.isEmpty(productName)) {
				f.append(" and tp.restauproductname like '%'||:productName||'%' ");
				f.setParam("productName", productName);
			}
			if (!StringUtil.isEmpty(restaurantId)) {
				f.append(" and tp.restaurantid=:restaurantId");
				f.setParam("restaurantId", restaurantId);
			}
			f.append(" order by to_number(tp.restaurantproductid) desc");
			return find(f, pageNo, pageSize);
		}

}
