package com.cct9k.dao.product.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.EntertainmentProductDao;
import com.cct9k.entity.product.EntertainmentProduct;
import com.cct9k.util.common.StringUtil;
@Repository
public class EntertainmentProductDaoImpl extends
		BaseDaoImpl<EntertainmentProduct, String> implements
		EntertainmentProductDao {

	@Override
	public Pagination getPage(String productName, String productStatu, String deptNo, int pageNo,
			int pageSize) {
		if(StringUtil.isEmpty(deptNo)){
			return new Pagination();		
		}
		Finder f = Finder.create("from EntertainmentProduct ep where ep.productstatuscatid<>13689 and ep.enableflag=1");	
		if(!StringUtil.isEmpty(productName)){
			f.append(" and ep.productname like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if(!StringUtil.isEmpty(productStatu)){
			f.append(" and ep.productstatuscatid="+productStatu);
		}
		f.append(" and ep.entertainment.entertainmentid in("+deptNo+")");
		f.append(" order by to_number(ep.productid) desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public void updateProductStatusById(String id) {
		String hql = "update EntertainmentProduct  ep set ep.productstatuscatid=12850 where ep.productstatuscatid=12849 and ep.entertainment.entertainmentid=?";
		getSession().createQuery(hql).setParameter(0, id).executeUpdate();
	}

	@Override
	public void updateObjectIdByNewId(String originalId, String newId) {
		String hql = "update EntertainmentProduct  ep set ep.entertainment.entertainmentid=? where ep.entertainment.entertainmentid=?";
		getSession().createQuery(hql).setParameter(0, newId).setParameter(1, originalId).executeUpdate();
	}
	 @Override
	    public Pagination getPage(int pageNo, int pageSize) {
	        Finder r = Finder.create("from EntertainmentProduct model where 1=1");

	        r.append(" order by createdate desc");

	        return find(r, pageNo, pageSize);
	    }
	    
	    public List<EntertainmentProduct> getEntertainmentProductList(String entertainmentProductIds) {

	        String hql = ("From EntertainmentProduct sp where sp.productid in("+entertainmentProductIds+")");
	        List<EntertainmentProduct> list = getListByHql(hql);
	        if (list != null && list.size() > 0) {
	            return list;
	        } else {
	            return null;
	        }
	    }
	    
	    
	    public List getEntertainmentSaleProductList(String entertainmentId, String status) {
			String sql = "select a.productname,b.enablesalenum,b.plandate,"
					+ "  a.productid,a.productstarttime,a.productendtime,"
					+ "  a.enterainmentid ,"
					+ "   a.memberprice"
					+ "  from t_entertainment_product a,T_SALE_PLAN b"
					+ "  where a.productid=b.objid and a.enterainmentid='"
					+ entertainmentId
					+ "' and b.plandate >sysdate-1 and b.enablesalenum>=1 and a.productstatuscatid = '"
					+ status + "'";
			Query query = this.getSession().createSQLQuery(sql);
			List resultList = query.list();
			if (resultList != null && resultList.size() > 0) {
				return resultList;
			} else {
				return null;
			}
		}

		@Override
		public List<Object[]> getEntertainmentSaleProductList(String objectType,
				String[] entertainmentids) {
			String str="";
			if(entertainmentids!=null){
			for (String s : entertainmentids) {
				str+=s+",";
			}
			str=str.substring(0,str.length()-1);
			}
			String sql=" select p.picUrl,p.picTitle,p.descriptions,e.productid,e.marketprice ,e.productname" +
					"  from t_picture p, t_entertainment_product e where p.objectID=e.productid " +
					"  and p.objectType='"+objectType+"' and e.productid in ("+str+")";
		      List<Object[]> obj =	getSession().createSQLQuery(sql).list();
			
			return obj;
		}
		
	 public List<EntertainmentProduct> getEntertainmentProductByEntertainmentId(String EntertainmentId,String Status){
			String hql="from EntertainmentProduct a where  a.entertainment.entertainmentid='"+EntertainmentId+"' and a.productstatuscatid='"+Status+"' and a.enableflag=1 and a.productendtime >(SYSDATE-1)";
			Finder f = Finder.create(hql);
			return find(f);
		}

	 @Override
		public List<EntertainmentProduct> getOnSaleEntertainmentProductByEntertainmentId(
				String entertainmentId) {
			// TODO Auto-generated method stub
			
			StringBuilder sb = new StringBuilder("from EntertainmentProduct model where model.productstatuscatid='12849' and model.enableflag='1' and model.entertainment.entertainmentid="+entertainmentId);
			Query query = getSession().createQuery(sb.toString());
			List li = query.list();
			return li;
		}

	@Override
	public Pagination getListByEntertainmentProductId(String productName,
			String entertainmentId, int pageNo, int pageSize) {
		Finder f = Finder.create("from EntertainmentProduct ep where ep.productstatuscatid=12849 and ep.enableflag=1");	
		if(!StringUtil.isEmpty(productName)){
			f.append(" and ep.productname like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if(!StringUtil.isEmpty(entertainmentId)){
			f.append(" and ep.entertainment.entertainmentid="+entertainmentId);
		}
		f.append(" order by to_number(ep.productid) desc");
		return find(f, pageNo, pageSize);
	}
}
