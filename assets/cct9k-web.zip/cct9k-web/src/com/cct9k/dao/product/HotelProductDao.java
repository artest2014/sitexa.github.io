package com.cct9k.dao.product;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.HotelProduct;

public interface HotelProductDao extends BaseDao<HotelProduct, String> {

	Pagination getPage(String productName, String productStatu, String deptNo,
			int pageNo, int pageSize);

	public List getHotelProductList(String HotelId);

	void updateProductStatusById(String id);

	void updateObjectIdByNewId(String originalId, String newId);

	public Pagination getPage(int pageNo, int pageSize);

	public List getHotelSaleProductList(String hotelId, String status,
			String auditStatus);

	public List getHotelProductByProductId(String productId, String status,
			String auditStatus);

	public List<Object[]> getHotelPics(String objectType, String[] hotelids);
	
	public List<HotelProduct> getHotelProducEntitytList(String hotelProductIds);
	/**
	 * 
	 * 描述:从直销查询产品插入到分销客户产品里面 
	 * @param hotelid
	 * @param Status
	 */
	public List<HotelProduct> getHotelProductByHotelId(String hotelid,String Status);

	public Pagination getListByHotelId(String productName,String hotelId, int cpn, int pageSize);

}
