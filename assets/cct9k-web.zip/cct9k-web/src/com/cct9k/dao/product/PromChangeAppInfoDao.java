package com.cct9k.dao.product;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.PromChangeAppInfo;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午12:53
 */
public interface PromChangeAppInfoDao extends BaseDao<PromChangeAppInfo, String> {

    public Pagination getPage(int pageNo, int pageSize);

}
