package com.cct9k.dao.product.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.ProductAppInfoDao;
import com.cct9k.entity.product.ProductAppInfo;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-9
 * Time: 下午5:31
 */
@Repository
public class ProductAppInfoDaoImpl extends BaseDaoImpl<ProductAppInfo, String> implements ProductAppInfoDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from ProductAppInfo model where 1=1");

        r.append(" order by apptime desc");

        return find(r, pageNo, pageSize);
    }

}
