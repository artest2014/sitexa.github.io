package com.cct9k.dao.product;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.SceneryProduct;

public interface SceneryProductDao extends BaseDao<SceneryProduct, String> {
	Pagination getPage(String productName, String productStatu, String deptNo,
			int pageNo, int pageSize);

	public Pagination getSceneryProductList(Map<String, Object> paraMap,
			int pageNo, int pageSize);

	void updateProductStatusById(String id);

	public List<Picture> findFigPicListBySceneProId(String sceneryProId);

	public List<Picture> findIntroPicListBySceneProId(String sceneryProId);

	void updateObjectIdByNewId(String originalId, String newId);
	
	public Pagination getPage(int pageNo, int pageSize);

	public List<SceneryProduct> searchByName(String productname);

	public List<SceneryProduct> getSceneryProductList(String sceneryProductIds);

	public List getScenerySaleProductList(String sceneryId, String status);

	public List<Object[]> getSceneryPics(String objectType, String[] sceneryids);

	public Object[] getSceneryPic(String objectType, String sceneryid);
	
	public List<SceneryProduct> getSceneryProductBySceneryId(String sceneryid,String Status);

	public Pagination getListBySceneryId(String productName, String sceneryId,
			int pageNo, int pageSize);
}
