package com.cct9k.dao.product;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.ProductLabelInfo;

public interface ProductLabelInfoDao extends BaseDao<ProductLabelInfo,String>{
	
	/**
	 * 初始化酒店产品标签数据
	 * @return
	 */
	public List<ProductLabelInfo> initProductLabelInfo(String objecType);
	
	
	/**
	 * 根据父ID查找从属酒店产品标签数据
	 * @param parentLabelId
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelInfoByParent(String parentLabelId);
	
	/**
	 * 
	 * @param shopid
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelByShopId(String shopid);
	
	/**
	 * 根据对象ID查找各个模块下的标签信息
	 * @param objid 对象ID
	 * @param labelType 标签类型ID
	 * @param siteid 所属区域ID
	 * @return
	 */
	public List<ProductLabelInfo> findObjectLabelByObjId(String objid,String labelType,String siteid);
	
	/**
	 * 查询某个酒店下对应的标签信息
	 * @param hotelid
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelByHotelId(String hotelid);
	
	/**
	 * 查询某个导游对应的标签信息
	 * @param memberid
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelByGuiderId(String memberid);
	
	/**
	 * 查询某个景点下对应的标签信息
	 * @param sceneryid
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelBySceneryId(String sceneryid);
	
	
	
	/**
	 * 根据区域查找标签
	 * @param area 区域，可以是多个区域，
	 * @param producttypecate 标签类型
	 **/
	List<ProductLabelInfo> findAllByArea(String [] area, String producttypecate);
	
	/**
	 * 查找某个餐馆下的所有标签
	 * @param restaurantId
	 * @return
	 */
	public List<ProductLabelInfo> findProductLabelByRestaurantId(String restaurantId);
	
	public List<ProductLabelInfo> findProductLabelByEntertainmentid(String entertainmentid);
	
	/**
	 * 
	 * 描述: 查询公用的父标签列表，不包含地区标签
	 * @param producttypecate
	 * @return
	 * @author    yangkun
	 */
	public List<ProductLabelInfo> findCommonLabel(String producttypecate);
	
	/**
	 * 
	 * 描述: 查询子地区标签列表
	 * @param producttypecate
	 * @return
	 * @author    yangkun

	 */
	public List<ProductLabelInfo> findAreaLabel(String producttypecate,String Areaid);
}
