package com.cct9k.dao.product.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.ProductSalePlanDao;
import com.cct9k.entity.product.SalePlan;

@Repository
public class ProductSalePlanDaoImpl extends BaseDaoImpl<SalePlan, String>
		implements ProductSalePlanDao {

	@Override
	public void deleteAllSalePlanByProductId(String id) {
		String sql = "delete from t_sale_plan where objid="+id;
		getSession().createSQLQuery(sql).executeUpdate();
	}


	@Override
	public List<SalePlan> selectProductNum(String objtypecatid,
			String productid, String Time) {
		String hql=" from SalePlan where objid=? and objtypecatid=? and "
				+ "  plandate=to_date('" + Time + "','yyyy-mm-dd')";
		Query query = getSession().createQuery(hql);
		query.setString(0, productid);
		query.setString(1, objtypecatid);
		return query.list();
	}


	

}
