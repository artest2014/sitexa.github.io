package com.cct9k.dao.product.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.GuideProductDao;
import com.cct9k.entity.main.Guide;
import com.cct9k.entity.product.GuideProduct;
import com.cct9k.util.common.StringUtil;

@Repository
public class GuideProductDaoImpl extends BaseDaoImpl<GuideProduct, String>
		implements
			GuideProductDao {

	@Override
	public Pagination getPage(String productName, String productStatu,
			int pageNo, int pageSize, String memberid) {
		Finder f = Finder.create("from GuideProduct gp where gp.enableflag=1 and gp.guide.memberid="+memberid);
		if (!StringUtil.isEmpty(productName)) {
			f.append(" and gp.serviceproductname like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if (!StringUtil.isEmpty(productStatu)) {
			f.append(" and gp.productstatuscatid=" + productStatu);
		}
		f.append(" order by to_number(gp.serviceid) desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public void updateProductStatusById(String id) {
		String hql = "update GuideProduct  gp set gp.productstatuscatid=12850 where gp.productstatuscatid=12849 and gp.guide.memberid=?";
		getSession().createQuery(hql).setParameter(0, id).executeUpdate();
	}

	@Override
	public void updateObjectIdByNewId(String originalId, String newId) {
		String hql = "update GuideProduct  gp set gp.memberid=? where gp.memberid=?";
		getSession().createQuery(hql).setParameter(0, newId)
				.setParameter(1, originalId).executeUpdate();
	}

	public List<GuideProduct> getGuideProductList(String guideProductIds) {

		String hql = ("From GuideProduct sp where sp.serviceid in("
				+ guideProductIds + ")");
		List<GuideProduct> list = getListByHql(hql);
		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<GuideProduct> findOnsaleGuideProductByGuideId(Guide guide){
		String hql="From GuideProduct gp where gp.guide=? and gp.productstatuscatid=? and gp.enableflag='1' ";
		List<GuideProduct> list=null;
		list=getSession().createQuery(hql).setParameter(0, guide).setParameter(1,"12849").list();
	    return list;
	}
}
