package com.cct9k.dao.product;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.product.RestaurantProduct;

public interface RestaurantProductDao
		extends
			BaseDao<RestaurantProduct, String> {
	Pagination getPage(String productName, String productStatu, String deptNo,
			int pageNo, int pageSize);
	void updateProductStatusById(String id);
	void updateObjectIdByNewId(String originalId, String newId);
	public Pagination getPage(int pageNo, int pageSize);

	public List<RestaurantProduct> getRestaurantProductList(
			String restaurantProductIds);

	public List getRestaurantSaleProductList(String restaurantId, String status);

	public List<Object[]> getIndexPics(String obhectType, String[] restaurantids);
	
	/**
	 * 
	 * 描述: 查询餐饮产品 保存到 分销客户产品。
	 * @param restaurantid
	 * @param Status
	 * @return
	 */
	public List<RestaurantProduct> getRestaurantProductByRestaurantId(String restaurantid,String Status);
	public Pagination getListByRestaurantId(String productName, String restaurantId,
			int pageNo, int pageSize);
}
