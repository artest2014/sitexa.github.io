package com.cct9k.dao.product.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.GuideAreaDao;
import com.cct9k.entity.product.GuideArea;

@Repository
public class GuideAreaDaoImpl extends BaseDaoImpl<GuideArea, String> implements
		GuideAreaDao {

}
