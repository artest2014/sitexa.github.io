package com.cct9k.dao.product;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Guide;
import com.cct9k.entity.product.GuideProduct;

public interface GuideProductDao extends BaseDao<GuideProduct, String> {

	Pagination getPage(String productName, String productStatu, int pageNo,
			int pageSize, String memberid);

	void updateProductStatusById(String id);

	void updateObjectIdByNewId(String originalId, String newId);
	
	public List<GuideProduct> getGuideProductList(String guideProductIds);

	public List<GuideProduct> findOnsaleGuideProductByGuideId(Guide guide);
}
