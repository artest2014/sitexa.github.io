package com.cct9k.dao.product.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.ShopGoodsDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.product.ShopGoods;
import com.cct9k.util.common.StringUtil;

/**
 * @author yics 2013-08-15
 */
@Repository
public class ShopGoodsDaoImpl extends BaseDaoImpl<ShopGoods, String> implements
		ShopGoodsDao {

	@Override
	public Pagination getPage(String memberid,String shopid, String shopgoodsname, int pageNo,
			int pageSize) {

		String sql = "select ";
		sql += " g.*,s.shopname,td.typename,m.membername,s.shopstatuscatid from t_shop s,t_shop_goods g ";
		sql += " left join t_dictionary td on g.goodsinventorycatid =td.dictid ";
		sql += " left join t_member m on g.creator =m.memberid ";
		sql += "where s.shopid =g.shopid ";
		sql +=" and s.creator ='"+memberid+"'";
		if (!StringUtil.isEmpty(shopgoodsname)) {
			sql += " and g.shopgoodsname like '%" + shopgoodsname + "%'";
		}

		if (!StringUtil.isEmpty(shopid)) {
			sql += " and g.shopid = '" + shopid + "'";
		}

		sql += " order by g.createdate desc ";

		return this.findSql(sql, pageNo, pageSize);
	}

	public List getshoplist(String shopid) {
		String sql = "select shopgoodsid, ";
		sql += " shopid, ";
		sql += "shopgoodsname,";
		sql += "pricedesc, ";
		sql += "goodsstatuscatid,";
		sql += "goodsinventorycatid,";
		sql += "shopgoodsdesc, ";
		sql += "creator, ";
		sql += "createdate,";
		sql += "updater, ";
		sql += "updatedate,";
		sql += "enableflag,";
		sql += "pic.picurl,";
		sql += "pic.abbrurl,";
		sql += "pic.descriptions ";
		sql += "from t_shop_goods good ";
		sql += "left join t_picture pic on good.shopgoodsid =pic.objectid";
		sql += " where good.shopid='" + shopid + "'";
		return getSession().createSQLQuery(sql).list();
	}
	
	@Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from ShopGoods model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }

	@Override
	public List<Object[]> getGoodsPics(String objectType) {
		 String sql = " select p.picUrl,p.picTitle,p.descriptions,s.shopid,s.shopgoodsname" +
	                "  from t_picture p, T_SHOP_GOODS s where p.objectID=s.shopgoodsid " +
	                "  and p.objectType='" + objectType + "' and s.iftop='1' and  rownum<=12 ";
	        List<Object[]> obj = getSession().createSQLQuery(sql).list();

	        return obj;
	}
	
	@Override
    public Pagination getPagination(Member member, String shopName, String shopgoodsName, int pageNo, int pageSize) {
        Finder f = Finder.create("from ShopGoods  s where 1=1");
        if (member != null) {
            f.append(" and s.shop.member.memberid=:memberid ");
            f.setParam("memberid", member.getMemberid());
        }

        if (!StringUtil.isEmpty(shopName)) {
            f.append(" and s.shopid= '"+shopName+"' ");
        }

        if (!StringUtil.isEmpty(shopgoodsName)) {
            f.append(" and s.shopgoodsname like '%'||:shopgoodsName||'%' ");
            f.setParam("shopgoodsName", shopgoodsName);
        }

        f.append(" order by s.iftop asc");

        return find(f, pageNo, pageSize);
    }
}
