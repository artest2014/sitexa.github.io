package com.cct9k.dao.product.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.CarSharingInfoDao;
import com.cct9k.entity.main.CarSharingInfo;

import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-9
 * Time: 下午5:08
 */
@Repository
public class CarSharingInfoDaoImpl extends BaseDaoImpl<CarSharingInfo, String> implements CarSharingInfoDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from CarSharingInfo model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }

}
