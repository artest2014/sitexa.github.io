package com.cct9k.dao.product;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.CashCouponInfo;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-9
 * Time: 下午5:09
 */
public interface CashCouponInfoDao extends BaseDao<CashCouponInfo, String> {

    public Pagination getPage(int pageNo, int pageSize);

}
