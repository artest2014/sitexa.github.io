package com.cct9k.dao.product.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.SceneryProductDao;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.SceneryProduct;
import com.cct9k.util.common.StringUtil;

@Repository
public class SceneryProductDaoImpl extends BaseDaoImpl<SceneryProduct, String> implements
		SceneryProductDao {

	@Override
	public Pagination getPage(String productName, String productStatu, String deptNo,
			int pageNo, int pageSize) {
		if(StringUtil.isEmpty(deptNo)){
			return new Pagination();		
		}
		Finder f = Finder.create("from SceneryProduct sp where sp.productstatuscatid<>13689 and sp.enableflag=1");
		if(!StringUtil.isEmpty(productName)){
			f.append(" and sp.productname like '%'||:productName||'%' ");
			f.setParam("productName", productName);
		}
		if(!StringUtil.isEmpty(productStatu)){
			f.append(" and sp.productstatuscatid="+productStatu);
		}
		f.append(" and sp.scenery.sceneryid in("+deptNo+")");
		f.append(" order by to_number(sp.productid) desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination getSceneryProductList(Map<String, Object> paraMap,
			int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateProductStatusById(String id) {
		String hql = "update SceneryProduct  sp set sp.productstatuscatid=12850 where sp.productstatuscatid=12849 and sp.scenery.sceneryid=?";
		getSession().createQuery(hql).setParameter(0, id).executeUpdate();
		
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<Picture> findFigPicListBySceneProId(String sceneryProId){
		String hql="from Picture a where a.objectID=? and a.objectType=?";
		Query query=this.getSession().createQuery(hql);
		query.setString(0, sceneryProId);
		query.setString(1, Picture.SCENERYPRO_FIGURE_PIC);
		return query.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<Picture> findIntroPicListBySceneProId(String sceneryProId){
		String hql="from Picture a where a.objectID=? and a.objectType=?";
		Query query=this.getSession().createQuery(hql);
		query.setString(0, sceneryProId);
		query.setString(1, Picture.SCENERYPRO_INTRO_PIC);
		return query.list();
	}

	@Override
	public void updateObjectIdByNewId(String originalId, String newId) {
		String hql = "update SceneryProduct  sp set sp.scenery.sceneryid=? where sp.scenery.sceneryid=?";
		getSession().createQuery(hql).setParameter(0, newId).setParameter(1, originalId).executeUpdate();
	}
	
	
	@Override
	public Pagination getPage(int pageNo, int pageSize) {
		Finder r = Finder.create("from SceneryProduct model where 1=1");

		r.append(" order by createdate desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public List<SceneryProduct> searchByName(String productname) {
		String hql = "from SceneryProduct model where productname like :productname||'%' order by productname asc ";
		return getSession().createQuery(hql)
				.setParameter("productname", productname).list();
	}

	public List<SceneryProduct> getSceneryProductList(String sceneryProductIds) {

		String hql = ("From SceneryProduct sp where sp.productid in("
				+ sceneryProductIds + ")");
		List<SceneryProduct> list = getListByHql(hql);
		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	public List getScenerySaleProductList(String sceneryId, String status) {
		String sql = "select a.productname,b.enablesalenum,b.plandate,"
				+ "  a.productid,a.productstarttime,a.productendtime,"
				+ "  a.sceneryid ,"
				+ "   a.memberprice"
				+ "  from t_scenery_product a,T_SALE_PLAN b"
				+ "  where a.productid=b.objid and a.sceneryid='"
				+ sceneryId
				+ "' and b.plandate >sysdate-1 and b.enablesalenum>=1 and a.productstatuscatid = '"
				+ status + "'";
		Query query = this.getSession().createSQLQuery(sql);
		List resultList = query.list();
		if (resultList != null && resultList.size() > 0) {
			return resultList;
		} else {
			return null;
		}
	}

	@Override
	public List<Object[]> getSceneryPics(String objectType, String[] sceneryids) {
		String str="";
		if(sceneryids!=null){
		for (String s : sceneryids) {
			str+=s+",";
		}
		str=str.substring(0,str.length()-1);
		}
		String sql=" select p.picUrl,p.picTitle,p.descriptions,s.productid,s.marketprice,s.productname" +
				"  from t_picture p, t_scenery_product s where p.objectID=s.productid " +
				"  and p.objectType='"+objectType+"' and s.productid in ("+str+")";
	      List<Object[]> obj =	getSession().createSQLQuery(sql).list();
		
		return obj;
	}

	@Override
	public Object[] getSceneryPic(String objectType, String sceneryid) {
		String sql=" select p.picUrl,p.picTitle,p.descriptions,s.productid,s.marketprice,s.productname" +
				"  from t_picture p, t_scenery_product s where p.objectID=s.productid " +
				"  and p.objectType='"+objectType+"' and s.productid='"+sceneryid+"' ";
		return (Object[]) getSession().createSQLQuery(sql).uniqueResult();
	}
	
	public List<SceneryProduct> getSceneryProductBySceneryId(String sceneryid,String Status){
		
		String hql="from SceneryProduct a where  a.scenery.sceneryid='"+sceneryid+"' and a.productstatuscatid='"+Status+"' and a.enableflag=1 and a.productendtime >(SYSDATE-1)";
		Finder f = Finder.create(hql);
		return find(f);
	}

	@Override
	public Pagination getListBySceneryId(String productName, String sceneryId,
			int pageNo, int pageSize) {
			Finder f = Finder.create("from SceneryProduct sp where sp.productstatuscatid=12849 and sp.enableflag=1");
			if(!StringUtil.isEmpty(productName)){
				f.append(" and sp.productname like '%'||:productName||'%' ");
				f.setParam("productName", productName);
			}
			if(!StringUtil.isEmpty(sceneryId)){
				f.append(" and sp.scenery.sceneryid="+sceneryId);
			}
			f.append(" order by to_number(sp.productid) desc");
			return find(f, pageNo, pageSize);
	}
	
}
