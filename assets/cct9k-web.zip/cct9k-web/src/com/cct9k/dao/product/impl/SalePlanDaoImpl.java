package com.cct9k.dao.product.impl;

import java.math.BigDecimal;
import java.util.List;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.SalePlanDao;
import com.cct9k.entity.product.SalePlan;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-9
 * Time: 下午5:34
 */
@Repository
public class SalePlanDaoImpl extends BaseDaoImpl<SalePlan, String> implements SalePlanDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from SalePlan model where 1=1");

        r.append(" order by plandate desc");

        return find(r, pageNo, pageSize);
    }
    
    //2:酒店订单 3:餐饮 4:景点 5:娱乐  flag :增加true 减少false
    public boolean updateSalePlanNum(int number,String productId,String objectId,String startTime,String endTime,String orderStyle,boolean flag) {
    	String queryString = "";
    	String symbol = "";
    	if(flag){
    		symbol = "+";
    	}else{
    		symbol = "-";
    	}
    	if("2".equals(orderStyle)){
    		queryString = " update t_sale_plan c"
    			    +" set c.enablesalenum = c.enablesalenum "+ 
    			    symbol 
    			    +number
    			    +" where c.saleplanid in"
    			    +"     (select b.saleplanid"
    			    +"        from t_hotel_product a, t_sale_plan b"
    			    +"       where a.productid = b.objid"
    			    +"          and a.hotelid = '"+objectId+"'"
    			    +"          and a.productid = '"+productId+"'"
    			    +"          and b.plandate >= to_date('"+startTime+"', 'yyyy-MM-dd')"
    			    +"          and b.plandate < to_date('"+endTime+"', 'yyyy-MM-dd'))";
    	}else if("3".equals(orderStyle)){
    		String[] s1 = startTime.split(" ");
    		String[] s2 = endTime.split(" ");
    		queryString = " update t_sale_plan c"
    			    +" set c.enablesalenum = c.enablesalenum "+symbol +number
    			    +" where c.saleplanid in"
    			    +"     (select b.saleplanid"
    			    +"        from t_restaurant_product a, t_sale_plan b"
    			    +"       where a.restaurantproductid = b.objid"
    			    +"          and a.restaurantid = '"+objectId+"'"
    			    +"          and a.restaurantproductid = '"+productId+"'"
    			    +"          and b.plandate >= to_date('"+s1[0]+"', 'yyyy-MM-dd')"
    			    +"          and b.plandate <= to_date('"+s2[0]+"', 'yyyy-MM-dd'))";
    	}else if("4".equals(orderStyle)){
    		queryString = " update t_sale_plan c"
    			    +" set c.enablesalenum = c.enablesalenum "+symbol +number
    			    +" where c.saleplanid in"
    			    +"     (select b.saleplanid"
    			    +"        from t_scenery_product a, t_sale_plan b"
    			    +"       where a.productid = b.objid"
    			    +"          and a.sceneryid = '"+objectId+"'"
    			    +"          and a.productid = '"+productId+"'"
    			    +"          and b.plandate >= to_date('"+startTime+"', 'yyyy-MM-dd')"
    			    +"          and b.plandate <= to_date('"+endTime+"', 'yyyy-MM-dd'))";
    	}else if("5".equals(orderStyle)){
    		queryString = " update t_sale_plan c"
    			    +" set c.enablesalenum = c.enablesalenum "+symbol +number
    			    +" where c.saleplanid in"
    			    +"     (select b.saleplanid"
    			    +"        from t_entertainment_product a, t_sale_plan b"
    			    +"       where a.productid = b.objid"
    			    +"          and a.enterainmentid = '"+objectId+"'"
    			    +"          and a.productid = '"+productId+"'"
    			    +"          and b.plandate >= to_date('"+startTime+"', 'yyyy-MM-dd')"
    			    +"          and b.plandate <= to_date('"+endTime+"', 'yyyy-MM-dd'))";
    	}
        
        int result  = getSession().createSQLQuery(queryString).executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public int getSaleHotelNumByDate(String objectId,String productId,String startTime,String endTime,String orderStyle){
    	String sql = "";
    	if("2".equals(orderStyle)){
    		sql="select min(b.enablesalenum) as num from t_hotel_product a,t_sale_plan b" +
        			" where a.productid=b.objid" +
        			" and a.hotelid='"+objectId+"'" +
        			//" and a.productid='"+productId+"' " +
        			" and b.plandate>=to_date('"+startTime+"','yyyy-MM-dd')" +
                    " and b.plandate<to_date('"+endTime+"','yyyy-MM-dd')";
    	}else if("3".equals(orderStyle)){
    		String[] s1 = startTime.split(" ");
    		String[] s2 = endTime.split(" ");
    		sql="select min(b.enablesalenum) as num from t_restaurant_product a,t_sale_plan b" +
        			" where a.restaurantproductid=b.objid" +
        			//" and a.restaurantid='"+objectId+"'" +
        			" and a.restaurantproductid='"+productId+"' " +
        			" and b.plandate>=to_date('"+s1[0]+"','yyyy-MM-dd')" +
                    " and b.plandate<=to_date('"+s2[0]+"','yyyy-MM-dd')";
    	}else if("4".equals(orderStyle)){
    		sql="select min(b.enablesalenum) as num from t_scenery_product a,t_sale_plan b" +
        			" where a.productid=b.objid" +
        			//" and a.sceneryid='"+objectId+"' " +
        			" and a.productid='"+productId+"' " +
        			" and b.plandate>=to_date('"+startTime+"','yyyy-MM-dd')" +
                    " and b.plandate<=to_date('"+endTime+"','yyyy-MM-dd')";
    	}else if("5".equals(orderStyle)){
    		sql="select min(b.enablesalenum) as num from t_entertainment_product a,t_sale_plan b" +
        			" where a.productid=b.objid" +
        			//" and a.enterainmentid='"+objectId+"' " +
        			" and a.productid='"+productId+"' " +
        			" and b.plandate>=to_date('"+startTime+"','yyyy-MM-dd')" +
                    " and b.plandate<=to_date('"+endTime+"','yyyy-MM-dd')";
    	}
    	Query query = this.getSession().createSQLQuery(sql);
		List resultList = query.list();
		int num=0;
		if (resultList.get(0)!= null ) {
			BigDecimal bigNum =  new BigDecimal(resultList.get(0).toString());
			num = bigNum.intValue();
		} 
		return num;
    }
    
}
