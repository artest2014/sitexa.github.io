package com.cct9k.dao.product.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.TransportRoutePriceDao;
import com.cct9k.entity.product.TransportRoutePrice;

@Repository
public class TransportRoutePriceDaoImpl extends
		BaseDaoImpl<TransportRoutePrice, String> implements
		TransportRoutePriceDao {

}
