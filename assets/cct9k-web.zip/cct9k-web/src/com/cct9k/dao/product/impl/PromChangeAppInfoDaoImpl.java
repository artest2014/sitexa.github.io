package com.cct9k.dao.product.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.product.PromChangeAppInfoDao;
import com.cct9k.entity.product.PromChangeAppInfo;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午12:52
 */
@Repository
public class PromChangeAppInfoDaoImpl extends BaseDaoImpl<PromChangeAppInfo, String> implements PromChangeAppInfoDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from PromChangeAppInfo model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }

}
