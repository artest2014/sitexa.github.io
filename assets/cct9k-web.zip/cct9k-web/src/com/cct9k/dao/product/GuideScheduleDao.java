package com.cct9k.dao.product;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.product.GuideSchedule;

public interface GuideScheduleDao extends BaseDao<GuideSchedule, String> {
	
	public boolean isHaveSchedule(String guideid,String startDate,String endDate);
	
	//导游订单，，保存订单ID，团队选择导游，保存团队ID
	public GuideSchedule getGuideScheduleObject(String orderId);
   
	 public List<GuideSchedule> getGuideScheduleList(String guideId);
}
