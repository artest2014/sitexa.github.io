package com.cct9k.dao.sightseer.card;

import java.util.Date;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Site;

public interface SightseerCardDao extends BaseDao<Object, String>{
	
	public Pagination findCards(String sellerId,String cardNo,Date startTime,Date endTime,Site site,int pageNo,int pageSize);

}
