package com.cct9k.dao.sightseer.card.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.sightseer.card.SightseerCardDao;
import com.cct9k.entity.admin.Site;
import com.cct9k.util.common.StringUtil;

@Repository
public class SightseerCardDaoImpl extends BaseDaoImpl<Object, String> implements SightseerCardDao {

	
	public Pagination findCards(String sellerId,String cardNo,Date startTime,Date endTime,Site site,int pageNo,int pageSize){
		Map<String,Object> params=new HashMap<String,Object>();
		
		StringBuffer sql=new StringBuffer();
		sql.append("SELECT tc.CARDNO,st.FULLNAME,TC.UPDATEDATE FROM T_TouristCard  tc ");
		sql.append("LEFT JOIN T_SITE st on TC.SITEID=ST.SITEID ");
		sql.append("WHERE tc.SELLERID=:sellerId ");
		
		if(!StringUtil.isEmpty(cardNo)){
			sql.append("AND tc.CARDNO=:cardNo ");
			params.put("cardNo", cardNo);
		}
		if(startTime!=null){
			sql.append("AND TC.CREATEDATE >= :startTime ");
			params.put("startTime", startTime);
		}
		if(endTime!=null){
			sql.append("AND TC.CREATEDATE <= :endTime ");
			params.put("endTime", endTime);
		}
		if(!StringUtil.isEmpty(site.getCountry())){
			sql.append("AND st.state=:country ");
			params.put("country", site.getCountry());
		}
		if(!StringUtil.isEmpty(site.getCity())){
			sql.append("AND st.city=:city ");
			params.put("city", site.getCity());
		}
		if(!StringUtil.isEmpty(site.getSiteid())){
			sql.append("AND st.siteId=:siteId ");
			params.put("siteId", site.getSiteid());
		}
		
		params.put("sellerId", sellerId);
		
		return findSql(sql.toString(), null, params, pageNo, pageSize);
	}
	
}
