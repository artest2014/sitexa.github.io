package com.cct9k.dao.b2bpurchase.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.b2bpurchase.B2BpurchaseDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.reseller.Onsale;
import com.cct9k.util.common.StringUtil;

@Repository
public class B2BPurchaseDaoImpl extends BaseDaoImpl<Onsale,String> implements B2BpurchaseDao  {

	
	/**
	 *@param ONSLEID 		上架id
	 *@param RESELLERID 	商家id
	 *@param ROUTENAME 		线路名称
	 *@param SALLERNAME		卖家名称
	 *@param GORUPSIZE 		成团人数
	 *@param STARTTIME 		发团时间
	 *@param VISITORNUM 	已预订人数
	 *@param DURATION  		行程天数
	 *@param MINPRICE 		最低价
	 *@param MAXPRICE 		最高价
	 **/
	@Override
	public Pagination getOnsaleList(String memberId, String routeName, String startTime,
			String endTime, String startSiteId, String endSiteId,
			String sallerName, String duration,int pageNo,int pageSize ) {
		Map<String, Object> params = new HashMap<String, Object>();
    	StringBuffer sql = new StringBuffer("SELECT * FROM (SELECT A.ONSALEID, MAX(B.RESELLER) AS RESELLERID,MAX(B.ROUTENAME) AS ROUTENAME,");
    	sql.append(" MAX(CASE C.MEMBERTYPE WHEN '27' THEN (SELECT P.REALNAME FROM T_MEMBER_PERSON P WHERE P.MEMBERID = C.MEMBERID)");
    	sql.append(" ELSE (SELECT O.ORGNAME FROM T_MEMBER_ORGAN O WHERE O.MEMBERID = C.MEMBERID)  END) AS SALLERNAME , ");
    	sql.append(" MAX(B.GROUPSIZE), MAX(A.STARTTIME) AS STARTTIME, MAX(NVL(E.NUM, 0)) AS VISITORNUM , MAX(B.DURATION) AS DURATION,NVL(MIN(OP.CHILDRENPRICE),0) AS MINPRICE, NVL( MAX(OP.ONSALEPRICE),0) AS MAXPRICE");
    	sql.append(" FROM  T_ONSALE A LEFT JOIN T_ROUTE B ON A.ROUTEID=B.ROUTEID ");
    	sql.append(" LEFT JOIN T_MEMBER C ON C.MEMBERID=B.RESELLER");
    	sql.append(" LEFT JOIN T_ONSALE_PRICE OP ON OP.ONSALEID=A.ONSALEID");
    	sql.append(" LEFT JOIN ( SELECT COUNT(*) AS NUM,D.ONSALEID FROM T_ORDER_DETAIL_PLAN D INNER JOIN T_VISITOR F ON F.ORDERID=D.ORDERID WHERE D.ORDERID=F.ORDERID  GROUP BY D.ONSALEID ) E  ON E.ONSALEID=A.ONSALEID");
    	
    	if(!StringUtil.isEmpty(startSiteId)){
    		sql.append(" INNER JOIN(SELECT R.ROUTEID FROM T_ROUTE_STOP R INNER JOIN (SELECT * FROM T_SITE  START WITH SITEID=:STARTSITEID ");
    		sql.append(" CONNECT BY PRIOR SITEID=PARENTID )  S ON R.DEPARTURESITE=S.SITEID GROUP BY R.ROUTEID ) STARTSITE ON STARTSITE.ROUTEID=A.ROUTEID");
    		params.put("STARTSITEID", startSiteId);
    	}
    	if(!StringUtil.isEmpty(endSiteId)){
    		sql.append(" INNER JOIN (SELECT R.ROUTEID FROM T_ROUTE_STOP R INNER JOIN (SELECT * FROM T_SITE  START WITH SITEID=:ENDSITEID ");
    		sql.append(" CONNECT BY PRIOR SITEID=PARENTID )  S ON R.DESTINATIONSITE=S.SITEID GROUP BY R.ROUTEID ) ENDSITE  ON ENDSITE.ROUTEID=A.ROUTEID");
    		params.put("ENDSITEID", endSiteId);
    	}
    	sql.append(" WHERE  A.STATUS='1' AND A.STARTTIME>=(SYSDATE+1) and A.RESELLER <>:MEMBERID ");
    	params.put("MEMBERID", memberId);
    	if(!StringUtil.isEmpty(duration)){
    		sql.append(" AND TO_CHAR(B.DURATION)=:DURATION");
    		params.put("DURATION", duration);
    	}
    	if(!StringUtil.isEmpty(routeName)){
    		sql.append(" AND B.ROUTENAME LIKE '%'||:ROUTENAME||'%' ");
    		params.put("ROUTENAME", routeName);
    	}
    	if(!StringUtil.isEmpty(startTime)){
    		sql.append(" AND A.STARTTIME>=to_date(:STARTTIME,'yyyy-MM-dd HH24:mi:ss')  ");
    		params.put("STARTTIME", startTime);
    	}
    	if(!StringUtil.isEmpty(endTime)){
    		sql.append(" AND A.STARTTIME<=to_date(:ENDTIME,'yyyy-MM-dd HH24:mi:ss')  ");
    		params.put("ENDTIME", endTime);
    	}
    	sql.append(" GROUP BY A.ONSALEID)");
    	if(!StringUtil.isEmpty(sallerName)){
    		sql.append(" WHERE SALLERNAME LIKE '%'||:SALLERNAME||'%' ");
    		params.put("SALLERNAME", sallerName);
    	}
    	return findSql(sql.toString(), null, params, pageNo, pageSize);
	}


}
