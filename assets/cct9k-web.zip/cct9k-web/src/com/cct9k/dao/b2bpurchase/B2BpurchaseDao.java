package com.cct9k.dao.b2bpurchase;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.reseller.Onsale;

public interface B2BpurchaseDao extends BaseDao<Onsale,String> {
  
	public Pagination getOnsaleList(String memberId,String routeName, String startTime,
			String endTime, String startSiteId, String endSiteId,
			String sallerName, String duration, int pageNo, int pageSize);
}
