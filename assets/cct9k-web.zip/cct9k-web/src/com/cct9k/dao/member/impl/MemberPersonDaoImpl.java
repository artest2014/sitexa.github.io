package com.cct9k.dao.member.impl;

import java.util.List;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.member.MemberPersonDao;
import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.MemberPerson;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class MemberPersonDaoImpl extends BaseDaoImpl<MemberPerson, String> implements MemberPersonDao {

	@Override
	public MemberPerson getMemberPersonByIdentity(String identity) {
		String hql =" from " + MemberPerson.class.getName() +" as model where model.memberid = '"+identity +"'";
		List<MemberPerson> list =getListByHql(hql);
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}
	
	@Override
	public MemberPerson getMemberPersonByIdentityNo(String identityNo) {
		String hql =" from " + MemberPerson.class.getName() +" as model where model.identityno = '"+identityNo +"'";
		List<MemberPerson> list =getListByHql(hql);
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}

	@Override
	public boolean checkIdentityNo(String memberId,String identityNo, String type) {
		String sql = "select count(*) from t_member_person where  memberid <> '"+memberId+"' and identityno='"+identityNo+"' and identitytype='"+type+"'";
		  Query query = this.getSession().createSQLQuery(sql);
		  List<String> resultList = query.list();
		  Object num = null;
		  int n;
		  if (resultList != null && resultList.size() > 0) {
	            num = (Object) resultList.get(0);
	            n= Integer.parseInt(num.toString());
	        } else {
	            n= 0;
	        }
		if(n>0){
			return false;
		}else{
			return true;
		}
	}
}
