package com.cct9k.dao.member;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.MemberPicture;

public interface MemberPictureDao extends BaseDao<MemberPicture, String> {
	  public String getSeqn();
	  public void delete(String pictureId); 
}
