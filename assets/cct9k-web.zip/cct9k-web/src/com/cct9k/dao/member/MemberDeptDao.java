package com.cct9k.dao.member;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.MemberDept;
import com.cct9k.entity.member.MemberExpansion;

public interface MemberDeptDao extends BaseDao<MemberDept, String>{
	/**
	 * 描述: .部门管理条件分页查询
	 * @param manager
	 * @param deptname
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-25
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-25               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getPage(String memberId,String manager,String deptname,int pageNo,
			int pageSize);
	
	/**
	 * 描述: .更新部门
	 * @param entity
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-25
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-25               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public void update(MemberDept entity);
	
	/**
	 * 描述: .保存部门
	 * @param entity
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-25
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-25               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public String save(MemberDept entity) ;
	
	/**
	 * 描述: .删除部门
	 * @param id
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-25
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-25               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public void delete(String id) ;
	
	
	/**
	 * 描述: .获取部门的所有成员
	 * @param deptId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-25
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-25               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getMemberByDeptId(String deptId,String memberName,int pageNo,
			int pageSize);
	
	/**
	 * 描述: .未添加部门的成员
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-25
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-25               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getNotAddMember(String memberName,int pageNo,
			int pageSize) ;
	
	/**
	 * 描述: .添加部门成员
	 * @param me
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-25
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-25               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean saveDeptMember(MemberExpansion me) ;
	/**
	 * 描述: .删除部门成员
	 * @param memberId
	 * @param deptId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-25
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-25               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean deleteDeptMember(String memberId,String deptId);
	public boolean delDeptMember(String deptId);
	public Pagination getChildById(String parentId,String name,int pageNo,
			int pageSize);
	public List<String> getDeptIdByMemberId(String memberId);
	public List<String> getDeptIdByMemberIdAndObjectType(String memberId,String objectTypeId);
	public List<MemberDept> getMemberDeptByMemberIdAndObjectType(String memberId,String objectTypeId);

	public void updateDeptIdByNewId(String originalId, String newId);

	public List<String> getMemberIdByRoleIdAndDeptId(String roleId,
			String objectId);

	public MemberDept getByOrgidAndObjectid(String orgid, String objectid);
	
	public List<MemberDept> getByObjectid(String objectid);
}
