/**
 * <p>Class Name: BookDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-3-22</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.member.impl;

import java.util.List;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.member.MemberOrganDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.member.MemberOrgan;

import org.springframework.stereotype.Repository;

/**
 * @author sxc
 */
@Repository
public class MemberOrganDaoImpl extends BaseDaoImpl<MemberOrgan, String> implements MemberOrganDao {
	@Override
	public MemberOrgan getMemberOrganByIdentity(String identity) {
		String hql =" from " + MemberOrgan.class.getName() +" as model where model.memberid = '"+identity +"'";
		List<MemberOrgan> list =getListByHql(hql);
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}

	@Override
	public boolean isExistIdentityNo(String identityNo,String memberId) {
		String hql = "from MemberOrgan model where model.memberid<>:memberId and model.identityNo=:identityNo ";
		List<MemberOrgan> organs= getSession().createQuery(hql).setParameter("memberId", memberId).setParameter("identityNo", identityNo).list();
		if(organs!=null&&organs.size()>0){
			return true;
		}
		return false;
	}
	

}