package com.cct9k.dao.member;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;

public interface MemberDao extends BaseDao<Member, String> {
    //主键生成
    public String getSeqn();

    //获取Member,identity可以是用户名，手机号，email中的一种
    public Member getMemberByIdentity(String identity);

	/**
	 * 描述: 
	 * @param memberName
	 * @param momberNo
	 * @param regDate
	 * @param pageNo
	 * @param i
	 * @return
	 */
	public  boolean isExistUsername(String membername);	
	    
	public Pagination getPage(String memberName, String mobileNo,
			String regDate, int pageNo, int pageSize);


	public Member getMemberByMobileno(String mobileno);

	public Pagination getPage(String memberName, String regDate, int pageNo,
			int pageSize);
	
	public List<Member> getMemberByMemberName(String memberName);
	
	/**
	 * 描述: .机构会员列表条件分页查询
	 * @param memberName
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-21
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-21               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getOrganPage(String memberId,String memberName,String memberType,int pageNo,int pageSize);
	
	/**
	 * 描述: .根据机构会员ID查询下面所有的子账户
	 * @param parentMemberId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-22
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-22               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public List<Member> getChildMember(String parentMemberId);
	
	/**
	 * 描述: .个人会员列表条件分页查询
	 * @param memberName
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-21
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-21               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getPersonPage(String memberName,String memberType,int pageNo,int pageSize);
	
	/**
	 * 描述: .添加子账号
	 * @param childMemberId
	 * @param parentId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-22
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-22               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean saveChildMember(String childMemberId,String parentId);
	
	/**
	 * 描述: .删除机构会员下的孩子节点（子账号）
	 * @param childMemberId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-24
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-24               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean deleteChildMember(String childMemberId) ;
	
	public Pagination getOrganList(String memberId, String memberName,int pageNo, int pageSize);
	
	public Pagination getmemberList(String memberId, String memberName,int pageNo, int pageSize);
	
	/**
	 * 描述: .获取某账号下子账号的角色关系
	 * @param orgId
	 * @param memberId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-7-12
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-7-12               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public List getMemberRoleList(String orgId,String memberId);
    
	/**
	 * 描述: .删除角色资源对应关系
	 * @param roleId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-7-12
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-7-12               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
    public boolean deleteRoleResource(String roleId) ;
    
    public Pagination getMemAndOrgList(String memberName,int pageNo, int pageSize);
    
    /**
     * 描述: .删除子账号对应机构分配的角色关系
     * @param memberId
     * @param roleId
     * @return
     * @author     chp
     * <p>Sample: 该方法使用样例</p>
     * date        2013-7-12
     * -----------------------------------------------------------
     * 修改人                                             修改日期                                   修改描述
     * chp                2013-7-12               创建
     * -----------------------------------------------------------
     * @Version  Ver1.0
     */
    public boolean deleteMemberRole(String memberId,String roleId) ;
	public Pagination getOrganChildPage(String memberName, int pageNo,
			int pageSize,Member me);
	
	public Pagination getAllMemberList(String memberName, int pageNo, int pageSize);

	public Pagination getAgreeCheck(String selectname, String inputvalue,
			String regDate, int pageNo, int pageSize);

	public List<String> getChildNotAllotById(String memberId);
	public Pagination getChildById(String parentId, String memberName, String memberTel, String memberEmail, String appid,int pageNo, int pageSize);	
	public List getMemberList(String keyword,String memberid,String dicId);

    public Member searchByRealnameOrOrganname(String seller);

    Pagination searchMember(String membername, int pageNo, int pageSize);

	public Member getMemberByname(String membername);
	
	/**
	 * 根据父id获取member
	 * @param parentId
	 * @return
	 */
	public List<Member> getMemberbyParentId(String parentId,String appId);
	
	/**
	 * 查询旅行社（不包括自己）
	 * @return
	 */
	public Pagination findTravel(String memberId,String travelName,int pageNo, int pageSize);
	
	/**
	 * 查询内部员工和导游
	 * @param memberName
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination findEmploeeAndGuide(String memberId,String appId,String memberName,int pageNo, int pageSize);
}
