package com.cct9k.dao.member;


import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.member.MemberLog;

public interface MemberLogDao extends BaseDao<MemberLog, String> {
    public String getSeqn();
    
    public Pagination getPage(String log_memberName, String log_memberinfo,
			String regDate, int pageNo, int pageSize);
    public Pagination getMemberLog(String log_memberId, String log_memberinfo,
			String LogDate, int pageNo, int pageSize);
    
    public List<MemberLog> getMemberLog(Member member);
}
