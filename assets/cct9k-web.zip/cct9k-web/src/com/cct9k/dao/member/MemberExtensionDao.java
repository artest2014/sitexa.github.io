package com.cct9k.dao.member;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.MemberExtension;

public interface MemberExtensionDao extends BaseDao<MemberExtension, String> {

}
