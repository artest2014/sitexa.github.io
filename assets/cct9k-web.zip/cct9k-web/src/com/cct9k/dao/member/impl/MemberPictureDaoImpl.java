package com.cct9k.dao.member.impl;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.member.MemberPictureDao;
import com.cct9k.entity.member.MemberPicture;

import org.springframework.stereotype.Repository;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class MemberPictureDaoImpl extends BaseDaoImpl<MemberPicture, String> implements MemberPictureDao {

	
	public MemberPicture get(String id) {
		return super.get(id);
	}
	public void delete(String id) {
		 super.delete(id);
	}
}
