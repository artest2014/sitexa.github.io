package com.cct9k.dao.member;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Dictionary;
import com.cct9k.entity.member.MemberPerson;

public interface MemberPersonDao extends BaseDao<MemberPerson, String> {
	public MemberPerson getMemberPersonByIdentity(String identity);
	public MemberPerson getMemberPersonByIdentityNo(String identityNo) ;
	public boolean checkIdentityNo(String memberId,String identityNo, String type);

}
