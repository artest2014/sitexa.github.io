/**
 * <p>Class Name: BookDao.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-3-22</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.member;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.MemberOrgan;

/**
 * @author sxc
 */
public interface MemberOrganDao extends BaseDao<MemberOrgan, String> {
	public MemberOrgan getMemberOrganByIdentity(String identity);

	public boolean isExistIdentityNo(String result,String memberId);
}