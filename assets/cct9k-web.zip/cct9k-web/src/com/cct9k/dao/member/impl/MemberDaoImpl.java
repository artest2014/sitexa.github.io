package com.cct9k.dao.member.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.member.MemberDao;
import com.cct9k.entity.main.Entertainment;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author yics 2013-04-08
 */
@Repository
public class MemberDaoImpl extends BaseDaoImpl<Member, String> implements MemberDao {

    @Override
    public List<Member> getAll() {
        return super.getAll();
    }

    @Override
    public String getSeqn() {
        String sql = " select s_member.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }

    // 根据id查询一个member
    @Override
    public Member get(String id) {
        return super.get(id);
    }

    @Override
    public Member getMemberByIdentity(String identity) {
        String hql = " from " + Member.class.getName() + " as model where lower(model.membername) = lower('"+ identity+ "') or model.mobileno = '" + identity + "' or model.email = '" + identity + "'";
        List<Member> list = getListByHql(hql);
        if (list.size() > 0) {
            return list.get(0);
        } else {
            return null;
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see com.cct9k.member.dao.MemberDao#getPage(java.lang.String,
     * java.lang.String, java.lang.String, int, int)
     */
    @Override
    public Pagination getPage(String selectname, String inputvalue, String regDate, int pageNo, int pageSize) {
        Finder f = Finder.create("from Member model where 1=1 ");
        if (!StringUtil.isEmpty(inputvalue)) {
            f.append(" and model." + selectname + " like '%" + inputvalue + "%'");
        }
        f.append(" order by model.memberid desc");
        return find(f, pageNo, pageSize);
    }

    @Override
    public void update(Member entity) {
        super.update(entity);
    }

    @Override
    public Member getMemberByMobileno(String mobileno) {
        return (Member) getSession().createQuery("select m from Member m where m.mobileno=" + mobileno).uniqueResult();
    }

    @Override
    public Pagination getPage(String memberName, String regDate, int pageNo, int pageSize) {
        Finder f = Finder.create("from Member model where 1=1 ");
        if (!StringUtil.isEmpty(memberName)) {
            f.append(" and model.membername like %'" + memberName + "'%");
        }
        f.append(" order by model.memberid desc");
        return find(f, pageNo, pageSize);
    }

    @Override
    public List<Member> getMemberByMemberName(String memberName) {
        String hql = "from Member model where model.membername like '%" + memberName + "%'";
        List<Member> list = getListByHql(hql);
        return list;

    }

    public Pagination getOrganPage(String memberId, String memberName, String memberType, int pageNo, int pageSize) {
        Finder f = Finder.create("from Member m where 1=1");
        if (!StringUtil.isEmpty(memberId)) {
            f.append(" and m.memberid = '" + memberId + "'");
        }
        if (!StringUtil.isEmpty(memberName)) {
            f.append(" and m.membername like '%" + memberName + "%'");
        }
        if (!StringUtil.isEmpty(memberType)) {
            f.append(" and m.memberType in(" + memberType + ")");
        }
        f.append("  order by m.registerdate desc");
        return find(f, pageNo, pageSize);
    }

    public List<Member> getChildMember(String parentMemberId) {
        String hql = "from Member m where 1=1 and m.parent='" + parentMemberId + "'";
        List<Member> childMemberList = getListByHql(hql);
        return childMemberList;
    }

    public Pagination getPersonPage(String memberName, String memberType, int pageNo, int pageSize) {
        Finder f = Finder.create("from Member m where 1=1");
        if (!StringUtil.isEmpty(memberName)) {
            f.append(" and m.memberPerson.realname like '%" + memberName + "%'");
        }
        f.append(" and m.memberType='" + memberType + "' and m.parent is null order by m.registerdate desc");
        return find(f, pageNo, pageSize);
    }

    public boolean saveChildMember(String childMemberId, String parentId) {
        String sql = " update t_member t set t.parentid=? where t.memberid in(" + childMemberId + ")";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, parentId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteChildMember(String childMemberId) {
        String sql = " update t_member t set t.parentid='' where t.memberid in(" + childMemberId + ")";
        Query query = this.getSession().createSQLQuery(sql);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    @SuppressWarnings("rawtypes")
    public List getMemberRoleList(String orgId, String memberId) {
        String sql = "select tr.* from t_role r, t_member_role tr  where r.orgid='" + orgId + "' and tr.roleid=r.roleid and tr.memberid in(" + memberId + ")";
        Query query = this.getSession().createSQLQuery(sql);
        List resultList = query.list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        } else {
            return null;
        }
    }

    public boolean deleteRoleResource(String roleId) {
        String sql = " delete from t_role_resource t where t.roleid ='" + roleId + "'";
        Query query = this.getSession().createSQLQuery(sql);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteMemberRole(String memberId, String roleId) {
        String sql = " delete from t_member_role tr where tr.memberid='" + memberId + "' and tr.roleid='" + roleId + "'";
        Query query = this.getSession().createSQLQuery(sql);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<Member> get(String[] ids) {
        return super.get(ids);
    }

	/*
     * public Pagination getmemberList(String memberId, String memberName, int
	 * pageNo, int pageSize) { String sql =
	 * "select mp.memberid,mp.realname,tm.mobileno,tm.membertype,mp.IDENTITYNO,mp.identitytype,tm.membername from t_member tm,t_member_person mp where tm.memberid=mp.memberid  and tm.membertype='27'"
	 * ; if (!StringUtil.isEmpty(memberId)) { sql += " and tm.memberid not in("
	 * + memberId + ")"; } if (!StringUtil.isEmpty(memberName)) { sql +=
	 * " and mp.realname like '%" + memberName + "%'"; } return
	 * this.findSql(sql, pageNo, pageSize); }
	 */

	/*
	 * public Pagination getOrganList(String memberId, String memberName, int
	 * pageNo, int pageSize) { String sql =
	 * "select mp.memberid,mp.orgname,tm.mobileno,tm.membertype,tm.membername from t_member tm,t_member_organ mp where tm.memberid=mp.memberid  and tm.membertype='28'"
	 * ; if (!StringUtil.isEmpty(memberId)) { sql += " and tm.memberid not in("
	 * + memberId + ")"; } if (!StringUtil.isEmpty(memberName)) { sql +=
	 * " and mp.orgname like '%" + memberName + "%'"; } return this.findSql(sql,
	 * pageNo, pageSize); }
	 */

	/*
	 * public Pagination getMemAndOrgList(String memberName, int pageNo, int
	 * pageSize) { String sql =
	 * "select mp.memberid,mp.realname,tm.mobileno,tm.membertype,tm.membername from t_member tm,t_member_person mp where tm.memberid=mp.memberid "
	 * ; if (!StringUtil.isEmpty(memberName)) { sql +=
	 * " and mp.realname like '%" + memberName + "%'"; } sql += " union"; sql +=
	 * " select mo.memberid,mo.orgname,tm.mobileno,tm.membertype,tm.membername from t_member tm,t_member_organ mo where tm.memberid=mo.memberid "
	 * ; if (!StringUtil.isEmpty(memberName)) { sql +=
	 * "  and mo.orgname like '%" + memberName + "%' "; } return
	 * this.findSql(sql, pageNo, pageSize); }
	 */

    public Pagination getmemberList(String memberId, String memberName, int pageNo, int pageSize) {
        String sql = "select mp.memberid,mp.realname,tm.mobileno,tm.membertype,mp.IDENTITYNO,mp.identitytype,tm.membername from t_member tm,t_member_person mp where tm.memberid=mp.memberid  and tm.membertype='27'";
        if (!StringUtil.isEmpty(memberId)) {
            sql += " and tm.memberid not in(" + memberId + ")";
        }
        if (!StringUtil.isEmpty(memberName)) {
            sql += " and mp.realname like '%" + memberName + "%'";
        }
        return this.findSql(sql, pageNo, pageSize);
    }

    public Pagination getOrganList(String memberId, String memberName, int pageNo, int pageSize) {
        String sql = "select mp.memberid,mp.orgname,tm.mobileno,tm.membertype,tm.membername from t_member tm,t_member_organ mp where tm.memberid=mp.memberid  and tm.membertype='28'";
        if (!StringUtil.isEmpty(memberId)) {
            sql += " and tm.memberid not in(" + memberId + ")";
        }
        if (!StringUtil.isEmpty(memberName)) {
            sql += " and mp.orgname like '%" + memberName + "%'";
        }
        return this.findSql(sql, pageNo, pageSize);
    }

    public Pagination getMemAndOrgList(String memberName, int pageNo, int pageSize) {
        String sql = "select mp.memberid,mp.realname,tm.mobileno,tm.membertype,tm.membername from t_member tm,t_member_person mp where tm.memberid=mp.memberid ";
        if (!StringUtil.isEmpty(memberName)) {
            sql += " and mp.realname like '%" + memberName + "%'";
        }
        sql += " union";
        sql += " select mo.memberid,mo.orgname,tm.mobileno,tm.membertype,tm.membername from t_member tm,t_member_organ mo where tm.memberid=mo.memberid ";
        if (!StringUtil.isEmpty(memberName)) {
            sql += "  and mo.orgname like '%" + memberName + "%' ";
        }
        return this.findSql(sql, pageNo, pageSize);

    }
    
    @Override
    public Pagination getAllMemberList(String memberName, int pageNo, int pageSize) {
    	String sql = "select mp.memberid,mp.realname,tm.mobileno,tm.membertype,tm.membername from t_member tm,t_member_person mp where tm.memberid=mp.memberid and tm.auditstate='15008' and tm.parentid is null";
        if (!StringUtil.isEmpty(memberName)) {
            sql += " and mp.realname like '%" + memberName + "%'";
        }
        sql += " union";
        sql += " select mo.memberid,mo.orgname,tm.mobileno,tm.membertype,tm.membername from t_member tm,t_member_organ mo where tm.memberid=mo.memberid and tm.auditstate='15008' and tm.parentid is null";
        if (!StringUtil.isEmpty(memberName)) {
            sql += "  and mo.orgname like '%" + memberName + "%' ";
        }
        return this.findSql(sql, pageNo, pageSize);
    }

    @Override
    public Pagination getOrganChildPage(String memberName, int pageNo, int pageSize, Member m) {

        Finder f = Finder.create("from Member m where 1=1");
        if (!StringUtil.isEmpty(memberName)) {
            f.append(" and m.memberPerson.realname like '%" + memberName + "%'");
        }
        f.append(" and m.parent.memberid=" + m.getMemberid());
        return find(f, pageNo, pageSize);
    }

    @Override
    public Pagination getAgreeCheck(String selectname, String inputvalue, String regDate, int pageNo, int pageSize) {
        Finder f = Finder.create("from Member model where model.auditstate='2'");
        if (!StringUtil.isEmpty(selectname)) {
            f.append(" and model.membername like '%" + selectname + "%'");
        }
        f.append(" order by model.memberid desc");
        return find(f, pageNo, pageSize);
    }

    @SuppressWarnings("unchecked")
    public List<String> getChildNotAllotById(String memberId) {
        String sql = "select t.memberid  from t_member t where t.parentid=?  and t.memberstate='1' and t.memberid not in(select distinct(tm.memberid) from t_member_role tm)";
        return getSession().createSQLQuery(sql).setParameter(0, memberId).list();

    }

    @Override

    public Pagination getChildById(String parentId, String memberName, String memberTel, String memberEmail, String appid,int pageNo, int pageSize) {
        //并根据角色取得应用
    	Finder f = Finder.create("select m  from Member as m inner join fetch m.all_roles as r where r.application.appid='"+appid+"' and m.parent=" + parentId);
        if (!StringUtil.isEmpty(memberName)) {
            f.append(" and m.membername like '%'||:memberName||'%' ");
            f.setParam("memberName", memberName);
        }
        if (!StringUtil.isEmpty(memberTel)) {
        	f.append(" and m.mobileno like '%'||:memberTel||'%' ");
        	f.setParam("memberTel", memberTel);
        }
        if (!StringUtil.isEmpty(memberEmail)) {
        	f.append(" and m.email like '%'||:memberEmail||'%' ");
        	f.setParam("memberEmail", memberEmail);
        }
        f.append(" order by m.memberid desc");
        return find(f, pageNo, pageSize);
    }

    // 审核通过的会员列表
    public List getMemberList(String keyword,String memberid, String dicId) {
        String sql = "select mp.memberid as memberId,tm1.membername,mp.realname from t_member tm1,t_member_person mp where tm1.memberid=mp.memberid and tm1.auditstate='" + dicId + "'";
        if (!StringUtil.isEmpty(keyword)) {
            sql += " and mp.realname like '%" + keyword + "%'";
        }
        if (!StringUtil.isEmpty(memberid)) {
            sql += " and tm1.memberid != '" + memberid + "'";
        }
        sql += " union";
        sql += " select mo.memberid as memberId,tm2.membername ,mo.orgname from t_member tm2,t_member_organ mo where tm2.memberid=mo.memberid and tm2.auditstate='" + dicId + "' ";
        if (!StringUtil.isEmpty(keyword)) {
            sql += "  and mo.orgname like '%" + keyword + "%' ";
        }
        if (!StringUtil.isEmpty(memberid)) {
            sql += " and tm2.memberid != '" + memberid + "'";
        }

        sql += "  order by memberId desc";
        Query query = this.getSession().createSQLQuery(sql);
        List resultList = query.list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        } else {
            return null;
        }
    }

    @Override
    public Member searchByRealnameOrOrganname(String seller) {
        String hql = "from Member m where m.memberPerson.realname = :seller or m.memberOrgan.orgname = :seller ";
        return (Member) getSession().createQuery(hql).setParameter("seller", seller).uniqueResult();

    }

    @Override
    public Pagination searchMember(String membername, int pageNo, int pageSize) {
        String hql = "from Member where 1=1  ";
        Finder f = Finder.create(hql);
        if (!StringUtil.isEmpty(membername)) {
            f.append(" and  membername like '%'|:membername|'%' ");
            f.setParam("membername", membername);
        }

        f.append("  order by membername asc");

        return find(f, pageNo, pageSize);
    }

	@Override
	public boolean isExistUsername(String membername) {
		String hql = "from Member where lower(membername)=lower('"+membername+"')";
		if((Member)getSession().createQuery(hql).uniqueResult()!=null){
			return true;
		}
		return false;
	}

	@Override
	public Member getMemberByname(String membername) {
		String hql = "from Member where lower(membername)=lower('"+membername+"')";
		return (Member)getSession().createQuery(hql).uniqueResult();
	}

	@Override
	public List<Member> getMemberbyParentId(String parentId,String appId) {
		// TODO Auto-generated method stub
		
		StringBuffer hql = new StringBuffer();
		hql.append("  select m  from Member as m inner join fetch m.all_roles as r where r.application.appid='"+appId+"' and m.memberstate=1 and m.parent=" + parentId);
		Query query = getSession().createQuery(hql.toString());
		List<Member> list = query.list();
		
		return list;
	}

	@Override
	public Pagination findTravel(String memberId,String travelName,int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String sql = "WITH TT AS ( SELECT TMP.MEMBERID MEMBERID ,TMP.REALNAME MEMBERNAME FROM T_MEMBER_PERSON TMP   UNION SELECT TMO.MEMBERID MEMBERID,TMO.ORGNAME MEMBERNAME FROM T_MEMBER_ORGAN TMO  )"+
					 " SELECT SS.* FROM ( SELECT TEMP.MEMBERID,CASE WHEN TT.MEMBERNAME IS NULL THEN TEMP.MEMBERNAME WHEN TT.MEMBERNAME IS NOT NULL THEN TT.MEMBERNAME END MEMBERNAME ,TEMP.MEMBERTYPE,TEMP.PASSWORD,TEMP.MOBILENO, "+
					 " TEMP.MOBILECONFIRMED,TEMP.QQNO,TEMP.EMAIL,TEMP.EMAILCONFIRMED,TEMP.WEIBONO,TEMP.MEMBERIMG,TEMP.REGISTERDATE,TEMP.MEMBERSTATE,TEMP.LOGINDATE,TEMP.LOGINADDRESS,TEMP.LOGINTIMES,TEMP.TRYDATE, "+
					 " TEMP.TRYTIMES,TEMP.AUDITSTATE,TEMP.AUDITDATE,TEMP.AUDITOR,TEMP.PARENTID,TEMP.DATASTATE,TEMP.SCORE,TEMP.TERMINALPASSWORD,TEMP.DEACTIVE,TEMP.REACTIVE,TEMP.WEIXIN,TEMP.SCORESUM FROM  "+
					 " ( SELECT TM.* FROM T_MEMBER TM INNER JOIN T_MEMBER_APPLICATION TMA ON TM.MEMBERID = TMA.MEMBERID AND TMA.APPID = '100'  WHERE TM.MEMBERSTATE = 1 AND TM.MEMBERID <>  "+memberId+" )"+ 
					 " TEMP LEFT JOIN TT ON TEMP.MEMBERID=TT.MEMBERID ) SS WHERE 1=1 ";


		if(!StringUtil.isEmpty(travelName)){
			sql = sql + " AND SS.MEMBERNAME LIKE '%"+travelName+"%'";
		}
		return findSql(sql, Member.class, null, pageNo, pageSize);
	}

	@Override
	public Pagination findEmploeeAndGuide(String memberId,String appId,String memberName,
			int pageNo, int pageSize) {
		// TODO Auto-generated method stub
//		String sql = "WITH TT AS ( SELECT TMP.MEMBERID MEMBERID ,TMP.REALNAME MEMBERNAME FROM T_MEMBER_PERSON TMP   UNION SELECT TMO.MEMBERID MEMBERID,TMO.ORGNAME MEMBERNAME FROM T_MEMBER_ORGAN TMO "+
//					" ) SELECT TMPP.MEMBERID,TMPP.MEMBERNAME FROM ( SELECT TRG.GUIDEID MEMBERID, TT.MEMBERNAME FROM T_RESELLER_GUIDE  TRG ,TT WHERE TRG.RESELLERID="+memberId+" AND TT.MEMBERID=TRG.GUIDEID  "+
//				" UNION SELECT TM.MEMBERID,CASE WHEN TT.MEMBERNAME IS NULL THEN TM.MEMBERNAME WHEN TT.MEMBERNAME IS NOT NULL THEN TT.MEMBERNAME END MEMBERNAME "+
//					"FROM T_MEMBER TM LEFT JOIN TT ON TM.MEMBERID=TT.MEMBERID INNER JOIN T_MEMBER_APPLICATION TMA ON TMA.APPID='"+appId+"' AND TMA.MEMBERID=TM.MEMBERID  WHERE TM.PARENTID="+memberId+"  ) TMPP WHERE 1=1 ";

		
		String sql = "SELECT TMPP.MEMBERID,TMPP.MEMBERNAME,TMPP.MEMBERTYPE FROM (  SELECT TRG.GUIDEID MEMBERID, CASE WHEN TMP.REALNAME IS NULL THEN TM.MEMBERNAME "+
					 " WHEN TMP.REALNAME IS NOT NULL THEN TMP.REALNAME END MEMBERNAME,'导游' MEMBERTYPE FROM T_RESELLER_GUIDE  TRG ,T_MEMBER TM LEFT JOIN T_MEMBER_PERSON TMP ON "+
				     " TM.MEMBERID=TMP.MEMBERID WHERE TRG.RESELLERID="+memberId+" AND  tm.MEMBERID=TRG.GUIDEID   UNION  SELECT TM.MEMBERID,CASE WHEN TMP.REALNAME IS NULL THEN TM.MEMBERNAME "+
				     " WHEN tmp.realname IS NOT NULL THEN tmp.realname END MEMBERNAME,'员工' membertype FROM T_MEMBER TM left JOIN T_MEMBER_PERSON TMP ON TM.MEMBERID=TMP.MEMBERID  "
				     + "INNER JOIN T_MEMBER_APPLICATION TMA ON TMA.APPID='"+appId+"' AND TMA.MEMBERID=TM.MEMBERID WHERE TM.PARENTID="+memberId+"   )  TMPP WHERE 1=1";
		
		if(!StringUtil.isEmpty(memberName)){
			sql = sql + " AND TMPP.MEMBERNAME LIKE '%"+memberName+"%'";
		}
		
		sql = sql + " GROUP BY TMPP.MEMBERID,TMPP.MEMBERNAME,TMPP.MEMBERTYPE";
		return findSql(sql, null, null, pageNo, pageSize);
	}

	

}
