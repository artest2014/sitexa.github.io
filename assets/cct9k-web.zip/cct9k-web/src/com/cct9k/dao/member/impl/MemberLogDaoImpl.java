package com.cct9k.dao.member.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.member.MemberLogDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.member.MemberLog;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class MemberLogDaoImpl extends BaseDaoImpl<MemberLog, String> implements MemberLogDao {
    @Override
    public String getSeqn() {
        String sql = " select s_memberLog.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }
    //得到会员的所有日志
	@Override
	public List<MemberLog> getAll() {
		return super.getAll();
	}
	@Override
	public Pagination getPage(String log_memberName, String log_memberinfo,
			String regDate, int pageNo, int pageSize) {
		Finder f = Finder.create("from MemberLog log where 1=1 ");
		if (!StringUtil.isEmpty(log_memberName)) {
			f.append(" and log.member.membername like '%'||:log_memberName||'%' ");
			f.setParam("log_memberName", log_memberName);
		}
		if (!StringUtil.isEmpty(log_memberinfo)) {
			f.append(" and log.content like '%'||:log_memberinfo||'%' ");
			f.setParam("log_memberinfo", log_memberinfo);
		}
		return find(f, pageNo, pageSize);
	}
	@Override
	public Pagination getMemberLog(String log_memberId, String log_memberinfo,
			String LogDate, int pageNo, int pageSize) {
		
		Finder f = Finder.create("from MemberLog log where 1=1 ");
		if (!StringUtil.isEmpty(log_memberId)) {
			f.append(" and log.member.memberid = '" + log_memberId + "'");
		}
		if (!StringUtil.isEmpty(log_memberinfo)) {
			f.append(" and log.content like '%'||:log_memberinfo||'%' ");
			f.setParam("log_memberinfo", log_memberinfo);
		}
		if (!StringUtil.isEmpty(LogDate)) {
			f.append(" and to_char(log.operationdate,'yyyy-MM-dd') ='"+LogDate+"' ");
		}
		f.append(" order by log.logid desc");
		System.out.println(f.toString());
		return find(f, pageNo, pageSize);
	}
	@Override
	public List<MemberLog> getMemberLog(Member member) {
		// TODO Auto-generated method stub
		String memberid= member.getMemberid();
		Finder f = Finder.create("from MemberLog log where log.member.memberid = '" + memberid + "'");
		f.setMaxResults(6);
		return find(f);
	}
    
}
