package com.cct9k.dao.member.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.member.MemberDeptDao;
import com.cct9k.entity.member.MemberDept;
import com.cct9k.entity.member.MemberExpansion;
import com.cct9k.util.common.StringUtil;

/**
 * 
 * <p>
 * Class Name: MemberDeptDaoImpl.
 * </p>
 * <p>
 * Description: 类功能说明
 * </p>
 * <p>
 * Sample: 该类的典型使用方法和用例
 * </p>
 * <p>
 * Author: chp
 * </p>
 * <p>
 * Date: 2013-6-25
 * </p>
 * <p>
 * Modified History: 修改记录，格式(Name) (Version) (Date) (Reason & Contents)
 * </p>
 */
@Repository
public class MemberDeptDaoImpl extends BaseDaoImpl<MemberDept, String>
		implements MemberDeptDao {
	public Pagination getPage(String memberId, String manager, String deptname,
			int pageNo, int pageSize) {
		Finder f = Finder.create("from MemberDept md where 1=1 ");

		if (!StringUtil.isEmpty(memberId)) {
			f.append(" and md.orgid =:orgid ");
			f.setParam("orgid", memberId);
		}
		if (!StringUtil.isEmpty(manager)) {
			f.append(" and md.manager like '%'||:manager||'%' ");
			f.setParam("manager", manager);
		}
		if (!StringUtil.isEmpty(deptname)) {
			f.append(" and md.deptname like '%'||:deptname||'%' ");
			f.setParam("deptname", deptname);
		}
		f.append(" order by md.deptid desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public void update(MemberDept entity) {
		super.update(entity);
	}

	@Override
	public String save(MemberDept entity) {
		entity.setDeptid(getSeqn());
		return super.save(entity);
	}

	@Override
	public void delete(String id) {
		super.delete(id);
	}

	public Pagination getMemberByDeptId(String deptId, String memberName,
			int pageNo, int pageSize) {
		// StringBuffer sb = new StringBuffer();
		// String
		// sql="select m.membername,m.membertype,m.mobileno,m.email,me.jobnumber,me.jobposition,m.memberid"
		// +" from t_member m ,t_member_dept md,t_member_expansion me where me.deptid=md.deptid and me.memberid=m.memberid";
		// sb.append(sql);
		// sb.append(" and md.deptid='"+deptId+"'");
		// sb.append(" and m.membername like '%"+memberName+"%'");
		// sb.append(" order by m.memberid desc");
		// return this.findSql(sb.toString(), pageNo, pageSize);
		Finder f = Finder
				.create("from Member m where m.memberid in(select me.memberid from MemberExpansion me where me.deptid="
						+ deptId + ")");
		if (!StringUtil.isEmpty(memberName)) {
			f.append(" and m.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", memberName);
		}
		return find(f, pageNo, pageSize);
	}

	public Pagination getNotAddMember(String memberName, int pageNo,
			int pageSize) {
		Finder f = Finder
				.create("select m  from Member m where m.memberid not in(select ex.memberid from MemberExpansion ex)");
		if (!StringUtil.isEmpty(memberName)) {
			f.append(" and m.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", memberName);
		}
		f.append(" order by m.memberid desc");
		return find(f, pageNo, pageSize);
	}

	public boolean saveDeptMember(MemberExpansion me) {
		String sql = " insert into t_member_expansion (MEMBERID, DEPTID, JOBNUMBER, GENDER, JOBPOSITION)"
				+ " values (?, ?, ?, ?, ?)";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, me.getMemberid());
		query.setString(1, me.getDeptid());
		query.setString(2, me.getJobnumber());
		query.setString(3, me.getGender());
		query.setString(4, me.getJobposition());
		int result = query.executeUpdate();
		if (result > 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean deleteDeptMember(String memberId, String deptId) {
		String sql = "delete from t_member_expansion where memberid=? and deptid=?";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, memberId);
		query.setString(1, deptId);
		int result = query.executeUpdate();
		if (result > 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean delDeptMember(String deptId) {
		String sql = "delete from t_member_expansion where  deptid=?";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, deptId);
		int result = query.executeUpdate();
		if (result > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public Pagination getChildById(String parentId, String memberName,
			int pageNo, int pageSize) {
		Finder f = Finder.create("select m  from Member m where m.parent="
				+ parentId + " and m.memberid not in"
				+ "(select distinct(md.orgid) from MemberDept md )");
		if (!StringUtil.isEmpty(memberName)) {
			f.append(" and m.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", memberName);
		}
		f.append(" order by m.memberid desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public MemberDept get(String id) {
		return super.get(id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDeptIdByMemberId(String memberId) {
		String hql = "select md.objectid from MemberDept md where md.manager=?";
		return getSession().createQuery(hql).setParameter(0, memberId).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDeptIdByMemberIdAndObjectType(String memberId,
			String objectTypeId) {
		String hql = "select md.objectid from MemberDept md where md.orgid=? and md.objecttype=?";
		return getSession().createQuery(hql).setParameter(0, memberId)
				.setParameter(1, objectTypeId).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MemberDept> getMemberDeptByMemberIdAndObjectType(
			String memberId, String objectTypeId) {
		String hql = "select md from MemberDept md where md.orgid=? and md.objecttype=? and md.enableflag=1";
		return getSession().createQuery(hql).setParameter(0, memberId)
				.setParameter(1, objectTypeId).list();
	}

	@Override
	public void updateDeptIdByNewId(String originalId, String newId) {
		String hql = "update MemberDept set md.objectid=? where md.objectid=?";
		getSession().createQuery(hql).setParameter(0, newId).setParameter(1, originalId).executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getMemberIdByRoleIdAndDeptId(String roleId,String objectId) {
		String sql = "select distinct(tmr.memberid) " +
					 "from t_member_role tmr,t_member_dept tmd " +
				     "where " +
				     "tmr.roleid=? and tmd.objectid=? " +
				     "and tmd.enableflag=1 " +
				     "and tmr.memberid=tmd.orgid";
		List<String> strings = getSession().createSQLQuery(sql).setParameter(0, roleId).setParameter(1, objectId).list();
		return strings;
	}

	@Override
	public MemberDept getByOrgidAndObjectid(String orgid, String objectid) {
		String hql = "select md from MemberDept md where md.orgid=? and md.objectid=?";
		return (MemberDept) getSession().createQuery(hql).setParameter(0, orgid).setParameter(1, objectid).uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MemberDept> getByObjectid(String objectid) {
		String hql = "select md from MemberDept md where md.objectid='"+objectid+"'";
		return getSession().createQuery(hql).list();
	}
}