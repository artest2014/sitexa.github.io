/**
 * <p>Class Name: CustomerProductDao.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: yangkun</p>
 * <p>Date: 2013-10-16</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.customer;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.CustomerProduct;

/**
 * @author yangkun
 *
 */
public interface CustomerProductDao extends BaseDao<CustomerProduct, String> {
	public Pagination getPage(Map<String, Object> paraMap,int pageNo, int pageSize);
	/**
	 * 
	 * 描述: 查询可用的客户产品
	 * @param customerid 客户id
	 * @return
	 */
	 public List<CustomerProduct> getEnableProductListByCustomerid(String customerid);
	 
	 //直销产品下架调用接口
	 public List<CustomerProduct> getCustomerProductByProduct(String productId);
}
