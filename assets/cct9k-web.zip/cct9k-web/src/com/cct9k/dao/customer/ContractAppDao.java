package com.cct9k.dao.customer;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.ContractApp;

//author:tianyuan
public interface ContractAppDao extends BaseDao<ContractApp,String>{
   public Pagination getContractAppFirstPage(String saller,String contractname,String membername,String appstatuscatid,String signcontracttype,int pageNo, int pageSize);
   
   public Pagination getFinanceContractAppPage(String saller,String signcontracttype,String contractname,String membername,String signapporg,String statetime,String endtime,String appstatuscatid, int pageNo,
			int pageSize);
   
   public Pagination getManagerContractAppPage(String saller,String signcontracttype,String contractname,String membername,String signapporg,String statetime,String endtime,String appstatuscatid, int pageNo,
			int pageSize);
}
