package com.cct9k.dao.customer.impl;

import java.math.BigDecimal;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.ConsultantDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.Consultant;
import com.cct9k.util.common.StringUtil;

/**
 * 客户咨询持久层实现类
 * <p>Class Name: ConsultantDaoImpl.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: chp</p>
 * <p>Date: 2013-6-14</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
@Repository
public class ConsultantDaoImpl extends BaseDaoImpl<Consultant, String> implements ConsultantDao{
	@Override
	public Pagination getPage(String contents,String startTime, String endTime, String memberId,String seller,String status,int pageNo,
			int pageSize){
		Finder f = Finder.create("from Consultant cs where 1=1 ");
		if (!StringUtil.isEmpty(contents)) {
			f.append(" and cs.contents like '%'||:contents||'%' ");
			f.setParam("contents", contents);
		}
		if (!StringUtil.isEmpty(memberId)) {
			f.append(" and cs.customer = "+memberId);
		}
		if (!StringUtil.isEmpty(seller)) {
			f.append(" and cs.seller = "+seller);
		}
		if (!StringUtil.isEmpty(status)) {
			f.append(" and cs.status = "+status);
		}
		if (!StringUtil.isEmpty(startTime)) {
			f.append(" and cs.createdate >=to_date('"+startTime+"','yyyy-MM-dd HH24:mi:ss') ");
		}
		if (!StringUtil.isEmpty(endTime)) {
			f.append(" and cs.createdate <=to_date('"+endTime+"','yyyy-MM-dd HH24:mi:ss') ");
		}
		f.append(" and cs.consultant is null");
		f.append(" order by cs.createdate desc");
		return find(f, pageNo, pageSize);
	}
	
	public boolean deleteConsultant(String consultantId,String parentId) {
        String sql = "delete from t_consultant  where consultantid=? or parentid=? ";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, consultantId);
        query.setString(1, parentId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }
	
	
	@Override
	public Pagination getPage(String contents,String startTime, String endTime,String parentId ,int pageNo,
			int pageSize){
		Finder f = Finder.create("from Consultant cs where 1=1 ");
		if (!StringUtil.isEmpty(contents)) {
			f.append(" and cs.contents like '%'||:contents||'%' ");
			f.setParam("contents", contents);
		}
		if (!StringUtil.isEmpty(startTime)) {
			f.append(" and cs.createdate >=to_date('"+startTime+"','yyyy-MM-dd HH24:mi:ss') ");
		}
		if (!StringUtil.isEmpty(endTime)) {
			f.append(" and cs.createdate <=to_date('"+endTime+"','yyyy-MM-dd HH24:mi:ss') ");
		}
		if (!StringUtil.isEmpty(parentId)) {
			f.append(" and cs.consultant.consultantid ='"+parentId+"'");
		}
		f.append(" order by cs.createdate desc");
		return find(f, pageNo, pageSize);
	}
	
	@Override
	public Pagination getConsultantList(String costomer,String seller,String objectId,String objectType,int pageNo,
			int pageSize){
		Finder f = Finder.create("from Consultant cs where 1=1 ");
		if (!StringUtil.isEmpty(objectId)) {
			f.append(" and cs.objectid ='"+objectId+"'");
		}
		if (!StringUtil.isEmpty(objectType)) {
			f.append(" and cs.objecttype ='"+objectType+"'");
		}
		//判断是否是卖家查看评论，如果登陆会员id和线路分销商id不等，说明是一般卖家会员查看
		if(costomer!=seller){
		if (!StringUtil.isEmpty(costomer)) {
			f.append(" and cs.customer ='"+costomer+"'");
		}
		if (!StringUtil.isEmpty(seller)) {
			f.append(" and cs.seller ='"+seller+"'");
		 }
		}
		else{

			if (!StringUtil.isEmpty(seller)) {
				f.append(" and cs.seller ='"+seller+"'");
			 }		
			
		}
		f.append("  order by cs.createdate desc");
		return find(f, pageNo, pageSize);
	}
	
	@Override
	public boolean saveConsultant(Consultant cons) {
		String sql = " insert into t_consultant (CONSULTANTID, PARENTID, SELLER, CUSTOMER, OBJECTTYPE, OBJECTID, CONTENTS, CREATEDATE, MEMBERID, STATUS)"
				+ " values (?,?,?, ?, ?, ?, ?, sysdate, ?, ?)";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, getSeqn());
		if(null==cons.getConsultant()){
			   query.setString(1, "");
			}else{
			   query.setString(1, cons.getConsultant().getConsultantid());
			}
		query.setString(2, cons.getSeller());
		query.setString(3, cons.getCustomer());
		query.setString(4, cons.getObjecttype());
		query.setString(5, cons.getObjectid());
		query.setString(6, cons.getContents());
		query.setString(7, cons.getMemberid());
		query.setString(8, cons.getStatus());
		int result = query.executeUpdate();
		if (result > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean updateConsultant(String status,String replyId,String parentId) {
		String sql = " update t_consultant t set t.status=?,t.memberid=? where t.CONSULTANTID=?";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, status);
		query.setString(1, replyId);
		query.setString(2, parentId);
		int result = query.executeUpdate();
		if (result > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public Consultant get(String id) {
		return super.get(id);
	}
	
}
