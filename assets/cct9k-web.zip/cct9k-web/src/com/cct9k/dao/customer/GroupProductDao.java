package com.cct9k.dao.customer;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.GroupProduct;

public interface GroupProductDao  extends BaseDao<GroupProduct,String>{
	//author:tianyuan
	public Pagination getPaginationGroupProduct(String groupid,
			int pageNo, int pageSize);
	
	public GroupProduct getGroupProduct(String groupid,String productid);
}
