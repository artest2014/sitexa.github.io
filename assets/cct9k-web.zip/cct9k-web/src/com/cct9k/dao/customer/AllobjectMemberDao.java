package com.cct9k.dao.customer;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.view.AllobjectMember;

public interface AllobjectMemberDao extends BaseDao<AllobjectMember, String>{
 public AllobjectMember getByobjectidAndObjecttype(String objectid,String objecttype);
}
