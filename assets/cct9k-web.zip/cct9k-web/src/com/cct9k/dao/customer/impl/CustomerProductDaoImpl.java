/**
 * <p>Class Name: CustomerProductDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: yangkun</p>
 * <p>Date: 2013-10-16</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.customer.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.CustomerProductDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.CustomerProduct;
import com.cct9k.util.common.StringUtil;

/**
 * @author yangkun
 *
 */
@Repository
public class CustomerProductDaoImpl extends BaseDaoImpl<CustomerProduct, String>  implements  CustomerProductDao{
	
	
	  public Pagination getPage(Map<String, Object> paraMap,int pageNo, int pageSize){
		  Finder r = Finder.create("from CustomerProduct model where 1=1");
		  Map<String, Object> paramMap = new HashMap<String, Object>();
		  if (paraMap != null){
				Set<String> paraSet = paraMap.keySet();
				Iterator<String> iter = paraSet.iterator();
				while(iter.hasNext()){
					String key = (String) iter.next();
					if ("productname".equals(key)){
						r.append(" and model.productname  like '%"+paraMap.get(key)+"%'");
					
					}
					if ("producttype".equals(key)){
						r.append(" and model.producttype like '%"+paraMap.get(key)+"%'");
				
					}
					if ("customerid".equals(key)){
						r.append(" and model.customer.customerid ="+paraMap.get(key)+"");
				
					}
					
				}
				r.append(" and model.isenable='1' order by model.productid desc");
				r.setParams(paramMap);
		  }

	       return find(r, pageNo, pageSize);
		
	  }
	  
public List<CustomerProduct> getEnableProductListByCustomerid(String customerid){
	    String hql=" from  CustomerProduct  c where c.customer.customerid='"+customerid+"' and c.isenable=1 and ( c.product is not null or c.product!='') ";
	   return getListByHql(hql);
	  
      }


@Override
public List<CustomerProduct> getCustomerProductByProduct(String productId) {
	  String hql=" from  CustomerProduct  c where c.product='"+productId+"' and c.isenable='1'  ";
	   return getListByHql(hql);
}
}
