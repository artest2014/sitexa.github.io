package com.cct9k.dao.customer;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.Complain;

/**
 * 客户投诉持久层接口
 * <p>Class Name: ComplainDao.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: chp</p>
 * <p>Date: 2013-6-14</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
public interface ComplainDao extends BaseDao<Complain, String>{
	/**
	 * 描述: .投诉管理列表条件分页查询
	 * @param contents
	 * @param createTime
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-14
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-14               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getPage(String contents, String startTime,String endTime ,String memberId,String seller,String status,int pageNo, int pageSize);
	
	/**
	 * 描述: .根据complainId删除客户投诉
	 * @param complainId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-17
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-17               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean deleteComplain(String complainId,String parentId);
	

	/**
	 * 描述: .投诉详情
	 * @param contents
	 * @param startTime
	 * @param endTime
	 * @param parentId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-18
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-18               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getPage(String contents,String startTime, String endTime,String parentId ,int pageNo,
			int pageSize);
	
	/**
	 * 描述: .投诉
	 * @param cons
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-18
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-18               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public String saveComplain(Complain cons);
	
	/**
	 * 得到投诉实体
	 */
	public Complain get(String id);
	
	/**
	 * 描述: .更新父级的投诉咨询
	 * @param status
	 * @param replyId
	 * @param parentId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-18
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-18               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean updateComplain(String status,String replyId,String parentId);
	
	/**
	 * 
	 * 描述: 查询出要删除的投诉ComlainId字符串。用逗号隔开
	 * @param complainId
	 * @param parentId
	 * @return
	 * @author    yangkun
	 * date        2013-7-30
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-30          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	public String getComplainIdStr(String complainId,String parentId);
	
	
}
