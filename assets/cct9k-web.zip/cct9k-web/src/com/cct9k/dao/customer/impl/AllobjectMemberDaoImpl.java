package com.cct9k.dao.customer.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.customer.AllobjectMemberDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.view.AllobjectMember;

@Repository
public class AllobjectMemberDaoImpl extends BaseDaoImpl<AllobjectMember,String> implements AllobjectMemberDao{

	@Override
	public AllobjectMember getByobjectidAndObjecttype(String objectid,
			String objecttype) {
		String hql="from AllobjectMember t where t.objectid='"+objectid+"' and t.objecttype='"+objecttype+"'";
		return (AllobjectMember) getSession().createQuery(hql).uniqueResult();
	}

}
