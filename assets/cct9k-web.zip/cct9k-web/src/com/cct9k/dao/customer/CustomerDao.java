package com.cct9k.dao.customer;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.Customer;
import com.cct9k.entity.customer.CustomerProduct;

/**
 * Author: oscar peng <xnpeng@hotmail.com> Date: 13-8-10 Time: 下午1:37
 */
public interface CustomerDao extends BaseDao<Customer, String>
{

	public Pagination getPage(int pageNo, int pageSize, String customerName, String customertype, String mobileNo, String identityNo, String ownerId, String dicid);

	public List getCustomerList(String keyword, String reseller);

	public List checkIdentityNo(String ownerId, String identityNo, String customerType, String customerid, String identityTypeId);

	public List<Map<String, Object>> getCustomerListByType(String keyword, String identityNo, String reseller, String type, String customerId);

	/**
	 * 根据类型查找客户信息
	 * 
	 * @param keyword
	 * @param customerType
	 * @return
	 */
	public List<Customer> findByCustomerType(String keyword, String customerType, String memberid);

	/**
	 * 根据计划线路过滤查询
	 * 
	 * @param keyword
	 * @param customerType
	 * @param planid
	 * @return
	 */
	public List<Customer> findByCustomerByRoutFilter(String keyword, String customerType, String planid, String memberid);

	/**
	 * 根据customid查找产品
	 * 
	 * @param customid
	 * @return
	 */
	public List<CustomerProduct> findProductByCustomid(String customid);

	/**
	 * 
	 * 描述: 弹出框分页查询客户类型
	 * 
	 * @param keyword
	 * @param customerType
	 * @param memberid
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination findByCustomerType(String keyword, String customerType, String memberid, int pageNo, int pageSize);

	/**
	 * 
	 * 描述: 直销产品下架 修改分销的客户
	 * 
	 * @param ShopId
	 * @return
	 */
	public List<Customer> getCustomerByObjectId(String ShopId);

	/**
	 * 描述：客户名称唯一性验证
	 * 
	 * @param customername
	 * @param customertypeid
	 * @return
	 */
	public Customer getByCustomernameAndcustomertype(String customername, String customertypeid, String ownerid);

	/**
	 * 根据ownerid查询customer，
	 * 
	 * @param ownerId
	 * @param customerName 模糊查询，可为空
	 * @param isAvalidate true:可用；false：不可用
	 * @return
	 */
	public Pagination findCustomerByOwner(String ownerId, String customerName, boolean isAvalidate, int pageNo, int pageSize);

	/**
	 * 这才是真正的根据ownerid，客户类型查询customer，
	 * 
	 * @param ownerId
	 * @param customerName 模糊查询，可为空
	 * @param isAvalidate true:可用；false：不可用
	 * @return
	 */
	public Pagination findCustomerByType(String ownerId, String customerName, String customerType, boolean isAvalidate, int pageNo, int pageSize);

	public Pagination findCustomerByTypeJdbcImpl(String ownerId, String customerName, String customerType, boolean isAvalidate, int pageNo, int pageSize);

	/**
	 * 验证同一线路中的订单，游客是否唯一
	 * 
	 * @param identityTypeId 证件类型
	 * @param identityNo 证件号
	 * @param onsaleId 线路上架ID
	 * @return
	 */
	public Boolean isIdentityVisitor(String onsaleId, String identityNo, String identityTypeId);
}
