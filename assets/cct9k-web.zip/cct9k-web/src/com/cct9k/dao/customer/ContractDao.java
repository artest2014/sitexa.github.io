package com.cct9k.dao.customer;


import java.util.Date;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.Contract;
import com.cct9k.entity.member.Member;


public interface ContractDao extends BaseDao<Contract, String>{
  public Contract getContractName(String reseller,String memberid);
  
  public Pagination getContract(String memberid,String contractName,String contractid,String status,
			int pageNo, int pageSize); 
  
  public void updateContractByDate();
  
  public Pagination getPage(int pageNo, int pageSize);

  public Pagination searchByBuyer(Member buyer, String sellername, Date start, int pageNo, int pageSize);

}
