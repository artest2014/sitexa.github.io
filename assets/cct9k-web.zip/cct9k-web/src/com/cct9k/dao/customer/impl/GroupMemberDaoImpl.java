package com.cct9k.dao.customer.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.GroupMemberDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.GroupMember;
import com.cct9k.util.common.StringUtil;
/**
 * @author yics
 *         2013-06-07
 */
@Repository
public class GroupMemberDaoImpl extends BaseDaoImpl<GroupMember, String> implements GroupMemberDao{
	
	@Override
	public List getGroupMemberByAudit(String memberid) {
		String hql =" from " + GroupMember.class.getName() +" as model where model.vipgroup.reseller = '"+memberid +"' and model.status = '2'";
		List<GroupMember> list =getListByHql(hql);
		return list;

	}
	
	public GroupMember getGroupMemberByBuyer(String seller,String buyer,String groupType,String status,String quotaType) {
		List<GroupMember> vip_resultList = null;
		GroupMember gm = null;
		
		if(!StringUtil.isEmpty(buyer)){
			String vip_sql="select gm.* from T_Group_Member gm ,T_VIP_Group vg where gm.memberid='"+buyer+"' and vg.reseller='"+seller+"' " +
					"and gm.groupid=vg.groupid  and vg.grouptype='"+groupType+"' and gm.quotatype='"+quotaType+"' ";
			Query vip_query = this.getSession().createSQLQuery(vip_sql).addEntity(GroupMember.class);
			vip_resultList = vip_query.list();
		}
		
		if(vip_resultList!=null&&vip_resultList.size()>0){
			gm = vip_resultList.get(0);
		}
		
		return gm;
	}
	
	@Override
	public Pagination getPage(String memberName, String memberid,
			String status, int pageNo, int pageSize) {
		Finder f = Finder.create("from GroupMember groupMember where groupMember.vipgroup.reseller = '"+memberid +"' and groupMember.status.dictid = '"+status+"' ");
		if(!StringUtil.isEmpty(memberName)){
			f.append(" and groupMember.member.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", memberName);
		}
		f.append(" order by groupMember.joindate desc");
		return find(f, pageNo, pageSize);
	}
	@Override
	public Pagination getFirstPage(String memberName,String groupName,String status, String memberid,
			int pageNo, int pageSize) {
		Finder f = Finder.create("from GroupMember groupMember where groupMember.vipgroup.reseller = '"+memberid + "' ");
		if(!StringUtil.isEmpty(memberName)){
			f.append(" and groupMember.member.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", memberName);
		}
		if(!StringUtil.isEmpty(groupName)){
			f.append(" and groupMember.vipgroup.groupname like '%'||:groupName||'%' ");
			f.setParam("groupName", groupName);
		}
		if(!StringUtil.isEmpty(status)){
			f.append(" and groupMember.status.typeid =:status ");
			f.setParam("status", status);
		}
		f.append(" order by groupMember.joindate desc");
		return find(f, pageNo, pageSize);
	}
	//查询客户名称
	public Pagination getgmPage(String reseller,int pageNo, int pageSize){
		Finder r =Finder.create("from GroupMember gm where  1=1");
		if (!StringUtil.isEmpty(reseller)) {
			r.append(" and gm.vipgroup.reseller =:reseller ");
			r.setParam("reseller", reseller);
		} 
        return find(r, pageNo, pageSize);
	}

	@Override
	public Pagination getGroupMemberPage(String groupid,String membername, int pageNo,
			int pageSize) {
		Finder f =Finder.create("from GroupMember gm where  groupid='"+groupid+"'");
		if (!StringUtil.isEmpty(membername)) {
			f.append(" and gm.member.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", membername);
		} 
        return find(f, pageNo, pageSize);
	}

	@Override
	public GroupMember getByMemberId(String memberid, String membername) {
		String hql="from GroupMember groupMember where groupMember.vipgroup.reseller = '"+memberid +"' and groupMember.member.membername= '"+membername+"' ";
		GroupMember groupmember=(GroupMember) getSession().createQuery(hql).uniqueResult();
		return groupmember;
	}
	
	@Override
	public GroupMember getByMemberIdType(String memberid, String dictid) {
		String hql="from GroupMember groupMember where groupMember.member.memberid = '"+memberid +"' and groupMember.quotatype.dictid= '"+dictid+"' ";
		GroupMember groupmember=(GroupMember) getSession().createQuery(hql).uniqueResult();
		return groupmember;
	}

	@Override
	public Pagination getGroupMemberPageByReseller(String reseller,String membername,String groupname,String typeid,int pageNo, int pageSize) {
		Finder f =Finder.create("from GroupMember groupMember where  groupMember.vipgroup.reseller='"+reseller+"'and groupMember.vipgroup.grouptype.typeid='"+typeid+"'");
		if (!StringUtil.isEmpty(membername)) {
			f.append(" and groupMember.member.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", membername);
		} 
		if (!StringUtil.isEmpty(groupname)) {
			f.append(" and groupMember.vipgroup.groupname like '%'||:groupName||'%' ");
			f.setParam("groupName", groupname);
		}
		return find(f, pageNo, pageSize);
	}

	@Override
	public GroupMember getGroupMemberByGroupidAndBuyerId(String groupid,
			String buyerid) {
		String hql="from GroupMember groupMember where groupMember.vipgroup.groupid = '"+groupid +"' and groupMember.member.memberid= '"+buyerid+"' ";
		GroupMember groupMember=(GroupMember) getSession().createQuery(hql).uniqueResult();
		return groupMember;
	}

	@Override
	public GroupMember getToCheck(String reseller, String memberid,
			String typeid) {
		String hql="from GroupMember groupMember where  groupMember.vipgroup.reseller='"+reseller+"'and groupMember.vipgroup.grouptype.typeid='"+typeid+"'and groupMember.member.memberid='"+memberid+"'";
		GroupMember groupMember=(GroupMember) getSession().createQuery(hql).uniqueResult();
		return groupMember;
	}

	@Override
	public GroupMember findBillDebt(String orderType, String receiver,
			String payer) {
		String hql="from GroupMember groupMember where  groupMember.vipgroup.reseller=:receiver and groupMember.vipgroup.grouptype.dictid= :orderType and groupMember.member.memberid=:payer";
		GroupMember groupMember=(GroupMember) getSession().createQuery(hql)
				.setParameter("receiver", receiver)
				.setParameter("orderType", orderType)
				.setParameter("payer", payer).uniqueResult();
		return groupMember;
	}

	@Override
	public void updateQuotaused(String receiver, String payer, String grouptype, float amount) {
		String sql = "update t_group_member t set t.quotaused = t.quotaused-:quotaused where t.memberid=:memberid and t.groupid in (select g.groupid from T_VIP_GROUP g where g.reseller=:reseller and g.grouptype=:grouptype)";
		getSession().createSQLQuery(sql).setParameter("quotaused", amount)
			.setParameter("memberid", payer)
			.setParameter("reseller", receiver)
			.setParameter("grouptype", grouptype).executeUpdate();
	}

	@Override
	public GroupMember getSupplierVip(String reseller,String memberid,String typeid){
		String hql="from GroupMember groupMember where  groupMember.vipgroup.reseller='"+reseller+"'and groupMember.vipgroup.grouptype.typeid='"+typeid+"'and groupMember.member.memberid='"+memberid+"'";
		GroupMember groupMember=(GroupMember) getSession().createQuery(hql).uniqueResult();
		return groupMember;
	}
	
	

}
