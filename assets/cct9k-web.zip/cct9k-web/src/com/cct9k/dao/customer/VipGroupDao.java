package com.cct9k.dao.customer;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.VipGroup;

public interface VipGroupDao  extends BaseDao<VipGroup,String>{
	
	 public Pagination getPaginationVipGroup(String reseller,
			int pageNo, int pageSize);
	
	 public VipGroup getByVipGroupname(String groupname,String memberid);
	 
	 public VipGroup getByResellerGroupmember(String reseller,String groupmember,String grouptype);
	 
	 public List<VipGroup> getByReseller(String reseller,String typeid);
	 
	 public Pagination getPaginationVipGroupByType(String reseller,String typeid,
				int pageNo, int pageSize);
	 
	 public VipGroup getByVipGroupnameAndType(String groupname,String memberid,String typeid);
	 
	 public float getRateByGroupOrProduct(String seller,String buyer,String productId,String groupType,String status);
	 
	
}
   