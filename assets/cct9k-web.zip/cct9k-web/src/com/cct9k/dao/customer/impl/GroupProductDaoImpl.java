package com.cct9k.dao.customer.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.GroupProductDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.GroupProduct;

@Repository
public class GroupProductDaoImpl extends BaseDaoImpl<GroupProduct, String> implements GroupProductDao{

	@Override
	public Pagination getPaginationGroupProduct(String groupid, int pageNo,
			int pageSize) {
		Finder f = Finder.create("from GroupProduct groupproduct where groupid = '"
				+ groupid + "' ");
		return find(f, pageNo, pageSize);
	}

	@Override
	public GroupProduct getGroupProduct(String groupid, String productid) {
		String hql="from GroupProduct groupproduct where groupproduct.vipgroup.groupid = '"+groupid +"' and groupproduct.productid= '"+productid+"' ";
		GroupProduct groupproduct=(GroupProduct) getSession().createQuery(hql).uniqueResult();
		return groupproduct;
	}

}
