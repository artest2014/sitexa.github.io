package com.cct9k.dao.customer.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.ComplainDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.Complain;
import com.cct9k.entity.customer.ReComplain;
import com.cct9k.util.common.StringUtil;

/**
 * 客户投诉持久层实现类
 * <p>Class Name: ComplainDaoImpl.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: chp</p>
 * <p>Date: 2013-6-14</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
@Repository
public class ComplainDaoImpl extends BaseDaoImpl<Complain, String> implements ComplainDao {
	@Override
	public Pagination getPage(String contents, String startTime,String endTime ,String memberId,String seller,String status,int pageNo, int pageSize) {
		String where="";
		if (!StringUtil.isEmpty(contents)) {
			where+="and  contents like '%"+contents+"%'";
		}
		if (!StringUtil.isEmpty(startTime)) {
			where+=" and createdate >=to_date('"+startTime+"','yyyy-MM-dd HH24:mi:ss') ";
		}
		if (!StringUtil.isEmpty(endTime)) {
			where+=" and createdate <=to_date('"+endTime+"','yyyy-MM-dd HH24:mi:ss') ";
		}
		if (!StringUtil.isEmpty(status)) {
			where+=" and status = "+status;
		}
		if (!StringUtil.isEmpty(memberId)) {
			where+=" and T_COMPLAIN.CUSTOMER = "+memberId;
		}
		if (!StringUtil.isEmpty(seller)) {
			where+=" and seller = "+seller;
		}
	
		String sql="select complainid,parentid,seller,T_COMPLAIN.ObjectType as t_object,T_COMPLAIN.ObjectID as t_objectid,"+
				" customer,MAX(TO_CHAR(\"CONTENTS\")),member,status,createdate,wm_concat(picid) as picidStr,wm_concat(picurl) as picStr from T_COMPLAIN "+
				" left JOIN T_PICTURE on T_COMPLAIN.COMPLAINID=T_PICTURE.OBJECTID where  1=1 and parentid is null  "+ where+
				  "  group by complainid, parentid,seller,customer,T_COMPLAIN.ObjectType,T_COMPLAIN.ObjectID,member,status,createdate  ";
		sql+=" order by createdate desc";
		return findSql(sql, pageNo, pageSize);
		
	}
	
	public boolean deleteComplain(String complainId,String parentId) {
        String sql = "delete from t_complain  where complainid=? or parentid=? ";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, complainId);
        query.setString(1, parentId);
        int result = query.executeUpdate();
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }
	
	@Override
	public Pagination getPage(String contents,String startTime, String endTime,String parentId ,int pageNo,
			int pageSize){
		//Finder f = Finder.create("from Complain cs where 1=1 ");
		String where="";
		if (!StringUtil.isEmpty(contents)) {
			where+="and  contents like '%"+contents+"%'";
		}
		if (!StringUtil.isEmpty(startTime)) {
			where+=" and createdate >=to_date('"+startTime+"','yyyy-MM-dd HH24:mi:ss') ";
		}
		if (!StringUtil.isEmpty(endTime)) {
			where+=" and createdate <=to_date('"+endTime+"','yyyy-MM-dd HH24:mi:ss') ";
		}
		if (!StringUtil.isEmpty(parentId)) {
			where+=" and parentid ='"+parentId+"'";
		}
		String sql="select complainid,parentid,seller,T_COMPLAIN.ObjectType as t_object,T_COMPLAIN.ObjectID as t_objectid,"+
				" customer,MAX(TO_CHAR(\"CONTENTS\")),member,status,createdate,wm_concat(picid) as picidStr,wm_concat(picurl) as picStr from T_COMPLAIN "+
				" left JOIN T_PICTURE on T_COMPLAIN.COMPLAINID=T_PICTURE.OBJECTID where  1=1 "+ where+
				  " group by complainid, parentid,seller,customer,T_COMPLAIN.ObjectType,T_COMPLAIN.ObjectID,member,status,createdate  ";
		sql+=" order by createdate desc";
		return findSql(sql, pageNo, pageSize);
	}
	

	
	public String getSeqn() {
        String sql = " select s_public.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }
	
	@Override
	public String saveComplain(Complain cons) {
		String sql = " insert into t_complain (complainid, PARENTID, SELLER, CUSTOMER, OBJECTTYPE, OBJECTID, CONTENTS, CREATEDATE, MEMBER, STATUS)"
				+ " values (?,?,?, ?, ?, ?, ?, sysdate, ?, ?)";
		String Seqn=getSeqn();
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, Seqn);
		if(null==cons.getComplain()){
			   query.setString(1, "");
			}else{
			   query.setString(1, cons.getComplain().getComplainid());
			}
		query.setString(2, cons.getSeller());
		query.setString(3, cons.getCustomer());
		query.setString(4, cons.getObjecttype());
		query.setString(5, cons.getObjectid());
		query.setString(6, cons.getContents());
		query.setString(7, cons.getMember());
		query.setString(8, cons.getStatus());
		int result = query.executeUpdate();
		if (result > 0) {
			return Seqn;
		} else {
			
			return "0";
		}
	}
	
	public boolean updateComplain(String status,String replyId,String parentId) {
		String sql = " update t_complain t set t.status=?,t.member=? where t.complainid=?";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, status);
		query.setString(1, replyId);
		query.setString(2, parentId);
		int result = query.executeUpdate();
		if (result > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public Complain get(String id) {
		return super.get(id);
	}

	
	@Override
	public String getComplainIdStr(String complainId, String parentId) {
		  String sql = " select wm_concat(complainid) from T_COMPLAIN where complainid=? or parentid=?";
		  Query query = this.getSession().createSQLQuery(sql);
	        query.setString(0, complainId);
	        query.setString(1, parentId);
	        String result=query.list().get(0).toString();
	        return result;
	}
}
