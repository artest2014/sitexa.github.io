package com.cct9k.dao.customer.impl;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.ContractDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.Contract;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

@Repository
public class ContractDaoimpl extends BaseDaoImpl<Contract, String> implements
		ContractDao {

	@Override
	public Contract getContractName(String reseller, String memberid) {
		String hql = "from Contract contract where seller = '" + reseller
				+ "' and buyer = '" + memberid + "' ";
		List<Contract> list = getListByHql(hql);
		if (list != null && list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}

	}

	@Override
	public Pagination getContract(String memberid, String contractName,
			String contractid,String status, int pageNo, int pageSize) {
		Finder f = Finder.create("from Contract contract where seller = '"
				+ memberid + "' ");
		if (!StringUtil.isEmpty(contractName)) {
			f.append(" and contract.contractname like '%'||:contractName||'%' ");
			f.setParam("contractName", contractName);
		}
		if (!StringUtil.isEmpty(contractid)) {
			f.append(" and contract.contractid like '%'||:contractid||'%' ");
			f.setParam("contractid", contractid);
		}
		if (!StringUtil.isEmpty(status)) {
			f.append(" and contract.status.typeid =:status");
			f.setParam("status", status);
		}
		f.append(" order by contract.signdate desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public void updateContractByDate() {
		String hql="update T_CONTRACT set status = '11012' where sysdate>enddate";
		super.updateBySQL(hql);
		
	}

	   @Override
	    public Pagination getPage(int pageNo, int pageSize) {
	        Finder r = Finder.create("from Contract model where 1=1");

	        r.append(" order by createdate desc");

	        return find(r, pageNo, pageSize);
	    }

	    @Override
	    public Pagination searchByBuyer(Member buyer, String sellername, Date start, int pageNo, int pageSize) {
	        Finder r = Finder.create("from Contract model where 1=1");

	        if (buyer != null) {
	            r.append(" and model.buyer.memberid=:memberid ");
	            r.setParam("memberid", buyer.getMemberid());
	        }

	        if (!StringUtil.isEmpty(sellername)) {
	            r.append(" and model.seller.memberPerson.realname like '%'||:name||'%' or  model.seller.memberOrgan.orgname like '%'||:name||'%' ");
	            r.setParam("name", sellername);
	        }

	        if (start != null) {
	            Date end = DateUtil.addDaysToDate(start, 1);
	            r.append(" and model.startdate >= :start and model.startdate < :end ");
	            r.setParam("start", start).setParam("end", end);
	        }

	        r.append(" order by model.startdate desc");

	        return find(r, pageNo, pageSize);
	    }

}
