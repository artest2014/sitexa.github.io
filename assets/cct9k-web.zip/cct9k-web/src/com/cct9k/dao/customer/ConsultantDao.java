package com.cct9k.dao.customer;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.Consultant;

/**
 * 客户咨询持久层接口
 * <p>Class Name: ConsultantDao.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: chp</p>
 * <p>Date: 2013-6-14</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
public interface ConsultantDao extends BaseDao<Consultant, String>{
	/**
	 * 描述: .咨询管理列表条件分页查询
	 * @param contents
	 * @param createTime
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-14
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-14               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getPage(String contents,String startTime, String endTime, String memberId,String seller,String status,int pageNo,
			int pageSize);
	
	/**
	 * 描述: .产品详情咨询列表
	 * @param objectId
	 * @param objectType
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-7-24
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-7-24               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getConsultantList(String costomer,String seller,String objectId,String objectType,int pageNo,
			int pageSize);
	
	/**
	 * 描述: .咨询详情
	 * @param contents
	 * @param startTime
	 * @param endTime
	 * @param parentId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-18
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-18               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public Pagination getPage(String contents,String startTime, String endTime,String parentId ,int pageNo,
			int pageSize);
	
	/**
	 * 描述: .根据咨询ID以及父ID为此ID的客户咨询进行删除
	 * @param consultantId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-17
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-17               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean deleteConsultant(String consultantId,String parentId);
	
	/**
	 * 描述: .咨询
	 * @param cons
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-18
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-18               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean saveConsultant(Consultant cons);
	
	/**
	 * 得到咨询实体
	 */
	public Consultant get(String id);
	
	/**
	 * 描述: .更新父级的客户咨询
	 * @param status
	 * @param replyId
	 * @param parentId
	 * @return
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-6-18
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-6-18               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean updateConsultant(String status,String replyId,String parentId);
}
