package com.cct9k.dao.customer;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.customer.GroupMember;
/**
 * @author yics
 *         2013-06-07
 */
public interface GroupMemberDao  extends BaseDao<GroupMember, String>{
	public List getGroupMemberByAudit(String memberid);
	public Pagination getPage(String memberName, String memberid,
			String status, int pageNo, int pageSize);
	 // 客户管理首页
	public Pagination getFirstPage(String memberName,String groupName,String status, String memberid,
			int pageNo, int pageSize);
	//查询客户名称
	public Pagination getgmPage(String reseller,int pageNo, int pageSize);
	
	//根据分组ID查询
	public Pagination getGroupMemberPage(String groupid,String membername,int pageNo, int pageSize);
	
	//根据membername查询客户
	public GroupMember getByMemberId(String memberid,String membername);
	
	public Pagination getGroupMemberPageByReseller(String reseller,String membername,String groupname,String typeid,int pageNo, int pageSize);
	
	public GroupMember getGroupMemberByGroupidAndBuyerId(String groupid,String buyerid);
	
	public GroupMember getByMemberIdType(String memberid, String dictid);
	
	public GroupMember getToCheck(String reseller,String memberid,String typeid);
	
	GroupMember findBillDebt(String orderType, String receiver, String payer);
	
	void updateQuotaused(String receiver, String payer, String grouptype, float amount);
	/**
	 * 得到当前登陆者memberid,在reseller那的会员等级
	 * @param reseller
	 * @param memberid
	 * @param typeid
	 * @return GroupMember
	 */
	public GroupMember getSupplierVip(String reseller,String memberid,String typeid);
	
	public GroupMember getGroupMemberByBuyer(String seller,String buyer,String groupType,String status,String quotaType) ;
}
 