package com.cct9k.dao.customer.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.VipGroupDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.VipGroup;
import com.cct9k.util.common.StringUtil;


@Repository
public class VipGroupDaoImpl extends BaseDaoImpl<VipGroup,String> implements VipGroupDao{

	@Override
	public Pagination getPaginationVipGroup(String reseller, int pageNo,
			int pageSize) {
		Finder f =Finder.create("from VipGroup where reseller='"+reseller+ "'");
		return find(f, pageNo, pageSize);
	}

	@Override
	public VipGroup getByVipGroupname(String groupname,String memberid) {
		String hql = "from VipGroup vipgroup where groupname ='" + groupname+"' and vipgroup.reseller= '"+memberid+"' ";
		VipGroup vipgroup=(VipGroup) getSession().createQuery(hql).uniqueResult();
		return vipgroup;
	}

	@Override
	public VipGroup getByResellerGroupmember(String reseller, String groupmember,String grouptype) {
		String sql = "select v.* from t_vip_group v where v.reseller='"+reseller+"'and v.grouptype='"+grouptype+"' and exists(select 1 from t_group_member t where v.groupid=t.groupid and t.memberid='"+groupmember+"')";
		VipGroup  vipGroup=(VipGroup)getSession().createSQLQuery(sql).addEntity(VipGroup.class).uniqueResult();
		return vipGroup;
	}

	@Override
	public List<VipGroup> getByReseller(String reseller,String typeid) {
		String hql="from VipGroup vipGroup where vipGroup.reseller='"+reseller+ "'and vipGroup.grouptype.typeid='"+typeid+"'order by vipGroup.groupname asc ";
		List<VipGroup> vipGroups=getListByHql(hql);
		return vipGroups;
	}

	@Override
	public Pagination getPaginationVipGroupByType(String reseller,
			String typeid, int pageNo, int pageSize) {
		Finder f =Finder.create("from VipGroup vipgroup where vipgroup.reseller='" + reseller+"' and vipgroup.grouptype.typeid= '"+typeid+"' order by vipgroup.enableflag desc,vipgroup.groupname");
		return find(f, pageNo, pageSize);
	}

	@Override
	public VipGroup getByVipGroupnameAndType(String groupname, String memberid,
			String typeid) {
		String hql = "from VipGroup vipgroup where vipgroup.groupname ='" + groupname+"' and vipgroup.reseller= '"+memberid+"'and vipgroup.grouptype.typeid='"+typeid+"'";
		VipGroup vipgroup=(VipGroup) getSession().createQuery(hql).uniqueResult();
		return vipgroup;
	}
	public float getRateByGroupOrProduct(String seller,String buyer,String productId,String groupType,String status) {
		List<String> vip_resultList = null;
		List<String> vip_pro_resultList = null;
		
		if(!StringUtil.isEmpty(buyer)){
			String vip_sql="select vg.rate from T_Group_Member gm ,T_VIP_Group vg where gm.memberid='"+buyer+"' and vg.reseller='"+seller+"' and gm.groupid=vg.groupid  and vg.grouptype='"+groupType+"'  ";
			Query vip_query = this.getSession().createSQLQuery(vip_sql);
			vip_resultList = vip_query.list();
		}
		if(!StringUtil.isEmpty(buyer)&&!StringUtil.isEmpty(productId)){
			String vip_pro_sql="select gp.discountrate from T_Group_Member gm ,T_VIP_Group vg,T_Group_Product gp where gm.memberid='"+buyer+"' " +
					" and vg.reseller='"+seller+"' and gm.groupid=vg.groupid and gp.groupid=gm.groupid and gp.productid='"+productId+"'  and vg.grouptype='"+groupType+"'  ";
			Query vip_pro_query = this.getSession().createSQLQuery(vip_pro_sql);
			vip_pro_resultList = vip_pro_query.list();
		}
		
		String rate="1";
		if(vip_pro_resultList != null && vip_pro_resultList.size() > 0){
			Object o_rate = (Object)vip_pro_resultList.get(0);
			rate = o_rate.toString();
		}else if(vip_resultList != null && vip_resultList.size() > 0){
			Object o_rate = (Object) vip_resultList.get(0);
			rate = o_rate.toString();
		}
		return Float.parseFloat(rate);
	}
	
}
