package com.cct9k.dao.customer.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.ContractAppDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.ContractApp;
import com.cct9k.util.common.StringUtil;


@Repository
public class ContractAppDaoImpl extends BaseDaoImpl<ContractApp,String> implements ContractAppDao{

	@Override
	public Pagination getContractAppFirstPage(String saller,String contractname,String membername,String appstatuscatid,String signcontracttype, int pageNo,
			int pageSize) {
		Finder f = Finder.create("from ContractApp contractApp where contractApp.seller.memberid = '"+saller + "'and contractApp.signcontracttype.typeid='"+signcontracttype+"'");
		if(!StringUtil.isEmpty(contractname)){
			f.append(" and contractApp.contractname like '%'||:contractName||'%' ");
			f.setParam("contractName", contractname);
		}
		if(!StringUtil.isEmpty(membername)){
			f.append(" and contractApp.buyer.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", membername);
		}
		if(!StringUtil.isEmpty(appstatuscatid)){
			f.append(" and contractApp.appstatuscatid.typeid =:appStatuscatid ");
			f.setParam("appStatuscatid", appstatuscatid);
		}
		f.append(" order by contractApp.updatedate desc");
		return find(f, pageNo, pageSize);
	}
	
	@Override
	public Pagination getFinanceContractAppPage(String saller,String signcontracttype,String contractname,String membername,String statetime,String endtime,String appstatuscatid,String signapporg, int pageNo,
			int pageSize) {
		Finder f = Finder.create("from ContractApp contractApp where contractApp.seller.parent.memberid = '"+saller + "' or contractApp.seller.memberid = '"+saller + "' and contractApp.signcontracttype.dictid='"+signcontracttype+"' ");
		if(!StringUtil.isEmpty(contractname)){
			f.append(" and contractApp.contractname like '%'||:contractName||'%' ");
			f.setParam("contractName", contractname);
		}
		if(!StringUtil.isEmpty(membername)){
			f.append(" and contractApp.buyer.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", membername);
		}
		if(!StringUtil.isEmpty(signapporg)){
			f.append(" and contractApp.signapporg.departmentId like '%'||:signapporg||'%' ");
			f.setParam("signapporg", signapporg);
		}
		if(!StringUtil.isEmpty(appstatuscatid)){
			f.append(" and contractApp.appstatuscatid.dictid =:appStatuscatid ");
			f.setParam("appStatuscatid", appstatuscatid);
		}
		if(!StringUtil.isEmpty(statetime)){
			f.append(" and contractApp.createdate >=:statetime ");
			f.setParam("statetime", java.sql.Date.valueOf(statetime));
		}
		if(!StringUtil.isEmpty(endtime)){
			f.append(" and contractApp.createdate <=:endtime ");
			f.setParam("endtime", java.sql.Date.valueOf(endtime));
		}
		f.append(" order by contractApp.updatedate desc");
		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination getManagerContractAppPage(String saller,String signcontracttype,
			String contractname, String membername, String signapporg,
			String statetime, String endtime, String appstatuscatid,
			int pageNo, int pageSize) {
		Finder f = Finder.create("from ContractApp contractApp where contractApp.seller.memberid = '"+saller + "'and contractApp.signcontracttype.typeid='"+signcontracttype+"' ");
		if(!StringUtil.isEmpty(contractname)){
			f.append(" and contractApp.contractname like '%'||:contractName||'%' ");
			f.setParam("contractName", contractname);
		}
		if(!StringUtil.isEmpty(membername)){
			f.append(" and contractApp.buyer.membername like '%'||:memberName||'%' ");
			f.setParam("memberName", membername);
		}
		if(!StringUtil.isEmpty(signapporg)){
			f.append(" and contractApp.signapporg.departmentId like '%'||:signapporg||'%' ");
			f.setParam("signapporg", signapporg);
		}
		if(!StringUtil.isEmpty(appstatuscatid)){
			f.append(" and contractApp.appstatuscatid.dictid =:appStatuscatid ");
			f.setParam("appStatuscatid", appstatuscatid);
		}
		if(!StringUtil.isEmpty(statetime)){
			f.append(" and contractApp.createdate >=:statetime ");
			f.setParam("statetime", java.sql.Date.valueOf(statetime));
		}
		if(!StringUtil.isEmpty(endtime)){
			f.append(" and contractApp.createdate <=:endtime ");
			f.setParam("endtime", java.sql.Date.valueOf(endtime));
		}
		f.append(" order by contractApp.updatedate desc");
		return find(f, pageNo, pageSize);
	}

}
