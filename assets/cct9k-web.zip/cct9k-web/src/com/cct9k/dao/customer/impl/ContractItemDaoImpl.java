package com.cct9k.dao.customer.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.ContractItemDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.ContractItem;


@Repository
public class ContractItemDaoImpl extends BaseDaoImpl<ContractItem,String> implements ContractItemDao{

	@Override
	public Pagination getContractItem(String contractid, int pageNo,
			int pageSize) {
		Finder f = Finder.create("from ContractItem contractitem where contractid = '"
				+ contractid + "' ");
		return find(f, pageNo, pageSize);
	}

}
