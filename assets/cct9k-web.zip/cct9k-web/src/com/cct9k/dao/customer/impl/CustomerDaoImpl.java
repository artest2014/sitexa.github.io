package com.cct9k.dao.customer.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.Query;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.customer.CustomerDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.customer.Customer;
import com.cct9k.entity.customer.CustomerProduct;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.reseller.RouteGate;
import com.cct9k.util.common.StringUtil;

/**
 * Author: oscar peng <xnpeng@hotmail.com> Date: 13-8-10 Time: 下午1:37
 */
@Repository
public class CustomerDaoImpl extends BaseDaoImpl<Customer, String> implements CustomerDao
{

	@Override
	public Pagination getPage(int pageNo, int pageSize, String customerName, String customertype, String mobileNo, String identityNo, String ownerId, String dicid)
	{
		Finder r = Finder.create("from Customer model where 1=1");
		if (!StringUtil.isEmpty(customerName))
		{
			r.append(" and model.customername like '%" + customerName + "%'");
		}
		if (!StringUtil.isEmpty(mobileNo))
		{
			r.append(" and model.mobile = '" + mobileNo + "'");
		}
		if (!StringUtil.isEmpty(identityNo))
		{
			r.append(" and model.identityno = '" + identityNo + "'");
		}
		if (!StringUtil.isEmpty(ownerId))
		{
			r.append(" and model.owner= '" + ownerId + "'");
		}
		if (!StringUtil.isEmpty(customertype))
		{
			r.append(" and model.customertype.dictid= '" + customertype + "'");
		}
		if (!StringUtil.isEmpty(dicid))
		{
			r.append(" and model.customertype.dictid!= '" + dicid + "'");
		}
		r.append(" and model.isenable='1' order by model.customerid desc");

		return find(r, pageNo, pageSize);
	}

	public List getCustomerList(String keyword, String reseller)
	{
		String sql = "select t.customerid,t.customername,t.mobile,t.gender,t.identityno,t.email from t_customer t where 1=1 and t.isenable='1' ";
		if (!StringUtil.isEmpty(keyword))
		{
			sql += " and t.customername like '%" + keyword + "%'";
		}
		if (!StringUtil.isEmpty(reseller))
		{
			sql += " and t.ownerid ='" + reseller + "' ";
		}
		Query query = this.getSession().createSQLQuery(sql);
		List resultList = query.list();
		if (resultList != null && resultList.size() > 0)
		{
			return resultList;
		}
		else
		{
			return null;
		}
	}

	/**
	 * 查询结果增加了证件类型
	 **/
	public List<Map<String, Object>> getCustomerListByType(String keyword, String identityNo, String reseller, String type, String customerId)
	{
		Map<String, Object> params = new HashMap<String, Object>();
		StringBuffer sql = new StringBuffer("SELECT T.CUSTOMERID,T.CUSTOMERNAME,T.MOBILE,T.GENDER,T.IDENTITYNO,T.EMAIL,T.IDENTITYTYPE FROM T_CUSTOMER T WHERE  T.ISENABLE='1' ");
		if (!StringUtil.isEmpty(keyword))
		{
			sql.append(" AND T.CUSTOMERNAME LIKE '%'||:KEYWORD||'%'");
			params.put("KEYWORD", keyword);
		}
		if (!StringUtil.isEmpty(identityNo))
		{
			sql.append(" AND T.IDENTITYNO LIKE '%'||:IDENTITYNO||'%'");
			params.put("IDENTITYNO", identityNo);
		}
		if (!StringUtil.isEmpty(type))
		{
			sql.append(" AND T.CUSTOMERTYPE = :TYPE");
			params.put("TYPE", type);
		}
		if (!StringUtil.isEmpty(reseller))
		{
			sql.append(" AND T.OWNERID =:RESELLER ");
			params.put("RESELLER", reseller);
		}
		if (!StringUtil.isEmpty(customerId))
		{
			sql.append(" AND T.CUSTOMERID !=:CUSTOMERID ");
			params.put("CUSTOMERID", customerId);
		}
		Query query = getSession().createSQLQuery(sql.toString()).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		if (params != null && !params.isEmpty())
		{
			for (Entry<String, Object> entry : params.entrySet())
			{
				query.setParameter(entry.getKey(), entry.getValue());
			}
		}
		return query.list();
	}

	public List checkIdentityNo(String ownerId, String identityNo, String customerType, String customerid, String identityTypeId)
	{
		StringBuffer sql = new StringBuffer("SELECT T.* FROM T_CUSTOMER T WHERE  T.ISENABLE='1' AND T.OWNERID=:OWNERID AND T.IDENTITYNO=:IDENTITYNO");
		sql.append(" AND T.CUSTOMERTYPE=:CUSTOMERTYPE  AND  T.IDENTITYTYPE=:IDENTITYTYPEID");
		if (!StringUtil.isEmpty(customerid))
		{
			sql.append(" AND T.CUSTOMERID !=:CUSTOMERID ");
		}
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter("OWNERID", ownerId);
		query.setParameter("IDENTITYNO", identityNo);
		query.setParameter("CUSTOMERTYPE", customerType);
		query.setParameter("IDENTITYTYPEID", identityTypeId);
		if (!StringUtil.isEmpty(customerid))
		{
			query.setParameter("CUSTOMERID", customerid);
		}
		List resultList = query.list();
		return resultList;
	}

	/**
	 * 根据类型查找客户信息
	 * 
	 * @param keyword
	 * @param customerType
	 * @return
	 */
	public List<Customer> findByCustomerType(String keyword, String customerType, String memberid)
	{
		String hql = "from Customer c where   c.isenable='1' and c.customername like '%" + keyword + "%' and c.customertype=? and c.owner.memberid=?";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, customerType);
		query.setString(1, memberid);
		List<Customer> result = query.list();
		return result;
	}

	/**
	 * 根据计划线路过滤查询
	 * 
	 * @param keyword
	 * @param customerType
	 * @param planid
	 * @return
	 */
	public List<Customer> findByCustomerByRoutFilter(String keyword, String customerType, String planid, String memberid)
	{

		String hql = "from RouteGate a,Plan b where a.route.routeid=b.route.routeid and b.planid=? and a.customer.customertype=? and a.customer.customername like '%" + keyword + "%' and a.customer.owner.memberid=? and a.customer.isenable='1' ";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, planid).setString(1, customerType);
		query.setString(2, memberid);
		List<Object[]> result = query.list();
		List<Customer> clist = null;
		if (result != null && result.size() > 0)
		{
			List<RouteGate> gateList = new ArrayList<RouteGate>();
			for (Object[] obj : result)
			{
				gateList.add((RouteGate) obj[0]);
			}
			clist = new ArrayList<Customer>();
			Customer cus = null;
			for (RouteGate routeGate : gateList)
			{
				cus = routeGate.getCustomer();
				clist.add(cus);
			}
		}
		return clist;
	}

	/**
	 * 根据customid查找产品
	 * 
	 * @param customid
	 * @return
	 */
	public List<CustomerProduct> findProductByCustomid(String customid)
	{
		String hql = "from CustomerProduct a where a.isenable='1' and a.customer.customerid=?";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, customid);
		List<CustomerProduct> result = query.list();
		return result;
	}

	/**
	 * 根据类型查找客户信息 分页查找
	 * 
	 * @param keyword
	 * @param customerType
	 * @return
	 */
	public Pagination findByCustomerType(String keyword, String customerType, String memberid, int pageNo, int pageSize)
	{
		String sql = "select c.CUSTOMERID,c.CUSTOMERNAME,c.MOBILE from t_customer c where c.isenable='1' and c.customertype='" + customerType + "' and c.ownerid='" + memberid + "' ";
		if (!StringUtil.isEmpty(keyword))
		{
			sql += " and c.customername like '%" + keyword + "%'";
		}
		return findSql(sql, pageNo, pageSize);
	}

	@Override
	public List<Customer> getCustomerByObjectId(String objectId)
	{
		String hql = " from  Customer  c where c.objectId='" + objectId + "' and c.isenable='1'  ";
		return getListByHql(hql);
	}

	@Override
	public Customer getByCustomernameAndcustomertype(String customername, String customertypeid, String ownerid)
	{
		String hql = " from  Customer  c where c.customername='" + customername + "' and c.customertype.typeid='" + customertypeid + "'and c.owner.memberid='" + ownerid + "'";
		return (Customer) getSession().createQuery(hql).uniqueResult();
	}

	@Override
	public Pagination findCustomerByOwner(String ownerId, String customerName, boolean isAvalidate, int pageNo, int pageSize)
	{
		// TODO Auto-generated method stub
		String sql = "   from Customer tc where tc.owner=" + ownerId + " and tc.customertype.dictid!='14321'";
		if (isAvalidate)
		{
			sql = sql + " and tc.isenable='1'";
		}
		if (!StringUtil.isEmpty(customerName))
		{
			sql = sql + " and tc.customername like '%" + customerName + "%'";
		}
		Finder f = Finder.create(sql);
		return find(f, pageNo, pageSize);

	}

	@Override
	public Pagination findCustomerByType(String ownerId, String customerName, String customerType, boolean isAvalidate, int pageNo, int pageSize)
	{
		// TODO Auto-generated method stub
		Finder f = Finder.create("from Customer tc where tc.owner=:ownerId");
		f.setParam(ownerId, ownerId);
		if (!StringUtil.isEmpty(customerName))
		{
			f.append(" and tc.customername like '%" + customerName + "%'");
			f.setParam(customerName, customerName);
		}
		if (isAvalidate)
		{
			f.append(" and tc.isenable='1'");
		}
		if (!StringUtil.isEmpty(customerType))
		{
			f.append(" and tc.customertype.dictid=:customerType");
			f.setParam(customerType, customerType);
		}
		return find(f, pageNo, pageSize);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.cct9k.dao.customer.CustomerDao#findCustomerByTypeJdbcImpl(java.lang
	 * .String, java.lang.String, java.lang.String, boolean, int, int)
	 */
	@Override
	public Pagination findCustomerByTypeJdbcImpl(String ownerId, String customerName, String customerType, boolean isAvalidate, int pageNo, int pageSize)
	{
		// TODO Auto-generated method stub
		Map<String, Object> paramMap = new HashMap<String, Object>();
		StringBuffer sql = new StringBuffer("select tc.*,tc.customername as title from t_customer tc where tc.ownerid = :ownerid");
		paramMap.put("ownerid", ownerId);

		if (!StringUtil.isEmpty(customerName))
		{
			sql.append(" and tc.customername like '%=:customerName%'");
			paramMap.put("customername", customerName);
		}
		if (isAvalidate)
		{
			sql.append(" and tc.isenable='1'");
		}
		if (!StringUtil.isEmpty(customerType))
		{
			sql.append(" and tc.customertype=:customertype");
			paramMap.put("customertype", customerType);
		}
		Pagination pagination = new Pagination();
		pagination.setPageNo(pageNo);
		pagination.setPageSize(pageSize);

		return this.simpleSpringJdbcTemplate.queryForPaginationMap(sql, pagination, paramMap);
	}

	@Override
	public Boolean isIdentityVisitor(String onsaleId, String identityNo, String identityTypeId)
	{
		StringBuffer sql = new StringBuffer();
		sql.append(" select b.visitorid                                          ");
		sql.append("   from t_visitor_stop_plan_rel a, t_visitor b, t_customer c ");
		sql.append("  where a.visitorid = b.visitorid                            ");
		sql.append("    and b.customerid = c.customerid                          ");
		sql.append("    and a.onsaleid = :onsaleId                               ");
		sql.append("    and c.identityno = :identityNo                  		 ");
		sql.append("    and c.identitytype = :identityTypeId                     ");
		Query query = getSession().createSQLQuery(sql.toString());
		query.setParameter("onsaleId", onsaleId);
		query.setParameter("identityNo", identityNo);
		query.setParameter("identityTypeId", identityTypeId);

		return query.list().size() == 0;
	}

	//	@Override
	//	public boolean isAffiliatedSaller(String customerid,String sallerId, String customerType,
	//			String identityNo, String identityType) {
	//		String sql ="select * from t_customer t where t.isenable='1' t.ownerid=:ownerid and t.customerType=:customerType " +
	//				" and t.identityNo=:identityNo and t.identityType=:identityType and t.customerid!=:customerid";
	//		Query query = getSession().createSQLQuery(sql.toString());
	//    	query.setParameter("OWNERID", sallerId);
	//    	query.setParameter("IDENTITYNO", identityNo);
	//    	query.setParameter("CUSTOMERTYPE", customerType);
	//    	query.setParameter("IDENTITYTYPE", identityType);
	//    		query.setParameter("CUSTOMERID", customerid);
	//    	}
	//		List resultList = query.list();
	//		if()
	//		return false;
	//	}

}
