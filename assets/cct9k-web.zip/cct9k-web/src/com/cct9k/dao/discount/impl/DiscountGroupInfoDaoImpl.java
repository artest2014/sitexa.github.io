package com.cct9k.dao.discount.impl;


import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.discount.DiscountGroupInfoDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.discount.DiscountGroupInfo;

/**
 * 
* @ClassName: DiscountGroupinfoDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-3-5 上午10:14:54
*
 */
@Repository
public class DiscountGroupInfoDaoImpl extends BaseDaoImpl<DiscountGroupInfo, String> implements DiscountGroupInfoDao{

	@Override
	public Pagination getDiscountGroupInfoPage(int pageNo, int pageSize) {
		Finder f=Finder.create("from DiscountGroupInfo t where t.enableflag='1'order by t.createtime");
		return find(f, pageNo, pageSize);
	}
}

