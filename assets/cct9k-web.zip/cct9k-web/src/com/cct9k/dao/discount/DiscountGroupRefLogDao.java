package com.cct9k.dao.discount;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.discount.DiscountGroupRefLog;

/**
 * 
* @ClassName: DiscountGroupRefLogDao
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-3-5 上午10:30:04
*
 */
public interface DiscountGroupRefLogDao extends BaseDao<DiscountGroupRefLog, String>{

}
