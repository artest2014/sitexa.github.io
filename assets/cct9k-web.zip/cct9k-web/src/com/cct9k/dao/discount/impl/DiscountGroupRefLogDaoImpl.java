package com.cct9k.dao.discount.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.discount.DiscountGroupRefLogDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.discount.DiscountGroupRefLog;

/**
 * 
* @ClassName: DiscountGroupRefLogDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-3-5 上午10:31:21
*
 */
@Repository
public class DiscountGroupRefLogDaoImpl extends BaseDaoImpl<DiscountGroupRefLog, String> implements DiscountGroupRefLogDao{

}
