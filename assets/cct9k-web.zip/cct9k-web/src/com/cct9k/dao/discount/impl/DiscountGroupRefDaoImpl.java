package com.cct9k.dao.discount.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.discount.DiscountGroupRefDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.discount.DiscountGroupRef;
import com.cct9k.entity.finance.CommissionGroupRef;
import com.cct9k.util.common.StringUtil;

/**
 * 
* @ClassName: DiscountGroupRefDaoImpl
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-3-5 上午10:26:38
*
 */

@Repository
public class DiscountGroupRefDaoImpl extends BaseDaoImpl<DiscountGroupRef,String> implements DiscountGroupRefDao{

	@Override
	public Pagination getDiscountGroupRefs(String discountgroupid,String discountname, int pageNo,
			int pageSize) {
		Finder f = Finder.create("from DiscountGroupRef t where t.enableflag='1'");
		if(!StringUtil.isEmpty(discountname)){
			f.append(" and t.discountgroupinfo.discountname like '%'||:discountname||'%' ");
			f.setParam("discountname", discountname);
		}
		if(!StringUtil.isEmpty(discountgroupid)){
			f.append(" and t.discountgroupinfo.discountgroupid =:discountgroupid ");
			f.setParam("discountgroupid", discountgroupid);
		}
		return find(f, pageNo, pageSize);
	}

	@Override
	public DiscountGroupRef getByobjectidAndObjecttypeid(String objectid,
			String objecttypeid) {
		String hql=" from DiscountGroupRef t where t.objectid='"+objectid+"' and t.objecttypeid='"+objecttypeid+"'";
		return (DiscountGroupRef) getSession().createQuery(hql).uniqueResult();
	}

}
