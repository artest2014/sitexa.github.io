package com.cct9k.dao.discount;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.discount.DiscountGroupInfo;
/**
 * 
* @ClassName: DiscountGroupInfoDao
* @Description: TODO(这里用一句话描述这个类的作用)
* @author ty
* @date 2014-3-5 上午10:15:04
*
 */
public interface DiscountGroupInfoDao extends BaseDao<DiscountGroupInfo, String>{
	
	public Pagination getDiscountGroupInfoPage(int pageNo, int pageSize);

}
