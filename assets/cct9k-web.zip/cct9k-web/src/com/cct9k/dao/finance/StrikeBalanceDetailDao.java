package com.cct9k.dao.finance;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.StrikeBalanceDetail;

import java.util.List;

/**
 * @author yics 2013-08-08
 */
public interface StrikeBalanceDetailDao extends BaseDao<StrikeBalanceDetail, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public List<StrikeBalanceDetail> getStrikeBalanceDetailList(String memberid, String saller, String statetime, String endtime, String type);
}
