package com.cct9k.dao.finance.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.BillDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.Bill;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:32
 */
@Repository
public class BillDaoImpl extends BaseDaoImpl<Bill, String> implements BillDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from ... model where 1=1");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }
    
    /**
     * 查询清帐日志
     * @param buy
     * @param sale
     * @param orderid
     * @param pageNo
     * @param pageSize
     * @return
     */
    public Pagination getcleanBillPage(String buy,String sale, String starttime, String endtime,int pageNo, int pageSize) {
        Finder r = Finder.create("from Bill b where 1=1 and b.billTypeCate ='billType' and  b.billType='creditRepayment' ");
        r.append(" and b.payer.memberid='"+buy+"' and b.receiver.memberid='"+sale+"'");
        
        if (!StringUtil.isEmpty(starttime)) {
            r.append(" and b.order.orderDate >=:starttime ");
            r.setParam("starttime", java.sql.Date.valueOf(starttime));
        }
        if (!StringUtil.isEmpty(endtime)) {
            r.append(" and b.order.orderDate <=:endtime ");
            r.setParam("endtime", java.sql.Date.valueOf(endtime));
        }
        r.append(" order by b.paymentdate desc");

        return find(r, pageNo, pageSize);
    }
    
    @Override
	public List<Bill> getBillListByOrderId(String orderId) {
		String hql="from Bill b where b.order.orderId='"+orderId+"' ";
		List<Bill> bills=getListByHql(hql);
		if(bills!=null&&bills.size()>0){
			return bills;
		}
		return null;
	}
    @Override
    public Bill getBillByOrderAndBillType(String orderId ,String billType){
    	String hql="from Bill b where b.order.orderId='"+orderId+"' and billType='"+billType+"'";
		Bill bill = null;
		List<Bill> bills=getListByHql(hql);
		if(bills!=null&&bills.size()>0){
			bill = bills.get(0);
		}
		return bill;
    	
    } 
    @Override
	public Bill getBillByOrderId(String orderId) {
		String hql="from Bill b where b.order.orderId='"+orderId+"' and (billType='credit' or billType='onlinetracash' or billType='payOnLine') ";
		Bill bill = null;
		List<Bill> bills=getListByHql(hql);
		if(bills!=null&&bills.size()>0){
			bill = bills.get(0);
		}
		return bill;
	}

	@Override
	public Pagination getBillCreat(String ordertype, String payer, String receiver,
			String billtype,String orderid,String starttime, String endtime,int pageNo, int pageSize) {
		Finder r = Finder.create("from Bill b where b.objecttype.dictid='"+ordertype+"' and b.payer.memberid='"+payer+"' and b.receiver.memberid='"+receiver+"' and b.billType='"+billtype+"'");
		if (!StringUtil.isEmpty(orderid)) {
            r.append(" and b.order.orderId like '%'||:orderid||'%' ");
            r.setParam("orderid", orderid);
        }
        if (!StringUtil.isEmpty(starttime)) {
            r.append(" and b.order.orderDate >=:starttime ");
            r.setParam("starttime", java.sql.Date.valueOf(starttime));
        }
        if (!StringUtil.isEmpty(endtime)) {
            r.append(" and b.order.orderDate <=:endtime ");
            r.setParam("endtime", java.sql.Date.valueOf(endtime));
        }
        r.append(" order by b.order.orderDate desc");
		return find(r, pageNo, pageSize);
	}
	
	@Override
	public Pagination getRepayBillLogByPayer(String payDate,String number,String payer,String reseller,int pageNo, int pageSize){
		Finder r = Finder.create("from Bill b where b.payer.memberid='"+payer+"' and b.receiver.memberid='"+reseller+"' and b.billType='repaymentRegi'");
	    if(!StringUtil.isEmpty(payDate)){
	    	r.append(" and b.paymentdate=:paydate");
	    	r.setParam("paydate", payDate);
	    }
	    if(!StringUtil.isEmpty(number)){
	    	r.append(" and b.transactionId=:number");
	    	r.setParam("number",number);
	    }
	    r.append(" order by b.paymentdate desc");
	    return find(r,pageNo,pageSize);
	}
	
	@Override
	public Pagination getMemberBillsByGroupType(String endDate,String membername,String groupType,String reseller,int pageNo, int pageSize){
		String sql="select a.payer,b.membername,sum(a.amount),sum(case when a.paymentdate >=";
		String endDateIn="";
		if(!StringUtils.isEmpty(endDate)){
			endDateIn=endDate;
		}
		else{
			Date date=new Date();
			endDateIn= DateFormat.getDateInstance().format(date);
		}
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Date endDateD=null;
			try {
				endDateD = (Date)sdf.parse(endDateIn);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Calendar cal=Calendar.getInstance();
	        cal.setTime(endDateD);
	        int year=cal.get(Calendar.YEAR);
	        String yearStr=String.valueOf(year);
	        int month=cal.get(Calendar.MONTH);
	        String monthStr="";
	        String lastDayStr="";
	        if((month+1)>9){
	          monthStr=String.valueOf(month+1);
	        }
	        else{
	        	monthStr="0"+String.valueOf(month+1);
	        }
	        int lastDay=DateUtil.getLastDayOfTheMonth(endDateD);
	        if(lastDay>9){
	        	lastDayStr=String.valueOf(lastDay);
	        }
	        else{
	        	lastDayStr="0"+String.valueOf(lastDay);
	        }
	        sql+="to_date('"+yearStr+"-"+monthStr+"-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss') and a.paymentdate <=";
			    sql+="to_date('"+yearStr+"-"+monthStr+"-"+lastDayStr+" 23:59:59', 'yyyy-mm-dd hh24:mi:ss') then a.amount";
		      sql+=" else 0 end),max(e.quota),max(e.quotaused),max(e.freezeamount) from t_bill a,t_member b,";
		      sql+=" (select c.groupid,d.memberid,c.reseller,d.quota,d.quotaused,d.freezeamount from t_vip_group c, t_group_member d ";
		      sql+="  where c.groupid = d.groupid and d.quotatype = '199' and c.grouptype = '250' and c.reseller = '"+reseller+"') e ";
		      sql+=" where a.receiver = '"+reseller+"' and a.payer = b.memberid and a.orderid is not null and b.memberid = e.memberid(+)";
		      if(!org.apache.commons.lang3.StringUtils.isEmpty(endDate)){           	
            	sql+=" and a.paymentdate<=to_date('"+endDate+" 23:59:59', 'yyyy-mm-dd hh24:mi:ss')";
            }
          if(!StringUtils.isEmpty(membername)){
            	sql+=" and b.membername='"+membername+"'";
            }
		      sql+=" group by a.payer,b.membername ";		      
            return findSql(sql,pageNo,pageSize);				
	}
	
	public List<String> getPaymentMethod(String orderId,String dictId){
		String sql = "select decode(t.billType,'onlinetracash','现金支付','payOnLine','通联支付','credit','挂账支付') from t_bill t "
				+ "where t.objecttype='"+dictId+"' and t.billname='导游账单' and t.orderid='"+orderId+"' and t.billtypecate='billType'";
		List<String> list = this.getSession().createSQLQuery(sql).list();
		return list;
	}
}
