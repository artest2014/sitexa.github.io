package com.cct9k.dao.finance.impl;

import com.cct9k.dao.finance.MemberAccountDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.MemberAccount;
import org.springframework.stereotype.Repository;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class MemberAccountDaoImpl extends BaseDaoImpl<MemberAccount, String> implements MemberAccountDao {

}
