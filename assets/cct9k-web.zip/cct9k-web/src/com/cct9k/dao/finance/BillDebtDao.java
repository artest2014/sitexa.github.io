package com.cct9k.dao.finance;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.view.BillDebt;
import com.cct9k.web.vo.BillDebtVo;

public interface BillDebtDao extends BaseDao<BillDebt, String> {

	/**
	 *酒店 
	 **/
	List<BillDebtVo> findHotelBuill(String receiver, String payer);
	/**
	 *娱乐
	 **/
	List<BillDebtVo> findEntertainmentBuill(String receiver, String payer);
	/**
	 *餐饮
	 **/
	List<BillDebtVo> findRestaurantBuill(String receiver, String payer);
	/**
	 *景点
	 **/
	List<BillDebtVo> findSceneryBuill(String receiver, String payer);
	/**
	 *旅运
	 **/
	List<BillDebtVo> findTransportBuill(String receiver, String payer);
	/**
	 *线路
	 **/
	List<BillDebtVo> findRouteBuill(String receiver, String payer);
}
