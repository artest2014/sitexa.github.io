package com.cct9k.dao.finance.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.AccountItemDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.AccountItem;
import com.cct9k.util.common.StringUtil;

/**
 * @author cyj
 *         2014-01-13
 */
@Repository
public class AccountItemDaoImpl extends BaseDaoImpl<AccountItem, String> implements AccountItemDao {
	
	
	@Override
	public String getCreateId() {
		// TODO Auto-generated method stub
		
		String sql = "SELECT S_ACCOUNTITEM.NEXTVAL FROM DUAL";
		Query query = getSession().createSQLQuery(sql);
        String id =   (query.uniqueResult()).toString();
		return id;
	}
    
    @Override
	public List<AccountItem> getAllItemByParentId(String parentId,String memberId,boolean isAvalidate,String orderBy) {
		// TODO Auto-generated method stub
    	StringBuffer sb = new StringBuffer();
		sb.append(" from AccountItem t where t.parentid=? " );
		if(isAvalidate){
			sb.append(" and t.status=1 ");
		}
		if(!StringUtil.isEmpty(memberId)){
			sb.append(" and t.memberid="+memberId);
		}
		sb.append(" order by t.itemid  " + orderBy);
		Query query = getSession().createQuery(sb.toString());
		query.setParameter(0, parentId);
		 
		List<AccountItem> accountItems =  query.list();
		return accountItems;
	}
	

	@Override
	public List<AccountItem> getCanUseAccountItemList(String memberId,boolean isDesc) {
		// TODO Auto-generated method stub
		
		StringBuffer sb = new StringBuffer();
		sb.append(" from AccountItem t where t.status='1' and ( t.memberid=? or t.memberid is null)");
		if(isDesc){
			sb.append(" order by t.itemid desc");
		}
		Query query = getSession().createQuery(sb.toString());
		query.setParameter(0, memberId);
		List<AccountItem> list = query.list();
		
		return list;
	}

	@Override
	public AccountItem getAvalidateAccountItemDetail(String accountitemid) {
		// TODO Auto-generated method stub
		
		StringBuffer sb = new StringBuffer();
		sb.append(" from AccountItem t where t.status='1' and t.accountitemid=?");
		Query query = getSession().createQuery(sb.toString());
		query.setParameter(0, accountitemid);
		AccountItem accountItem = (AccountItem) query.uniqueResult();
		return accountItem;
	}

	@Override
	public AccountItem getByItemIdAndMemberid(String itemId, String memberid) {
		String sql=" select *  from t_account_item t where t.itemid=? ";
		if(StringUtil.isNullOrEmpty(memberid))
			sql+=" and (t.memberid ='' or t.memberid is null)";
		else
			sql+=" and t.member.memberid =? ";
		Query query = getSession().createSQLQuery(sql).addEntity(AccountItem.class);
		query.setParameter(0, itemId);
		if(!StringUtil.isNullOrEmpty(memberid))
		query.setParameter(1, memberid);
		AccountItem accountItem = (AccountItem) query.uniqueResult();
		return accountItem;
	}

	@Override
	public Pagination getAccountItemByMemberIdAndItemType(
			String memberId, String itemType,String itemName,int pageSize,int pageNo) {
		// TODO Auto-generated method stub
		Map<String,Object> paramMap = new HashMap<String,Object> ();
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT T.*,(SELECT TT.ITEMNAME FROM T_ACCOUNT_ITEM TT WHERE TT.ACCOUNTITEMID=T.PARENTID) PARENTNAME FROM T_ACCOUNT_ITEM T  WHERE T.STATUS='1' AND  (T.MEMBERID=:memberId OR T.MEMBERID IS NULL) ");
		if(!StringUtil.isEmpty(itemType) && !itemType.equals("`income") && !itemType.equals("`outcome") && !itemType.equals("`bank")){
			sb.append(" AND T.PARENTID=:itemType");
			paramMap.put("itemType", itemType);
		}
		if("`income".equals(itemType)){
			sb.append(" AND (T.PARENTID='1007' OR T.PARENTID='1008')");
		}
		if("`outcome".equals(itemType)){
			sb.append(" AND (T.PARENTID='1010' OR T.PARENTID='1011')");
		}
		if("`bank".equals(itemType)){
			sb.append(" AND (T.PARENTID='1015')");
		}
		if(!StringUtil.isEmpty(itemName)){
			sb.append(" AND T.ITEMNAME LIKE '%"+itemName+"%'");
		}
		Pagination pagination = new Pagination();
		pagination.setPageNo(pageNo);
		pagination.setPageSize(pageSize);
		paramMap.put("memberId", memberId);
		
		Pagination paginations = this.getSimpleSpringJdbcTemplate().queryForPaginationMap(sb, pagination, paramMap);
		return paginations;
	}

	@Override
	public List<Map<String, Object>> getItemByItemNameAndPrentId(
			String memberId,String accountItemId, String parentId,String itemName) {
		
		Map<String,Object> paramMap = new HashMap<String,Object> ();
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT T.*,(SELECT TT.ITEMNAME FROM T_ACCOUNT_ITEM TT WHERE TT.ACCOUNTITEMID=T.PARENTID) PARENTNAME FROM T_ACCOUNT_ITEM T  WHERE T.STATUS='1' AND  (T.MEMBERID=:memberId OR T.MEMBERID IS NULL) ");
		
		if(!StringUtil.isEmpty(accountItemId) ){
			sb.append(" AND (T.ACCOUNTITEMID !="+accountItemId+")");
		}
		
		sb.append(" AND T.PARENTID=:parentId");
		sb.append(" AND T.ITEMNAME=:itemName");
		paramMap.put("memberId", memberId);
		paramMap.put("parentId", parentId);
		paramMap.put("itemName", itemName);
		List<Map<String, Object>> list = this.getSimpleSpringJdbcTemplate().queryForMap(sb, paramMap);
		return list;
	}

	@Override
	public List<AccountItem> getItemByMemberIdAndParentId(String memberId,
			String parentId, boolean isAvalide) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		sb.append("select t from AccountItem t where (t.memberid=? or t.memberid=null) and t.parentid=?");
		if(isAvalide){
			sb.append(" and t.status=1");
		}
		
		sb.append(" order by t.itemid asc");
		Query query = getSession().createQuery(sb.toString());
		query.setParameter(0, memberId);
		query.setParameter(1, parentId);
		List<AccountItem> list= query.list();
		return list;
	}


}
