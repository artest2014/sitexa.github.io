package com.cct9k.dao.finance.impl;

import com.cct9k.dao.finance.BankDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.Bank;

import org.springframework.stereotype.Repository;

@Repository
public class BankDaoImpl extends BaseDaoImpl<Bank, String> implements BankDao {

}
