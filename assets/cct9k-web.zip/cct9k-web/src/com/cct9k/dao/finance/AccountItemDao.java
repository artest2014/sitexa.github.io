package com.cct9k.dao.finance;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.AccountItem;

public interface AccountItemDao extends BaseDao<AccountItem, String> {
	
	/**
	 * 获取科目id
	 * @return
	 */
	public String getCreateId();
	
	/**
	 * 获取用户下的可用的科目（按科目类别分【父科目id】）
	 * @param memberId
	 * @param itemType
	 * @return
	 */
	public Pagination getAccountItemByMemberIdAndItemType(String memberId,String itemTyp,String itemName,int pageSize,int pageNo);
    
    
    /**
     * 根据父节点id查询所有子科目
     * @param orderBy  科目id 升序or降序
     * @param isAvalidate  true:查询可用的；false:查询所有的
     * @param memberId memberId可为"",此时为查询该父科目下所有的科目；memberId不为空时，查询的是当前登录用户所属的科目
     * @return
     */
    public List<AccountItem> getAllItemByParentId(String parentId,String memberId,boolean isAvalidate,String orderBy);
    
    /**查询  可用的科目
     * @param isDesc 是否降幂排序
     * @return List<AccountItem> list
     */
    public List<AccountItem> getCanUseAccountItemList(String memberId,boolean isDesc);
    
    /**查询  可用的科目  详情
     * 
     * @return  AccountItem 
     */
    public  AccountItem  getAvalidateAccountItemDetail(String accountitemid);
    
    /**
     * 根据ItemId 和memberid查AccountItem
     * @return
     */
    public  AccountItem  getByItemIdAndMemberid(String itemId,String memberid);
    
    /**
     * 按科目名称查询指定机构下的指定科目的可用子科目
     * @param memberId
     * @param parentId
     * @return
     */
    public List<Map<String,Object>> getItemByItemNameAndPrentId(String memberId,String accountItemId,String parentId,String itemName);
    
    /**
     * 根据父id和memberId查询item（isAvalide=true,查询可用的子科目；isAvalide=false,查询所有的子科目；）
     * @param memberId
     * @param parentId
     * @param isAvalide
     * @return
     */
    public List<AccountItem> getItemByMemberIdAndParentId(String memberId,String parentId,boolean isAvalide);
}
