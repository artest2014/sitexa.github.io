package com.cct9k.dao.finance.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.RefundItemDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.order.GenericOrderDao;
import com.cct9k.dao.order.OrderDetailGateDao;
import com.cct9k.dao.order.OrderDetailGuideDao;
import com.cct9k.dao.order.OrderDetailHotelDao;
import com.cct9k.dao.order.OrderDetailRestaurantDao;
import com.cct9k.dao.order.OrderDetailShowDao;
import com.cct9k.dao.order.OrderDetailTransportDao;
import com.cct9k.entity.allinpay.DepositApplyDetail;
import com.cct9k.entity.finance.RefundItem;
import com.cct9k.entity.order.GenericOrder;
import com.cct9k.entity.order.OrderDetailGate;
import com.cct9k.entity.order.OrderDetailGuide;
import com.cct9k.entity.order.OrderDetailHotel;
import com.cct9k.entity.order.OrderDetailRestaurant;
import com.cct9k.entity.order.OrderDetailShow;
import com.cct9k.entity.order.OrderDetailTransport;

/**
 * Author: oscar peng <xnpeng@hotmail.com> Date: 13-8-10 Time: 下午2:06
 */
@Repository
public class RefundItemDaoImpl extends BaseDaoImpl<RefundItem, String>
		implements RefundItemDao {

	@Override
	public Pagination getPage(int pageNo, int pageSize) {
		Finder r = Finder.create("from RefundItem model where 1=1");

		r.append(" order by leadtime asc");

		return find(r, pageNo, pageSize);
	}

	
	public RefundItem getRouteRefund(String orderId){
		StringBuffer sb = new StringBuffer();
		sb.append("select * from ( select b.*");
	    sb.append("  from t_refund_rule a, t_refund_item b");
	    sb.append("  where a.ruleid = b.ruleid");
	    sb.append("  and a.producttype = 'route'");
	    sb.append("  and a.productid = (select d.routeid");
	    sb.append("                        from t_generic_order c, t_order_detail_plan d");
	    sb.append("                      where c.orderid = d.orderid");
	    sb.append("                        and d.orderid = '"+orderId+"'");
	    sb.append("                        )");
	    sb.append("         and b.leadtime "  );             
	    sb.append("         >=");
	    sb.append("         (select (os.starttime-sysdate)*24 from t_onsale os where os.onsaleid= " );          
	    sb.append("                  (select d.onsaleid");
	    sb.append("                       from t_generic_order c, t_order_detail_plan d");
	    sb.append("                       where c.orderid = d.orderid");
	    sb.append("                        and d.orderid = '"+orderId+"'");
	    sb.append("                         ))  order by b.leadtime asc ) where 1=1 and rownum <= 1   ");
	    RefundItem refundItem =  (RefundItem)getSession().createSQLQuery(sb.toString()).addEntity(RefundItem.class).uniqueResult();
  	    return refundItem;
	    
	}
	

	
	public RefundItem getHotelRefund(String detailId,String hotelId){
    	StringBuffer sb = new StringBuffer();
    	sb.append( "select * from (select b.* from t_refund_rule a, t_refund_item b where a.ruleid = b.ruleid");
    	sb.append( " and a.producttype = 'hotel' and a.productid='"+hotelId+"' and b.leadtime>");
    	sb.append( "           (select (c.checkin - sysdate) * 24 from t_order_detail_hotel c where");
    	sb.append( "          c.detailid='"+detailId+"') order by b.leadtime asc) where 1=1 and rownum<=1");
        RefundItem refundItem =  (RefundItem)getSession().createSQLQuery(sb.toString()).addEntity(RefundItem.class).uniqueResult();
  	    return refundItem;
	}
	
	

	
	public RefundItem getRestaurantRefund(String detailId,String restaurantId){
    	StringBuffer sb = new StringBuffer();
    	sb.append( "select * from (select b.* from t_refund_rule a, t_refund_item b where a.ruleid = b.ruleid");
    	sb.append( " and a.producttype = 'restaurant' and a.productid='"+restaurantId+"' and b.leadtime>");
    	sb.append( "           (select (c.starttime - sysdate) * 24 from t_order_detail_restaurant c where");
    	sb.append( "          c.detailid='"+detailId+"') order by b.leadtime asc) where 1=1 and rownum<=1");
        RefundItem refundItem =  (RefundItem)getSession().createSQLQuery(sb.toString()).addEntity(RefundItem.class).uniqueResult();
  	    return refundItem;
	}
    

	
	public RefundItem getShowRefund(String detailId,String showId){
    	StringBuffer sb = new StringBuffer();
    	sb.append( "select * from (select b.* from t_refund_rule a, t_refund_item b where a.ruleid = b.ruleid");
    	sb.append( " and a.producttype = 'entertainment' and a.productid='"+showId+"' and b.leadtime>");
    	sb.append( "           (select (c.startdate - sysdate) * 24 from t_order_detail_show c where");
    	sb.append( "          c.detailid='"+detailId+"') order by b.leadtime asc) where 1=1 and rownum<=1");
        RefundItem refundItem =  (RefundItem)getSession().createSQLQuery(sb.toString()).addEntity(RefundItem.class).uniqueResult();
  	    return refundItem;
	}

	
	public RefundItem getTransportRefund(String detailId,String transportId){
    	StringBuffer sb = new StringBuffer();
    	sb.append( "select * from (select b.* from t_refund_rule a, t_refund_item b where a.ruleid = b.ruleid");
    	sb.append( " and a.producttype = 'transport' and a.productid='"+transportId+"' and b.leadtime>");
    	sb.append( "           (select (c.startdate - sysdate) * 24 from t_order_detail_transport c where");
    	sb.append( "          c.detailid='"+detailId+"') order by b.leadtime asc) where 1=1 and rownum<=1");
        RefundItem refundItem =  (RefundItem)getSession().createSQLQuery(sb.toString()).addEntity(RefundItem.class).uniqueResult();
  	    return refundItem;
	}
	
	public RefundItem getGuideRefund(String detailId,String guideId){
    	StringBuffer sb = new StringBuffer();
    	sb.append( "select * from (select b.* from t_refund_rule a, t_refund_item b where a.ruleid = b.ruleid");
    	sb.append( " and a.producttype = 'guide' and a.productid='"+guideId+"' and b.leadtime>");
    	sb.append( "           (select (c.startdate - sysdate) * 24 from t_order_detail_guide c where");
    	sb.append( "          c.detailid='"+detailId+"') order by b.leadtime asc) where 1=1 and rownum<=1");
        RefundItem refundItem =  (RefundItem)getSession().createSQLQuery(sb.toString()).addEntity(RefundItem.class).uniqueResult();
  	    return refundItem;
	}
	
	public RefundItem getGateRefund(String detailId,String sceneryId){
    	StringBuffer sb = new StringBuffer();
    	sb.append( "select * from (select b.* from t_refund_rule a, t_refund_item b where a.ruleid = b.ruleid");
    	sb.append( " and a.producttype = 'scenery' and a.productid='"+sceneryId+"' and b.leadtime>");
    	sb.append( "           (select (c.startdate - sysdate) * 24 from t_order_detail_gate c where");
    	sb.append( "          c.detailid='"+detailId+"') order by b.leadtime asc) where 1=1 and rownum<=1");
        RefundItem refundItem =  (RefundItem)getSession().createSQLQuery(sb.toString()).addEntity(RefundItem.class).uniqueResult();
  	    return refundItem;
	}

	
	//验证线路订单是否可以退款 true可以退款  false不可以退款
	public boolean validateRouteIfRefund(String orderId){
		boolean oneResult = false;
		boolean twoResult = false;
	    String sql1 = "select os.* from t_onsale os where os.onsaleid=       "  
                     +"   (select d.onsaleid " 
                     +"        from t_generic_order c, t_order_detail_plan d " 
                     +"        where c.orderid = d.orderid " 
                     +"         and d.orderid = '"+orderId+"') and os.starttime<=sysdate " ;
        List resultList1 = null;
	    resultList1 = this.getSession().createSQLQuery(sql1).list();
        if (resultList1 != null && resultList1.size() > 0) {
        	oneResult =  false;
        }else{
        	oneResult = true;
        }
        
        String sql2 = " select os.* from t_onsale os where os.onsaleid=        "  
				+"   (select d.onsaleid "
                  +"           from t_generic_order c, t_order_detail_plan d "
                 +"            where c.orderid = d.orderid "
                  +"            and d.orderid = '"+orderId+"') and (os.starttime-sysdate)*24<= (select min(b.leadtime) from t_refund_rule a,  "
                  +"            t_refund_item b where a.ruleid = b.ruleid and a.producttype = 'route' and a.productid=(select d.routeid"
                  +"              from t_generic_order c, t_order_detail_plan d"
	              +"            where c.orderid = d.orderid"
	              +"              and d.orderid = '"+orderId+"')) ";
		List resultList2 = null;
	    resultList2 = this.getSession().createSQLQuery(sql2).list();
        if (resultList2 != null && resultList2.size() > 0) {
        	twoResult = false;
        }else{
        	twoResult = true;
        }
        if(oneResult&&twoResult){
        	return true;
        }else{
        	return false;
        }
    }
	
	//验证景点产品是否可以退款 true可以退款  false不可以退款
	public boolean validateGateIfRefund(String detailId,String sceneryId){
		boolean oneResult = false;
		boolean twoResult = false;
	    String sql1 = " select c.* from t_order_detail_gate c where c.detailid='"+detailId+"' and c.startdate<= sysdate " ;
        List resultList1 = null;
	    resultList1 = this.getSession().createSQLQuery(sql1).list();
        if (resultList1 != null && resultList1.size() > 0) {
        	oneResult =  false;
        }else{
        	oneResult = true;
        }
        
        String sql2 = " select c.* from t_order_detail_gate c where c.detailid='"+detailId+"' and "
        		+ " (c.startdate-sysdate)*24<= ( select min(b.leadtime) from t_refund_rule a, t_refund_item b "
        		+ "    where a.ruleid = b.ruleid and a.producttype = 'scenery' and a.productid='"+sceneryId+"' ) ";
		List resultList2 = null;
	    resultList2 = this.getSession().createSQLQuery(sql2).list();
        if (resultList2 != null && resultList2.size() > 0) {
        	twoResult = false;
        }else{
        	twoResult = true;
        }
        if(oneResult&&twoResult){
        	return true;
        }else{
        	return false;
        }
    }
	
	//验证餐饮产品是否可以退款 true可以退款  false不可以退款
		public boolean validateRestaurantIfRefund(String detailId,String restaurantId){
			boolean oneResult = false;
			boolean twoResult = false;
		    String sql1 = " select c.* from t_order_detail_restaurant c where c.detailid='"+detailId+"' and c.starttime<= sysdate " ;
	        List resultList1 = null;
		    resultList1 = this.getSession().createSQLQuery(sql1).list();
	        if (resultList1 != null && resultList1.size() > 0) {
	        	oneResult =  false;
	        }else{
	        	oneResult = true;
	        }
	        
	        String sql2 = " select c.* from t_order_detail_restaurant c where c.detailid='"+detailId+"' and "
	        		+ " (c.starttime-sysdate)*24<= ( select min(b.leadtime) from t_refund_rule a, t_refund_item b "
	        		+ "    where a.ruleid = b.ruleid and a.producttype = 'restaurant' and a.productid='"+restaurantId+"' ) ";
			List resultList2 = null;
		    resultList2 = this.getSession().createSQLQuery(sql2).list();
	        if (resultList2 != null && resultList2.size() > 0) {
	        	twoResult = false;
	        }else{
	        	twoResult = true;
	        }
	        if(oneResult&&twoResult){
	        	return true;
	        }else{
	        	return false;
	        }
	    }
		
		//验证酒店产品是否可以退款 true可以退款  false不可以退款
		public boolean validateHotelIfRefund(String detailId,String hotelId){
			boolean oneResult = false;
			boolean twoResult = false;
		    String sql1 = " select c.* from t_order_detail_hotel c where c.detailid='"+detailId+"' and c.checkin<= sysdate " ;
	        List resultList1 = null;
		    resultList1 = this.getSession().createSQLQuery(sql1).list();
	        if (resultList1 != null && resultList1.size() > 0) {
	        	oneResult =  false;
	        }else{
	        	oneResult = true;
	        }
	        
	        String sql2 = " select c.* from t_order_detail_hotel c where c.detailid='"+detailId+"' and "
	        		+ " (c.checkin-sysdate)*24<= ( select min(b.leadtime) from t_refund_rule a, t_refund_item b "
	        		+ "    where a.ruleid = b.ruleid and a.producttype = 'hotel' and a.productid='"+hotelId+"' ) ";
			List resultList2 = null;
		    resultList2 = this.getSession().createSQLQuery(sql2).list();
	        if (resultList2 != null && resultList2.size() > 0) {
	        	twoResult = false;
	        }else{
	        	twoResult = true;
	        }
	        if(oneResult&&twoResult){
	        	return true;
	        }else{
	        	return false;
	        }
	    }
		
		//验证娱乐产品是否可以退款 true可以退款  false不可以退款
		public boolean validateShowIfRefund(String detailId,String showId){
			boolean oneResult = false;
			boolean twoResult = false;
		    String sql1 = " select c.* from t_order_detail_show c where c.detailid='"+detailId+"' and c.startdate<= sysdate " ;
	        List resultList1 = null;
		    resultList1 = this.getSession().createSQLQuery(sql1).list();
	        if (resultList1 != null && resultList1.size() > 0) {
	        	oneResult =  false;
	        }else{
	        	oneResult = true;
	        }
	        
	        String sql2 = " select c.* from t_order_detail_show c where c.detailid='"+detailId+"' and "
	        		+ " (c.startdate-sysdate)*24<= ( select min(b.leadtime) from t_refund_rule a, t_refund_item b "
	        		+ "    where a.ruleid = b.ruleid and a.producttype = 'entertainment' and a.productid='"+showId+"' ) ";
			List resultList2 = null;
		    resultList2 = this.getSession().createSQLQuery(sql2).list();
	        if (resultList2 != null && resultList2.size() > 0) {
	        	twoResult = false;
	        }else{
	        	twoResult = true;
	        }
	        if(oneResult&&twoResult){
	        	return true;
	        }else{
	        	return false;
	        }
	    }
		
		//验证旅运产品是否可以退款 true可以退款  false不可以退款
		public boolean validateTransportIfRefund(String detailId,String transportId){
			boolean oneResult = false;
			boolean twoResult = false;
		    String sql1 = " select c.* from t_order_detail_transport c where c.detailid='"+detailId+"' and c.startdate<= sysdate " ;
	        List resultList1 = null;
		    resultList1 = this.getSession().createSQLQuery(sql1).list();
	        if (resultList1 != null && resultList1.size() > 0) {
	        	oneResult =  false;
	        }else{
	        	oneResult = true;
	        }
	        
	        String sql2 = " select c.* from t_order_detail_transport c where c.detailid='"+detailId+"' and "
	        		+ " (c.startdate-sysdate)*24<= ( select min(b.leadtime) from t_refund_rule a, t_refund_item b "
	        		+ "    where a.ruleid = b.ruleid and a.producttype = 'transport' and a.productid='"+transportId+"' ) ";
			List resultList2 = null;
		    resultList2 = this.getSession().createSQLQuery(sql2).list();
	        if (resultList2 != null && resultList2.size() > 0) {
	        	twoResult = false;
	        }else{
	        	twoResult = true;
	        }
	        if(oneResult&&twoResult){
	        	return true;
	        }else{
	        	return false;
	        }
	    }
		
		//验证导游产品是否可以退款 true可以退款  false不可以退款
		public boolean validateGuideIfRefund(String detailId,String guideId){
			boolean oneResult = false;
			boolean twoResult = false;
		    String sql1 = " select c.* from t_order_detail_guide c where c.detailid='"+detailId+"' and c.startdate<= sysdate " ;
	        List resultList1 = null;
		    resultList1 = this.getSession().createSQLQuery(sql1).list();
	        if (resultList1 != null && resultList1.size() > 0) {
	        	oneResult =  false;
	        }else{
	        	oneResult = true;
	        }
	        
	        String sql2 = " select c.* from t_order_detail_guide c where c.detailid='"+detailId+"' and "
	        		+ " (c.startdate-sysdate)*24<= ( select min(b.leadtime) from t_refund_rule a, t_refund_item b "
	        		+ "    where a.ruleid = b.ruleid and a.producttype = 'guide' and a.productid='"+guideId+"' ) ";
			List resultList2 = null;
		    resultList2 = this.getSession().createSQLQuery(sql2).list();
	        if (resultList2 != null && resultList2.size() > 0) {
	        	twoResult = false;
	        }else{
	        	twoResult = true;
	        }
	        if(oneResult&&twoResult){
	        	return true;
	        }else{
	        	return false;
	        }
	    }

}
