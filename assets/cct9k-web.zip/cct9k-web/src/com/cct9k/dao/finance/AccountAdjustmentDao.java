package com.cct9k.dao.finance;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.AccountAdjustment;

public interface AccountAdjustmentDao extends BaseDao<AccountAdjustment, String> {
 
	public String getSeqn();
	
	/**
	 * 根据memberid找到与之相关的已完成的订单信息，用于调账（调账首页的订单展示信息）
	 * @param memberId
	 * @return
	 */
	public Pagination getAccountAdjustmentByMember(int pageNo,int pageSize,Map<String,String> paramMap);
	
	/**
	 * 根据memberId,orderid获取调账申请详情
	 * @param orderId
	 * @return
	 */
	public List<Map<String,Object>> getAccountAdjustmentDetail(String memberId,String orderId);
	
	/**
	 * 保存一个调账申请
	 * @param accountAdjustment
	 */
	public int saveAccountAdjustment(AccountAdjustment accountAdjustment); 
}
