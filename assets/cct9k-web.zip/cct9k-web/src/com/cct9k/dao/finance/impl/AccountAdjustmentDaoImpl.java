package com.cct9k.dao.finance.impl;


import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.AccountAdjustmentDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.AccountAdjustment;
import com.cct9k.util.common.StringUtil;

@Repository
public class AccountAdjustmentDaoImpl extends BaseDaoImpl<AccountAdjustment, String> implements
AccountAdjustmentDao {

@Override
public String getSeqn(){
	String sql = " SELECT S_ACCOUNT_ADJUSTMENT.NEXTVAL FROM DUAL";
	Query query = getSession().createSQLQuery(sql);
	BigDecimal b = (BigDecimal) query.uniqueResult();
	return b.toString();
}

@Override
public Pagination getAccountAdjustmentByMember(int pageNo,int pageSize,Map<String,String> paramsMap) {
	// TODO Auto-generated method stub
	
	String memberId = paramsMap.get("memberId");
	String startDate = paramsMap.get("startDate");
	String endDate = paramsMap.get("endDate");
	String orderType = paramsMap.get("orderType");
	String selectItem = paramsMap.get("selectItem");
	
	Map<String,Object> paramMap = new HashMap<String,Object>();
	StringBuffer sb = new StringBuffer();
	sb.append(" SELECT * FROM (");
	sb.append(" WITH TP AS (");
	sb.append(" SELECT TMP.MEMBERID MEMBERID,TMP.REALNAME REALNAME FROM T_MEMBER_PERSON TMP ");
	sb.append(" UNION ");
	sb.append(" SELECT TMO.MEMBERID MEMBERID,TMO.ORGNAME REALNAME FROM T_MEMBER_ORGAN TMO ");
	sb.append(" )");
	sb.append(" SELECT TT.WLOBJ WLID,");
	sb.append(" TP.REALNAME WLNAME,");
	sb.append(" TD.TYPENAME WLTYPE,");
	sb.append(" TT.ORDERID,");
	sb.append(" TT.NAME,");
	sb.append(" TT.OBJECTTYPE,");
	sb.append(" TDD.TYPENAME,");
	sb.append(" TT.ORDERDATE,");
	sb.append(" TT.TOTALQUANTITY,");
	sb.append(" TT.TOTALAMOUNT,");
	sb.append(" TT.FACTAMOUNT,");
	sb.append(" (TT.TOTALAMOUNT-TT.FACTAMOUNT)  CE,");
	sb.append(" TAA.ACCOUNTADJUSTMENTID");
	sb.append(" FROM (SELECT CASE");
	sb.append(" WHEN TG.SELLER =:memberId THEN");
	sb.append(" TG.BUYER");
	sb.append(" WHEN TG.BUYER =:memberId THEN");
	sb.append(" TG.SELLER");
	sb.append(" END WLOBJ,");
	sb.append(" TG.*");
	sb.append(" FROM T_GENERIC_ORDER TG");
	sb.append(" WHERE (TG.SELLER =:memberId OR TG.BUYER =:memberId) AND TG.ORDERSTATUS='12895') TT LEFT JOIN T_ACCOUNT_ADJUSTMENT TAA ON TAA.ORDERID=TT.ORDERID,");
	sb.append(" TP,T_MEMBER TM,T_DICTIONARY TD,T_DICTIONARY TDD");
	sb.append(" WHERE TP.MEMBERID = TT.WLOBJ AND TM.MEMBERID=TT.WLOBJ AND TD.DICTID=TM.MEMBERTYPE AND TDD.DICTID=TT.OBJECTTYPE ");
	sb.append(" ) SS WHERE 1=1");
	
	//日期条件
	if(!StringUtil.isEmpty(startDate) || !StringUtil.isEmpty(endDate)){
		if(!StringUtil.isEmpty(startDate)){
			sb.append(" AND SS.ORDERDATE >=TO_DATE(:startDate,'YYYY-MM-DD')");
			paramMap.put("startDate", startDate);
		}else if(!StringUtil.isEmpty(endDate)){
			sb.append(" AND SS.ORDERDATE <TO_DATE(:endDate,'YYYY-MM-DD')");
			paramMap.put("endDate", endDate);
		}
		if(!StringUtil.isEmpty(startDate) && !StringUtil.isEmpty(endDate)){
			sb.append(" AND SS.ORDERDATE >=TO_DATE(:startDate,'YYYY-MM-DD')");
			paramMap.put("startDate", startDate);
			sb.append(" AND SS.ORDERDATE <TO_DATE(:endDate,'YYYY-MM-DD')");
			paramMap.put("endDate", endDate);
		}
	}
	
	//订单类型
	if(!StringUtil.isEmpty(orderType)){
		sb.append(" AND SS.OBJECTTYPE=:orderType ");
		paramMap.put("orderType", orderType);
	}
	
	if(!StringUtil.isEmpty(selectItem)){
		sb.append(" AND (");
		sb.append(" SS.ORDERID='"+selectItem+"' OR");
		sb.append(" SS.NAME like '%"+selectItem+"%' OR");
		sb.append(" SS.WLNAME like '%"+selectItem+"%'");
		sb.append(" )");
//		paramMap.put("selectitem", selectItem);
	}
	
	paramMap.put("memberId", memberId);
	Pagination pagination = new Pagination();
	pagination.setPageNo(pageNo); 
 	pagination.setPageSize(pageSize);

	Pagination paginations  = this.getSimpleSpringJdbcTemplate().queryForPaginationMap(sb, pagination, paramMap);
	
	return paginations;
}

@Override
public List<Map<String, Object>> getAccountAdjustmentDetail(String memberId,String orderId) {
	// TODO Auto-generated method stub
	
	Map<String,Object> paramMap = new HashMap<String,Object>();
	StringBuffer sb = new StringBuffer();
	sb.append(" WITH TP AS (");
	sb.append(" SELECT TMP.MEMBERID MEMBERID,TMP.REALNAME REALNAME FROM T_MEMBER_PERSON TMP ");
	sb.append(" UNION ");
	sb.append(" SELECT TMO.MEMBERID MEMBERID,TMO.ORGNAME REALNAME FROM T_MEMBER_ORGAN TMO )");
	sb.append(" SELECT TT.WLOBJ WLID,");
	sb.append(" TP.REALNAME WLNAME,");
	sb.append(" TD.TYPENAME,");
	sb.append(" TT.ORDERID,");
	sb.append(" TT.NAME,");
	sb.append(" TDD.TYPENAME ORDERTYPE,");
	sb.append(" TT.TOTALQUANTITY,TT.TOTALAMOUNT,TT.FACTAMOUNT,TT.ORDERDATE ,SE.ONLINEAMOUNT,SE.OFFLINEAMOUNT,SE.CREDITAMOUNT,SE.COLSNUM");
	sb.append(" FROM (SELECT CASE WHEN TG.SELLER =:memberid THEN TG.BUYER WHEN TG.BUYER =:memberid THEN TG.SELLER END WLOBJ, TG.*");
	sb.append(" FROM T_GENERIC_ORDER TG WHERE TG.ORDERID =:orderid AND TG.ORDERSTATUS='12895' AND (TG.BUYER=:memberid OR TG.SELLER=:memberid)) TT, TP,T_MEMBER TM,T_DICTIONARY TD,T_DICTIONARY TDD,(");
	sb.append(" SELECT SS.ORDERID, CASE WHEN SUM(SS.ONLINEAMOUNT) IS NULL THEN 0 WHEN SUM(SS.ONLINEAMOUNT) IS NOT NULL THEN SUM(SS.ONLINEAMOUNT) END ONLINEAMOUNT,");
	sb.append(" CASE WHEN SUM(SS.OFFLINEAMOUNT) IS NULL THEN 0 WHEN SUM(SS.OFFLINEAMOUNT) IS NOT NULL THEN SUM(SS.OFFLINEAMOUNT) END OFFLINEAMOUNT,");
	sb.append(" CASE WHEN SUM(SS.CREDITAMOUNT) IS NULL THEN 0 WHEN SUM(SS.CREDITAMOUNT) IS NOT NULL THEN SUM(SS.CREDITAMOUNT) END CREDITAMOUNT,");
	sb.append(" COUNT(SS.ORDERID) COLSNUM");
	sb.append(" FROM (SELECT TTB.ORDERID, CASE WHEN TTB.PAYMENTMETHOD = 81 THEN TTB.AMOUNT END ONLINEAMOUNT, CASE WHEN TTB.PAYMENTMETHOD = 80 THEN TTB.AMOUNT END OFFLINEAMOUNT,");
	sb.append(" CASE WHEN TTB.PAYMENTMETHOD = 82 THEN TTB.AMOUNT END CREDITAMOUNT");
	sb.append(" FROM (SELECT TB.ORDERID,");
	sb.append(" TB.PAYMENTMETHOD,");
	sb.append(" TB.BILLTYPE,");
	sb.append(" CASE WHEN TB.AMOUNT IS NULL THEN 0 WHEN TB.AMOUNT IS NOT NULL THEN TB.AMOUNT END AMOUNT");
	sb.append(" FROM T_BILL TB WHERE 1=1 GROUP BY TB.ORDERID, TB.PAYMENTMETHOD, TB.BILLTYPE, TB.AMOUNT) TTB) SS");
	sb.append(" GROUP BY SS.ORDERID )  SE  WHERE TT.WLOBJ = TP.MEMBERID AND TM.MEMBERID=TT.WLOBJ AND TM.MEMBERTYPE=TD.DICTID AND TDD.DICTID=TT.OBJECTTYPE AND TT.ORDERID=SE.ORDERID  ");
	
	paramMap.put("memberid", memberId);
	paramMap.put("orderid", orderId);
	
	List<Map<String, Object>> list = this.getSimpleSpringJdbcTemplate().queryForMap(sb, paramMap);
	return list;
}

@Override
public int saveAccountAdjustment(AccountAdjustment accountAdjustment) {
	// TODO Auto-generated method stub
	StringBuffer sb = new StringBuffer();
	sb.append(" insert into  t_account_adjustment(accountadjustmentid,orderid,adjustdate,adjusttype,amount,memberid,transactionid,parentid,remark,status,auditstatus)  values('"+accountAdjustment.getAccountadjustmentid()+"','"+accountAdjustment.getOrderid()+"',to_timestamp('"+accountAdjustment.getAdjustdate()+"','yyyy-mm-dd hh24:mi:ss.ff'),'"+accountAdjustment.getAdjusttype()+"',"+accountAdjustment.getAmount()+",'"+accountAdjustment.getMemberid()+"','"+accountAdjustment.getTransactionid()+"','"+accountAdjustment.getParentid()+"','"+accountAdjustment.getRemark()+"','"+accountAdjustment.getStatus()+"','"+accountAdjustment.getAuditstatus()+"')");
	
	int i = getSession().createSQLQuery(sb.toString()).executeUpdate();
	return i;
}
	
}
