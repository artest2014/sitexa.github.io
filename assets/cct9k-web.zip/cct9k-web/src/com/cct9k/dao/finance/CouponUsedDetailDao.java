package com.cct9k.dao.finance;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.CouponUsedDetail;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午12:23
 */
public interface CouponUsedDetailDao extends BaseDao<CouponUsedDetail, String> {

    public Pagination getPage(int pageNo, int pageSize);

}
