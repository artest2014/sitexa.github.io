package com.cct9k.dao.finance;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.RefundRule;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:07
 */
public interface RefundRuleDao extends BaseDao<RefundRule, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public RefundRule getByProduct(String productType, String productId);
}
