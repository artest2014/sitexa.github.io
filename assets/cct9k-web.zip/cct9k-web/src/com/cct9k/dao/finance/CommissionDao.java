package com.cct9k.dao.finance;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.Commission;
import com.cct9k.entity.member.Member;

import java.util.Date;
import java.util.List;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-12
 * Time: 下午2:55
 */
public interface CommissionDao extends BaseDao<Commission, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public Pagination searchByBuyer(Member buyer, String payername, Date eventdate, int pageNo, int pageSize);
    
    public Commission getCommissionByBillId(String billId);
    
    public List<Commission> getCommissionByStatus(String status,String payer);
}
