package com.cct9k.dao.finance.impl;


import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.AccountDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.Account;
import com.cct9k.util.common.StringUtil;

@Repository
public class AccountDaoImpl extends BaseDaoImpl<Account, String> implements
		AccountDao {

	@Override
	public String getSeqn(){
		String sql = " select S_account.nextval from dual";
		Query query = getSession().createSQLQuery(sql);
		BigDecimal b = (BigDecimal) query.uniqueResult();
		return b.toString();
	}
	@Override
	public Account getAccountByOrderAndAccountItem(String sourceid,String accountItemId){
		String hql="from Account  a where a.sourceid='"+sourceid+"' and AccountItem='"+accountItemId+"'";
		List<Account> accountList=this.getListByHql(hql);
		Account account=accountList.size()==0?null:accountList.get(0);
		return account;
	} 
   @Override
   public String getOtherGetAccountAmountSum(String accountItemId,String planId,String guideId){
		StringBuffer sqlBuff=new StringBuffer("");
		sqlBuff.append("SELECT SUM(CASE A.OFFSETAMOUNT WHEN 0 THEN A.AMOUNT WHEN 1 THEN A.AMOUNT-A.OFFSETAMOUNT  END) AS AMOUNT   FROM T_ACCOUNT A WHERE A.ITEMID='"+accountItemId+"' AND A.SOURCEID='"+planId+"' AND A.OFFSETAMOUNT!=3 AND A.MEMBERID='"+guideId+"'");
		List querylist= getSession().createSQLQuery(sqlBuff.toString()).list();
		String result=querylist==null?"":(String)querylist.get(0);
		return result;
	}

@Override
public List<Account> getAccountBySalesAndBuyerAndItem(String memberId,String salesId,
		String buyerId, String itemId,String orderByAccountDate,boolean isAvalide) {
	// TODO Auto-generated method stub
	
	String sql = "SELECT * FROM T_ACCOUNT TS WHERE TS.MEMBERID="+memberId+" AND ((TS.BUYERID="+buyerId+" AND TS.SALERID="+salesId+") OR (TS.BUYERID="+salesId+" AND TS.SALERID="+buyerId+")) AND (TS.IFOFFSET='0' OR TS.IFOFFSET='1') AND TS.AMOUNT>0";
	
	if(!StringUtil.isEmpty(itemId)){
		sql = sql + " AND TS.ITEMID="+itemId; 
	}
	
	if(isAvalide){
		sql = sql +" AND TS.STATUS='1'";
	}else{
		sql = sql +" AND TS.STATUS='2'";
	}
	if(!StringUtil.isEmpty(orderByAccountDate)){
		sql = sql + "order by ts.accountdate "+orderByAccountDate;
	}
	
	SQLQuery query = getSession().createSQLQuery(sql);
	List<Account> list = (List<Account>)(query.addEntity(Account.class).list());
	
	return list;
}
@Override
public List<Account> getAccountList(HashMap<String, String> paraMap,HashMap<String,String> orderMap) {
		// TODO Auto-generated method stub
		
		Set<String> hashSet = paraMap.keySet();
		Set<String> orderSet = null;
		if(orderMap!=null){
			orderSet = orderMap.keySet();
		}
		
		
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT * FROM T_ACCOUNT TS WHERE 1=1");
		
		Iterator<String> it = hashSet.iterator(); 
		while(it.hasNext()){
			String prop = it.next();
			String value = paraMap.get(prop);
			if(!StringUtil.isEmpty(value)){
				sb.append(" AND "+prop+"="+value);
			}
		}
		
		String descStr = "";
		int descFlag = 0;
		String ascStr = "";
		int ascFlag = 0;
		if(orderSet!=null){
			sb.append(" order by ");
			Iterator<String> orderIt = orderSet.iterator(); 
			while(orderIt.hasNext()){
				String prop = orderIt.next();
				String value = paraMap.get(prop);
				if("desc".equals(value.trim())){
					if(descFlag>1){
						descStr = descStr + ",";
					}
					descStr = descStr + prop;
					descFlag = descFlag +1;
				}
				if("asc".equals(value.trim())){
					if(ascFlag>1){
						ascStr =  ascStr + "1";
					}
					ascStr = ascStr + prop;
					ascFlag = ascFlag +1 ;
				}
			}
		}
		if(descStr.length()>0){
			sb.append(descStr);
		}else if(ascStr.length()>0){
			sb.append(ascStr);
		}
		
		
		
		SQLQuery query = getSession().createSQLQuery(sb.toString());
		List<Account> list = query.addEntity(Account.class).list();
		return list;
	}

/**
 * @param paraMap : 参数集合。
 * memberId 几张主体
 * customerName 客户名字
 * startDate 查询开始日期
 * endDate 查询结束日期
 * customerSource 客户来源：自维护客户、内部员工或者平台商铺
 * customerType 客户类型：吃住行游购娱和旅行社，该字段为其dic表里的typeid
 */
@Override
public Pagination getAccountReconciliationStatement(HashMap<String,String> paraMap ,int pageSize,int pageNo) {
	// TODO Auto-generated method stub
	
	Map<String,Object> csMap = new HashMap<String,Object>();
	
	String memberid = paraMap.get("memberId");
	String customerName = paraMap.get("customerName");
	String startDate = paraMap.get("startDate");
	String endDate = paraMap.get("endDate");
	String customerSource = paraMap.get("customerSource");
	String customerType = paraMap.get("customerType");
	
	StringBuffer sb = new StringBuffer();
	String sql = " select * 				"+
				 " from ( 					"+
				 " select taccd.chekcdayid, "+
				 " taccd.customername,      "+
       			 " case                     "+
				 " when taccd.customertype = 1 then "+
                 " '自维护客户'							"+
				 " when taccd.customertype = 2 then "+
				 " '内部员工'							"+
				 " when taccd.customertype = 3 then "+
				 " '平台商铺'							"+
				 " end customersource,				"+
				 " fun_finance_getCustomerType(taccd.customertype, "+
                 "                  taccd.objectcateid,			   "+
                 "                  taccd.objecttypeid,			   "+
                 "                  taccd.associateobjectid) customertypename, "+
                 " fun_finance_getCustomerType_Id(taccd.customertype, "+
                 "                         taccd.objectcateid,		  "+
                 "                         taccd.objecttypeid,        "+
                 "                         taccd.associateobjectid) customertypeid,"+
				 " taccd.associateobjectid customerid,  "+
				 " taccd.openingaccounts,				"+
				 " taccd.accountreceivabletoday,		"+
				 " taccd.receivedtoday,					"+
				 " taccd.receivedbalancetoday,			"+
				 " taccd.currentpayable,				"+
				 " taccd.accountpayabletoday,			"+
				 " taccd.payabledtoday,					"+
				 " taccd.payablebalancetoday,			"+
				 " taccd.amount,						"+ 
				 " taccd.customertype, 					"+
				 " taccd.checkdate,						"+
				 " taccd.objectcateid,					"+
				 " taccd.objecttypeid						"+
				 " from t_account_customer_check_day taccd	"+
				 " where taccd.memberid =:memberId   				"+ 
				 " ) tt 									"+
				 " where 1 = 1 ";	
	
	csMap.put("memberId", memberid);
	
	if(!StringUtil.isEmpty(customerName)){
		sql = sql + " and tt.customername like '%"+customerName+"%'";
	}
	if(!StringUtil.isEmpty(startDate)){
		sql = sql + " and to_date(tt.checkdate,'yyyy-mm-dd')>to_date('"+startDate+"','yyyy-mm-dd')";
	}
	if(!StringUtil.isEmpty(endDate)){
		sql = sql + " and to_date(tt.checkdate,'yyyy-mm-dd')<=to_date('"+endDate+"','yyyy-mm-dd')";
	}
	if(!StringUtil.isEmpty(customerSource)){
		sql = sql + " and tt.customertype=:customerSource";
		csMap.put("customerSource", customerSource);
	}
	if(!StringUtil.isEmpty(customerType)){
		sql = sql + " and tt.customertypeid=:customerType";
		csMap.put("customerType", customerType);
	}
	
	Pagination pagination = new Pagination();
	pagination.setPageNo(pageNo);
	pagination.setPageSize(pageSize);
	
	sb.append(sql);
	
	return this.getSimpleSpringJdbcTemplate().queryForPaginationMap(sb, pagination, csMap);
}
	
}
