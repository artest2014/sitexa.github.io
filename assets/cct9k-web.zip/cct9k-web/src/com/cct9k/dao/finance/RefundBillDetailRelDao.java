package com.cct9k.dao.finance;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.RefundBillDetailRel;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:06
 */
public interface RefundBillDetailRelDao extends BaseDao<RefundBillDetailRel, String> {

	public List<RefundBillDetailRel>   getRefundBillDetailRelList(String orderId);
	
	public List<RefundBillDetailRel>   getRefundBillDetailRelListByRefundId(String refundId);
}
