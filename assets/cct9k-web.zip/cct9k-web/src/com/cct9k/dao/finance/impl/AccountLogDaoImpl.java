package com.cct9k.dao.finance.impl;

import com.cct9k.dao.finance.AccountLogDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.AccountLog;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class AccountLogDaoImpl extends BaseDaoImpl<AccountLog, String> implements AccountLogDao {
    @Override
    public String getSeqn() {
        String sql = " select s_accountLog.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }
}
