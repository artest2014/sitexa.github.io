package com.cct9k.dao.finance.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.PlanCheckDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Plan;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;
import org.springframework.stereotype.Repository;

import java.util.Date;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:50
 */
@Repository
public class PlanCheckDaoImpl extends BaseDaoImpl<Plan, String> implements PlanCheckDao {
 
    //行程计划审核   过滤
    public Pagination searchByPlanstatus(Member reseller, String planid, String planname, String routename, Date starttime, int pageNo, int pageSize) {
        if (reseller == null) return null;												
        Finder f = Finder.create("from Plan p where p.reseller.memberid=:memberid and p.planstatus in (1,2) ");
        f.setParam("memberid", reseller.getMemberid());

        if (!StringUtil.isEmpty(planid)) {
            f.append(" and p.planid=:planid ");
            f.setParam("planid", planid);
        }

        if (!StringUtil.isEmpty(planname)) {
            f.append(" and p.planname like '%'||:planname||'%' ");
            f.setParam("planname", planname);
        }

        if (!StringUtil.isEmpty(routename)) {
            f.append(" and p.route.routename like '%'||:routename||'%' ");
            f.setParam("routename", routename);
        }

        if (starttime != null) {
            Date endtime = DateUtil.addDaysToDate(starttime, 1);
            f.append(" and p.starttime >=:starttime and p.starttime <=:endtime ");
            f.setParam("starttime", starttime).setParam("endtime", endtime);
        }

        f.append(" order by p.starttime desc ");

        return find(f, pageNo, pageSize);
    }

}
