/**
 * <p>Class Name: TeamDao.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-5-31</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.finance;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.CheckSheet;
import com.cct9k.web.vo.reseller.CheckSheetDaysVo;
import com.cct9k.web.vo.reseller.CheckSheetDetailVo;
import com.cct9k.web.vo.reseller.CheckSheetStatisticsVo;


/**
 *
 */
public interface CheckSheetDao extends BaseDao<CheckSheet, String> {
	public Pagination getPage(String planid,String startTime, String routename,  String guide,String seller,String status,int pageNo,
			int pageSize);
	public List<CheckSheetStatisticsVo> getCheckSheetStatistics(String planid);
	public List<CheckSheetDaysVo> getCheckSheetDays(String sheetid,int invoicetype);
	public List<CheckSheetDetailVo> getCheckSheetDetail(String sheetid,int invoicetype,String starttime,String tabname,String idcolname,String plansellercolname);
}
