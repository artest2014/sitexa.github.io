package com.cct9k.dao.finance;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.reseller.Plan;

import java.util.Date;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:49
 */
public interface PlanCheckDao extends BaseDao<Plan, String> {
	
    public Pagination searchByPlanstatus(Member reseller, String planid, String planname, String routename, Date starttime, int pageNo, int pageSize);
  }
