package com.cct9k.dao.finance;

import java.util.HashMap;
import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.Account;

public interface AccountDao extends BaseDao<Account, String> {
 
	public String getSeqn();

	/**
	 * 获取记账信息
	 * @param sourceid 来源id
	 * @param accountItemId 账单类型
	 * @return
	 */
	public Account getAccountByOrderAndAccountItem(String sourceid,
			String accountItemId);
	
	/**
	 * 根据卖家、买家和科目获取部分冲抵或者未充抵的account
	 * @param memberId 主体id
	 * @param salesId
	 * @param BuyerId
	 * @param itemId 
	 * @param isAvalide true:可用的；false:不可用的
	 * @param orderByAccountDate  按accountDate记账日期排序，orderByAccountDate：asc，升序；orderByAccountDate：desc 降序（可为空）
	 * @return
	 */
	public List<Account> getAccountBySalesAndBuyerAndItem(String memberId,String salesId,String BuyerId,String itemId,String orderByAccountDate,boolean isAvalide);
	
	/**
	 * 查找 符合条件的account集合
	 * @param paraMap <key,value>,其中key为要过滤的数据库字段；value为其值
	 * @param orderMap <key,value> 如：<accountid,desc>
	 * @return
	 */
	public List<Account> getAccountList(HashMap<String,String> paraMap,HashMap<String,String> orderMap);

	/**
	 * 查询团的 其他应收总额
	 * @param accountItemId  其他应收 账目id
	 * @param planId 团id
	 * @return
	 */
	public String getOtherGetAccountAmountSum(String accountItemId, String planId,String guideId);
	
	/**
	 * 财务，客户对账报表
	 * @return
	 * @param paraMap : 参数集合。
	 * memberId 几张主体
	 * customerName 客户名字
	 * startDate 查询开始日期
	 * endDate 查询结束日期
	 * customerSource 客户来源：自维护客户、内部员工或者平台商铺
	 * customerType 客户类型：吃住行游购娱和旅行社，该字段为其dic表里的typeid
	 */
	public Pagination getAccountReconciliationStatement(HashMap<String,String> paraMap ,int pageSize,int pageNo);
}
