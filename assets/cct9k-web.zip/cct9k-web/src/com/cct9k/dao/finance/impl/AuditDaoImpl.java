/**
 * <p>Class Name: AuditDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-5-31</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.finance.impl;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.AuditDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.Audit;

/**
 *
 */
@Repository
public class AuditDaoImpl extends BaseDaoImpl<Audit, String>
		implements
			AuditDao {

	@Override
	public Audit getAuditByObjectid(String objectid) {
		String hql = "from Audit ad where  ad.objectid='" + objectid + "'";
		Audit audit = (Audit) getSession().createQuery(hql).uniqueResult();
		return audit;
	}
	@Override
	public Pagination getPage(int pageNo, int pageSize) {
		Finder r = Finder.create("from Audit model where 1=1");

		r.append(" order by auditdate1 desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public List<Audit> getAuditList(String objectid) {
		String hql = ("select a from Audit a where a.objectid='" + objectid + "'");

		List<Audit> list = getListByHql(hql);
		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	@Override
	public Audit getNewestAuditByObjectid(String objectid) {
		String sql = "select * from (select t.*,row_number() over (order by t.auditid desc ) row_number from t_audit t where t.objectid='"
				+ objectid + "') where row_number=1  ";
		return (Audit) getSession().createSQLQuery(sql).addEntity(Audit.class)
				.uniqueResult();
	}

}
