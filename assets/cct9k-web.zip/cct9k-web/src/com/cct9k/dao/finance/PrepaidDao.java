package com.cct9k.dao.finance;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.Prepaid;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:03
 */
public interface PrepaidDao extends BaseDao<Prepaid, String> {

    public Pagination getPage(int pageNo, int pageSize);

}
