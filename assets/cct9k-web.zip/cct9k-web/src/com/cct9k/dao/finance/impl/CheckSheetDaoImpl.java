/**
 * <p>Class Name: TeamDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-5-31</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.finance.impl;


import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.CheckSheetDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.CheckSheet;
import com.cct9k.entity.finance.Invoice;
import com.cct9k.util.common.StringUtil;
import com.cct9k.web.vo.reseller.CheckSheetDaysVo;
import com.cct9k.web.vo.reseller.CheckSheetDetailVo;
import com.cct9k.web.vo.reseller.CheckSheetStatisticsVo;


/**
 *
 */
@Repository
public class CheckSheetDaoImpl extends BaseDaoImpl<CheckSheet, String> implements CheckSheetDao {
	public Pagination getPage(String planid,String starttime, String routename,  String guide,String seller,String status,int pageNo,
			int pageSize){
		Finder f = Finder.create("from CheckSheet model where 1=1 ");	
		if(!StringUtil.isEmpty(planid)){
			f.append(" and model.plan.planid = :planid ");
			f.setParam("planid", planid);
		}
		if(!StringUtil.isEmpty(routename)){
			f.append(" and model.plan.route.routename like '%'||:routename||'%' ");
			f.setParam("routename", routename);
		}
		if(!StringUtil.isEmpty(starttime)){
			f.append(" and to_char(model.plan.starttime,'yyyy-mm-dd') = :starttime ");
			f.setParam("starttime", starttime);
		}
		if(!StringUtil.isEmpty(guide)){
			f.append(" and model.plan.guide.memberPerson.realname like '%'||:guide||'%' ");
			f.setParam("guide", guide);
		}
		if(!StringUtil.isEmpty(seller)){
			f.append(" and model.plan.reseller.memberid = :seller ");
			f.setParam("seller", seller);
		}
		if(!StringUtil.isEmpty(status)){
			f.append(" and model.status.typeid = :status ");
			f.setParam("status", status);
		}

		f.append(" order by model.createdate desc");
		return find(f, pageNo, pageSize);
	}
	
	public List<CheckSheetStatisticsVo> getCheckSheetStatistics(String planid){
		StringBuffer sb = new StringBuffer();
		sb.append("select to_char(starttime,'yyyy-mm-dd') starttime,");
		sb.append("(select sum(amount) from t_plan_restaurant a where a.stopid = t.stopid) restaurantPlan ,");
		sb.append("(select sum(b.amount) from t_invoice b,t_plan_restaurant bb where b.objecttype = "+Invoice.INVOICE_TYPE_RESTAURANT+"  and  bb.stopid = t.stopid) restaurantReal,");
		sb.append("(select sum(amount) from t_plan_hotel c where c.stopid = t.stopid) hotelPlan,");
		sb.append("(select sum(d.amount) from t_invoice d,t_plan_hotel dd where d.objecttype = "+Invoice.INVOICE_TYPE_HOTEL+"  and  dd.stopid = t.stopid) hotelReal,");
		sb.append("(select sum(amount) from t_plan_transport e where e.stopid = t.stopid) transportPlan,");
		sb.append("(select sum(f.amount) from t_invoice f,t_plan_transport ff where f.objecttype = "+Invoice.INVOICE_TYPE_TRANSPORT+"  and  ff.stopid = t.stopid) transportReal,");
		sb.append("(select sum(amount) from t_plan_gate g where g.stopid = t.stopid) gatePlan,");
		sb.append("(select sum(h.amount) from t_invoice h,t_plan_gate hh where h.objecttype = "+Invoice.INVOICE_TYPE_GATE+"  and  hh.stopid = t.stopid) gateReal,");
		sb.append("(select sum(amount) from t_plan_show i where i.stopid = t.stopid) showPlan,");
		sb.append("(select sum(j.amount) from t_invoice j,t_plan_show jj where j.objecttype = "+Invoice.INVOICE_TYPE_SHOW+" and  jj.stopid = t.stopid) showReal ");
		sb.append("from t_plan_stop t where t.planid = '"+planid+"' order by t.starttime asc");
		
		System.out.println(sb.toString());
		List<Object[]> list = getSession().createSQLQuery(sb.toString()).list();
		List<CheckSheetStatisticsVo> checkSheetStatList = new ArrayList<CheckSheetStatisticsVo>();
		for (Object[] mr : list) {
			  CheckSheetStatisticsVo  vo = new CheckSheetStatisticsVo();
			  vo.setStarttime(StringUtil.emptyToDefined(mr[0],""));
			  vo.setRestaurantPlan(StringUtil.emptyToDefined(mr[1],""));
			  vo.setRestaurantReal(StringUtil.emptyToDefined(mr[2],""));
			  vo.setHotelPlan(StringUtil.emptyToDefined(mr[3],""));
			  vo.setHotelReal(StringUtil.emptyToDefined(mr[4],""));
			  vo.setTransportPlan(StringUtil.emptyToDefined(mr[5],""));
			  vo.setTransportReal(StringUtil.emptyToDefined(mr[6],""));
			  vo.setGatePlan(StringUtil.emptyToDefined(mr[7],""));
			  vo.setGateReal(StringUtil.emptyToDefined(mr[8],""));
			  vo.setShowPlan(StringUtil.emptyToDefined(mr[9],""));
			  vo.setShowReal(StringUtil.emptyToDefined(mr[10],""));
			  
			  checkSheetStatList.add(vo);	
		}
		return checkSheetStatList;
	}
	
	public List<CheckSheetDaysVo> getCheckSheetDays(String sheetid,int invoicetype){
		String tabname = "";
		String idcolname = "";
		String plansellercolname = "";
		switch(invoicetype)
		{
		  case 62:
			  tabname = "t_plan_restaurant";
			  idcolname = "planrestaurantid";
			  plansellercolname = "restauaurant";
			  break;
		  case 63:
			  tabname = "t_plan_hotel";
			  idcolname = "planhotelid";
			  plansellercolname = "hotel";
			  break;
		  case 64: 
			  tabname = "t_plan_transport";
			  idcolname = "plantransportid";
			  plansellercolname = "transport";
			  break;
		  case 65: 
			  tabname = "t_plan_gate";
			  idcolname = "plangateid";
			  plansellercolname = "gate";
			  break;
		  case 67: 
			  tabname = "t_plan_show";
			  idcolname = "planshowid";
			  plansellercolname = "show";
			  break;
		}
		
		StringBuffer sb = new StringBuffer();
		sb.append("select to_char(ttt.starttime,'yyyy-mm-dd') starttime,sum(t.amount),count(*)+1 from ");
		sb.append("t_invoice t,"+tabname+" tt,t_plan_stop ttt ");
		sb.append("where t.sheetid = "+sheetid+" and t.objecttype = "+invoicetype+" and t.objectid = tt."+idcolname+" ");
		sb.append("and tt.stopid = ttt.stopid group by ttt.starttime order by ttt.starttime asc");

		List<Object[]> list = getSession().createSQLQuery(sb.toString()).list();
		List<CheckSheetDaysVo> checkSheetDaysList = new ArrayList<CheckSheetDaysVo>();
		for (Object[] mr : list) {
			CheckSheetDaysVo vo = new CheckSheetDaysVo();
			vo.setStarttime(StringUtil.emptyToDefined(mr[0],""));
			vo.setTotalamount(StringUtil.emptyToDefined(mr[1],""));
			vo.setRowspan(StringUtil.emptyToDefined(mr[2],""));
			vo.setDetail(this.getCheckSheetDetail(sheetid, invoicetype, vo.getStarttime(),tabname,idcolname,plansellercolname));
			checkSheetDaysList.add(vo);
		}
		return checkSheetDaysList;
	}
	
	
	public List<CheckSheetDetailVo> getCheckSheetDetail(String sheetid,int invoicetype,String starttime,String tabname,String idcolname,String plansellercolname){
		StringBuffer sb = new StringBuffer();
		sb.append("select c.starttime,c.invoiceno,d.membername||','||c.planamount plan,c.membername,c.amount,c."+idcolname+" from ");
		sb.append("(select a.starttime,a.invoiceno,a.planseller,a.planamount,b.membername,a.amount,a."+idcolname+" from ");
		sb.append("(select to_char(ttt.starttime,'yyyy-mm-dd') starttime,t.invoiceno,tt."+plansellercolname+" planseller,tt.amount planamount,t.seller realseller,t.amount,tt."+idcolname+" from ");
		sb.append("t_invoice t,"+tabname+" tt,t_plan_stop ttt ");
		sb.append("where t.sheetid = "+sheetid+" and t.objecttype = "+invoicetype+" and t.objectid = tt."+idcolname+" ");
		sb.append("and tt.stopid = ttt.stopid and to_char(ttt.starttime,'yyyy-mm-dd')='"+starttime+"' order by ttt.starttime asc) a,t_member b ");
		sb.append("where a.realseller = b.memberid) c,t_member d ");
		sb.append("where c.planseller = d.memberid");
		
		List<Object[]> list = getSession().createSQLQuery(sb.toString()).list();
		List<CheckSheetDetailVo> checkSheetDetailList = new ArrayList<CheckSheetDetailVo>();
		for (int i = 0; i < list.size(); i++) {
			Object[] mr = (Object[])list.get(i);
			CheckSheetDetailVo vo = new CheckSheetDetailVo();
			vo.setStarttime(StringUtil.emptyToDefined(mr[0],""));
			vo.setInvoiceno(StringUtil.emptyToDefined(mr[1],""));
			vo.setPlan(StringUtil.emptyToDefined(mr[2],""));
			if(i!=0&&StringUtil.emptyToDefined(mr[5],"").equals(StringUtil.emptyToDefined(((Object[])list.get(i-1))[5],""))){
				vo.setPlan("");
			}
			vo.setRealseller(StringUtil.emptyToDefined(mr[3],""));
			vo.setAmount(StringUtil.emptyToDefined(mr[4],""));
			vo.setPlanid(StringUtil.emptyToDefined(mr[5],""));
			checkSheetDetailList.add(vo);
		}

		return checkSheetDetailList;
	}
}
