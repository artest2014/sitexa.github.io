package com.cct9k.dao.finance.impl;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.finance.BillDebtDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.view.BillDebt;
import com.cct9k.web.vo.BillDebtVo;

@Repository
public class BillDebtDaoImpl extends BaseDaoImpl<BillDebt, String> implements BillDebtDao {

	@Override
	public List<BillDebtVo> findEntertainmentBuill(String receiver, String payer) {
		StringBuffer sb = new StringBuffer("select vb.billid, o.id, o.name,");
		sb.append("o.sonId, o.orderId, vb.amount, vb.debt, o.orderDate from V_BILL_DEBT vb inner join (select tgo.orderId, ");
		sb.append("max(tgo.orderDate) as orderDate, max(ods.showName) as name, max(ods.productid) as sonId, max(ods.entertainmentid) as id from T_GENERIC_ORDER ");
		sb.append("tgo inner join T_Order_Detail_Show ods on tgo.orderId=ods.orderId group by tgo.orderid) o on vb.orderid=o.orderId where vb.receiver=:receiver ");
		sb.append("and vb.payer=:payer and vb.debt>0");
		
		return ((SQLQuery) getSession().createSQLQuery(sb.toString())
				.setParameter("receiver", receiver).setParameter("payer", payer)
				.setResultTransformer(Transformers.aliasToBean(BillDebtVo.class)))
				.addScalar("billId").addScalar("id").addScalar("name").addScalar("sonId")
				.addScalar("orderId").addScalar("amount").addScalar("debt").addScalar("orderDate").list();
		
	}

	@Override
	public List<BillDebtVo> findHotelBuill(String receiver, String payer) {
		StringBuffer sb = new StringBuffer("select vb.billid, o.id, o.name,");
		sb.append("o.sonId, o.orderId, vb.amount, vb.debt, o.orderDate from V_BILL_DEBT vb inner join (");
		sb.append("select tgo.orderid, max(tgo.orderdate) as orderdate, max(odh.hotelname) as name, max(odh.productid) as sonId, ");
		sb.append("max(odh.hotelid) as id from t_generic_order tgo inner join t_order_detail_hotel odh on tgo.orderid = odh.orderid");
		sb.append(" group by tgo.orderid) o on vb.orderid=o.orderId where vb.receiver=:receiver ");
		sb.append("and vb.payer=:payer and vb.debt>0");
		return ((SQLQuery) getSession().createSQLQuery(sb.toString())
				.setParameter("receiver", receiver).setParameter("payer", payer)
				.setResultTransformer(Transformers.aliasToBean(BillDebtVo.class)))
				.addScalar("billId").addScalar("id").addScalar("name").addScalar("sonId")
				.addScalar("orderId").addScalar("amount").addScalar("debt").addScalar("orderDate").list();
	}

	@Override
	public List<BillDebtVo> findRestaurantBuill(String receiver, String payer) {
		StringBuffer sb = new StringBuffer("select vb.billid, o.id, o.name,");
		sb.append("o.sonId, o.orderId, vb.amount, vb.debt, o.orderDate from V_BILL_DEBT vb inner join (");
		sb.append("select tgo.orderid, max(tgo.orderdate) as orderdate, max(odr.restaurant) as name, max(odr.productid) as sonId, ");
		sb.append("max(odr.restaurantid) as id from t_generic_order tgo inner join t_order_detail_restaurant odr on tgo.orderid = odr.orderid");
		sb.append(" group by tgo.orderid) o on vb.orderid=o.orderId where vb.receiver=:receiver ");
		sb.append("and vb.payer=:payer and vb.debt>0");
		return ((SQLQuery) getSession().createSQLQuery(sb.toString())
				.setParameter("receiver", receiver).setParameter("payer", payer)
				.setResultTransformer(Transformers.aliasToBean(BillDebtVo.class)))
				.addScalar("billId").addScalar("id").addScalar("name").addScalar("sonId")
				.addScalar("orderId").addScalar("amount").addScalar("debt").addScalar("orderDate").list();
	}

	@Override
	public List<BillDebtVo> findSceneryBuill(String receiver, String payer) {
		StringBuffer sb = new StringBuffer("select vb.billid, o.id, o.name,");
		sb.append("o.sonId, o.orderId, vb.amount, vb.debt, o.orderDate from V_BILL_DEBT vb inner join (");
		sb.append("select tgo.orderid, max(tgo.orderdate) as orderdate, max(odg.gatename) as name, max(odg.productid) as sonId, ");
		sb.append("max(odg.sceneryid) as id from t_generic_order tgo inner join t_order_detail_gate odg on tgo.orderid = odg.orderid");
		sb.append(" group by tgo.orderid) o on vb.orderid=o.orderId where vb.receiver=:receiver ");
		sb.append("and vb.payer=:payer and vb.debt>0");
		return ((SQLQuery) getSession().createSQLQuery(sb.toString())
				.setParameter("receiver", receiver).setParameter("payer", payer)
				.setResultTransformer(Transformers.aliasToBean(BillDebtVo.class)))
				.addScalar("billId").addScalar("id").addScalar("name").addScalar("sonId")
				.addScalar("orderId").addScalar("amount").addScalar("debt").addScalar("orderDate").list();
	}

	@Override
	public List<BillDebtVo> findTransportBuill(String receiver, String payer) {
		StringBuffer sb = new StringBuffer("select vb.billid, o.id, o.name,");
		sb.append("o.sonId, o.orderId, vb.amount, vb.debt, o.orderDate from V_BILL_DEBT vb inner join (");
		sb.append("select tgo.orderid, max(tgo.orderdate) as orderdate, max(odt.transportname) as name, max(odt.productid) as sonId,");
		sb.append(" max(odt.transportid) as id from t_generic_order tgo inner join t_order_detail_transport odt on tgo.orderid = odt.orderid");
		sb.append(" group by tgo.orderid) o on vb.orderid=o.orderId where vb.receiver=:receiver ");
		sb.append("and vb.payer=:payer and vb.debt>0");
		return ((SQLQuery) getSession().createSQLQuery(sb.toString())
				.setParameter("receiver", receiver).setParameter("payer", payer)
				.setResultTransformer(Transformers.aliasToBean(BillDebtVo.class)))
				.addScalar("billId").addScalar("id").addScalar("name").addScalar("sonId")
				.addScalar("orderId").addScalar("amount").addScalar("debt").addScalar("orderDate").list();
	}
	@Override
	public List<BillDebtVo> findRouteBuill(String receiver, String payer) {
		StringBuffer sb = new StringBuffer("select vb.billid, o.id, o.name, o.orderId, ");
		sb.append("vb.amount, vb.debt, o.orderDate from V_BILL_DEBT vb inner join(select tgo.orderid, tgo.orderdate,");
		sb.append("tr.routename as name,tr.routeid as id from t_generic_order tgo ");
		sb.append(" inner join t_order_detail_plan odp on tgo.orderid=odp.orderid inner join t_route tr");
		sb.append(" on odp.routeid=tr.routeid ) o on vb.orderid=o.orderid where ");		
		sb.append(" vb.receiver=:receiver and vb.payer=:payer and vb.debt>0");
		return ((SQLQuery) getSession().createSQLQuery(sb.toString())
				.setParameter("receiver", receiver).setParameter("payer", payer)
				.setResultTransformer(Transformers.aliasToBean(BillDebtVo.class)))
				.addScalar("billId").addScalar("id").addScalar("name").addScalar("orderId").addScalar("amount").addScalar("debt").addScalar("orderDate").list();
	}
}
