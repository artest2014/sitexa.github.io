package com.cct9k.dao.finance;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.Bank;

public interface BankDao extends BaseDao<Bank, String> {

}
