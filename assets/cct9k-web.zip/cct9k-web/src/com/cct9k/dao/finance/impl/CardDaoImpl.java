package com.cct9k.dao.finance.impl;

import com.cct9k.dao.finance.CardDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.Card;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class CardDaoImpl extends BaseDaoImpl<Card, String> implements CardDao {

    @Override
    public String getSeqn() {
        String sql = " select S_CARD.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }
}
