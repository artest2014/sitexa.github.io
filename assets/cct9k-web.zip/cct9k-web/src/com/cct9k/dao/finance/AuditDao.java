/**
 * <p>Class Name: AuditDao.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Date: 2013-5-31</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.finance;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.Audit;

/**
 *
 */
public interface AuditDao extends BaseDao<Audit, String> {
	public String getSeqn();

	public Audit getAuditByObjectid(String objectid);

	public List<Audit> getAuditList(String objectid);

	public Audit getNewestAuditByObjectid(String objectid);

	public Pagination getPage(int pageNo, int pageSize);

}
