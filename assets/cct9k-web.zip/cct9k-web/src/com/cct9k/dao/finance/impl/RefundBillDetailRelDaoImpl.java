package com.cct9k.dao.finance.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.finance.RefundBillDetailRelDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.allinpay.WithdrawApplyDetail;
import com.cct9k.entity.finance.RefundBillDetailRel;

/**
 * Author: oscar peng <xnpeng@hotmail.com> Date: 13-8-10 Time: 下午2:06
 */
@Repository
public class RefundBillDetailRelDaoImpl extends BaseDaoImpl<RefundBillDetailRel, String>
		implements RefundBillDetailRelDao {

	public List<RefundBillDetailRel>   getRefundBillDetailRelList(String orderId){
	    String sql = "select b.* from t_bill t,t_refund_bill_detail_rel b where t.orderid='"+orderId+"' and t.billtypecate='billType' "
	    		+ "and t.billtype='onlinetracash'  and t.ifpay='1' and t.billid=b.billid " ;
        List<RefundBillDetailRel> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(RefundBillDetailRel.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
    }
	
	public List<RefundBillDetailRel>   getRefundBillDetailRelListByRefundId(String refundId){
	    String sql = "select b.* from t_refund_apply_detail a,t_refund_bill_detail_rel b where a.auditstatus='2' "
	    		+ "  and a.refundid=b.refundid and a.refundid='"+refundId+"'" ;
        List<RefundBillDetailRel> resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).addEntity(RefundBillDetailRel.class).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
    }
	
	

}
