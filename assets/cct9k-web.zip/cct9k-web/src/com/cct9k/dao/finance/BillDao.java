package com.cct9k.dao.finance;


import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.Bill;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:32
 */
public interface BillDao extends BaseDao<Bill, String> {

    public Pagination getPage(int pageNo, int pageSize);
    
    public Pagination getcleanBillPage(String buy,String sale,String starttime, String endtime,int pageNo, int pageSize);
    
    public Bill getBillByOrderId(String orderId);
    
    public List<String> getPaymentMethod(String orderId,String dictId);
    /**
     * 根据买卖双方和挂账类型查询挂账账单
     * @param ordertype
     * @param payer
     * @param receiver
     * @param billtype
     * @return Bill
     */
    public Pagination getBillCreat(String ordertype,String payer,String receiver,String billtype,String orderid,String starttime, String endtime, int pageNo, int pageSize);

    public Pagination getMemberBillsByGroupType(String endDate,String membername,String groupType,String reseller,int pageNo, int pageSize);

    public Pagination getRepayBillLogByPayer(String payDate,String number,String payer,String reseller,int pageNo, int pageSize);
    /**
     * 根据订单号查询 bill列表，因为线路可以支持 3种付款方式 ，可以一个订单记账多次
     * @param orderId 订单id
     * @return
     */
	List<Bill> getBillListByOrderId(String orderId);
	 /**
     * 根据订单号查询 bill列表，因为线路可以支持 3种付款方式 ，可以一个订单记账多次
     * @param orderId 订单id
     * @param billType 账单类型
     * @return
     */
	Bill getBillByOrderAndBillType(String orderId, String billType);

}
