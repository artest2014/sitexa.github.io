package com.cct9k.dao.finance.impl;

import com.cct9k.dao.finance.CardTypeDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.CardType;

import org.springframework.stereotype.Repository;

/**
 * @author yics
 *         2013-04-08
 */
@Repository
public class CardTypeDaoImpl extends BaseDaoImpl<CardType, String> implements CardTypeDao {

}
