package com.cct9k.dao.finance.impl;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.finance.AccountRelatedDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.AccountItem;
import com.cct9k.entity.finance.AccountRelated;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.StringUtil;

@Repository
public class AccountRelatedDaoImpl extends BaseDaoImpl<AccountRelated, String> implements
AccountRelatedDao {

	@Override
	public List<AccountRelated> getAccountRelatedByMemberIdAndRelateTypeAndRelateSource(
			String memberId, String relateType, String relateSource) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM T_ACCOUNT_RELATED TAR WHERE TAR.MEMBERID="+memberId;
		
		if(!StringUtil.isEmpty(relateType)){
			sql = sql + " AND TAR.RELATETYPE="+relateType;
		}
		
		if(!StringUtil.isEmpty(relateSource)){
			sql = sql + " AND TAR.RELATESOURCE="+relateSource;
		}
		SQLQuery query = getSession().createSQLQuery(sql);
		List<AccountRelated> list= query.addEntity(AccountRelated.class).list();
		
		return list;
	}

	@Override
	public List<AccountRelated> checkMemberExist(String memberId, String relateType,
			String relateMemberId) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM T_ACCOUNT_RELATED TAR WHERE TAR.MEMBERID="+memberId+" AND TAR.RELATEMEMBERID="+relateMemberId;
		if(!StringUtil.isEmpty(relateType)){
			sql = sql + " AND TAR.RELATETYPE="+relateType;
		}
		
		SQLQuery sqlQuery = getSession().createSQLQuery(sql);
		List<AccountRelated> list = sqlQuery.addEntity(AccountRelated.class).list();
		return list;
	}

	@Override
	public List<AccountRelated> getDetail(String memberId, String relateId,
			String relateMemberId) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM T_ACCOUNT_RELATED TAR WHERE TAR.MEMBERID="+memberId;
		if(!StringUtil.isEmpty(relateId)){
			sql = sql + " AND TAR.RELATEID="+relateId;
		}
		if(!StringUtil.isEmpty(relateMemberId)){
			sql = sql + " AND TAR.RELATEMEMBERID="+relateMemberId;
		}
		SQLQuery sqlQuery = getSession().createSQLQuery(sql);
		List<AccountRelated> list = sqlQuery.addEntity(AccountRelated.class).list();
		return list;
	}

}
