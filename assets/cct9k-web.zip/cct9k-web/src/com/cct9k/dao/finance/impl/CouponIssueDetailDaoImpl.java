package com.cct9k.dao.finance.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.CouponIssueDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.CouponIssueDetail;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午12:23
 */
@Repository
public class CouponIssueDetailDaoImpl extends BaseDaoImpl<CouponIssueDetail, String> implements CouponIssueDetailDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from CouponIssueDetail model where 1=1");

        r.append(" order by createtime desc");

        return find(r, pageNo, pageSize);
    }

}
