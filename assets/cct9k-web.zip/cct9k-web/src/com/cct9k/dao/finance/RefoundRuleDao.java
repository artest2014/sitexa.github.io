package com.cct9k.dao.finance;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.RefoundRule;

public interface RefoundRuleDao extends BaseDao<RefoundRule, String> {
	
	 public RefoundRule getRefoundRuleByOrderId(String orderId,String orderStyle);

}
