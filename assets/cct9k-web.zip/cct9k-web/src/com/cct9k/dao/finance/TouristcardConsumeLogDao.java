package com.cct9k.dao.finance;

import java.util.Date;
import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.TouristcardConsumeLog;

public interface TouristcardConsumeLogDao extends
		BaseDao<TouristcardConsumeLog, String> {

	Pagination getpage(String associateobjectid,Date startDate, Date endDate, String applyStatu,int pageNo, int pageSize);

	List<Object[]> sum(Date startDate, Date endDate, String applyStatu,String associateobjectid);

}
