package com.cct9k.dao.finance;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.Card;

public interface CardDao extends BaseDao<Card, String> {
    public String getSeqn();
}
