package com.cct9k.dao.finance;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.VoucherSmsLog;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午12:32
 */
public interface VoucherSmsLogDao extends BaseDao<VoucherSmsLog, String> {

    public Pagination getPage(int pageNo, int pageSize);

}
