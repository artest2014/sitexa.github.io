package com.cct9k.dao.finance.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.MemberQuotaLogDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.MemberQuotaLog;
import com.cct9k.util.common.StringUtil;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author yics 2013-08-08
 */
@Repository
public class MemberQuotaLogDaoImpl extends BaseDaoImpl<MemberQuotaLog, String> implements MemberQuotaLogDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from MemberQuotaLog model where 1=1");

        r.append(" order by limitupdateid desc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public List<MemberQuotaLog> getMemberQuotaLogbyMemberid(String memberid, String credittype, String saller) {
        String hql = " from MemberQuotaLog log where log.keepaccountsmember.memberid='" + memberid + "' and log.saller ='" + saller + "'";
        if (!StringUtil.isEmpty(credittype)) {
            hql += " and log.credittype ='" + credittype + "'";
        }
        hql += " order by log.operatortime desc";
        return getSession().createQuery(hql).list();
    }
}
