package com.cct9k.dao.finance.impl;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.ShopCommissionDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.ShopCommission;
import com.cct9k.util.common.StringUtil;
@Repository
public class ShopCommissionDaoImpl extends BaseDaoImpl<ShopCommission, String>implements ShopCommissionDao {

	@Override
	public Pagination getPage(Timestamp startDate, Timestamp endDate, String applyStatu,String objectid, String objecttypeid, String objectcateid, int pageNo, int pageSize) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("startDate",startDate);
		map.put("endDate", endDate);
//		map.put("objectid", objectid);
//		map.put("objecttypeid", objecttypeid);
//		map.put("objectcateid", objectcateid);
		StringBuffer sql = new StringBuffer(""
				+ " select t1.tradesquence,t1.tradetime,t2.poscardno,t1.tradeamount,t2.paymethod,t1.amount,t1.status"
				+ " from t_shop_commission t1,t_touristcard_consume_log t2"
				+ " where t1.consumptionlogid=t2.consumptionlogid"
				+ " and t1.tradetime>=:startDate"
				+ " and t1.tradetime<=:endDate");
//				+ " and t1.objectid=:objectid"
//				+ " and t1.objecttypeid=:objecttypeid"
//				+ " and t1.objecttypecatid=:objectcateid");
		if(!StringUtil.isEmpty(applyStatu)){
			sql.append(" and t1.status=:applyStatu");
			map.put("applyStatu", applyStatu);
		}
		return findSql(sql.toString(), null, map, pageNo, pageSize);
	}
	
	
	@Override
	public Pagination getPage(String startDate, String endDate, String applyStatu,String objectid, String objecttypeid, String objectcateid, int pageNo, int pageSize) {
		String sql = "select t1.tradesquence,t1.tradetime,t2.poscardno,t1.tradeamount,t2.paymethod,t1.amount,t1.status"
				+ " from t_shop_commission t1,t_touristcard_consume_log t2"
				+ " where t1.consumptionlogid=t2.consumptionlogid"
				+ " and t1.tradetime>=to_date('"+startDate+"','yyyy-MM-dd')"
				+ " and t1.tradetime<=to_date('"+endDate+"','yyyy-MM-dd')"
				+ " and t1.objectid='"+objectid+"'"
				+ " and t1.objecttypeid='"+objecttypeid+"'"
				+ " and t1.objecttypecatid='"+objectcateid+"'";
		if(!StringUtil.isEmpty(applyStatu)){
			sql +=" and t1.status="+applyStatu;
		}
		return findSql(sql.toString(), pageNo, pageSize);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> sum(String startDate, String endDate, String applyStatu,String objectid, String objecttypeid, String objectcateid) {
		String hql = "select sum(t1.tradeamount),sum(t1.amount) from t_shop_commission t1"
				+ " where t1.tradetime>=to_date('"+startDate+"','yyyy-MM-dd')"
				+ " and t1.tradetime<=to_date('"+endDate+"','yyyy-MM-dd')"
				+ " and t1.objectid='"+objectid+"'"
				+ " and t1.objecttypeid='"+objecttypeid+"'"
				+ " and t1.objecttypecatid='"+objectcateid+"'";
		return getSession().createSQLQuery(hql).list();
	}
}
