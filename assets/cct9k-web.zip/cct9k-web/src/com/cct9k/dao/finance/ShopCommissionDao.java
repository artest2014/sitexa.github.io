package com.cct9k.dao.finance;

import java.sql.Timestamp;
import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.ShopCommission;
/**
 * @author caimao
 * @date   Feb 28, 2014
 */
public interface ShopCommissionDao extends BaseDao<ShopCommission, String> {

	Pagination getPage(Timestamp startDate, Timestamp endDate, String applyStatu,String objectid, String objecttypeid, String objectcateid,int pageNo, int pageSize);
	Pagination getPage(String startDate, String endDate, String applyStatu,String objectid, String objecttypeid, String objectcateid,int pageNo, int pageSize);

	List<Object[]> sum(String startDate, String endDate,String applyStatu, String objectid, String objecttypeid,String objectcateid);

}
