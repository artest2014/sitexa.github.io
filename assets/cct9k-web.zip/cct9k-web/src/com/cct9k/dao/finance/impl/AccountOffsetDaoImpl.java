package com.cct9k.dao.finance.impl;


import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.cct9k.dao.finance.AccountDao;
import com.cct9k.dao.finance.AccountOffsetDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.Account;
import com.cct9k.entity.finance.AccountOffset;
import com.cct9k.util.common.StringUtil;

@Repository
public class AccountOffsetDaoImpl extends BaseDaoImpl<AccountOffset, String> implements
AccountOffsetDao {

	@Override
	public String getSeqn(){
		String sql = " SELECT S_ACCOUNTOFFSET.NEXTVAL FROM DUAL";
		Query query = getSession().createSQLQuery(sql);
		BigDecimal b = (BigDecimal) query.uniqueResult();
		return b.toString();
	}
	
}
