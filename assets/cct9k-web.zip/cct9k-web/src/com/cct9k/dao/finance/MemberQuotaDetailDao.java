package com.cct9k.dao.finance;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.MemberQuotaDetail;

/**
 * @author yics 2013-08-08
 */
public interface MemberQuotaDetailDao extends BaseDao<MemberQuotaDetail, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public Pagination getMemberQuotaDetail(String memberid, String salemember, String quotatype, String detailid, String starttime, String endtime, int pageNo, int pageSize);
    
    public Pagination getBuyMemberQuotaDetail(String memberid, String salememberid, String quotatype, String orderid, int pageNo, int pageSize);
}
