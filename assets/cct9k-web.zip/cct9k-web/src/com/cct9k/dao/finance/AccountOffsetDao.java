package com.cct9k.dao.finance;

import java.util.HashMap;
import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.AccountOffset;

public interface AccountOffsetDao extends BaseDao<AccountOffset, String> {
 
	public String getSeqn();

}
