/**
 * <p>Class Name: ScoreLogDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: qlg</p>
 * <p>Date: 2013-6-20</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */

package com.cct9k.dao.finance.impl;


import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.ScoreLogDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.ScoreLog;
import com.cct9k.util.common.StringUtil;
import org.springframework.stereotype.Repository;

/**
 * @author qlg
 */
@Repository
public class ScoreLogDaoImpl extends BaseDaoImpl<ScoreLog, String> implements ScoreLogDao {

    @Override
    public Pagination getListPage(String memberid, String orderid, int pageNo, int pageSize) {
        Finder r = Finder.create("from ScoreLog sl where sl.member.memberid='" + memberid+"'");
        if (!StringUtil.isEmpty(orderid)) {
            r.append(" and sl.orderno=:orderno ");
            r.setParam("orderno", orderid);
        }
        return find(r, pageNo, pageSize);
    }

}
