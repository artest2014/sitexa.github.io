package com.cct9k.dao.finance.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.StrikeBalanceDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.StrikeBalanceDetail;
import com.cct9k.util.common.StringUtil;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author yics 2013-08-08
 */
@Repository
public class StrikeBalanceDetailDaoImpl extends BaseDaoImpl<StrikeBalanceDetail, String> implements StrikeBalanceDetailDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from StrikeBalanceDetail model where 1=1");

        r.append(" order by refunddate desc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public List<StrikeBalanceDetail> getStrikeBalanceDetailList(String memberid, String saller, String statetime, String endtime, String type) {
        String hql = "from StrikeBalanceDetail d where d.gmid.memberid=" + memberid + " and d.MEMBER.memberid=" + saller;
        if (!StringUtil.isEmpty(statetime)) {
            hql += " and d.refunddate >=to_date('" + statetime + "','yyyy-MM-dd') ";
        }

        if (!StringUtil.isEmpty(endtime)) {
            hql += " and d.refunddate <=to_date('" + endtime + "','yyyy-MM-dd') ";
        }
        if (!StringUtil.isEmpty(type)) {
            hql += "  and d.GTYPE.dictid ='" + type + "'";
        }
        hql += " order by  d.detailid desc ";
        return getSession().createQuery(hql).list();
    }

}
