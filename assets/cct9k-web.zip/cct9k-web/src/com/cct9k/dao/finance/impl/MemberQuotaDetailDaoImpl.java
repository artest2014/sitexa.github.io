package com.cct9k.dao.finance.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.MemberQuotaDetailDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.MemberQuotaDetail;
import com.cct9k.util.common.StringUtil;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午12:08
 */
@Repository
public class MemberQuotaDetailDaoImpl extends BaseDaoImpl<MemberQuotaDetail, String> implements MemberQuotaDetailDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from MemberQuotaDetail model where 1=1");

        r.append(" order by order desc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public Pagination getMemberQuotaDetail(String memberid, String salememberid, String quotatype, String detailid, String starttime, String endtime, int pageNo, int pageSize) {
        Finder f = Finder.create("from MemberQuotaDetail mqd where mqd.member.memberid='" + memberid + "' and mqd.salemember.memberid='" + salememberid + "' and mqd.quotatype.typeid='" + quotatype + "'");
        if (!StringUtil.isEmpty(detailid)) {
            f.append(" and mqd.detailid like '%'||:detailid||'%' ");
            f.setParam("detailid", detailid);
        }
        if (!StringUtil.isEmpty(starttime)) {
            f.append(" and mqd.order.orderDate >=:starttime ");
            f.setParam("starttime", java.sql.Date.valueOf(starttime));
        }
        if (!StringUtil.isEmpty(endtime)) {
            f.append(" and mqd.order.orderDate <=:endtime ");
            f.setParam("endtime", java.sql.Date.valueOf(endtime));
        }
        f.append(" order by mqd.order.orderDate desc");
        return find(f, pageNo, pageSize);
    }
    
    @Override
    public Pagination getBuyMemberQuotaDetail(String memberid, String salememberid, String quotatype, String orderid, int pageNo, int pageSize) {
        Finder f = Finder.create("from MemberQuotaDetail mqd where mqd.member.memberid='" + memberid + "' and mqd.salemember.memberid='" + salememberid + "' and mqd.quotatype.dictid='" + quotatype + "'");
        if (!StringUtil.isEmpty(orderid)) {
            f.append(" and mqd.order.orderId=:orderid");
            f.setParam("orderid", orderid);
        }
        f.append(" order by mqd.detailid desc");
        return find(f, pageNo, pageSize);
    }



}
