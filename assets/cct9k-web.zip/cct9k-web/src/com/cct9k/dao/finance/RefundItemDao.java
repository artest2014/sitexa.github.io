package com.cct9k.dao.finance;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.RefundItem;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午2:06
 */
public interface RefundItemDao extends BaseDao<RefundItem, String> {

    public Pagination getPage(int pageNo, int pageSize);
   
    
    public RefundItem getRouteRefund(String orderId);
	

	
	public RefundItem getHotelRefund(String detailId,String hotelId);
	

	
	public RefundItem getRestaurantRefund(String detailId,String restaurantId);
    

	
	public RefundItem getShowRefund(String detailId,String showId);

	
	public RefundItem getTransportRefund(String detailId,String transportId);
	
	public RefundItem getGuideRefund(String detailId,String guideId);
	
	public RefundItem getGateRefund(String detailId,String sceneryId);
	
	//验证线路订单是否可以退款 true可以退款  false不可以退款
	public boolean validateRouteIfRefund(String orderId);
	
	//验证景点产品是否可以退款 true可以退款  false不可以退款
	public boolean validateGateIfRefund(String detailId,String sceneryId);
	
	//验证餐饮产品是否可以退款 true可以退款  false不可以退款
		public boolean validateRestaurantIfRefund(String detailId,String restaurantId);
		
		//验证酒店产品是否可以退款 true可以退款  false不可以退款
		public boolean validateHotelIfRefund(String detailId,String hotelId);
		
		//验证娱乐产品是否可以退款 true可以退款  false不可以退款
		public boolean validateShowIfRefund(String detailId,String showId);
		
		//验证旅运产品是否可以退款 true可以退款  false不可以退款
		public boolean validateTransportIfRefund(String detailId,String transportId);
		
		//验证导游产品是否可以退款 true可以退款  false不可以退款
		public boolean validateGuideIfRefund(String detailId,String guideId);
}
