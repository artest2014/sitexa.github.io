package com.cct9k.dao.finance;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.Account;
import com.cct9k.entity.finance.AccountRelated;
import com.cct9k.entity.member.Member;

public interface AccountRelatedDao extends BaseDao<AccountRelated, String> {
	
	/**
	 * 根据memberid、relateType（1:机构/2:人员）、relateSource(1:系统录入/2:人工录入)，查询往来人员或者机构
	 * 参数除memberId外，可为空（""）,不能为null
	 * 
	 * @param memberId
	 * @param relateType 往来类型（人员or机构）
	 * @param relateSource 往来者来源（系统or人工）
	 * @return List<AccountRelated>
	 */
	public List<AccountRelated> getAccountRelatedByMemberIdAndRelateTypeAndRelateSource(String memberId,String relateType,String relateSource);
	
	/**
	 * 查询是否已经存在属于member的指定relateMemberId的机构或者人员
	 * @param member
	 * @param relateType 1:机构，2：人员    （ 可为空）
	 * @param relateMemberId
	 * @return
	 */
	public List<AccountRelated> checkMemberExist(String memberId,String relateType,String relateMemberId);
	
	/**
	 * 根据memberid，relateId或者relateMemberId查询详情
	 * @param memberId
	 * @param relateId 可为空
	 * @param relateMemberId 可为空
	 * @return
	 */
	public List<AccountRelated> getDetail(String memberId,String relateId,String relateMemberId);
}
