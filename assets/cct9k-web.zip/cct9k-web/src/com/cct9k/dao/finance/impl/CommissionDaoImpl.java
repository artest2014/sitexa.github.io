package com.cct9k.dao.finance.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.CommissionDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.Bill;
import com.cct9k.entity.finance.Commission;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-12
 * Time: 下午2:56
 */
@Repository
public class CommissionDaoImpl extends BaseDaoImpl<Commission, String> implements CommissionDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from Commission model where 1=1 ");

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }
    
    @Override
	public Commission getCommissionByBillId(String billId) {
		String hql="from Commission b where b.billid='"+billId+"'  ";
		Commission commission = null;
		List<Commission> commissions=getListByHql(hql);
		if(commissions!=null&&commissions.size()>0){
			commission = commissions.get(0);
		}
		return commission;
	}
    
    @Override
	public List<Commission> getCommissionByStatus(String status,String payer) {
		String hql="from Commission b where b.paystatus='"+status+"' and b.payer ='"+payer+"'  ";
		List<Commission> commissions=getListByHql(hql);
		return commissions;
	}

    @Override
    public Pagination searchByBuyer(Member buyer, String payername, Date eventdate, int pageNo, int pageSize) {
        Finder f = Finder.create("from Commission model where 1=1 ");

        if (buyer != null) {
            f.append(" and model.member.memberid = :memberid ");
            f.setParam("memberid", buyer.getMemberid());
        }

        if (!StringUtil.isEmpty(payername)) {
            f.append(" and model.payer.memberPerson.realname like '%'||:name||'%' or  model.payer.memberOrg.orgname like '%'||:name||'%'");
            f.setParam("name", payername);
        }

        if (eventdate != null) {
            f.append(" and model.eventdate >= :start");
            f.setParam("start", eventdate);

            Date end = DateUtil.addDaysToDate(eventdate, 1);
            f.append(" and model.eventdate < :end");
            f.setParam("end", end);
        }

        f.append(" order by model.eventdate desc");

        return find(f, pageNo, pageSize);
    }
}
