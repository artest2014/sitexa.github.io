package com.cct9k.dao.finance;


import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.finance.ScoreLog;

/**
 * @author sxc
 *         2013-06-07
 */
public interface ScoreLogDao  extends BaseDao<ScoreLog, String>{


	Pagination getListPage(String memberid, String orderid, int pageNo,
			int pageSize);


}
