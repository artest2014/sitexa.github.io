package com.cct9k.dao.finance.impl;

import java.math.BigDecimal;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.InvoiceDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.Invoice;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-10
 * Time: 下午1:44
 */
@Repository
public class InvoiceDaoImpl extends BaseDaoImpl<Invoice, String> implements InvoiceDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from Invoice model where 1=1");

        r.append(" order by invoicedate desc");

        return find(r, pageNo, pageSize);
    }
    
    @Override
    public float invoiceAmount(String sheetid){
    	String sql="select sum(amount) from t_invoice where sheetid=?";
    	Query query=getSession().createSQLQuery(sql);
    	query.setString(0, sheetid);
    	BigDecimal amount=null;
    	try{
    	  amount=(BigDecimal)query.uniqueResult();
    	}catch(Exception e){
    		return 0;
    	}
    	if(amount==null){
    		return 0;
    	}
    	else{
    		return amount.floatValue();
    	}
    	
    }

}
