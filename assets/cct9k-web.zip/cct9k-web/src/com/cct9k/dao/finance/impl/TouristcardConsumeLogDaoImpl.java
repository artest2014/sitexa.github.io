package com.cct9k.dao.finance.impl;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.finance.TouristcardConsumeLogDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.TouristcardConsumeLog;
import com.cct9k.util.common.StringUtil;

@Repository
public class TouristcardConsumeLogDaoImpl extends
		BaseDaoImpl<TouristcardConsumeLog, String> implements
		TouristcardConsumeLogDao {
	@Override
	public Pagination getpage(String associateobjectid,Date startDate, Date endDate, String applyStatu,
			int pageNo, int pageSize) {
		Finder f = null;
		if(!StringUtil.isEmpty(applyStatu)){
			f = Finder.create("select t from TouristcardConsumeLog t,ShopCommissiont1 "
					+ "	where t.consumptionlogid=t1.TouristcardConsumeLog.consumptionlogid"
					+ "	and t1.status=:applyStatu"
					+ " and t.tradetime >=:startDate and t.tradetime<=:endDate");
			f.setParam("applyStatu", applyStatu);
		}else{
			f = Finder.create("from TouristcardConsumeLog t where t.tradetime >=:startDate and t.tradetime<=:endDate");
		}
		f.setParam("startDate", startDate);
		f.setParam("endDate", endDate);
		f.append(" and t.TravelTerminal.associateobjectid=:associateobjectid");
		f.setParam("associateobjectid", associateobjectid);
		return find(f, pageNo, pageSize);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> sum(Date startDate, Date endDate, String applyStatu,String associateobjectid) {
		String hql = "select sum(t.tradeamount),sum(t1.amount)"
				+ " from TouristcardConsumeLog t,ShopCommission t1"
				+ "	where t.consumptionlogid=t1.TouristcardConsumeLog.consumptionlogid"
				+ " and t.tradetime >=? and t.tradetime<=?"
				+ " and t.TravelTerminal.associateobjectid=?";
		return getSession().createQuery(hql).setDate(0, startDate).setDate(1, endDate).setString(2, associateobjectid).list();
		
		
	}


}
