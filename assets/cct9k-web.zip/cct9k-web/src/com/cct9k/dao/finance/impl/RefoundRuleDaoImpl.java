package com.cct9k.dao.finance.impl;

import com.cct9k.dao.finance.RefoundRuleDao;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.entity.finance.RefoundRule;
import com.cct9k.entity.finance.RefundItem;

import org.springframework.stereotype.Repository;

@Repository
public class RefoundRuleDaoImpl extends BaseDaoImpl<RefoundRule, String> implements RefoundRuleDao {
	
	
	@Override
    public RefoundRule getRefoundRuleByOrderId(String orderId,String orderStyle){
		//2酒店订单 3餐饮 4景点 5娱乐 6旅运 7导游
    	  String sql2= " select t.*"
                      +"   from t_refound_rule t"
                      +"  where t.objid = (select d.hotelid"
                      +"                     from t_generic_order      c,"
                      +"                          t_order_detail_hotel d"
                      +"                    where c.orderid = d.orderid"
                      +"                      and d.orderid = '"+orderId+"'"
                      +"                      and rownum <= 1)"
                      +"    and t.starthours <= round"
                      +"(select (min(d.checkin) - sysdate) * 24"
                      +"           from t_generic_order      c,"
                      +"                t_order_detail_hotel d"
                      +"          where c.orderid = d.orderid"
                      +"            and d.orderid = '"+orderId+"')"
                      +"    and t.endhours >= round"
                      +"(select (min(d.checkin) - sysdate) * 24"
                      +"           from t_generic_order      c,"
                      +"                t_order_detail_hotel d"
                      +"          where c.orderid = d.orderid"
                      +"            and d.orderid = '"+orderId+"')";
    	  
    	  String sql3= " select t.*"
                  +"   from t_refound_rule t"
                  +"  where t.objid = (select d.restaurantid"
                  +"                     from t_generic_order      c,"
                  +"                          t_order_detail_restaurant d"
                  +"                    where c.orderid = d.orderid"
                  +"                      and d.orderid = '"+orderId+"'"
                  +"                      and rownum <= 1)"
                  +"    and t.starthours <= round"
                  +"(select (min(d.starttime) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_restaurant d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')"
                  +"    and t.endhours >= round"
                  +"(select (min(d.starttime) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_restaurant d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')";
    	  
    	  String sql4= " select t.*"
                  +"   from t_refound_rule t"
                  +"  where t.objid = (select d.sceneryid"
                  +"                     from t_generic_order      c,"
                  +"                          t_order_detail_gate d"
                  +"                    where c.orderid = d.orderid"
                  +"                      and d.orderid = '"+orderId+"'"
                  +"                      and rownum <= 1)"
                  +"    and t.starthours <= round"
                  +"(select (min(d.startdate) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_gate d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')"
                  +"    and t.endhours >= round"
                  +"(select (min(d.startdate) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_gate d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')";
    	  
    	  String sql5= " select t.*"
                  +"   from t_refound_rule t"
                  +"  where t.objid = (select d.entertainmentid"
                  +"                     from t_generic_order      c,"
                  +"                          t_order_detail_show d"
                  +"                    where c.orderid = d.orderid"
                  +"                      and d.orderid = '"+orderId+"'"
                  +"                      and rownum <= 1)"
                  +"    and t.starthours <= round"
                  +"(select (min(d.startdate) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_show d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')"
                  +"    and t.endhours >= round"
                  +"(select (min(d.startdate) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_show d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')";
    	  
    	  String sql6= " select t.*"
                  +"   from t_refound_rule t"
                  +"  where t.objid = (select d.transportid"
                  +"                     from t_generic_order      c,"
                  +"                          t_order_detail_transport d"
                  +"                    where c.orderid = d.orderid"
                  +"                      and d.orderid = '"+orderId+"'"
                  +"                      and rownum <= 1)"
                  +"    and t.starthours <= round"
                  +"(select (min(d.startdate) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_transport d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')"
                  +"    and t.endhours >= round"
                  +"(select (min(d.startdate) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_transport d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')";
    	  
    	  String sql7= " select t.*"
                  +"   from t_refound_rule t"
                  +"  where t.objid = (select d.guideid"
                  +"                     from t_generic_order      c,"
                  +"                          t_order_detail_guide d"
                  +"                    where c.orderid = d.orderid"
                  +"                      and d.orderid = '"+orderId+"'"
                  +"                      and rownum <= 1)"
                  +"    and t.starthours <= round"
                  +"(select (min(d.startdate) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_guide d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')"
                  +"    and t.endhours >= round"
                  +"(select (min(d.startdate) - sysdate) * 24"
                  +"           from t_generic_order      c,"
                  +"                t_order_detail_guide d"
                  +"          where c.orderid = d.orderid"
                  +"            and d.orderid = '"+orderId+"')";
    	  
    	  int flag = Integer.parseInt(orderStyle);
    	  String sql = "";
    	  switch(flag){
    	     case 2:
    	    	 sql = sql2;
    	    	 break;
    	     case 3:
    	    	 sql = sql3;
    	    	 break;
    	     case 4:
    	    	 sql = sql4;
    	    	 break;
    	     case 5:
    	    	 sql = sql5;
    	    	 break;
    	     case 6:
    	    	 sql = sql6;
    	    	 break;
    	     case 7:
    	    	 sql = sql7;
    	    	 break;
    	  }
    	  
    	  RefoundRule refoundRule = (RefoundRule) getSession().createSQLQuery(sql).addEntity(RefoundRule.class);
    	  return refoundRule;
    }

}
