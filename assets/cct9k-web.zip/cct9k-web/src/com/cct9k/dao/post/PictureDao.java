package com.cct9k.dao.post;

import java.math.BigDecimal;

import com.cct9k.dao.BaseDao;

import com.cct9k.entity.post.Picture;

public interface PictureDao extends BaseDao<Picture, String> {
	/**
	 * 
	 * 描述: 
	 * @return    获得最大的排序数字
	 * @author     yangkun
	 * date        2013-7-25
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-25          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	public BigDecimal getMaxSortOrder();
	
	/**
	 * 
	 * 描述: 
	 * @param picStr
	 * @return
	 * @author     yankgun
	 * date        2013-7-25
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-25          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean updatePicture(String picStr,String complainid);

	 /**
	  * 
	  * 描述: 查询图片
	  * @param objectId
	  * @return
	  * @author    yangkun
	  * date        2013-7-29
	  * --------------------------------------------------
	  * 修改人          修改日期        修改描述
	  * yangkun    2013-7-29          创建
	  * --------------------------------------------------
	  * @Version  Ver1.0
	  */
	public String getPicture(String objectId);
	
	
	/**
	 * 
	 * 描述: 删除数据库图片
	 * @param complainId
	 * @param parentId
	 * @return
	 * @author    yangkun
	 * date        2013-7-30
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-30          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean deletePicture(String delcomplainId);
}
