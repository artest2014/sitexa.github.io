package com.cct9k.dao.post;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.post.Category;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午9:54
 */
public interface CategoryDao extends BaseDao<Category, String> {

}
