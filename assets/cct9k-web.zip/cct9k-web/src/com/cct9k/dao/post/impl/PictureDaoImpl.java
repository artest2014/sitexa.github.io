/**
 * <p>Class Name: PictureDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: yangkun</p>
 * <p>Date: 2013-7-25</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.post.impl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.post.PictureDao;
import com.cct9k.entity.post.Picture;

/**
 * @author yangkun
 *
 */
@Repository
public class PictureDaoImpl extends  BaseDaoImpl<Picture, String>  implements PictureDao {

	/**
	 * 
	 * 描述: 
	 * @return    获得最大的排序数字
	 * @author     yangkun
	 * date        2013-7-25
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-25          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	@Override
	public BigDecimal getMaxSortOrder() {
		String sql="select max(sortorder) from T_Picture";
		 Query query = this.getSession().createSQLQuery(sql);
		 Integer MaxSort = Integer.valueOf(query.list().get(0)==null?"0":query.list().get(0).toString());
		 if(!"0".equals(MaxSort))
			 MaxSort=Integer.valueOf(Integer.parseInt(MaxSort.toString()) +1);
		BigDecimal t =  new BigDecimal(Integer.parseInt(MaxSort.toString()));
		return t;
	}

	/**
	 * 
	 * 描述: 
	 * @return    保存图片
	 * @author     yangkun
	 * date        2013-7-25
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-25          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */

	@Override
	public String save(Picture picture) {
		super.save(picture);
		return picture.getPicID();
	}

	/**
	 * 
	 * 描述: 
	 * @return    修改图片 对应的投诉id
	 * @author     yangkun
	 * date        2013-7-25
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-25          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	@Override
	public boolean updatePicture(String picStr,String complainid) {
		String sql = " update T_Picture  set Objectid=? where PICID in ("+picStr+")";
		Query query = this.getSession().createSQLQuery(sql);
		query.setString(0, complainid);
		int result = query.executeUpdate();
		if (result > 0) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * 
	 * 描述: 
	 * @return    查询投诉有多少图片，用逗号连接起来
	 * @author     yangkun
	 * date        2013-7-25
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-25          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	@Override
	public String getPicture(String objectId) {
		String sql = " select wm_concat(picurl) from T_PICTURE  where objectid in ("+objectId+")";
		Query query = this.getSession().createSQLQuery(sql);
		String result;
		try {
			result = query.list().get(0).toString();
		} catch (HibernateException e) {
		
			result="";
		}
		return result;
	}
	
	/**
	 * 
	 * 描述: 删除数据库图片
	 * @param complainId
	 * @param parentId
	 * @return
	 * @author    yangkun
	 * date        2013-7-30
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-7-30          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	public boolean deletePicture(String delcomplainId)
	{
	     String sql = "delete from T_PICTURE  where OBJECTID in("+delcomplainId+") ";
	        Query query = this.getSession().createSQLQuery(sql);
	        int result = query.executeUpdate();
	        if (result > 0) {
	            return true;
	        } else {
	            return false;
	        }
	
	}
	

}
