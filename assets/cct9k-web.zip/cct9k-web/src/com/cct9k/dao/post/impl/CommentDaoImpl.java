package com.cct9k.dao.post.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.post.CommentDao;
import com.cct9k.entity.post.Comment;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午10:05
 */
@Repository
public class CommentDaoImpl extends BaseDaoImpl<Comment, String> implements CommentDao {

    @Override
    public Pagination getPage(String objectType, String objectId, int pageNo, int pageSize) {
        Finder r = Finder.create("from Comment p where 1=1");

        if (objectType != null) {
            r.append(" and p.objecttype =:objectType");
            r.setParam("objectType", objectType);
        }

        if (objectId != null) {
            r.append(" and p.objectid =:objectId ");
            r.setParam("objectId", objectId);
        }

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }
}
