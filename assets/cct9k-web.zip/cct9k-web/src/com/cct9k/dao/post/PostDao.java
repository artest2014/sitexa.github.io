package com.cct9k.dao.post;

import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.admin.Site;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.post.Post;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午9:54
 */
public interface PostDao extends BaseDao<Post, String> {

    public Pagination getPage(Site site, Member creator, String nametext, String subjecttext, int pageNo, int pageSize);
    
    
    /**
	 * 获取当前登录用户是否评论过某个游记
	 * 
	 * @param memberid
	 * @param postid
	 * @return
	 */
	public int getMemberPostNum(String memberid, String postid);

	/**
	 * 执行赞美
	 * 
	 * @param memberid
	 * @param postid
	 */
	public void addPost(String memberid, String postid);

	/**
	 * 条件分页查询旅游博客列表
	 * 
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @param sort
	 * @return
	 */
	public Pagination getPostList(Map<String, Object> paraMap, int pageNo,
			int pageSize, String sort);
	
	
	/**
     * 获取某个游记的评论信息
     * @param postid
     * @return
     */
    public Pagination getEstInfoByPostId(String postid,int pageNo,int pageSize);

}
