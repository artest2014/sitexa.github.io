package com.cct9k.dao.post.impl;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.post.CategoryDao;
import com.cct9k.entity.post.Category;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午10:03
 */
@Repository
public class CategoryDaoImpl extends BaseDaoImpl<Category, String> implements CategoryDao {

}
