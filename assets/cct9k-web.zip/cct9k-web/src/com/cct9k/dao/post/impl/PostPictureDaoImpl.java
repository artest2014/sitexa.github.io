package com.cct9k.dao.post.impl;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.post.PostPictureDao;
import com.cct9k.entity.post.PostPicture;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午10:07
 */
@Repository
public class PostPictureDaoImpl extends BaseDaoImpl<PostPicture, String> implements PostPictureDao {

    @Override
    public String getPicSeqn() {
        String sql = " select S_PUBLIC.nextval from dual";
        Query query = getSession().createSQLQuery(sql);
        BigDecimal b = (BigDecimal) query.uniqueResult();
        return b.toString();
    }

    public PostPicture get(String picId) {
        return super.get(picId);
    }
}
