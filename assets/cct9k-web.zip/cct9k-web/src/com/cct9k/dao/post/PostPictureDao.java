package com.cct9k.dao.post;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.post.PostPicture;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午9:54
 */
public interface PostPictureDao extends BaseDao<PostPicture, String> {

    public String getPicSeqn();

    public PostPicture get(String picId);
}
