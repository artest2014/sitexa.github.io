package com.cct9k.dao.post;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.post.Comment;
import com.cct9k.entity.post.Post;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午9:55
 */
public interface CommentDao extends BaseDao<Comment, String> {

    public Pagination getPage(String objectType, String objectId, int pageNo, int pageSize);

}
