package com.cct9k.dao.post.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.post.PostDao;
import com.cct9k.entity.admin.Site;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.post.Post;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-7-10
 * Time: 上午10:06
 */
@Repository
public class PostDaoImpl extends BaseDaoImpl<Post, String> implements PostDao {

    @Override
    public Pagination getPage(Site site, Member creator, String nametext, String subjecttext, int pageNo, int pageSize) {
        Finder r = Finder.create("from Post p where 1=1");

        if (creator != null) {
            r.append(" and p.creator =:creator");
            r.setParam("creator", creator);
        }

        if (site != null) {
            r.append(" and p.site =:site ");
            r.setParam("site", site);
        }

        if (!StringUtil.isEmpty(nametext)) {
            r.append(" and p.name like '%'|| :nametext||'%'");
            r.setParam("nametext", nametext);
        }

        if (!StringUtil.isEmpty(subjecttext)) {
            r.append(" and p.subject like '%'|| :subjecttext||'%'");
            r.setParam("subjecttext", subjecttext);
        }

        r.append(" order by createdate desc");

        return find(r, pageNo, pageSize);
    }

    public String save(Post post) {
        return super.save(post);
    }

    public void update(Post post) {
        super.update(post);
    }
    
    /**
     * 获取当前登录用户是否评论过某个游记
     * @param memberid
     * @param postid
     * @return
     */
    public int getMemberPostNum(String memberid,String postid){
    	int num = 0;
    	String sql = "select count(a.memberid) as num from t_post_rel a where a.memberid=? and a.postid=?";
    	Query query = this.getSession().createSQLQuery(sql);
    	query.setString(0, memberid).setString(1, postid);
    	List result = query.list();
    	if (result != null){
    		BigDecimal decimal =  (BigDecimal) result.get(0);
    	//	BigDecimal decimal = (BigDecimal)o[0];
    		num = decimal.intValue();
    	}
    	return num;
    }
    
    /**
     * 执行赞美
     * @param memberid
     * @param postid
     */
    public void addPost(String memberid,String postid){
    	String sql = "insert into t_post_rel values(?,?)";
    	Query query = this.getSession().createSQLQuery(sql);
    	query.setString(0, memberid);
    	query.setString(1, postid);
    	query.executeUpdate();
    }
    
    /**
     * 条件分页查询旅游博客列表
     * @param paraMap
     * @param pageNo
     * @param pageSize
     * @param sort
     * @return
     */
      public Pagination getPostList(Map<String,Object> paraMap, int pageNo,
  			int pageSize,String sort){
		StringBuffer sql = new StringBuffer();
		sql.append(" select a.id,a.name,a.subject,pic.ABBRURL,d.MEMBERID,d.MEMBERIMG,d.membername,b.relNum,c.commentName,e.commentNum from t_post a");
		sql.append(" left join");
		sql.append("(select * from t_post_picture t where t.picid in(select min(q.picid) from t_post_picture q group by q.post)) pic");
		sql.append(" on a.id=pic.post");
		sql.append(" left join v_rel_num b on a.id=b.postid");
		sql.append(" left join v_post_action c on a.id=c.objectid");
		sql.append(" left join t_member d on a.creator=d.memberid");
		sql.append(" left join v_post_count e on a.id=e.objectid");
		
		if (paraMap != null && paraMap.size() > 0) {
			
			//关联 对象关键字表
			if (paraMap.get("keyword") != null){
				sql.append(" inner join t_object_search_keyword k on k.objectid=a.id ");
			}
		}
		sql.append(" where 1=1");
		if (paraMap != null && paraMap.size() > 0) {
			if (!StringUtil.isEmpty((String) paraMap.get("keyword"))) {
				// 给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
				String keywordstr = StringUtil.deleteExtraSpace(paraMap.get(
						"keyword").toString());
				
				// 以空格为分隔符 把keywordstr分隔成数组
				String[] str = keywordstr.split(" ");
				sql.append(" and(");
				// 循环数组 and条件查询
				for (int i = 0; i < str.length; i++) {
					if (i == 0){
						sql.append(" k.searchkeyword like '%" + str[i] + "%' ");
					}
					else{
						sql.append(" or k.searchkeyword like '%" + str[i] + "%' ");
					}
					if (i == str.length-1){
						sql.append(")");
					}
					
				}
				sql.append(" and k.objecttypetypeid='post' and  k.objecttypecateid='objecttype' ");
			}
			if (!StringUtil.isEmpty((String) paraMap.get("sortType"))){
				if ("dp".equals(paraMap.get("sortType"))){
					sql.append(" order by e.commentNum");
				}
				else if ("dz".equals(paraMap.get("sortType"))){
					sql.append(" order by b.relNum");
				}
			}
			
		}
		// 获取数据
		Pagination p = findSql(sql.toString(), pageNo, pageSize);
		List<Object[]> result = (List<Object[]>) p.getList();
		List<Post> rstlist = null;
		if (result != null) {
			Post post = null;
			rstlist = new ArrayList<Post>();
			for (Object[] arr : result) {
				if (arr != null && arr.length > 0) {
					post = new Post();
					post.setId(arr[0] != null ? (String) arr[0] : "");
					post.setName(arr[1] != null ? (String) arr[1] : "");
					post.setSubject(arr[2] != null ? (String) arr[2] : "");
					post.setPicUrl(arr[3] != null ? (String) arr[3] : "");
					post.setCreatorid(arr[4] != null ? (String) arr[4] : "");
					post.setCreatorPic(arr[5] != null ? (String) arr[5] : "");
					post.setMembername(arr[6] != null ? (String) arr[6] : "");
					post.setRelNum(arr[7] != null ? (BigDecimal) arr[7] : null);
					post.setCommentName(arr[8] != null ? (String) arr[8] : "");
					post.setCommentNum(arr[9] != null ? (BigDecimal) arr[9]
							: null);
					rstlist.add(post);
				}
			}
		}
		p.setList(rstlist);
		return p;
      }
      
      /**
       * 获取某个游记的评论信息
       * @param postid
       * @return
       */
      public Pagination getEstInfoByPostId(String postid,int pageNo,int pageSize){
    	  String hql = "from Comment c where c.objectid=:postid order by c.createdate desc";
    	  Finder f = Finder.create(hql);
    	  f.setParam("postid", postid);
    	  return find(f, pageNo, pageSize);
      }
}
