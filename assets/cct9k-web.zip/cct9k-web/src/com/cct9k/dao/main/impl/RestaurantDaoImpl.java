package com.cct9k.dao.main.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.RestaurantDao;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.main.Restaurant;
import com.cct9k.entity.main.Scenery;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.StringUtil;

@Repository
public class RestaurantDaoImpl extends BaseDaoImpl<Restaurant, String>
		implements
			RestaurantDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<Restaurant> getRestaurantsIsValidByMemberid(String memberId) {
		String hql = "from Restaurant r where r.member.memberid=? and r.enableflag=1 ";
		return getSession().createQuery(hql).setParameter(0, memberId).list();
	}

	@Override
	public List<Restaurant> getRestaurantList(String memberid) {
		String hql = ("select h from Restaurant h where h.member.parent.memberid='"
				+ memberid + "' or h.member.memberid='" + memberid + "'");

		List<Restaurant> list = getListByHql(hql);
		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}
	@Override
	public Pagination getPage(int pageNo, int pageSize) {
		Finder r = Finder.create("from Restaurant model where 1=1");

		r.append(" order by createdate desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public List<Restaurant> searchByName(String keyword) {
		String hql = "from Restaurant r  where r.restaurantname like :name||'%' and r.enableflag='1' order by restaurantname ";
		return getSession().createQuery(hql).setParameter("name", keyword).list();
	}
	@Override
	public Pagination getPagination(Member member, String restaurantName,
			int pageNo, int pageSize) {
		 Finder f = Finder.create("from Restaurant  r where 1=1");
		    if (member != null) {
	            f.append(" and r.member.memberid=:memberid ");
	            f.setParam("memberid", member.getMemberid());
	        }

	        if (!StringUtil.isEmpty(restaurantName)) {
	            f.append(" and r.restaurantname like '%'||:restaurantname||'%' ");
	            f.setParam("restaurantname", restaurantName);
	        }

	        f.append(" order by r.iftop asc");

	        return find(f, pageNo, pageSize);
	}

	@Override
	public List<Object[]> getIndexPics(String objectType) {
		String sql = " select p.picUrl,p.picTitle,p.descriptions ,r.restaurantid,r.restaurantname" +
				" from  t_picture p ,t_restaurant r where r.restaurantid=p.objectID" +
				" and p.objectType='"+objectType+"' and r.iftop='1' and rownum<=3 ";
		   List<Object[]> obj = getSession().createSQLQuery(sql).list();

		return obj;
	}
	
	public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize){
	    	String sql = " select a.restaurantid,a.restaurantname,a.restauranttel from t_restaurant a where a.restaurantstatuscatid='14009' and a.enableflag='1' ";
	    	if(!StringUtil.isEmpty(paraMap.get("Name").toString()))
				sql+="  and a.restaurantname like '%"+paraMap.get("Name").toString()+"%'";
			return findSql(sql, pageNo, pageSize);
		}
	@Override
	public List<Restaurant> get(String[] ids) {
		Assert.notEmpty(ids, "ids must not be empty");
		String hql = "from Restaurant as model where model.enableflag='1' and model.restaurantstatuscatid='14009' and model.id in(:ids)";
		return getSession().createQuery(hql).setParameterList("ids", ids).list();
	}
	

	@Override
	public Pagination getAllRestaurantList(String restaurantName,
			String sitetype, String siteid, int pageNo, int pageSize) {
		StringBuffer sb = new StringBuffer("from Restaurant restaurant where restaurant.restaurantstatuscatid='14009' and restaurant.enableflag='1' ");
		Map<String, Object> paramMap = new HashMap<String, Object>();
		if (!StringUtil.isEmpty(restaurantName)) {
			sb.append(" and restaurant.restaurantname like :restaurantName");
			paramMap.put("restaurantName", "%" + restaurantName + "%");
		}
		if (!StringUtil.isEmpty(sitetype)&&!StringUtil.isEmpty(siteid)) {
			if(sitetype.equals("2")){
				sb.append(" and restaurant.site.state = :siteid");
			}else if(sitetype.equals("3")){
				sb.append(" and restaurant.site.city = :siteid");
			}else if(sitetype.equals("4")){
				sb.append(" and restaurant.site.siteid = :siteid");
			}
			paramMap.put("siteid", siteid);
		}
		Finder f = Finder.create(sb.toString());
		f.append(" order by restaurant.restaurantid desc");
		f.setParams(paramMap);
		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination findRestaurantNotBind(String restaurantName,int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM T_RESTAURANT TR WHERE TR.ENABLEFLAG=1 AND TR.RESTAURANTSTATUSCATID=(SELECT TD.DICTID FROM T_DICTIONARY TD WHERE TD.TYPEID='UP' AND TD.CATEID='Status') AND  NOT EXISTS(SELECT TC.CUSTOMERID FROM T_CUSTOMER TC WHERE TC.OBJECTID=TR.RESTAURANTID AND TC.ISENABLE=1)";
		if(!StringUtil.isEmpty(restaurantName)){
			sql = sql + " and tr.restaurantname like '%"+restaurantName+"%'";
		}
		return findSql(sql, Restaurant.class, null, pageNo, pageSize);
	}		
}
