/**
 * <p>Class Name: HotelProductAuditDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: yangkun</p>
 * <p>Date: 2013-8-10</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.main.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.HotelProductAuditDao;
import com.cct9k.entity.finance.Audit;
import com.cct9k.util.common.StringUtil;

/**
 * @author yangkun
 *
 */
@Repository
public class HotelProductAuditDaoImpl extends BaseDaoImpl<Audit, String> implements HotelProductAuditDao {


	/**
	 * 查询审核的酒店产品 列表
	 */
	@Override
	public Pagination getProductAuditList(String startTime, String endTime,String hotelStr,
			String hotelId, String hotelProduct, String auditStatus,int pageNo,
			int pageSize) {
				String where="";
	
				if (!StringUtil.isEmpty(startTime)&&!StringUtil.isEmpty(endTime)) {
					where+="  and (c.apptime  BETWEEN  to_date('"+startTime+" 00:00:00','yyyy-mm-dd,hh24:mi:ss')     and to_date('"+endTime+" 23:59:59','yyyy-mm-dd,hh24:mi:ss') ) ";
				}
				if (!StringUtil.isEmpty(hotelId)) {
					where+=" and tp.hotelid in ("+hotelId+")  ";
				}
				if(StringUtil.isEmpty(hotelId)&& !StringUtil.isEmpty(hotelStr))
				{
					where+=" and tp.hotelid in ("+hotelStr+") ";
					
				}
				if(StringUtil.isEmpty(hotelId)&& StringUtil.isEmpty(hotelStr))
				{
					where+=" and tp.hotelid ='' ";
					
				}
				if (!StringUtil.isEmpty(hotelProduct)) {
					where+="   and tp.PRODUCTNAME like '%"+hotelProduct+"%'  ";
				}
				if (!StringUtil.isEmpty(auditStatus)) {
					where+="  and  f.objecttype in("+auditStatus+")   ";
				}
				
				
				String sql="select nvl((select typename from  t_dictionary where t_dictionary.DICTID=t.objecttype),0) as audiname,t.* " +
						"from  (select f.objecttype,tp.productid,tp.productname,c.apptime,b.typename,f.auditdate1,tm.membername,c.productAppId,f.auditid,th.hotelname  from" +
						" t_dictionary b right join (select ap.* from(select ab.*, row_number() OVER (PARTITION BY ab.objectid ORDER BY ab.apptime desc) sn from " +
						" T_PRODUCT_APP_INFO ab ORDER BY ab.apptime desc )ap where sn=1) c  on b.dictid=c.Apptype left join  " +
						"t_audit f on c.productAppId= f.ObjectID LEFT JOIN T_HOTEL_PRODUCT tp on  tp.productId=c.objectId" +
						"  LEFT JOIN T_MEMBER tm on tm.memberId=tp.UPDATEr  left join t_hotel th on th.hotelid=tp.hotelid  where 1=1 "+where+" order by c.apptime desc ) t";
				return findSql(sql, pageNo, pageSize);
	}

	
	/**
	 * 查看 审核的产品
	 */
	@Override
	public List getProductAudit(String ProductId) {
	 String sql="select * from T_HOTEL_PRODUCT  INNER JOIN T_PICTURE on T_PICTURE.OBJECTID=T_HOTEL_PRODUCT.PRODUCTID where PRODUCTID=? and OBJECTTYPE='hotelproductpage'";
	  Query query = this.getSession().createSQLQuery(sql);
      query.setString(0, ProductId);
		return query.list();
	}


	/**
	 * 查询产品的审核历史列表
	 */
	@Override
	public List getProductAuditHistoryList(String hotelProductId) {
   String sql="select  a.auditid,a.auditdate1,a.auditcontent1, case b.apptype when '13029' then '产品上架审核' when '13030' then '产品下架审核' end as appname,d.membername,c.typename,b.PRODUCTAPPID,b.appTime,b.appdesc" +
   		"  from T_AUDIT a inner JOIN   T_PRODUCT_APP_INFO b on b.PRODUCTAPPID=a.OBJECTID left join  T_DICTIONARY  c on c.DICTID=a.OBJECTTYPE LEFT JOIN T_MEMBER d " 
			+" on d.memberId=a.auditor1 where a.auditstatus1 not in ('12872','12869')  and b.objectId="+hotelProductId+" order by b.appTime desc ";
     Query query = this.getSession().createSQLQuery(sql);
	return query.list();
	}



	@Override
	public String save(Audit audit) {
	
		return super.save(audit);
	}





}
