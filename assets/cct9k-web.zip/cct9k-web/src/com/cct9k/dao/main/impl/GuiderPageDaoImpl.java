package com.cct9k.dao.main.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.GuiderPageDao;
import com.cct9k.dao.member.MemberDao;
import com.cct9k.entity.main.Guide;
import com.cct9k.entity.main.GuiderPage;
import com.cct9k.entity.order.OrderEstimateInfo;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.GuideProduct;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

@Repository
public class GuiderPageDaoImpl extends BaseDaoImpl<Guide, String> implements GuiderPageDao{
	
	@Resource
	private MemberDao dao;
	/**
	 * 查询导游信息
	 * 
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination getGuiderList(Map<String, Object> paraMap, int pageNo,
			int pageSize,String sort) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from ");
		sql.append("((");
		sql.append("select a.MEMBERID,c.REALNAME,a.PERSONDESC,");
		sql.append(" b.PICURL");
		sql.append(" from T_GUIDE a");
		sql.append(" left join t_picture b on a.MEMBERID=b.OBJECTID");
		sql.append(" and b.objecttype='14370'");
		sql.append(" left join t_member_person c on a.MEMBERID=c.MEMBERID");
//		if (paraMap != null) {
//			if (paraMap.get("labels") != null
//					&& !"".equals(paraMap.get("labels"))) {
//				sql.append(" inner join T_OBJ_LABEL_REF d on a.MEMBERID=d.OBJID");
//				sql.append(" inner join T_PRODUCT_LABEL_INFO e on d.LABELID=e.LABELID");
//			}
//		}
		
		//sql.append(" where 1=1");
		if (paraMap != null) {
			if (paraMap.get("labels") != null){
				Map<String, Object> m = (Map<String, Object>) paraMap.get("labels");
				Set<String> s = m.keySet();
				Iterator<String> it = s.iterator();
				if (m.size() > 1){
					sql.append(" inner join(");
					int index = 1;
					sql.append(" select r1.objid from ");
					sql.append("(select ref").append(index).append(".labelid").append(",ref").append(index).append(".objid");
					sql.append(" from t_obj_label_ref ref").append(index);
					sql.append(" where ref").append(index).append(".labelid in (").append(m.get(it.next())).append(")");
					sql.append(") r").append(index);
					index++;
					while (it.hasNext()) {
						sql.append(" inner join(select ref").append(index).append(".labelid, ref").append(index).append(".objid from t_obj_label_ref ref").append(index);
						sql.append(" where ref").append(index).append(".labelid in (").append(m.get(it.next())).append(")");
						sql.append(") r").append(index);
						sql.append(" on r1.objid = r").append(index).append(".objid");
						index++;
					}
					sql.append(") r").append(index);
					sql.append(" on a.MEMBERID=");
					sql.append("r").append(index).append(".objid");
				}
				else{
					sql.append(" inner join");
					sql.append(" (select distinct(d.objid) from T_OBJ_LABEL_REF d where d.labelid in");
					sql.append("(").append(m.get(it.next()));
					sql.append(")) sub");
					sql.append(" on a.MEMBERID=sub.objid");
				}
			}
			if (paraMap.get("keyword") != null){
				sql.append(" inner join t_object_search_keyword k on k.objectid=a.MEMBERID   ");
			}
			sql.append(" where a.ENABLEFLAG='1'");
			if (paraMap.get("site") != null){
				sql.append(" and exists");
				sql.append(
						" (select gg.siteid from (select ff.siteid from t_site ff start with ff.siteid in(")
						.append(paraMap.get("site")).append(")");
				sql.append(" Connect by Prior ff.siteid=ff.parentid) gg")
						.append(" where c.SITEID=gg.siteid").append(")");
			}
			if (paraMap.get("keyword")!= null){
				
				//给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
				String keywordstr=StringUtil.deleteExtraSpace(paraMap.get("keyword").toString());
				
				//以空格为分隔符  把keywordstr分隔成数组
				  String[] str = keywordstr.split(" ");
				  sql.append(" and(");
				  //循环数组 and条件查询
				for(int i=0;i<str.length;i++){
					if (i == 0){
						sql.append(" k.searchkeyword like '%" + str[i] + "%' ");
					}
					else{
						sql.append(" or k.searchkeyword like '%" + str[i] + "%' ");
					}
					if (i == str.length-1){
						sql.append(")");
					}
				}
				sql.append(" and k.objecttypetypeid='guide' and  k.objecttypecateid='objecttype' ");
			}
		}		
		sql.append(") a1");
		sql.append(" left join");
		sql.append("(select p.memberid, min(p.DAYPRICE) as dayprice from T_GUIDE_PRODUCT p group by p.memberid) v");
		sql.append(" on a1.MEMBERID=v.memberid");
		sql.append(")");
		
		// 价格排序
		if (!StringUtil.isEmpty(sort)){
			if ("asc".equals(sort)) {
				sql.append("order by dayprice asc");
			} else if ("desc".equals(sort)) {
				sql.append("order by dayprice desc");
			}
		}else{
			sql.append("order by dayprice asc");
		}
		// 获取数据
		Pagination p = findSql(sql.toString(), pageNo, pageSize);
		List<Object[]> result = (List<Object[]>) p.getList();
		List rstlist = null;
		if (result != null && result.size()>0) {
			GuiderPage guider = null;
			rstlist = new ArrayList();
			for (Object[] arr : result) {
				if (arr != null && arr.length > 0) {
					guider = new GuiderPage();
					guider.setMemberid(arr[0] != null ? (String) arr[0] : "");
					guider.setRealname(arr[1] != null ? (String) arr[1] : "");
					guider.setPersondesc(arr[2] != null ? (String) arr[2] : "");
					guider.setPicurl(arr[3] != null ? (String) arr[3] : "");
					if(arr.length>5){
					    guider.setDayprice(arr[5] != null ? (BigDecimal) arr[5]
							: null);
					}
					rstlist.add(guider);
				}
			}
		}
		p.setList(rstlist);
		return p;
	}
	
	/**
	 * 根据会员ID查找导游信息
	 * @param memberid
	 * @return
	 */
	public Guide getGuiderInfoById(String memberid){
		String hql = "from Guide a where a.memberid=? and a.enableflag='1' order by a.createtime desc";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, memberid);
		List<Guide> result = query.list();
		return result.get(0);
	}
	
	/**
	 * 根据图片类型查找导游图片
	 * @param memberid
	 * @param picType
	 * @return
	 */
	public List<Picture> findPicListByGuiderId(String memberid,String picType){
		String hql = "from Picture a where a.objectID=? and a.objectType=? order by a.objectType";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, memberid);
		query.setString(1, picType);
		return query.list();
	}
	
	/**
	 * 根据导游
	 * @param memberid
	 * @return
	 */
	public List<GuideProduct> findProductByGuider(String memberid){
		String hql = "from GuideProduct a where a.";
		return null;
	}
	
	
}
