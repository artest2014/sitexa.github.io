package com.cct9k.dao.main.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.MainGuideDao;
import com.cct9k.entity.main.Guide;

@Repository
public class MainGuideDaoImpl extends BaseDaoImpl<Guide, String> implements MainGuideDao {


}
