package com.cct9k.dao.main;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Guide;
import com.cct9k.entity.product.GuideProduct;

import java.util.List;


/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-9
 * Time: 下午2:41
 */
public interface GuideDao extends BaseDao<Guide, String> {

    public Pagination getPage(int pageNo, int pageSize);

    public List<Guide> searchByName(String keyword,String memberid);

	public Pagination getPagination(String guideName, int pageNo, int pageSize);
	
	public List<Guide> getTopGuide(String top);
	
	public List   getResellerGuideList(String guideId);
	
}
