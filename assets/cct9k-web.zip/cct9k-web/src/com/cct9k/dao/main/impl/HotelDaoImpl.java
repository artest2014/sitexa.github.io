package com.cct9k.dao.main.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.HotelDao;
import com.cct9k.dao.member.MemberDao;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.main.HotelExt;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.OrderEstimateInfo;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.HotelProduct;
import com.cct9k.entity.product.HotelProductExt;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

@Repository
public class HotelDaoImpl extends BaseDaoImpl<Hotel, String>
		implements
			HotelDao {
	@Resource
	private MemberDao dao;
	@Override
	public Pagination getPage(String hotelName, String hotelStatus,
			String hotelGrade, int pageNo, int pageSize) {
		String flag = " Where ";
		StringBuffer sb = new StringBuffer("from Hotel hotel ");
		Map<String, Object> paramMap = new HashMap<String, Object>();
		if (hotelName != null && !hotelName.trim().isEmpty()) {
			sb.append(flag);
			sb.append("hotel.hotelname like :hotelName");
			flag = " and ";
			paramMap.put("hotelName", "%" + hotelName + "%");
		}
		if (hotelStatus != null && !hotelStatus.trim().isEmpty()) {
			sb.append(flag);
			sb.append("hotel.hotelstatus = :hotelstatus");
			flag = " and ";
			paramMap.put("hotelstatus", hotelStatus);
		}
		if (hotelGrade != null && !hotelGrade.trim().isEmpty()) {
			sb.append(flag);
			sb.append("hotel.hotelgrade.dictid = :hotelgrade");
			flag = " and ";
			paramMap.put("hotelgrade", hotelGrade);
		}
		Finder f = Finder.create(sb.toString());
		f.append(" order by hotel.createdate desc");
		f.setParams(paramMap);
		return find(f, pageNo, pageSize);
	}

	@Override
	public List<Hotel> getList(String propertyName, Object value) {
		return super.getList(propertyName, value);
	}

	@Override
	public Hotel get(String id) {
		return super.get(id);
	}

	/**
	 * 查找某个酒店的所有图片信息
	 * 
	 * @param hotelid
	 * @return
	 */
	@Override
	public List<Hotel> getHotelList(String memberid) {
		String hql = ("select h from Hotel h where h.member.parent.memberid='"
				+ memberid + "' or h.member.memberid='" + memberid + "'");

		List<Hotel> list = getListByHql(hql);
		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	/**
	 * 条件检索酒店
	 */
	public Pagination getHotelList(Map<String, Object> paraMap, int pageNo,
			int pageSize,String sort) {
		StringBuffer sql = new StringBuffer();

		sql.append("select bb.wifi,");
		sql.append(" aa.HOTELID,aa.HOTELNAME,aa.ADDRESS,aa.QQNO,aa.Telephone,aa.LONGtitude,aa.LATitude,aa.PICURL,aa.busstop as busstop,aa.MINPRICE");
		sql.append(" from(");

		sql.append(" (");
		sql.append("select a.HOTELID,a.siteid,a.HOTELNAME,a.ADDRESS,");
		sql.append(" a.QQNO,a.Telephone,a.LONGtitude,a.LATitude,");
		sql.append(" b.PICURL,r.labelid as busstop,v.MINPRICE");
		sql.append(" from T_HOTEL a");
		sql.append(" left join t_picture b on a.HOTELID=b.OBJECTID");
		sql.append(" and b.objecttype='13110'");
		sql.append(" left join t_obj_label_ref r on a.hotelid=r.objid and r.labelid='109'");
		
		sql.append(" left join v_hotel_min_price v on a.hotelid=v.hotelid");
		
		//关联 对象关键字表
		if (paraMap != null){
			if (paraMap.get("keyword") != null){
				sql.append(" inner join t_object_search_keyword k on k.objectid=a.hotelid   ");
			}
			
		}
		// 如果labels标签为空，则可以拼接 where 
		if (paraMap == null || !paraMap.containsKey("labels")){
			sql.append(" where 1=1");
		}
		
		
		
		if (paraMap != null) {
			Set<String> paraSet = paraMap.keySet();
			Iterator<String> iter = paraSet.iterator();
			while (iter.hasNext()) {
				String key = (String) iter.next();
				
				// 标签筛选
				if ("labels".equals(key)) {
					
					Map<String, Object> m = (Map<String, Object>) paraMap
							.get(key);
					Set<String> s = m.keySet();
					Iterator<String> it = s.iterator();
					if (m.size() > 1){
						sql.append(" inner join(");
						int index = 1;
						sql.append(" select r1.objid from ");
						//sql.append(" from(");
						sql.append("(select ref").append(index).append(".labelid").append(",ref").append(index).append(".objid");
						sql.append(" from t_obj_label_ref ref").append(index);
						sql.append(" where ref").append(index).append(".labelid in (").append(m.get(it.next())).append(")");
						sql.append(") r").append(index);
						index++;
						while (it.hasNext()) {
							sql.append(" inner join(select ref").append(index).append(".labelid, ref").append(index).append(".objid from t_obj_label_ref ref").append(index);
							sql.append(" where ref").append(index).append(".labelid in (").append(m.get(it.next())).append(")");
							sql.append(") r").append(index);
							sql.append(" on r1.objid = r").append(index).append(".objid");
							
							index++;
						}
						sql.append(") r").append(index);
						sql.append(" on a.hotelid=");
						sql.append("r").append(index).append(".objid");
					}
					else{
						sql.append(" inner join");
						sql.append(" (select distinct(d.objid) from T_OBJ_LABEL_REF d where d.labelid in");
						sql.append("(").append(m.get(it.next()));
						sql.append(")) sub");
						sql.append(" on a.HOTELID=sub.objid");
					}
					sql.append(" where 1=1");
				}
				
				else if ("keyword".equals(key)) {
					
					//给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
					String keywordstr=StringUtil.deleteExtraSpace(paraMap.get(key).toString());
					
					//以空格为分隔符  把keywordstr分隔成数组
					  String[] str = keywordstr.split(" ");
					  sql.append(" and(");
					  //循环数组 and条件查询
					for(int i=0;i<str.length;i++){
						if(i == 0){
							sql.append(" k.searchkeyword like '%"+str[i]+"%' ");
						}
						else{
							sql.append(" or k.searchkeyword like '%"+str[i]+"%' ");
						}
						if(i == str.length-1){
							sql.append(")");
						}
					}
					sql.append(" and k.objecttypetypeid='hotel' and  k.objecttypecateid='objecttype' ");
				}
				
				// 国省市下拉框递归筛选
				else if ("site".equals(key)) {
					// sql.append(" and a.siteid in(").append(paraMap.get(key)).append(")");
					sql.append(" and exists");
					sql.append(
							" (select gg.siteid from (select ff.siteid from t_site ff start with ff.siteid ='")
							.append(paraMap.get(key)).append("'");
					sql.append(" Connect by Prior ff.siteid=ff.parentid) gg")
							.append(" where a.siteid=gg.siteid").append(")");
				}
			}
		}
		sql.append(" and a.ENABLEFLAG='1' and a.HOTELSTATUS='14009'");
		
		sql.append(") aa");
		sql.append(" left join");
		sql.append(" (select b.labelid as wifi,a.hotelid from t_hotel a left join t_obj_label_ref b on a.hotelid=b.objid");
		sql.append(" and b.labelid='108'");
		sql.append(") bb");

		sql.append(" on aa.hotelid=bb.hotelid");
		sql.append(")");
		
		// 价格排序
		if (!StringUtil.isEmpty(sort)){
			if ("asc".equals(sort)) {
				sql.append("order by aa.minprice asc");
			} else if ("desc".equals(sort)) {
				sql.append("order by aa.minprice desc");
			}
		}
		String sqlStr = sql.toString();
		// 获取数据
		Pagination p = findSql(sqlStr, pageNo, pageSize);
		List<Object[]> result = (List<Object[]>) p.getList();
		List rstlist = null;
		if (result != null) {
			HotelExt hotel = null;
			rstlist = new ArrayList();
			for (Object[] arr : result) {
				if (arr != null && arr.length > 0) {
					hotel = new HotelExt();
					hotel.setWifi(arr[0] != null ? (String) arr[0] : "");
					hotel.setHotelid(arr[1] != null ? (String) arr[1] : "");
					hotel.setHotelname(arr[2] != null ? (String) arr[2] : "");
					hotel.setAddress(arr[3] != null ? (String) arr[3] : "");
					hotel.setQqno(arr[5] != null ? (String) arr[4] : "");
					hotel.setTelephone(arr[5] != null ? (String) arr[5] : "");
					hotel.setLongtitude(arr[6] != null ? (BigDecimal) arr[6]+""
							: null);
					hotel.setLatitude(arr[7] != null ? (BigDecimal) arr[7]+""
							 : null);
					hotel.setPicurl((String) arr[8] != null
							? (String) arr[8]
							: "");
					hotel.setBusstop(arr[9] != null ? (String) arr[9] : "");
					hotel.setMinPrice(arr[10] != null ? (BigDecimal) arr[10] : null);
					rstlist.add(hotel);
				}
			}
		}
		p.setList(rstlist);
		return p;
	}

	/**
	 * 查找某个酒店下的房间信息
	 * 
	 * @param hotelid
	 * @return
	 * @author zhoubi
	 */
	public List<HotelProduct> getListByHotelId(String hotelid) {
		StringBuffer sql = new StringBuffer(
				"select a.PRODUCTID,a.PRODUCTNAME,a.BROADBAND,aa.LABELNAME,a.MEMBERPRICE,a.PublicPRICE,d.picurl,a.STARTTIME,a.ENDTIME,");
		sql.append("(CASE WHEN a.STATUS='12972' THEN '1002'");
		sql.append(" ELSE '1001' END) isValid");
		sql.append(" from t_hotel_product a");
		// sql.append(" left join t_hotel b on a.HOTELID=b.HOTELID");
		sql.append(" left join (");
		sql.append(" select b.OBJID ,c.LABELNAME from T_OBJ_LABEL_REF b");
		sql.append(" inner join T_PRODUCT_LABEL_INFO c on b.LABELID=c.LABELID");
		sql.append(" where b.objtypecatid=?");
		sql.append(" and c.parentlabelid=?");
		sql.append(" ) aa on a.PRODUCTID=aa.OBJID");
//		sql.append(" left join T_OBJ_LABEL_REF b on a.PRODUCTID=b.OBJID")
//				.append(" and b.objtypecatid =?");
//		sql.append(" left join T_PRODUCT_LABEL_INFO c on b.LABELID=c.LABELID")
//				.append(" and c.parentlabelid=?");
		sql.append(" left join t_picture d on a.productid=d.OBJECTID");
		sql.append(" and d.objecttype=?");
		sql.append(" where a.HOTELID=?");
		sql.append(" and a.ENABLEFLAG='1'");
		sql.append(" and (a.STATUS='12849' or a.STATUS='12972')");
		// sql.append(" and b.objtypecatid =?");
		// sql.append(" and c.parentlabelid=?");
		// String hql = "from HotelProduct a where a.hotel.hotelid=?";
		Query query = this.getSession().createSQLQuery(sql.toString());
		query.setString(0, "13089");
		query.setString(1, "125");
		query.setString(2, "13112");
		query.setString(3, hotelid);
		List<Object[]> objList = query.list();
		List<HotelProduct> resultList = new ArrayList<HotelProduct>();
		
		// 进行实体封装
		if (objList != null) {
			HotelProduct pro = null;

			for (Object[] arr : objList) {
				pro = new HotelProduct();
				pro.setProductid(arr[0] != null ? (String) arr[0] : "");
				pro.setProductname(arr[1] != null ? (String) arr[1] : "");
				pro.setLabelzc(arr[2] != null ? (String) arr[2] : "");
				pro.setBroadband(arr[3] != null ? (String) arr[3] : "");
				pro.setMemberprice(arr[4] != null ? (BigDecimal) arr[4] : null);
				pro.setPublicprice(arr[5] != null ? (BigDecimal) arr[5] : null);
				pro.setPicUrl(arr[6] != null ? (String) arr[6] : "");
				pro.setStarttime(arr[7]!=null?(Date)arr[7]:null);
				pro.setEndtime(arr[8]!=null?(Date)arr[8]:null);
				pro.setIsValid(arr[9] != null ? (String) arr[9] : "");
				resultList.add(pro);
			}
		}
		return resultList;
	}

	/**
	 * 查找某个酒店的所有图片信息
	 * 
	 * @param hotelid
	 * @return
	 */
	public List<Picture> findPicListByHotelId(String hotelid) {
		String hql = "from Picture a where a.objectID=? and (a.objectType=? or a.objectType=?) order by a.objectType";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, hotelid);
		query.setString(1, Picture.OBJECT_TYPE_XINGXIANG);
		query.setString(2, Picture.OBJECT_TYPE_ZHANSHI);
		return query.list();
	}


	/**
	 * 查询某个酒店信息
	 * @param hotelid
	 * @return
	 */
	public HotelExt getHotelById(String hotelid){
		StringBuffer sql = new StringBuffer();
		sql.append("select aa.*,bb.tcc,cc.wifi,dd.jsf,ee.hys,ff.cy,gg.yyc");
		sql.append(" from (");
		sql.append("(select a.hotelid,a.HOTELNAME,a.ADDRESS,a.LONGtitude,a.LATitude,a.hotelGrade,a.qqno,");
		sql.append("d.labelid as sw");
		sql.append("  from T_HOTEL a");
		//sql.append(" left join T_HOTEL b on a.hotelid = b.hotelid");
		//sql.append(" left join t_picture c on a.productid = c.objectid and c.objecttype = '13112'");
		sql.append(" left join t_obj_label_ref d on a.hotelid = d.objid and d.labelid = '108'");
		sql.append(" where a.hotelid = ?");
		sql.append(" ) aa");

		// 第一次连接
		sql.append(" left join (select b1.labelid as tcc, a1.hotelid");
		sql.append(" from T_HOTEL a1");
		sql.append(" left join t_obj_label_ref b1 on a1.hotelid = b1.objid and b1.labelid='109' ) bb");
		sql.append(" on aa.hotelid=bb.hotelid");

		// 第二次连接
		sql.append(" left join (select b2.labelid as wifi, a2.hotelid");
		sql.append(" from T_HOTEL a2");
		sql.append(" left join t_obj_label_ref b2 on a2.hotelid = b2.objid and b2.labelid='301' ) cc");
		sql.append(" on aa.hotelid=cc.hotelid");

		// 第三次连接
		sql.append(" left join (select b3.labelid as jsf, a3.hotelid");
		sql.append(" from T_HOTEL a3");
		sql.append(" left join t_obj_label_ref b3 on a3.hotelid = b3.objid and b3.labelid='302' ) dd");
		sql.append(" on aa.hotelid=dd.hotelid");

		// 第四次连接
		sql.append(" left join (select b4.labelid as hys, a4.hotelid");
		sql.append(" from T_HOTEL a4");
		sql.append(" left join t_obj_label_ref b4 on a4.hotelid = b4.objid and b4.labelid='303' ) ee");
		sql.append(" on aa.hotelid=ee.hotelid");

		// 第五次连接
		sql.append(" left join (select b5.labelid as cy, a5.hotelid");
		sql.append(" from T_HOTEL a5");
		sql.append(" left join t_obj_label_ref b5 on a5.hotelid = b5.objid and b5.labelid='304' ) ff");
		sql.append(" on aa.hotelid=ff.hotelid");

		// 第五次连接
		sql.append(" left join (select b6.labelid as yyc, a6.hotelid");
		sql.append(" from T_HOTEL a6");
		sql.append(" left join t_obj_label_ref b6 on a6.hotelid = b6.objid and b6.labelid='115' ) gg");
		sql.append(" on aa.hotelid=gg.hotelid");
		sql.append(")");
		Query query = this.getSession().createSQLQuery(sql.toString());
		query.setString(0, hotelid);
		List<Object[]> list = query.list();
		HotelExt hotel = null;
		if (list != null && list.size()>0) {
			Object[] arr = list.get(0);
			hotel = new HotelExt();
			hotel.setHotelid(arr[0]!=null?(String)arr[0]:"");
			hotel.setHotelname(arr[1] != null ? (String) arr[1] : "");
			hotel.setAddress(arr[2] != null ? (String) arr[2] : "");
			hotel.setLongtitude(arr[3] != null ? (BigDecimal) arr[3]+"" : null);
			hotel.setLatitude(arr[4] != null ? (BigDecimal) arr[4]+"" : null);
			hotel.setHotelgrade(arr[5] != null ? (String) arr[5] : "");
			hotel.setQqno(arr[6] != null ? (String) arr[6] : "");
			hotel.setSw(arr[7] != null ? (String) arr[7] : "");
			hotel.setTcc(arr[8] != null ? (String) arr[8] : "");
			hotel.setWifi(arr[9] != null ? (String) arr[9] : "");
			hotel.setJsf(arr[10] != null ? (String) arr[10] : "");
			hotel.setHys(arr[11] != null ? (String) arr[11] : "");
			hotel.setCy(arr[12] != null ? (String) arr[12] : "");
		}
		return hotel;
	}
	
	/**
	 * 酒店产品ID
	 * 
	 * @param productId
	 * @return
	 */
	public HotelProductExt getProductById(String productId) {
		StringBuffer sql = new StringBuffer();
		sql.append("select aa.*,bb.tcc,cc.wifi,dd.jsf,ee.hys,ff.cy,gg.yyc");
		sql.append(" from (");
		sql.append("(select a.productid,a.productname,a.publicprice,a.memberprice,a.QUOTAS,a.BROADBAND,");
		sql.append("b.hotelid,b.hotelname,b.address,b.LONGtitude,b.latitude,b.hotelGrade,b.qqno,");
		sql.append("d.labelid as sw,c.DESCRIPTIONS,a.PRODUCTDESC");
		sql.append("  from T_HOTEL_PRODUCT a");
		sql.append(" left join T_HOTEL b on a.hotelid = b.hotelid");
		sql.append(" left join t_picture c on a.productid = c.objectid and c.objecttype = '13112'");
		sql.append(" left join t_obj_label_ref d on b.hotelid = d.objid and d.labelid = '108'");
		sql.append(" where a.productid = ?");
		sql.append(" ) aa");

		// 第一次连接
		sql.append(" left join (select b1.labelid as tcc, a1.productid");
		sql.append(" from t_hotel_product a1");
		sql.append(" left join t_obj_label_ref b1 on a1.productid = b1.objid and b1.labelid='109' ) bb");
		sql.append(" on aa.productid=bb.productid");

		// 第二次连接
		sql.append(" left join (select b2.labelid as wifi, a2.productid");
		sql.append(" from t_hotel_product a2");
		sql.append(" left join t_obj_label_ref b2 on a2.productid = b2.objid and b2.labelid='301' ) cc");
		sql.append(" on aa.productid=cc.productid");

		// 第三次连接
		sql.append(" left join (select b3.labelid as jsf, a3.productid");
		sql.append(" from t_hotel_product a3");
		sql.append(" left join t_obj_label_ref b3 on a3.productid = b3.objid and b3.labelid='302' ) dd");
		sql.append(" on aa.productid=dd.productid");

		// 第四次连接
		sql.append(" left join (select b4.labelid as hys, a4.productid");
		sql.append(" from t_hotel_product a4");
		sql.append(" left join t_obj_label_ref b4 on a4.productid = b4.objid and b4.labelid='303' ) ee");
		sql.append(" on aa.productid=ee.productid");

		// 第五次连接
		sql.append(" left join (select b5.labelid as cy, a5.productid");
		sql.append(" from t_hotel_product a5");
		sql.append(" left join t_obj_label_ref b5 on a5.productid = b5.objid and b5.labelid='304' ) ff");
		sql.append(" on aa.productid=ff.productid");

		// 第五次连接
		sql.append(" left join (select b6.labelid as yyc, a6.productid");
		sql.append(" from t_hotel_product a6");
		sql.append(" left join t_obj_label_ref b6 on a6.productid = b6.objid and b6.labelid='115' ) gg");
		sql.append(" on aa.productid=gg.productid");
		sql.append(")");
		Query query = this.getSession().createSQLQuery(sql.toString());
		query.setString(0, productId);
		List<Object[]> list = query.list();
		HotelProductExt pro = null;
		if (list != null) {
			Object[] arr = list.get(0);
			pro = new HotelProductExt();
			pro.setProductid(arr[0]!=null?(String)arr[0]:"");
			pro.setProductname(arr[1] != null ? (String) arr[1] : "");
			pro.setPublicprice(arr[2] != null ? (BigDecimal) arr[2] : null);
			pro.setMemberprice(arr[3] != null ? (BigDecimal) arr[3] : null);
			pro.setQuotas(arr[4] != null ? (BigDecimal) arr[4] : null);
			pro.setBroadband(arr[5] != null ? (String) arr[5] : "");
			pro.setHotelid(arr[6] != null ? (String) arr[6] : "");
			pro.setHotelname(arr[7] != null ? (String) arr[7] : "");
			pro.setAddress(arr[8] != null ? (String) arr[8] : "");
			pro.setLONGtitude(arr[9] != null
					? ((BigDecimal) arr[9]).toString()
					: "");
			pro.setLatitude(arr[10] != null
					? ((BigDecimal) arr[10]).toString()
					: "");
			pro.setHotelGrade(arr[11] != null ? (String) arr[11] : "");
			pro.setQqno(arr[12] != null ? (String) arr[12] : "");
			pro.setSw(arr[13] != null ? (String) arr[13] : "");
			pro.setDescription(arr[14] != null ? (String) arr[14] : "");
			pro.setProductdesc(arr[15] != null ? (String) arr[15] : "");
			pro.setTcc(arr[16] != null ? (String) arr[16] : "");
			pro.setWifi(arr[17] != null ? (String) arr[17] : "");
			pro.setJsf(arr[18] != null ? (String) arr[18] : "");
			pro.setHys(arr[19] != null ? (String) arr[19] : "");
			pro.setCy(arr[20] != null ? (String) arr[20] : "");
		}
		return pro;
	}
	
	/**
	 * 查找某一房型的所有图片
	 * 
	 * @param productId
	 * @return
	 */
	public List<Picture> findRoomListByProId(String productId) {
		String hql = "select new Picture(picUrl,descriptions,picTitle) from Picture a where a.objectID=? and (a.objectType=? or a.objectType=?) order by a.objectType";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, productId);
		query.setString(1, Picture.OBJECT_TYPE_HOTEL_PRODUCT_XINGXIANG);
		query.setString(2, Picture.OBJECT_TYPE_HOTEL_PRODUCT_ZHANSHI);
		return query.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Hotel> getHotelsIsValidByMemberid(String memberId) {
		String hql = "from Hotel h where h.member.memberid=? and h.enableflag=1 ";
		return getSession().createQuery(hql).setParameter(0, memberId).list();
	}
	@Override
	public Pagination getPage(int pageNo, int pageSize) {
		Finder r = Finder.create("from Hotel  model where 1=1");

		r.append(" order by createtime desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public List<Hotel> searchByName(String keyword) {
		String hql = "from Hotel where hotelname like :name||'%' and enableflag='1'  order by hotelname ";
		return getSession().createQuery(hql).setParameter("name", keyword)
				.list();
	}
	@Override
	public Pagination getPaginationgetPagination(Member member,
			String hotelName, int pageNo, int pageSize) {
		Finder f = Finder.create("from Hotel  h where 1=1");
		if (member != null) {
			f.append(" and h.member.memberid=:memberid ");
			f.setParam("memberid", member.getMemberid());
		}

		if (!StringUtil.isEmpty(hotelName)) {
			f.append(" and h.hotelname like '%'||:hotelname||'%' ");
			f.setParam("hotelname", hotelName);
		}

		f.append(" order by h.iftop asc");

		return find(f, pageNo, pageSize);
	}
	
	   @Override
	   public List<Object[]> getHotelPics(String objectType) {
	        String sql = " select p.picUrl,p.picTitle,p.descriptions ,h.hotelid,h.hotelname" +
	                " from  t_picture p ,t_hotel h where h.hotelid=p.objectID" +
	                " and p.objectType='" + objectType + "' and h.iftop='1' and rownum<=3 ";
	        List<Object[]> obj = getSession().createSQLQuery(sql).list();

	        return obj;
	    }

	    
	   public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize){
				String sql = " select  a.hotelid,a.hotelname,b.typename,a.telephone  from t_hotel a  inner join t_dictionary b on a.hotelgrade=b.dictid where a.hotelstatus='14009' and a.enableflag='1'";
				if(!StringUtil.isEmpty(paraMap.get("Name").toString()))
					sql+=" and a.hotelname like '%"+paraMap.get("Name").toString()+"%'";
				return findSql(sql, pageNo, pageSize);
			}
	@Override
	public List<Hotel> get(String[] ids) {
		Assert.notEmpty(ids, "ids must not be empty");
		String hql = "from Hotel as model where model.enableflag='1' and model.hotelstatus='14009' and model.id in(:ids)";
		return getSession().createQuery(hql).setParameterList("ids", ids).list();
	}

	@Override
	public Pagination getAllHotelList(String hotelName, String sitetype,
			String siteid, String hotelGrade, int pageNo, int pageSize) {
		StringBuffer sb = new StringBuffer("from Hotel hotel where hotel.hotelstatus='14009'  ");
		Map<String, Object> paramMap = new HashMap<String, Object>();
		if (hotelName != null && !hotelName.trim().isEmpty()) {
			sb.append(" and hotel.hotelname like :hotelName");
			paramMap.put("hotelName", "%" + hotelName + "%");
		}
		if (hotelGrade != null && !hotelGrade.trim().isEmpty()) {
			sb.append(" and hotel.hotelgrade.dictid = :hotelgrade");
			paramMap.put("hotelgrade", hotelGrade);
		}
		if (!StringUtil.isEmpty(sitetype)&&!StringUtil.isEmpty(siteid)) {
			if(sitetype.equals("2")){
				sb.append(" and hotel.site.state = :siteid");
			}else if(sitetype.equals("3")){
				sb.append(" and hotel.site.city = :siteid");
			}else if(sitetype.equals("4")){
				sb.append(" and hotel.site.siteid = :siteid");
			}
			paramMap.put("siteid", siteid);
		}
		Finder f = Finder.create(sb.toString());
		f.append(" order by hotel.createdate desc");
		f.setParams(paramMap);
		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination findHotelNotBind(String hotelName,int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		
		String sql = "SELECT * FROM T_HOTEL TH WHERE TH.ENABLEFLAG=1 AND TH.HOTELSTATUS=(SELECT TD.DICTID FROM T_DICTIONARY TD WHERE TD.TYPEID='UP' AND TD.CATEID='Status')  AND  NOT EXISTS(SELECT TC.CUSTOMERID FROM T_CUSTOMER TC WHERE TC.OBJECTID=TH.HOTELID AND TC.ISENABLE=1)";
		if(!StringUtil.isEmpty(hotelName)){
			sql = sql + " AND TH.HOTELNAME LIKE '%"+hotelName+"%'";
		}
		return findSql(sql, Hotel.class, null, pageNo, pageSize);
	}		
}
