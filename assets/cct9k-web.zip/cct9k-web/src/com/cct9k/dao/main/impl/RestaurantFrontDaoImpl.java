package com.cct9k.dao.main.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.RestaurantFrontDao;
import com.cct9k.dao.member.MemberDao;
import com.cct9k.entity.main.Restaurant;
import com.cct9k.entity.order.OrderEstimateInfo;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.ResProductPage;
import com.cct9k.entity.product.RestaurantProduct;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

@Repository
public class RestaurantFrontDaoImpl extends BaseDaoImpl<Restaurant, String> implements RestaurantFrontDao{
	/**
	 * 初始化查询餐饮信息
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@Resource
	private MemberDao dao;
	public Pagination getRestaurantList(Map<String,Object> paraMap,int pageNo, int pageSize){
		StringBuffer sql = new StringBuffer();
		
		sql.append("select a.restaurantproductid,a.restauproductname,a.restauproductdesc,");
		sql.append(" a.memberprice,b.picurl,c.restaurantid,c.restaurantname,substr(a.restauproductdesc,0,40) as subDesc,");
		sql.append("(CASE WHEN a.PRODUCTSTATUSCATID='12972' THEN '1002'");
		sql.append(" ELSE '1001' END) isValid");
		sql.append(" from T_RESTAURANT_PRODUCT a");
		sql.append(" left join t_picture b on a.restaurantproductid = b.OBJECTID and b.objecttype = '13833'");
		if (paraMap != null){
			if (paraMap.get("site") != null && !"".equals(paraMap.get("site"))){
				sql.append(" inner join T_RESTAURANT c on a.restaurantid = c.restaurantid and c.enableflag = '1'");
			}
			else{
				sql.append(" left join T_RESTAURANT c on a.restaurantid = c.restaurantid and c.enableflag = '1'");
			}
			//关联 对象关键字表
			if (paraMap.get("keyword") != null){
				sql.append(" inner join t_object_search_keyword k on k.objectid=a.restaurantproductid   ");
			}
		}
		else{
			sql.append(" left join T_RESTAURANT c on a.restaurantid = c.restaurantid and c.enableflag = '1'");
		}
		
		// 如果labels标签为空，则可以拼接 where 
		if (paraMap == null || !paraMap.containsKey("labels")){
			sql.append(" where 1=1");
		}
		if (paraMap != null){
			Set<String> paraSet = paraMap.keySet();
			Iterator<String> iter = paraSet.iterator();
			while(iter.hasNext()){
				String key = (String) iter.next();
				if ("labels".equals(key)){
					Map<String, Object> m = (Map<String, Object>) paraMap.get(key);
					Set<String> s = m.keySet();
					Iterator<String> it = s.iterator();
					if (m.size() > 1){
						sql.append(" inner join(");
						int index = 1;
						sql.append(" select r1.objid from ");
						//sql.append(" from(");
						sql.append("(select ref").append(index).append(".labelid").append(",ref").append(index).append(".objid");
						sql.append(" from t_obj_label_ref ref").append(index);
						sql.append(" where ref").append(index).append(".labelid in (").append(m.get(it.next())).append(")");
						sql.append(") r").append(index);
						index++;
						while (it.hasNext()) {
							sql.append(" inner join(select ref").append(index).append(".labelid, ref").append(index).append(".objid from t_obj_label_ref ref").append(index);
							sql.append(" where ref").append(index).append(".labelid in (").append(m.get(it.next())).append(")");
							sql.append(") r").append(index);
							sql.append(" on r1.objid = r").append(index).append(".objid");
							
							index++;
						}
						sql.append(") r").append(index);
						sql.append(" on a.restaurantproductid=");
						sql.append("r").append(index).append(".objid");
					}
					else{
						sql.append(" inner join");
						sql.append(" (select distinct(d.objid) from T_OBJ_LABEL_REF d where d.labelid in");
						sql.append("(").append(m.get(it.next()));
						sql.append(")) sub");
						sql.append(" on a.restaurantproductid=sub.objid");
					}
					sql.append(" where 1=1");
				}
				else if ("keyword".equals(key)){
					
					//给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
					String keywordstr=StringUtil.deleteExtraSpace(paraMap.get(key).toString());
					
					//以空格为分隔符  把keywordstr分隔成数组
					  String[] str = keywordstr.split(" ");
					  
					  //循环数组 and条件查询
					for(int i=0;i<str.length;i++){
						sql.append(" and  k.searchkeyword like '%"+str[i]+"%' ");
					}
					sql.append(" and k.objecttypetypeid='restaurantProduct' and  k.objecttypecateid='objecttype' ");
				}
				else if ("site".equals(key)){
					//sql.append(" and c.siteid in(").append(paraMap.get(key)).append(")");
					sql.append(" and exists");
					sql.append(" (select gg.siteid from (select ff.siteid from t_site ff start with ff.siteid ='").append(paraMap.get(key)).append("'");
					sql.append(" Connect by Prior ff.siteid=ff.parentid) gg").append(" where c.siteid=gg.siteid").append(")");
				}
				else if ("labels".equals(key)){
					sql.append(" and e.labelid in(").append(paraMap.get(key)).append(")");
				}
			}
		}
		sql.append(" and a.enableflag = '1'");
		sql.append(" and a.PRODUCTSTATUSCATID='12849'");
		// 价格排序筛选
		if (paraMap != null && paraMap.get("sort") != null){
			if ("asc".equals(paraMap.get("sort"))) {
				sql.append(" order by a.memberprice asc");
			} else if ("desc".equals(paraMap.get("sort"))) {
				sql.append(" order by a.memberprice desc");
			}
		}
		String sqlStr = sql.toString();
		
		// 获取数据
		Pagination p = findSql(sqlStr, pageNo, pageSize);
		List<Object[]> result = (List<Object[]>) p.getList();
		List<ResProductPage> rstlist = null;
		if (result != null) {
			ResProductPage res = null;
			rstlist = new ArrayList<ResProductPage>();
			for (Object[] arr : result) {
				if (arr != null && arr.length > 0) {
					res = new ResProductPage();
					res.setRestaurantproductid(arr[0]!=null?(String) arr[0]:"");
					res.setRestauproductname(arr[1]!=null?(String) arr[1]:"");
					res.setRestauproductdesc(arr[2]!=null?(String) arr[2]:"");
					res.setMemberprice(arr[3]!=null?(BigDecimal) arr[3]:null);
					res.setPicUrl(arr[4]!=null?(String) arr[4]:"");
					res.setRestaurantid(arr[5]!=null?(String) arr[5]:"");
					res.setReataurantname(arr[6]!=null?(String) arr[6]:"");
					res.setSubDesc(arr[7]!=null?(String)arr[7]:"");
					res.setIsValid(arr[8]!=null?(String) arr[8]:"");
					rstlist.add(res);
				}
			}
		}
		p.setList(rstlist);
		return p;
	}
	
	/**
	 * 根据ID查找餐饮产品信息
	 * 
	 * @param resProductId
	 * @return
	 */
	public ResProductPage getObjByResProductId(String resProductId) {
		StringBuffer sql = new StringBuffer();
		sql.append("select a.restauproductdesc,a.MEMBERPRICE,a.PRODUCTQUOTAS,");
		sql.append(" c.descriptions,c.PicUrl,b.RESTAURANTNAME,b.RESTAURANTQQ,b.RESTAURANTTEL,a.MARKETPRICE,to_char(a.CREATEDate,'yyyy-mm-dd'),");
		sql.append(" b.RESTAURANTADDRESS,b.RESTAURANTLONG,b.RESTAURANTLAT,a.restauproductname ");
		sql.append(" from T_RESTAURANT_PRODUCT a");
		sql.append(" left join T_RESTAURANT b on a.RESTAURANTID=b.RESTAURANTID ");
		sql.append(
				" left join t_picture c on a.restaurantproductid = c.OBJECTID and c.objecttype='")
				.append(Picture.RESPRODUCT_IMAGE_TYPE_CP).append("'");
		sql.append(" where a.RESTAURANTPRODUCTID=?");
		Query query = this.getSession().createSQLQuery(sql.toString());
		query.setString(0, resProductId);
		List<Object[]> result = query.list();
		ResProductPage bean = null;
		if (result != null){
			Object[] arr = result.get(0);
			bean = new ResProductPage();
			bean.setRestauproductdesc(arr[0]!=null?(String)arr[0]:"");
			bean.setMemberprice(arr[1]!=null&&!"".equals(arr[1])?(BigDecimal)arr[1]:null);
			bean.setProNum(arr[2]!=null&&!"".equals(arr[2])?(BigDecimal)arr[2]:null);
			//bean.setRestauproductdesc(arr[3]!=null?(String)arr[3]:"");
			bean.setPicUrl(arr[4]!=null?(String)arr[4]:"");
			bean.setReataurantname(arr[5]!=null?(String)arr[5]:"");
			bean.setQqNo(arr[6]!=null?(String)arr[6]:"");
			bean.setTelNo(arr[7]!=null?(String)arr[7]:"");
			bean.setMarketprice(arr[8]!=null&&!"".equals(arr[8])?(BigDecimal)arr[8]:null);
			bean.setCreateDate(arr[9]!=null?(String)arr[9]:"");
			bean.setResAddress(arr[10]!=null?(String)arr[10]:"");
			bean.setResLong(arr[11]!=null?((Number)arr[11]).toString():"");
			bean.setResLat(arr[12]!=null?((Number)arr[12]).toString():"");
			bean.setRestauproductname(arr[13]!=null?(String)arr[13]:"");
		}
		return bean;
	}
	
	/**
	 * 根据餐饮产品ID查询餐饮产品的介绍图片列表
	 * @param proId
	 * @return
	 */
	public List<Picture> getResProPicbyId(String proId){
		
		String hql = "from Picture a where a.objectID=? and a.objectType=?";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, proId);
		query.setString(1, Picture.RESPRODUCT_IMAGE_TYPE_JS);
		return query.list();
	}
	
	
	
	/**
	 * 根据ID查找餐馆信息
	 * 
	 * @param restaurantId
	 * @return
	 */
	public Restaurant getObjByRestaurantId(String restaurantId) {
		String hql = "select new Restaurant(restaurantid,restaurantname,restaurantaddress," +
				"restaurantlong,restaurantlat,restaurantqq,restaurantdesc) from Restaurant a where a.restaurantid=?";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, restaurantId);
		List<Restaurant> list = query.list();
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		else{
			return null;
		}
	}
	
	/**
	 * 查找某个餐馆的所有图片信息
	 * @param restaurantId
	 * @param isAll
	 * @return
	 */
	public List<Picture> findPicListByRestaurantId(String restaurantId,boolean isAll){
		String hql = "from Picture a where a.objectID=? and (a.objectType=? or a.objectType=?) order by a.objectType";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, restaurantId);
		query.setString(1, Picture.RESTAURANT_IMAGE_TYPE_XINGXIANG);
		query.setString(2, Picture.RESTAURANT_IMAGE_TYPE_ZHANSHI);
		if (!isAll){
			query.setFirstResult(0);
			query.setMaxResults(4);
		}
		
		List<Picture> list = query.list();
		return list;
	}
	
	/**
	 * 统计某个餐馆下的餐饮产品情况
	 * @param restaurantId
	 * @return
	 */
	public List<ResProductPage> findResProductNum(String restaurantId){
		StringBuffer sql = new StringBuffer();
		sql.append("select a.RESTAURANTPRODUCTID,a.RESTAUPRODUCTNAME,a.PRODUCTQUOTAS from T_RESTAURANT_PRODUCT a where a.RESTAURANTID=?");
		Query query = this.getSession().createSQLQuery(sql.toString()).setString(0, restaurantId);
		List<Object[]> result = query.list();
		List<ResProductPage> list = null;
		if (result != null){
			list = new ArrayList<ResProductPage>();
			ResProductPage res = null;
			for (Object[] arr : result){
				res = new ResProductPage();
				res.setRestaurantproductid(arr[0]!=null?(String)arr[0]:"");
				res.setRestauproductname(arr[1]!=null?(String)arr[1]:"");
				res.setProductquotas(arr[2]!=null?(BigDecimal)arr[2]:null);
				list.add(res);
			}
		}
		return list;
	}
	
	/**
	 * 根据菜的种类统计餐馆下的产品情况
	 * @param restaurantId
	 * @return
	 */
	public List<ResProductPage> findResProductByType(String restaurantId){
		StringBuffer sql = new StringBuffer();
		sql.append("select sub.*,d1.labelname from");
		sql.append("(select count(c1.restaurantproductid) num,a1.labelid from t_product_label_info a1");
		sql.append(" left join t_obj_label_ref b1 on a1.labelid=b1.labelid");
		sql.append(" left join t_restaurant_product c1 on b1.objid=c1.restaurantproductid");
		sql.append(" where c1.restaurantid=?");
		sql.append(" and a1.parentlabelid='190'");
		sql.append(" group by a1.labelid");
		sql.append(")");
		sql.append(" sub inner join t_product_label_info d1 on sub.labelid=d1.labelid");
		Query query = this.getSession().createSQLQuery(sql.toString()).setString(0, restaurantId);
		List<Object[]> result = query.list();
		List<ResProductPage> list = null;
		if (result != null){
			list = new ArrayList<ResProductPage>();
			ResProductPage res = null;
			for (Object[] arr : result){
				res = new ResProductPage();
				res.setNum(arr[0]!=null?(BigDecimal)arr[0]:null);
				res.setLabelid(arr[1]!=null?(String)arr[1]:"");
				res.setLabelname(arr[2]!=null?(String)arr[2]:"");
				list.add(res);
			}
		}
		return list;
	}
	
	/**
	 * 查询某个餐馆下的餐饮产品并分页
	 * @param restaurantId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination findResProductPage(String restaurantId,int pageNo, int pageSize,String labelid){
		StringBuffer sql = new StringBuffer();
		sql.append("select a.restaurantproductid,a.restauproductname,a.restauproductdesc,a.PRODUCTQUOTAS,a.CREATEDate,b.picurl,a.MEMBERPRICE");
		sql.append(" from T_RESTAURANT_PRODUCT a");
		sql.append(" left join t_picture b on a.restaurantproductid = b.OBJECTID and b.objecttype = '13833'");
		if (!StringUtil.isEmpty(labelid)){
			sql.append(" inner join t_obj_label_ref c on a.restaurantproductid=c.objid");
		}
		sql.append(" where a.ENABLEFLAG='1'");
		sql.append(" and a.RESTAURANTID='").append(restaurantId).append("'");
		
		if (!StringUtil.isEmpty(labelid)){
			sql.append(" and c.labelid='").append(labelid).append("'");
		}
		// 获取数据
		Pagination p = findSql(sql.toString(), pageNo, pageSize);
		List<Object[]> result = (List<Object[]>) p.getList();
		List<RestaurantProduct> list = null;
		if (result != null){
			list = new ArrayList<RestaurantProduct>();
			RestaurantProduct pro = null;
			for (Object[] arr : result){
				pro = new RestaurantProduct();
				pro.setRestaurantproductid(arr[0]!=null?(String)arr[0]:"");
				pro.setRestauproductname(arr[1]!=null?(String)arr[1]:"");
				pro.setRestauproductdesc(arr[2]!=null?(String)arr[2]:"");
				pro.setProductquotas(arr[3]!=null?(BigDecimal)arr[3]:null);
				pro.setCreatedate(arr[4]!=null?(Date)arr[4]:null);
				pro.setPicurl(arr[5]!=null?(String)arr[5]:"");
				pro.setMemberprice(arr[6]!=null?(BigDecimal)arr[6]:null);
				list.add(pro);
			}
		}
		p.setList(list);
		return p;
	}
	
	public List<Picture> getFigurePicListByRestProdId(String resProductId){
		String hql="from Picture a where a.objectID=? and a.objectType=?";
		Query query=this.getSession().createQuery(hql);
		query.setString(0, resProductId);
		query.setString(1, Picture.RESPRODUCT_IMAGE_TYPE_CP);
		return query.list();
	}
}
