package com.cct9k.dao.main;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Restaurant;
import com.cct9k.entity.main.Transport;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.ProductLabelInfo;

public interface TransportDao extends BaseDao<Transport, String> {

	List<Transport> getTransportsIsValidByMemberid(String memberId);

	public Pagination getPage(int pageNo, int pageSize);

	public List<Picture> getTransIntroPicListByTransportId(String transportid,boolean isAll);

	public List<ProductLabelInfo> getTransLabelInfoListByTransportId(
			String transportid);

	public List<Transport> searchByName(String keyword);
	
	public Pagination getPagination(Member member, String transportName, int pageNo, int pageSize);

	List<Object[]> getTransportPics(String objectType);

	public List<Transport> getTransportsByTransportId(String transportId);
	/**
	 * 
	 * 描述: 分销商客户关联旅运
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author    yangkun
	 * @Version  Ver1.0
	 */
	public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize);
	
	public List<Transport> get(String[] ids) ;

	public Pagination getAllTransportList(String transportName, String sitetype,
			String siteid, int pageNo, int pageSize);
	
	/**
	 * 查询没有被客户绑定的旅运
	 * @return
	 */
	public Pagination findTransportNotBind(String transportName,int pageNo, int pageSize);
}
