/**
 * <p>Class Name: CarSharingDaoImpl.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: yangkun</p>
 * <p>Date: 2013-8-22</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.main.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.CarSharingDao;
import com.cct9k.entity.main.CarSharingInfo;
import com.cct9k.util.common.StringUtil;

/**
 * @author yangkun
 *
 */
@Repository
public class CarSharingDaoImpl extends BaseDaoImpl<CarSharingInfo, String> implements
		CarSharingDao {

    
	public Pagination getPage(String infoTitle, String startime,
			String endtime,String memberId, int pageNo, int pageSize) {
		
	 String	sql="select a.info_title,"
     +"  a.go_off_time, "
     +"  a.create_time, "
     +"   a.enable_flag, "
     +"   a.seat_price,a.MEMBER_ID, "
     +"   d.name as name1, "
     +"    b.name as name2, "
     +"   e.name as name3, "
     +"   c.name as name4,a.total_seat_num,a.surplus_seat_num,a.CAR_SHARING_ID"
     +"  from (select info_title,MEMBER_ID, "
     +"          go_off_time, "
     +"           go_off_area_id, "
     +"           destination_area_id, "
     +"           total_seat_num, "
     +"            CREATE_TIME, "
     +"            enable_flag, "
     +"          seat_price,surplus_seat_num ,CAR_SHARING_ID"
     +"    from T_CAR_SHARING_INFO) a "
     +"  inner join t_site b on a.go_off_area_id = b.siteid "
     +"  inner join t_site c on a.destination_area_id = c.siteid "
     +"  inner join t_site d on d.siteid = b.parentid "
     +"  inner join t_site e on e.siteid = c.parentid where 1=1  ";
		
		if(infoTitle!=null && !infoTitle.trim().isEmpty()){
			sql+="   and a.info_title like '%"+infoTitle+"%'  ";
		}
		if(startime!=null && !startime.trim().isEmpty()){
	       sql+="  and a.create_time >  to_date('"+startime+" 00:00:00','yyyy-mm-dd,hh24:mi:ss')";   
		}
		if(endtime!=null && !endtime.trim().isEmpty()){
			  sql+="   and a.create_time <to_date('"+endtime+" 23:59:59','yyyy-mm-dd,hh24:mi:ss')  ";
			
		}
		sql+= " and a.MEMBER_ID="+memberId+" order by a.create_time desc ";
		return findSql(sql, pageNo, pageSize);
	   
    }

	@Override
	public Pagination getCarsharingList(Map<String, Object> paraMap, int cpn,
			int pageSize) {
	    StringBuffer sql=new StringBuffer(); 
	    sql.append("select a.info_title," );
			     sql.append("  a.go_off_time, " );
			     sql.append("  a.create_time, " );
			     sql.append("   a.enable_flag, " );
			     sql.append("   a.seat_price,a.MEMBER_ID, " );
			     sql.append("   d.name as name1, " );
			     sql.append("    b.name as name2, " );
			     sql.append("   e.name as name3, " );
			     sql.append("   c.name as name4,a.total_seat_num,a.surplus_seat_num,a.CAR_SHARING_ID,f.picurl,pr.labelname,m.mobileno " );
			     sql.append("  from (select info_title,MEMBER_ID, " );
			     sql.append("          go_off_time, " );
			     sql.append("            go_off_area_id, " );
			     sql.append("           destination_area_id, " );
			     sql.append("           total_seat_num, " );
			     sql.append("            CREATE_TIME, " );
			     sql.append("            enable_flag, " );
			     sql.append("          seat_price,surplus_seat_num ,CAR_SHARING_ID" );
			     sql.append("    from T_CAR_SHARING_INFO) a " );
			     sql.append("  inner join t_site b on a.go_off_area_id = b.siteid " );
			     sql.append("  inner join t_site c on a.destination_area_id = c.siteid " );
			     sql.append("  inner join t_site d on d.siteid = b.parentid " );
			     sql.append("  inner join t_site e on e.siteid = c.parentid " );
			     sql.append("  inner join t_site bd on bd.siteid = d.parentid " );
			     sql.append("  inner join t_site ce on ce.siteid = e.parentid " );
			     sql.append("  inner join  t_picture f on f.objecttype='13830' and f.objectid=a.car_sharing_id "  );
			     sql.append("  inner join t_obj_label_ref r on a.car_sharing_id=r.objid  "  );
			     sql.append(" inner join t_product_label_info pr on pr.labelid=r.labelid and  pr.parentlabelid=219 " );
			     sql.append("  inner  join t_member m on a.member_id=m.memberid   " );;
		   if (paraMap != null){
				if (paraMap.get("labels") != null && !"".equals(paraMap.get("labels"))){
					sql.append("  inner join ( select distinct(table1.objid) from   ( "  );;
			          int index=0;
			          Map<String, Object> m = (Map<String, Object>) paraMap
								.get("labels");
		                Set<String> s = m.keySet();
		                Iterator<String> it = s.iterator();
		                if (m.size() >= 1){
			        	  if(m.size()==1){
			        		sql.append("select aa.objid,aa.labelid  from t_obj_label_ref aa "  );
			        			 sql.append("  where aa.objtypecatid = '13729' and aa.labelid in ("+m.get(it.next()) +") )  table1 ) h  on a.car_sharing_id = h.objid" ); 
			        		
				          }else{
				          while(it.hasNext()) {
				        	  index++;
				        	  if(index==1){
			        		  sql.append("select aa.objid,aa.labelid  from t_obj_label_ref aa " );
					        			 sql.append(" where aa.objtypecatid = '13729' and aa.labelid in ("+m.get(it.next())+") )  table1 " ); 
				        	  }
				        	  if(index!=m.size() &&index!=1){
				        		  sql.append("inner join  ( select aa.objid ,aa.labelid  from t_obj_label_ref aa " );
                    sql.append("  where aa.objtypecatid = '13729' " );
                    sql.append("     and aa.labelid in ("+m.get(it.next()) +")) " );
                    sql.append("    table"+index+"  on table1.objid=table"+(index - 1)+".objid" );
				        	  }
				        	  if(index==m.size() &&index!=1){
				        		  sql.append("inner join  ( select aa.objid ,aa.labelid  from t_obj_label_ref aa " );
                    sql.append("  where aa.objtypecatid = '13729' " );
                    sql.append("     and aa.labelid in ("+m.get(it.next()) +")) " );
                    sql.append("    table"+index+"  on table1.objid=table"+(index - 1)+".objid ) h on a.car_sharing_id = h.objid " );
				        	  }
				           }
			        	  }
			          }
				}

		   }
				sql.append(" where 1=1 and a.GO_OFF_TIME>SYSDATE and a.ENABLE_FLAG=1 " );
				if (paraMap != null){
					Set<String> paraSet = paraMap.keySet();
					Iterator<String> iter = paraSet.iterator();
					while(iter.hasNext()){
						String key = (String) iter.next();
						if ("state1".equals(key)){
							sql.append(" and bd.siteid ="+paraMap.get(key)+"" );
						}
						if ("city1".equals(key)){
							sql.append(" and d.siteid ="+paraMap.get(key)+"" );
						}
						if ("area1".equals(key)){
							sql.append(" and b.siteid ="+paraMap.get(key)+"" );
						}
						if ("state2".equals(key)){
							 sql.append(" and ce.siteid ="+paraMap.get(key)+"" );
							}
						if ("city2".equals(key)){
								 sql.append(" and e.siteid ="+paraMap.get(key)+"" );
							}
					    if ("area2".equals(key)){
								 sql.append(" and c.siteid ="+paraMap.get(key)+"" );
							}
					    if ("area2".equals(key)){
							 sql.append(" and c.siteid ="+paraMap.get(key)+"" );
						}
					    if ("queryStartdate".equals(key)){
							 sql.append(" and ( a.go_off_time between to_date('"+paraMap.get(key)+" "+paraMap.get("time1")+"','yyyy-mm-dd,hh24:mi:ss') " );
							 sql.append(" and to_date('"+paraMap.get(key)+" "+paraMap.get("time2")+"','yyyy-mm-dd,hh24:mi:ss'))  " );
						}
						 if ("keyword".equals(key)){
							
							//给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
							String keywordstr=StringUtil.deleteExtraSpace(paraMap.get(key).toString());
							
							//以空格为分隔符  把keywordstr分隔成数组
							  String[] str = keywordstr.split(" ");
							  
							  //循环数组 and条件查询
							for(int i=0;i<str.length;i++){
								sql.append(" and  k.searchkeyword like '%"+str[i]+"%' ");
							}
							sql.append(" and k.objecttypetypeid='restaurantProduct' and  k.objecttypecateid='objecttype' ");
						}
						 
					}

		       	
		   }
				sql.append("   order by  a.create_time desc  " );
		return findSql(sql.toString(),cpn,pageSize);
	}
}
