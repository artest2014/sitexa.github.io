package com.cct9k.dao.main;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.main.Restaurant;
import com.cct9k.entity.member.Member;

public interface RestaurantDao extends BaseDao<Restaurant, String> {

	List<Restaurant> getRestaurantsIsValidByMemberid(String memberId);

	public List<Restaurant> getRestaurantList(String memberid);

	public Pagination getPage(int pageNo, int pageSize);

	public List<Restaurant> searchByName(String keyword);
	
	public Pagination getPagination(Member member, String restaurantName,
			int pageNo, int pageSize);
	
	public List<Object[]> getIndexPics(String objectType);
	/**
	 * 
	 * 描述: 分销商客户关联娱乐店铺
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author    yangkun
	 * @Version  Ver1.0
	 */
	public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize);
	
	public List<Restaurant> get(String[] ids) ;

	public Pagination getAllRestaurantList(String restaurantName, String sitetype,
			String siteid, int pageNo, int pageSize);
	
	/**
	 * 查询没有被客户绑定的餐馆
	 * @return
	 */
	public Pagination findRestaurantNotBind(String restaurantName,int pageNo, int pageSize);
}
