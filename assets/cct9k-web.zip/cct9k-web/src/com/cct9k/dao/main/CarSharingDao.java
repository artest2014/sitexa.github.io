/**
 * <p>Class Name: CarSharing.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: yangkun</p>
 * <p>Date: 2013-8-22</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.dao.main;

import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.CarSharingInfo;

/**
 * @author yangkun
 *
 */
public interface CarSharingDao extends BaseDao<CarSharingInfo, String> {

	public Pagination getPage(String infoTitle, String startime,
			String endtime,String memberId, int pageNo, int pageSize) ;

	/**
	 * 描述: 前台拼车展示
	 * @param paraMap
	 * @param cpn
	 * @param pageSize
	 * @return
	 * @author    yangkun
	 * date        2013-9-7
	 * --------------------------------------------------
	 * 修改人          修改日期        修改描述
	 * yangkun    2013-9-7          创建
	 * --------------------------------------------------
	 * @Version  Ver1.0
	 */
	    
	public Pagination getCarsharingList(Map<String, Object> paraMap, int cpn,
			int pageSize);
}
