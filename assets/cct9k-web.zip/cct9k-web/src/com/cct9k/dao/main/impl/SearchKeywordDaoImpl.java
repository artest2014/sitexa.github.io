package com.cct9k.dao.main.impl;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.SearchKeywordDao;
import com.cct9k.entity.main.ObjectSearchKeyword;

@Repository
public class SearchKeywordDaoImpl extends
		BaseDaoImpl<ObjectSearchKeyword, String> implements SearchKeywordDao {

	// 酒店
	public void addHotelSearchKeyword(String objectId, String objectTypeId,
			String objectCateId) {
		
		// TODO Auto-generated method stub
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.hotelid,").append("'" + objectTypeId + "','" + objectCateId + "',").append("t.hotelname||','||t.searchkeyword||','||t.address||','||t.telephone||','||w.fullname||','||wm_concat(r.searchkeyword)||','||case when e.typename = '三星' then '3,三星'when e.typename = '四星' then '4,四星' when e.typename = '五星' then '5,五星'else '' end");
		sql.append(" from t_hotel t, t_site w,  ( select q.objid,r.searchkeyword from t_dictionary d,t_obj_label_ref q, t_product_label_info r where d.typeid ='hotel' and d.cateid='objecttype' and q.labelid = r.labelid and q.objtypecatid = d.dictid) r, t_dictionary e");
		sql.append(" where t.siteid = w.siteid and t.hotelid = r.objid(+) and t.hotelgrade = e.dictid").append(" and t.hotelid = '" + objectId + "' ");
		sql.append(" group by t.hotelname,  t.address, e.typename,  t.telephone, w.fullname,t.searchkeyword, t.hotelid) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	// 景点
	public void addScenerySearchKeyword(String objectId, String objectTypeId,
			String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.sceneryid,").append("'" + objectTypeId + "','" + objectCateId + "',").append("t.name||','|| t.searchkeyword||','||t.address||','||t.tel||','|| t.trafficguide||','||w.fullname||','|| wm_concat(r.searchkeyword)");
		sql.append(" from t_scenery t,t_site w, (select q.objid,r.searchkeyword from t_obj_label_ref q, t_product_label_info r, t_dictionary d where q.labelid = r.labelid and q.objtypecatid = d.dictid and d.typeid = 'scenery' and d.cateid = 'objecttype') r");
		sql.append(" where t.siteid = w.siteid and t.sceneryid= r.objid(+)").append(" and t.sceneryid = '" + objectId + "' ");
		sql.append(" group by t.name,t.address,t.tel,w.fullname,t.searchkeyword,t.trafficguide,t.sceneryid) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	// 娱乐场
	public void addEntertainmentSearchKeyword(String objectId,
			String objectTypeId, String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.entertainmentid,").append("'" + objectTypeId + "','" + objectCateId + "',").append("t.entertainmentname||','|| t.keyword||','||t.address||','||t.tel||','|| t.trafficguide||','||w.fullname||','|| wm_concat(r.searchkeyword)");
		sql.append(" from t_entertainment t,t_site w, (select q.objid,r.searchkeyword from t_obj_label_ref q, t_product_label_info r, t_dictionary d where q.labelid = r.labelid and q.objtypecatid = d.dictid and d.typeid = 'entertainment' and d.cateid = 'objecttype') r");
		sql.append(" where t.siteid = w.siteid and t.entertainmentid= r.objid(+)").append(" and t.entertainmentid = '" + objectId + "' ");
		sql.append(" group by t.entertainmentname,t.address,t.tel,w.fullname,t.keyword,t.trafficguide,t.entertainmentid) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	// 餐饮
	public void addRestaurantSearchKeyword(String objectId,
			String objectTypeId, String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.restaurantid,").append("'" + objectTypeId + "','" + objectCateId + "',").append("t.restaurantname||','|| t.restsearchkeyword||','||t.restaurantaddress||','||t.restauranttel||','||t.trafficguide||','||w.fullname||','||wm_concat(r.searchkeyword)");
		sql.append(" from t_restaurant t,t_site w, (select q.objid,r.searchkeyword from t_obj_label_ref q, t_product_label_info r, t_dictionary d where q.labelid = r.labelid and q.objtypecatid = d.dictid and d.typeid = 'restaurant' and d.cateid = 'objecttype') r");
		sql.append(" where t.siteid = w.siteid and t.restaurantid= r.objid(+)").append(" and t.restaurantid = '" + objectId + "' ");
		sql.append(" group by t.restaurantname, t.restaurantaddress, t.restaurantid, t.restauranttel, w.fullname,t.restsearchkeyword,t.trafficguide) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
	}
	
	// 餐饮产品
	public void addRestaurantProductSearchKeyword(String objectId,
			String objectTypeId, String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.restaurantproductid,").append("'" + objectTypeId + "','" + objectCateId + "',").append("t.restauproductname || ',' || t.keyword || ',' || wm_concat(r.searchkeyword) || ',' ||");
		sql.append(" (select t2.searchkeyword from t_restaurant_product t, t_object_search_keyword t2");
        sql.append("  where t.restaurantproductid  = ").append("'"+objectId+"'  and t.restaurantid = t2.objectid  and t2.objecttypetypeid = 'restaurant' and t2.objecttypecateid = 'objecttype')");
		sql.append(" from t_restaurant_product t,(select q.objid,r.searchkeyword from t_obj_label_ref q, t_product_label_info r, t_dictionary d where q.labelid = r.labelid and q.objtypecatid = d.dictid and d.typeid = 'restaurantProduct' and d.cateid = 'objecttype') r");
		sql.append(" where t.restaurantproductid = r.objid(+)").append(" and t.restaurantproductid = '" + objectId + "'");
		sql.append(" group by t.restauproductname, t.keyword, t.restaurantproductid) a");
		
		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
	}

	// 旅运
	public void addTransportSearchKeyword(String objectId, String objectTypeId,
			String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.transportid,").append("'" + objectTypeId + "','" + objectCateId + "',").append("t.companyname||','||t.searchkeyword||','||t.detailaddress||','||t.telephone||','||t.trafficguide||','||w.fullname||','||wm_concat(r.searchkeyword)");
		sql.append(" from t_transport t,t_site w,(select q.objid,r.searchkeyword from t_obj_label_ref q, t_product_label_info r, t_dictionary d where q.labelid = r.labelid and q.objtypecatid = d.dictid and d.typeid = 'transport' and d.cateid = 'objecttype') r");
		sql.append(" where t.siteid = w.siteid and t.transportid= r.objid(+)").append(" and t.transportid = '" + objectId + "'");
		sql.append(" group by t.companyname, t.detailaddress, t.transportid, t.telephone,w.fullname,t.searchkeyword, t.trafficguide) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}
	// 旅运产品
	public void addTransportProductSearchKeyword(String objectId, String objectTypeId,
			String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.productid,").append("'" + objectTypeId + "','" + objectCateId + "',").append("t.productname || ',' || t.keyword || ',' || wm_concat(r.searchkeyword) || ',' ||");
		sql.append(" (select t2.searchkeyword from t_transport_product t, t_object_search_keyword t2");
        sql.append("  where t.productid = ").append("'"+objectId+"' and t.transportid = t2.objectid and t2.objecttypetypeid = 'transport' and t2.objecttypecateid = 'objecttype')");
		sql.append(" from t_transport_product t,(select q.objid,r.searchkeyword from t_obj_label_ref q, t_product_label_info r, t_dictionary d where q.labelid = r.labelid and q.objtypecatid = d.dictid and d.typeid = 'transportProduct' and d.cateid = 'objecttype') r");
		sql.append(" where t.productid = r.objid(+)").append(" and t.productid = '" + objectId + "'");
		sql.append(" group by t.productname, t.keyword, t.productid) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	// 购物广场
	public void addShopSearchKeyword(String objectId, String objectTypeId,
			String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.shopid,").append("'" + objectTypeId + "','" + objectCateId + "',").append("t.shopname||','||t.shopsearchkeyword||','|| t.shopaddress||','||t.shoptel||','||t.trafficguide||','||w.fullname||','||wm_concat(r.searchkeyword)");
		sql.append(" from t_shop t, t_site w, (select q.objid,r.searchkeyword from t_obj_label_ref q, t_product_label_info r, t_dictionary d where q.labelid = r.labelid and q.objtypecatid = d.dictid and d.typeid = 'shop' and d.cateid = 'objecttype') r");
		sql.append(" where t.siteid = w.siteid and t.shopid = r.objid(+)").append(" and t.shopid = '" + objectId + "' ");
		sql.append(" group by t.shopname, t.shopaddress, t.shopid, t.shoptel,w.fullname,t.shopsearchkeyword,t.trafficguide) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	// 拼车
	public void addCarSharingSearchKeyword(String objectId,
			String objectTypeId, String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.car_sharing_id,'" + objectTypeId + "','"+ objectCateId + "',").append("t.info_title||','|| s.fullname||','|| w.fullname||','|| wm_concat(r.searchkeyword)");
		sql.append(" from t_car_sharing_info t,  t_site w,  t_site s, (select q.objid,r.searchkeyword from t_obj_label_ref q, t_product_label_info r, t_dictionary d where q.labelid = r.labelid and q.objtypecatid = d.dictid and d.typeid = 'carsharing' and d.cateid = 'objecttype') r");
		sql.append(" where t.car_sharing_id = r.objid(+) and t.GO_OFF_AREA_ID = w.siteid and t.DESTINATION_AREA_ID = s.siteid ").append(" and t.car_sharing_id ='" + objectId + "'");
		sql.append(" group by t.info_title, t.car_sharing_id, s.fullname, w.fullname) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	// 游记
	public void addPostSearchKeyword(String objectId, String objectTypeId,
			String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.id,'" + objectTypeId + "','" + objectCateId + "',").append("t.name||','|| t.subject||','|| w.fullname");
		sql.append(" from t_post t, t_site w");
		sql.append(" where t.site = w.siteid ").append(" and t.id='" + objectId + "'");
		sql.append(" group by t.name,t.subject,t.id, w.fullname) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	// 线路
	public void addRouteSearchKeyword(String objectId, String objectTypeId,
			String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.routeid,'" + objectTypeId + "','" + objectCateId+ "',").append(" t.routename||','|| t.departure||','||t.destination||','|| m.membername||','||w.fullname||','|| w1.fullname|| ',' ||case when  t.duration>=5 then '5天以上' else  t.duration ||'天' end  as duration ");
		sql.append(" from t_route t, t_site w,  t_site w1,t_member m");
		sql.append(" where t.departuresite = w.siteid  and t.reseller = m.memberid and t.destinationsite= w1.siteid").append(" and t.routeid='" + objectId + "'");
		sql.append(" group by t.routename,t.departure,t.destination,w.fullname,m.membername,t.routeid,w1.fullname,t.duration) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	// 导游
	public void addGuideSearchKeyword(String objectId, String objectTypeId,
			String objectCateId) {
		
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId;
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}

		StringBuffer sql = new StringBuffer();
		sql.append("insert into t_object_search_keyword(id,objectid,objecttypetypeid,objecttypecateid,searchkeyword) ");
		sql.append(" select s_public.nextval id,a.* from");
		sql.append(" (select t.memberid,'" + objectTypeId + "','" + objectCateId+ "',");
		sql.append("  m.membername||','||(select wm_concat(s.fullname) from t_guide_area t, t_site s  where t.cityareaid = s.siteid and memberid = ").append("'"+objectId+"')||','|| wm_concat(r.searchkeyword)||','|| case when m1.gendercode = '0' then '男' when m1.gendercode = '1' then '女' else '' end");
		sql.append(" from t_guide t,  t_member m,t_member_person m1,( select q.objid,r.searchkeyword,d.typeid,d.cateid from t_dictionary d, t_obj_label_ref q,  t_product_label_info r where d.typeid ='guide' and d.cateid='objecttype' and q.labelid = r.labelid and q.objtypecatid = d.dictid) r");
		sql.append(" where t.memberid = r.objid(+) and t.memberid = m.memberid  and t.memberid = m1.memberid").append(" and t.memberid='" + objectId + "'");
		sql.append(" group by m.membername,t.memberid,  m1.gendercode) a");

		this.getSession().createSQLQuery(sql.toString()).executeUpdate();
		
	}

	@Override
	public void delete(String objectId, String objectType) {
		// TODO Auto-generated method stub
		String hql = "from ObjectSearchKeyword o where o.objectid=" + objectId+" and o.objecttypetypeid = "+"'"+objectType+"'";
		ObjectSearchKeyword obj = (ObjectSearchKeyword) this.getSession()
				.createQuery(hql).uniqueResult();
		if (obj != null) {
			this.delete(obj.getId());
		}
	}
}
