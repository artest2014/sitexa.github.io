package com.cct9k.dao.main.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.SceneryDao;
import com.cct9k.entity.main.Scenery;
import com.cct9k.entity.main.SceneryExt;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.SceneryProductExt;
import com.cct9k.util.common.StringUtil;

@Repository
public class SceneryDaoImpl extends BaseDaoImpl<Scenery, String>
		implements
			SceneryDao {

	public Pagination getSceneryList(Map<String, Object> paraMap, int pageNo,
			int pageSize) {
		StringBuffer sql = new StringBuffer(
				"select  a.SCENERYID,a.NAME,a.SiteID, ");
		sql.append(" b.PICURL,a.scenerydesc,( case   when d.minprice is  null  then 0 when d.minprice ='' then 0 else  d.minprice  end ) as minprice  ");
		sql.append(" from T_SCENERY a");
		sql.append(" left join t_picture b on a.SCENERYID=b.OBJECTID");
		sql.append(" and b.objecttype='13889' ");
		sql.append(" left join (select SCENERYID, min(memberprice) as minprice ");
        sql.append("   from t_scenery_product ");
        sql.append(" where PRODUCTSTATUSCATID = '12849'  and  enableflag = '1' and   productendtime>=to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd')  group by SCENERYID) d ");
        sql.append(" on d.SCENERYID = a.SCENERYID");
		if (paraMap != null  && paraMap.size() > 0) {
			if (paraMap.get("labels") != null && !"".equals(paraMap.get("labels"))) {
                sql.append("  inner join ( select table1.objid from   ( ");
                int index = 0;
                Map<String, Object> m = (Map<String, Object>) paraMap
						.get("labels");
                Set<String> s = m.keySet();
				Iterator<String> it = s.iterator();
				if (m.size() >= 1){
                        if (m.size() == 1) {
                            sql.append("select aa.objid  from t_obj_label_ref aa  where aa.objtypecatid = '13489' and aa.labelid in (" +m.get(it.next()) + ")  group by  aa.objid )  table1 ) h  on a.SCENERYID = h.objid");
                           
                        } else {
                        	while (it.hasNext()) {
                            index++;
                            if (index == 1) {
                                sql.append("select aa.objid   from t_obj_label_ref aa ");
                                sql.append("  where aa.objtypecatid = '13489' and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid)  table1 ");
                            }
                            if (index != m.size() && index != 1) {
                                sql.append(" inner join  ( select aa.objid  from t_obj_label_ref aa   where aa.objtypecatid = '13489' ");
                                sql.append("     and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid) ");
                                sql.append("    table" + index + "  on table" + (index - 1) + ".objid=table" + index + ".objid");
                            }
                            if (index == m.size() && index != 1) {
                                sql.append(" inner join  ( select aa.objid   from t_obj_label_ref aa ");
                                sql.append("  where aa.objtypecatid = '13489' ");
                                sql.append("     and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid) ");
                                sql.append("    table" + index + "  on table" + (index - 1) + ".objid=table" + index + ".objid ) h on a.SCENERYID = h.objid ");
                            }
                          }
                        }

                }

            }
			
			if(paraMap.get("keyword")!=null && !"".equals(paraMap.get("keyword"))){
				sql.append(" inner join t_object_search_keyword k on a.sceneryid=k.objectid  ");
			}
		}

		sql.append(" where 1=1 and a.statuscatid='14009' and a.enableflag='1' ");
	
		if (paraMap != null  && paraMap.size() > 0) {
			Set<String> paraSet = paraMap.keySet();
			Iterator<String> iter = paraSet.iterator();
			while (iter.hasNext()) {
				String key = (String) iter.next();

				if ("site".equals(key)) {
					// sql.append(" and a.siteid in(").append(paraMap.get(key)).append(")");
					sql.append(" and exists");
					sql.append(
							" (select gg.siteid from (select ff.siteid from t_site ff start with ff.siteid ='")
							.append(paraMap.get(key)).append("'");
					sql.append(" Connect by Prior ff.siteid=ff.parentid) gg")
							.append(" where a.siteid=gg.siteid").append(")");
				}
                  if ("keyword".equals(key)) {
					
					//给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
					String keywordstr=StringUtil.deleteExtraSpace(paraMap.get(key).toString());
					
					//以空格为分隔符  把keywordstr分隔成数组
					  String[] str = keywordstr.split(" ");
					  sql.append(" and(");
					  //循环数组 and条件查询
					for(int i=0;i<str.length;i++){
						if (i == 0){
							sql.append(" k.searchkeyword like '%" + str[i] + "%' ");
						}
						else{
							sql.append(" or k.searchkeyword like '%" + str[i] + "%' ");
						}
						if (i == str.length-1){
							sql.append(")");
						}

					}
					sql.append(" and k.objecttypetypeid='scenery' and  k.objecttypecateid='objecttype' ");
				}
               
                
			}
			   if (paraMap.get("sort") != null && !"".equals(paraMap.get("sort"))) {
                   if ("asc".equals(paraMap.get("sort"))) {
                       sql.append(" order by minprice asc");
                   } else if ("desc".equals(paraMap.get("sort"))) {
                       sql.append(" order by minprice desc");
                   }
               }else{
                  sql.append(" order by minprice desc");
                }
		}
		else{
			sql.append("order by minprice desc");
		}
		String sqlStr = sql.toString();
		Pagination p = findSql(sqlStr, pageNo, pageSize);
		List<Object[]> result = (List<Object[]>) p.getList();
		List rslist = null;
		if (result != null) {
			SceneryExt scenery = null;
			rslist = new ArrayList();
			for (Object[] arr : result) {
				if (arr != null && arr.length > 0) {
					scenery = new SceneryExt();
					scenery.setSceneryid((String) arr[0]);
					scenery.setSceneryname((String) arr[1]);
					scenery.setPicurl((String) arr[3]);
					scenery.setDescription((String) arr[4]);
					if(arr[5]!=null)
					scenery.setMinprice(Integer.parseInt(arr[5].toString()));
				}
				rslist.add(scenery);
			}
		}

		p.setList(rslist);
		return p;
	}

	public List<SceneryExt> getSceneryExtList(Map<String, Object> paraMap) {
		StringBuffer sql = new StringBuffer(
				"select DISTINCT a.SCENERYID,a.NAME,a.SiteID,");
		sql.append(" b.PICURL,a.scenerydesc ");
		sql.append(" from T_SCENERY a");
		sql.append(" left join t_picture b on a.SCENERYID=b.OBJECTID");
		sql.append(" and b.objecttype='13889' ");
		if (paraMap != null) {
			if (paraMap.get("labels") != null
					&& !"".equals(paraMap.get("labels"))) {
				sql.append(" inner join T_OBJ_LABEL_REF d on a.SCENERYID=d.OBJID");
				sql.append(" inner join T_PRODUCT_LABEL_INFO e on d.LABELID=e.LABELID");
			}
		}
		sql.append(" where 1=1 and a.statuscatid='14009' and a.enableflag='1' ");
		if (paraMap != null) {
			Set<String> paraSet = paraMap.keySet();
			Iterator<String> iter = paraSet.iterator();
			while (iter.hasNext()) {
				String key = (String) iter.next();

				if ("site".equals(key)) {
					sql.append(" and a.siteid in(").append(paraMap.get(key))
							.append(")");
				}
				else if ("labels".equals(key)) {
					sql.append(" and e.labelid in(").append(paraMap.get(key))
							.append(")");
				} else if ("keyword".equals(key)) {
					String keywordStr = (String) paraMap.get(key);
					String[] keywordArr = keywordStr.split("\\s+");
					sql.append(" and (");
					for (int i = 0; i < keywordArr.length; i++) {
						if (i == 0) {
							sql.append("a.searchkeyword like '%"
									+ keywordArr[i] + "%'");
						} else {
							sql.append(" or a.searchkeyword like '%"
									+ keywordArr[i] + "%'");
						}
					}
					sql.append(" )");
				} else if ("sort".equals(key)) {
					if ("asc".equals(paraMap.get(key))) {
						sql.append("order by v.minprice asc");
					} else  {
						sql.append("order by v.minprice desc");
					} 
				}

			}
		}else{
			sql.append("order by a.CREATEDATE desc");
		}
		String sqlStr = sql.toString();
		Query query = getSession().createSQLQuery(sqlStr);
		List<Object[]> rawList = (List<Object[]>) query.list();
		List<SceneryExt> rslist = null;
		if (rawList != null) {
			SceneryExt scenery = null;
			rslist = new ArrayList();
			for (Object[] arr : rawList) {
				if (arr != null && arr.length > 0) {
					scenery = new SceneryExt();
					scenery.setSceneryid((String) arr[0]);
					scenery.setSceneryname((String) arr[1]);
					scenery.setPicurl((String) arr[3]);
					scenery.setDescription((String) arr[4]);
				}
				rslist.add(scenery);
			}
		}
		return rslist;
	}

	public List<SceneryProductExt> getListBySceneryId(String sceneryId) {
		StringBuffer sql = new StringBuffer(
				"select a.PRODUCTID,a.PRODUCTNAME,a.MEMBERPRICE,a.PRODUCTQUOTAS,a.MARKETPRICE,a.productdesc, (CASE WHEN a.productstatuscatid='12972' THEN '1002' ELSE '1001' END) isValid  from T_SCENERY_PRODUCT a ");
		sql.append("where   a.enableflag='1' and a.SCENERYID=?  and (a.productstatuscatid='12849' or  a.productstatuscatid='12972')   ");
		Query query = this.getSession().createSQLQuery(sql.toString());
		query.setString(0, sceneryId);
		List<Object[]> objlist = query.list();
		List<SceneryProductExt> resultList = new ArrayList<SceneryProductExt>();
		if (objlist != null) {
			SceneryProductExt scpt = null;
			for (Object[] arr : objlist) {
				scpt = new SceneryProductExt();
				scpt.setProductid((String) arr[0]);
				scpt.setProductname((String) arr[1]);
				scpt.setMemberprice((BigDecimal) arr[2]);
				scpt.setProductquotas((BigDecimal) arr[3]);
				scpt.setMarketprice((BigDecimal) arr[4]);
				scpt.setProductdesc((String) arr[5]);
				scpt.setIsValid((String) arr[6]);
				resultList.add(scpt);
			}
		}
		return resultList;
	}

	/**
	 * 
	 * @param sceneryid
	 * @return
	 * @author liu weili
	 */
	@SuppressWarnings("unchecked")
	public List<Picture> findPicListBySceneryId(String sceneryid) {
		String hql = "from Picture a where a.objectID=? and (a.objectType=? or a.objectType=?) order by a.objectType asc ";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, sceneryid);
		query.setString(1, Picture.SCENERY_INTRO_PIC);
		query.setString(2, Picture.SCENERY_FIGURE_PIC);
		return query.list();
	}

	/**
	 * 
	 * @param sceneryid
	 * @return picture
	 * @author liu weili
	 */
	public List<Picture> findFigurePicBySceneryId(String sceneryid) {
		String hql = "from Picture a where a.objectID=? and a.objectType=?";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, sceneryid);
		query.setString(1, Picture.SCENERY_FIGURE_PIC);
		return query.list();
	}

	public List<Picture> findDescPicBySceneryId(String sceneryid) {
		String hql = "from Picture a where a.objectID=? and a.objectType=?";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, sceneryid);
		query.setString(1, Picture.SCENERY_INTROWORDS_PIC);
		return query.list();
	}

	@Override
	public List<Scenery> getSceneryList(String memberid) {
		String hql = ("select h from Scenery h where h.member.parent.memberid='"
				+ memberid + "' or h.member.memberid='" + memberid + "'");

		List<Scenery> list = getListByHql(hql);
		if (list != null && list.size() > 0) {
			return list;
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Scenery> getSceneriesIsValidByMemberId(String memberId) {
		String hql = "from Scenery s where s.member.memberid=? and s.enableflag=1 ";
		return getSession().createQuery(hql).setParameter(0, memberId).list();
	}

	@Override
	public Pagination getPage(int pageNo, int pageSize) {
		Finder r = Finder.create("from Scenery model where 1=1");

		r.append(" order by createdate desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public List<Scenery> searchByName(String keyword) {
		String hql = "from Scenery where name like :name||'%' and enableflag='1' order by name ";
		return getSession().createQuery(hql).setParameter("name", keyword)
				.list();
	}
	@Override
	public Pagination getPagination(Member member, String sceneryName,
			int pageNo, int pageSize) {
		  Finder f = Finder.create("from Scenery  s where 1=1");
		    if (member != null) {
	            f.append(" and s.member.memberid=:memberid ");
	            f.setParam("memberid", member.getMemberid());
	        }

	        if (!StringUtil.isEmpty(sceneryName)) {
	            f.append(" and s.name like '%'||:sceneryname||'%' ");
	            f.setParam("hoscenerynametelname", sceneryName);
	        }

	        f.append(" order by s.iftop asc");

	        return find(f, pageNo, pageSize);
	}
	
	@Override
	public List<Object[]> getSceneryPics(String sceneryCateid) {
		String sql = " select p.picUrl,p.picTitle,p.descriptions ,s.sceneryid,s.name" +
				" from  t_picture p ,t_scenery s where s.sceneryid=p.objectID" +
				" and p.objectType='"+sceneryCateid+"' and s.iftop='1' and rownum<=2 ";
		   List<Object[]> obj = getSession().createSQLQuery(sql).list();
		return obj;
	}

	
	@Override
	public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize){
    	String sql = " select a.sceneryid,a.name,a.tel  from t_scenery a where a.statuscatid='14009' and a.enableflag='1' ";
    	if(!StringUtil.isEmpty(paraMap.get("Name").toString()))
			sql+="  and a.name like '%"+paraMap.get("Name").toString()+"%'";
    	return findSql(sql, pageNo, pageSize);
	}
	
	@Override
	public List<Scenery> get(String[] ids) {
		Assert.notEmpty(ids, "ids must not be empty");
		String hql = "from Scenery as model where model.enableflag='1' and model.statuscatid='14009' and model.id in(:ids)";
		return getSession().createQuery(hql).setParameterList("ids", ids).list();
	}

	@Override
	public Pagination getAllSceneryList(String sceneryName, String sitetype,
			String siteid, int pageNo, int pageSize) {
		StringBuffer sb = new StringBuffer("from Scenery scenery where scenery.statuscatid='14009' and scenery.enableflag='1' ");
		Map<String, Object> paramMap = new HashMap<String, Object>();
		if (!StringUtil.isEmpty(sceneryName)) {
			sb.append(" and scenery.name like :sceneryName");
			paramMap.put("sceneryName", "%" + sceneryName + "%");
		}
		if (!StringUtil.isEmpty(sitetype)&&!StringUtil.isEmpty(siteid)) {
			if(sitetype.equals("2")){
				sb.append(" and scenery.site.state = :siteid");
			}else if(sitetype.equals("3")){
				sb.append(" and scenery.site.city = :siteid");
			}else if(sitetype.equals("4")){
				sb.append(" and scenery.site.siteid = :siteid");
			}
			paramMap.put("siteid", siteid);
		}
		Finder f = Finder.create(sb.toString());
		f.append(" order by scenery.sceneryid desc");
		f.setParams(paramMap);
		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination findSceneryNotBind(String sceneryName,int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM T_SCENERY TS WHERE TS.ENABLEFLAG=1 AND TS.STATUSCATID=(SELECT TD.DICTID FROM T_DICTIONARY TD WHERE TD.TYPEID='UP' AND TD.CATEID='Status') AND NOT EXISTS(SELECT TC.CUSTOMERID FROM T_CUSTOMER TC WHERE TC.OBJECTID=TS.SCENERYID AND TC.ISENABLE=1)";
		if(!StringUtil.isEmpty(sceneryName)){
			sql =sql + " AND TS.NAME LIKE '%"+sceneryName+"%'";
		}
		return findSql(sql, Scenery.class, null, pageNo, pageSize);
	}	
}
