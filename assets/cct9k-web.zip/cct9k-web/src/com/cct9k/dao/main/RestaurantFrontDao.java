package com.cct9k.dao.main;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Restaurant;
import com.cct9k.entity.order.OrderEstimateInfo;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.ResProductPage;
import com.cct9k.entity.product.RestaurantProduct;

public interface RestaurantFrontDao extends BaseDao<Restaurant, String>{
	/**
	 * 初始化查询餐饮信息
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination getRestaurantList(Map<String,Object> paraMap,int pageNo, int pageSize);
	
	/**
	 * 根据ID查找餐饮产品信息
	 * @param resProductId
	 * @return
	 */
	public ResProductPage getObjByResProductId(String resProductId);
	
	/**
	 * 根据餐饮产品ID查询餐饮产品的介绍图片列表
	 * @param proId
	 * @return
	 */
	public List<Picture> getResProPicbyId(String proId);

	
	/**
	 * 根据ID查找餐馆信息
	 * @param restaurantId
	 * @return
	 */
	public Restaurant getObjByRestaurantId(String restaurantId);
	
	/**
	 * 查找某个餐馆的所有图片信息
	 * @param restaurantId
	 * @param isAll
	 * @return
	 */
	public List<Picture> findPicListByRestaurantId(String restaurantId,boolean isAll);
	
	/**
	 * 统计某个餐馆下的餐饮产品情况
	 * @param restaurantId
	 * @return
	 */
	public List<ResProductPage> findResProductNum(String restaurantId);
	
	/**
	 * 查询某个餐馆下的餐饮产品并分页
	 * @param restaurantId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination findResProductPage(String restaurantId,int pageNo, int pageSize,String labelid);
	
	/**
	 * 根据菜的种类统计餐馆下的产品情况
	 * @param restaurantId
	 * @return
	 */
	public List<ResProductPage> findResProductByType(String restaurantId);
	
	public List<Picture> getFigurePicListByRestProdId(String resProductId);
	
}
