package com.cct9k.dao.main.impl;


import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.EntertainmentDao;
import com.cct9k.dao.member.MemberDao;
import com.cct9k.entity.main.Entertainment;
import com.cct9k.entity.main.EntertainmentExt;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.main.Shop;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.OrderEstimateInfo;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.EntertainmentProduct;
import com.cct9k.util.common.DateUtil;
import com.cct9k.util.common.StringUtil;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import javax.annotation.Resource;

import java.math.BigDecimal;
import java.util.*;

/**
 * @author yics 2013-08-30
 */
@Repository
public class EntertainmentDaoImpl extends BaseDaoImpl<Entertainment, String> implements EntertainmentDao {

    @Resource
    private MemberDao dao;

    @Override
    public List<Entertainment> getEntertainmentList(String memberid) {
        String hql = ("select h from Entertainment h where h.member.parent.memberid='" + memberid + "' or h.member.memberid='" + memberid + "'");

        List<Entertainment> list = getListByHql(hql);
        if (list != null && list.size() > 0) {
            return list;
        } else {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Entertainment> getEntertainmentIsValidByMemberId(String memberId) {
        String hql = "from Entertainment e where e.member.memberid=? and e.enableflag=1 ";
        return getSession().createQuery(hql).setParameter(0, memberId).list();
    }

    @Override
    public Pagination getEntertainmentList(Map<String, Object> paraMap, int pageNo, int pageSize) {
        StringBuffer sql = new StringBuffer();
        sql.append(" select a.entertainmentid,a.entertainmentname,a.enterainmentdesc,b.picurl,d.minprice ");
        sql.append(" from t_entertainment a");
        sql.append(" left join t_picture b on a.entertainmentid = b.objectid and b.objecttype = 14289");
        sql.append(" left join (select enterainmentid, min(memberprice) as minprice ");
        sql.append("   from t_entertainment_product ");
        sql.append(" where PRODUCTSTATUSCATID = 12849  and  enableflag = '1' and   productendtime>=to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd')  group by enterainmentid) d ");
        sql.append(" on d.enterainmentid = a.entertainmentid");
        if (paraMap != null &&  paraMap.size() > 0) {
            if (paraMap.get("labels") != null && !"".equals(paraMap.get("labels"))) {
                sql.append("  inner join ( select table1.objid from   ( ");
                int index = 0;
                Map<String, Object> m = (Map<String, Object>) paraMap
						.get("labels");
                Set<String> s = m.keySet();
				Iterator<String> it = s.iterator();
				if (m.size() >= 1){
                        if (m.size() == 1) {
                            sql.append("select aa.objid  from t_obj_label_ref aa  where aa.objtypecatid = '14070' and aa.labelid in (" +m.get(it.next()) + ")  group by  aa.objid )  table1 ) h  on a.entertainmentid = h.objid");
                           
                        } else {
                        	while (it.hasNext()) {
                            index++;
                            if (index == 1) {
                                sql.append("select aa.objid   from t_obj_label_ref aa ");
                                sql.append("  where aa.objtypecatid = '14070' and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid)  table1 ");
                            }
                            if (index != m.size() && index != 1) {
                                sql.append(" inner join  ( select aa.objid  from t_obj_label_ref aa   where aa.objtypecatid = '14070' ");
                                sql.append("     and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid) ");
                                sql.append("    table" + index + "  on table" + (index - 1) + ".objid=table" + index + ".objid");
                            }
                            if (index == m.size() && index != 1) {
                                sql.append(" inner join  ( select aa.objid   from t_obj_label_ref aa ");
                                sql.append("  where aa.objtypecatid = '14070' ");
                                sql.append("     and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid) ");
                                sql.append("    table" + index + "  on table" + (index - 1) + ".objid=table" + index + ".objid ) h on a.entertainmentid = h.objid ");
                            }
                          }
                        }

                }

            }
            if (paraMap.get("keyword") != null && !"".equals(paraMap.get("keyword"))) {
                sql.append(" inner join t_object_search_keyword k on k.objectid=a.entertainmentid   ");
            }
        }
        sql.append(" where a.statuscatid = '14009' and a.enableflag = '1' ");
        if (paraMap != null  &&  paraMap.size() > 0) {
            Set<String> paraSet = paraMap.keySet();
            Iterator<String> iter = paraSet.iterator();
            while (iter.hasNext()) {
                String key = (String) iter.next();
                if ("site".equals(key)) {
					sql.append(" and exists");
					sql.append(
							" (select gg.siteid from (select ff.siteid from t_site ff start with ff.siteid ='")
							.append(paraMap.get(key)).append("'");
					sql.append(" Connect by Prior ff.siteid=ff.parentid) gg")
							.append(" where a.siteid=gg.siteid").append(")");
				}
                if ("keyword".equals(key)) {
                    //给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
                    String keywordstr = StringUtil.deleteExtraSpace(paraMap.get(key).toString());
                    //以空格为分隔符  把keywordstr分隔成数组
                    String[] str = keywordstr.split(" ");
                    sql.append(" and (");

                    //循环数组 and条件查询
                    for (int i = 0; i < str.length; i++) {
                    	if (i == 0){
                        sql.append("   k.searchkeyword like '%" + str[i] + "%' ");
                    	}
                    	else{
    						sql.append(" or k.searchkeyword like '%" + str[i] + "%' ");
    					}
                    	if (i == str.length-1){
    						sql.append(")");
    					}
                    }
                    sql.append(" and k.objecttypetypeid='entertainment' and  k.objecttypecateid='objecttype' ");
                }
            }

            if (paraMap.get("sort") != null && !"".equals(paraMap.get("sort"))) {
                if ("asc".equals(paraMap.get("sort"))) {
                    sql.append("order by d.minprice asc");
                } else if ("desc".equals(paraMap.get("sort"))) {
                    sql.append("order by d.minprice desc");
                }
            }else{
                sql.append(" order by d.minprice desc");
              }
        }else{
			sql.append("order by d.minprice desc");
		}
        String sqlStr = sql.toString();
        Pagination p = findSql(sqlStr, pageNo, pageSize);
        List<Object[]> result = (List<Object[]>) p.getList();
        List rstlist = null;
        if (result != null) {
            EntertainmentExt entertainment = null;
            rstlist = new ArrayList();
            for (Object[] arr : result) {
                if (arr != null && arr.length > 0) {
                    entertainment = new EntertainmentExt();
                    entertainment.setEntertainmentid((String) arr[0]);
                    entertainment.setEntertainmenName((String) arr[1]);
                    entertainment.setDescription((String) arr[2]);
                    entertainment.setIndexpicurl((String) arr[3]);
                    entertainment.setMinPrice(arr[4] != null ? arr[4].toString() : "");
                    rstlist.add(entertainment);
                }
            }
        }
        p.setList(rstlist);
        return p;
    }

    public List<EntertainmentProduct> findProductListByEntertainmentid(String entertainmentid) {
        String sql = "select  a.productid,a.productname,a.marketprice,a.memberprice,a.productquotas, b.picurl, (CASE WHEN a.productstatuscatid='12972' THEN '1002' ELSE '1001' END) isValid from " + " t_entertainment_product a  left join t_picture b on b.objectid=a.productid  and b.objecttype='13950' " + "  where a.enterainmentid=? and a.enableflag='1' and (a.productstatuscatid='12849' or  a.productstatuscatid='12972')  ";
        Query query = this.getSession().createSQLQuery(sql);
        query.setString(0, entertainmentid);
         List<Object[]> objList= query.list();
         List<EntertainmentProduct> entainmentProduct=new ArrayList<EntertainmentProduct>();
      // 进行实体封装
      			if (objList != null) {
      				EntertainmentProduct entertainmentProduct=null;
      				for (Object[] arr : objList) {
      					entertainmentProduct=new EntertainmentProduct();
      					entertainmentProduct.setProductid(arr[0] != null ? (String) arr[0] : "");
      					entertainmentProduct.setProductname(arr[1] != null ? (String) arr[1] : "");
      					entertainmentProduct.setMarketprice(arr[2] != null ? (BigDecimal) arr[2] : null);
      					entertainmentProduct.setMemberprice(arr[3] != null ? (BigDecimal) arr[3] : null);
      					entertainmentProduct.setProductquotas(arr[4] != null ? (BigDecimal) arr[4] : null);
      					entertainmentProduct.setPicUrl(arr[5] != null ? (String) arr[5] : "");
      					entertainmentProduct.setIsValid(arr[6] != null ? (String) arr[6] : "");
     					entainmentProduct.add(entertainmentProduct);
      				}
      			}
         return entainmentProduct;
    }

   

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * 查找某个娱乐场所的所有图片信息
     *
     * @param enterainmentid
     * @return
     */
    public List<Picture> findPicListbyEnterainmentid(String enterainmentid) {
        String hql = "from Picture a where a.objectID=? and (a.objectType=? or a.objectType=?) order by a.objectType";
        Query query = this.getSession().createQuery(hql);
        query.setString(0, enterainmentid);
        query.setString(1, Picture.OBJECT_TYPE_XINGXIANG_ENTERTAIMENT);
        query.setString(2, Picture.OBJECT_TYPE_ZHANSHI_ENTERTAIMENT);
        return query.list();
    }

    @Override
    public List<Entertainment> searchByName(String keyword) {
        String hql = "from Entertainment where entertainmentname like :name||'%' and enableflag='1' order by entertainmentname ";
        return getSession().createQuery(hql).setParameter("name", keyword).list();
    }

    @Override
    public Pagination getPagination(Member member, String entertainmentName, int pageNo, int pageSize) {
        Finder f = Finder.create("from Entertainment  e where 1=1");
        if (member != null) {
            f.append(" and e.member.memberid=:memberid ");
            f.setParam("memberid", member.getMemberid());
        }

        if (!StringUtil.isEmpty(entertainmentName)) {
            f.append(" and e.entertainmentname like '%'||:entertainmentname||'%' ");
            f.setParam("entertainmentname", entertainmentName);
        }

        f.append(" order by e.iftop asc");
        return find(f, pageNo, pageSize);

    }

    @Override
    public List<Object[]> getEntertainmentPics(String objectType) {
        String sql = " select p.picUrl,p.picTitle,p.descriptions ,e.entertainmentid,e.entertainmentname" +
                " from  t_picture p ,T_ENTERTAINMENT e where e.entertainmentid=p.objectID" +
                " and p.objectType='" + objectType + "' and e.iftop='1' and rownum<=2 ";
        List<Object[]> obj = getSession().createSQLQuery(sql).list();

        return obj;

    }

    public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize){
    	String sql = " select a.entertainmentid,a.entertainmentname,a.tel from  t_entertainment a where a.statuscatid='14009' and a.enableflag='1' ";
    	if(!StringUtil.isEmpty(paraMap.get("Name").toString()))
			sql+=" and a.entertainmentname like '%"+paraMap.get("Name").toString()+"%'";
    	return findSql(sql, pageNo, pageSize);
	}

	@Override
	public List<Entertainment> getOnSaleEntertainmentById(String entertainmentId) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder("from Entertainment model where model.statuscatid='14009' and model.enableflag='1' and model.entertainmentid="+entertainmentId);
		 
		Query query = getSession().createQuery(sb.toString());
		List list = query.list();
		return list;
	}
	
	@Override
	public List<Entertainment> get(String[] ids) {
		Assert.notEmpty(ids, "ids must not be empty");
		String hql = "from Entertainment as model where model.enableflag='1' and model.statuscatid='14009' and model.id in(:ids)";
		return getSession().createQuery(hql).setParameterList("ids", ids).list();
	}

	@Override
	public Pagination getAllShowList(String showName, String sitetype,
			String siteid, int pageNo, int pageSize) {
			StringBuffer sb = new StringBuffer("from Entertainment entertainment where entertainment.statuscatid='14009' and entertainment.enableflag='1' ");
			Map<String, Object> paramMap = new HashMap<String, Object>();
			if (!StringUtil.isEmpty(showName)) {
				sb.append(" and entertainment.entertainmentname like :showName");
				paramMap.put("showName", "%" + showName + "%");
			}
			if (!StringUtil.isEmpty(sitetype)&&!StringUtil.isEmpty(siteid)) {
				if(sitetype.equals("2")){
					sb.append(" and entertainment.site.state = :siteid");
				}else if(sitetype.equals("3")){
					sb.append(" and entertainment.site.city = :siteid");
				}else if(sitetype.equals("4")){
					sb.append(" and entertainment.site.siteid = :siteid");
				}
				paramMap.put("siteid", siteid);
			}
			Finder f = Finder.create(sb.toString());
			f.append(" order by entertainment.entertainmentid desc");
			f.setParams(paramMap);
			return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination findEntertainmentNotBind(String entertainmentName,int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM T_ENTERTAINMENT TE WHERE TE.ENABLEFLAG=1 AND TE.STATUSCATID=(SELECT TD.DICTID FROM T_DICTIONARY TD WHERE TD.TYPEID='UP' AND TD.CATEID='Status')  AND NOT EXISTS(SELECT TC.CUSTOMERID FROM T_CUSTOMER TC WHERE TC.OBJECTID=TE.ENTERTAINMENTID AND TC.ISENABLE=1)";
		if(!StringUtil.isEmpty( entertainmentName)){
			sql =sql + " AND TE.ENTERTAINMENTNAME LIKE '%"+entertainmentName+"%'";
		}
		return findSql(sql, Entertainment.class, null, pageNo, pageSize);
	}	


}
