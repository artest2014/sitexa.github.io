package com.cct9k.dao.main;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Shop;

/**
 * @author yics 2013-08-15
 */
public interface ShopDao extends BaseDao<Shop, String>{

	public Pagination getPage(String memberid,String shopname,String status,int pageNo, int pageSize);
	
	public Pagination getIndexPage(Map<String,Object> paraMap,int pageNo, int pageSize);
	
	public List<Shop> getShopbymember(String memberid);
	
    public Pagination getPage(int pageNo, int pageSize);

    public List<Shop> searchByName(String keyword);
    
    /**
	 * 查询没有被客户绑定的商铺
	 * @return
	 */
	public Pagination findShopNotBind(String shopName,int pageNo, int pageSize);
}
