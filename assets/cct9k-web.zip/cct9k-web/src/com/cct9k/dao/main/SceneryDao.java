package com.cct9k.dao.main;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.main.Scenery;
import com.cct9k.entity.main.SceneryExt;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.SceneryProductExt;

public interface SceneryDao extends BaseDao<Scenery, String> {

	/**
	 * 
	 * @param paraMap
	 * @return
	 * @author liuweili
	 */
	public Pagination getSceneryList(Map<String, Object> paraMap, int pageNo,
			int pageSize);

	public List<SceneryExt> getSceneryExtList(Map<String, Object> paraMap);

	public List<SceneryProductExt> getListBySceneryId(String sceneryId);

	List<Scenery> getSceneriesIsValidByMemberId(String memberId);

	/**
	 * 
	 * @author liu weili
	 */
	public List<Picture> findPicListBySceneryId(String sceneryid);

	public List<Scenery> getSceneryList(String memberid);

	/**
	 * 
	 * @author liu weili
	 */
	public List<Picture> findFigurePicBySceneryId(String sceneryid);

	public List<Picture> findDescPicBySceneryId(String sceneryid);

	public Pagination getPage(int pageNo, int pageSize);
	
	public Pagination getPagination(Member member, String sceneryName,
			int pageNo, int pageSize);

	public List<Scenery> searchByName(String keyword);

	public List<Object[]> getSceneryPics(String sceneryCateid);
	
	/**
	 * 
	 * 描述: 分销商客户关联景点
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author    yangkun
	 * @Version  Ver1.0
	 */
	public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize);
	
	public List<Scenery> get(String[] ids) ;

	public Pagination getAllSceneryList(String sceneryName, String sitetype,
			String siteid, int pageNo, int pageSize);
	
	/**
	 * 查询没有被客户绑定的景点
	 * @return
	 */
	public Pagination findSceneryNotBind(String sceneryName,int pageNo, int pageSize);
}
