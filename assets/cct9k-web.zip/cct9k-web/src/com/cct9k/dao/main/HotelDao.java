package com.cct9k.dao.main;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.main.HotelExt;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.HotelProduct;
import com.cct9k.entity.product.HotelProductExt;

public interface HotelDao extends BaseDao<Hotel, String> {

	public Pagination getPage(String hotelName, String hotelStatus,
			String hotelGrade, int pageNo, int pageSize);

	public List<Hotel> getHotelList(String memberid);

	/**
	 * 条件查询酒店信息
	 * 
	 * @param paraMap
	 * @return
	 * @author zhoubi
	 */
	public Pagination getHotelList(Map<String, Object> paraMap, int pageNo,
			int pageSize,String sort);

	/**
	 * 查找某个酒店下的房间信息
	 * 
	 * @param hotelid
	 * @return
	 * @author zhoubi
	 */
	public List<HotelProduct> getListByHotelId(String hotelid);

	/**
	 * 查找某个酒店的所有图片信息
	 * 
	 * @param hotelid
	 * @return
	 */
	public List<Picture> findPicListByHotelId(String hotelid);



	/**
	 * 酒店产品ID
	 * 
	 * @param productId
	 * @return
	 */
	public HotelProductExt getProductById(String productId);

	/**
	 * 查找某一房型的所有图片
	 * 
	 * @param productId
	 * @return
	 */
	public List<Picture> findRoomListByProId(String productId);
	
	/**
	 * 查询某个酒店信息
	 * @param hotelid
	 * @return
	 */
	public HotelExt getHotelById(String hotelid);

	public List<Hotel> getHotelsIsValidByMemberid(String memberId);

	public Pagination getPage(int pageNo, int pageSize);

	public List<Hotel> searchByName(String keyword);
	
	public Pagination getPaginationgetPagination(Member member, String hotelName, int pageNo, int pageSize);

	public List<Object[]> getHotelPics(String objectType);
    /**
     * 
     * 描述: 分销根据客户类型查找直销酒店店铺
     * @param paraMap
     * @param pageNo
     * @param pageSize
     * @return
     * @author    yangkun
     * date        2013-10-30
     * --------------------------------------------------
     * 修改人          修改日期        修改描述
     * yangkun    2013-10-30          创建
     * --------------------------------------------------
     * @Version  Ver1.0
     */
	public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize);
    
	public List<Hotel> get(String[] ids) ;

	public Pagination getAllHotelList(String hotelName, String sitetype,
			String siteid, String hotelGrade, int pageNo, int pageSize);
	
	/**
	 * 查询没有被客户绑定的酒店
	 * @param hotelName
	 * @return
	 */
	public Pagination findHotelNotBind(String hotelName ,int pageNo, int pageSize);
	
}
