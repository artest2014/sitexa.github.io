package com.cct9k.dao.main.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.ShopDao;
import com.cct9k.entity.main.Scenery;
import com.cct9k.entity.main.Shop;
import com.cct9k.entity.member.Member;
import com.cct9k.util.common.StringUtil;

/**
 * @author yics 2013-08-15
 */
@Repository
public class ShopDaoImpl extends BaseDaoImpl<Shop, String> implements ShopDao {

	@Override
	public Pagination getPage(String memberid, String shopname, String status,
			int pageNo, int pageSize) {

		Finder s = Finder.create("from Shop shop where 1=1 and shop.member.memberid="+ memberid);

		if (!StringUtil.isEmpty(shopname)) {
			s.append(" and shop.shopname like '%'||:shopname||'%' ");
			s.setParam("shopname", shopname);

		}
		if (!StringUtil.isEmpty(status)) {
			s.append(" and shop.shopstatus.dictid =:status ");
			s.setParam("status", status);
		}
		s.append(" order by shop.updatedate desc");

		return find(s, pageNo, pageSize);
	}
/**
 * String shopname, List<String> label,
			String siteid,
 * @param pageNo
 * @param pageSize
 * @return
 */
	@Override
	public Pagination getIndexPage(Map<String,Object> paraMap, int pageNo, int pageSize) {
        StringBuffer sql=new StringBuffer();
		 sql.append( " select  distinct s.shopid, ");
		sql.append("s.shopname, ");
		sql.append("s.shoplong, ");
		sql.append("s.shoplat, ");
		sql.append("s.siteid, ");
		sql.append("s.shopqq,");
		sql.append("s.shoptel, ");
		sql.append("s.shopaddress,");
		sql.append("s.trafficguide, ");
		sql.append( "s.shopkeyword,");
		sql.append( "s.shopsearchkeyword,");
		sql.append("s.shopstatuscatid, ");
		sql.append("s.memberid, ");
		sql.append("s.creator, ");
		sql.append("s.createdate,");
		sql.append("s.updater, ");
		sql.append("s.updatedate,");
		sql.append("s.enableflag,");
		sql.append("p.picurl,");
		sql.append("p.abbrurl,");
		sql.append("p.descriptions from t_obj_label_ref re,t_shop s ");
		sql.append("left join t_picture p on s.shopid = p.objectid ");

		
		if (paraMap != null &&  paraMap.size() > 0) {
//		if (label!=null && label.size() > 0) {
//			sql += "	and s.shopid = re.objid and re.objtypecatid='14829'";
//			sql += "    and re.labelid in ("
//					+ label.toString().replace("[", "").replace("]", "") + ")";
//		}

			if (paraMap.get("labels") != null && !"".equals(paraMap.get("labels"))) {
				sql.append("  inner join ( select table1.objid from   ( ");
					int index = 0;
				Map<String, Object> m = (Map<String, Object>) paraMap
					.get("labels");
         Set<String> s = m.keySet();
			Iterator<String> it = s.iterator();
			if (m.size() >= 1){
                 if (m.size() == 1) {
                     sql.append("select aa.objid  from t_obj_label_ref aa  where aa.objtypecatid = '14829' and aa.labelid in (" +m.get(it.next()) + ")  group by  aa.objid )  table1 ) h  on s.shopid = h.objid");
                    
                 } else {
                 	while (it.hasNext()) {
                     index++;
                     if (index == 1) {
                         sql.append("select aa.objid   from t_obj_label_ref aa ");
                         sql.append("  where aa.objtypecatid = '14829' and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid)  table1 ");
                     }
                     if (index != m.size() && index != 1) {
                         sql.append(" inner join  ( select aa.objid  from t_obj_label_ref aa   where aa.objtypecatid = '14070' ");
                         sql.append("     and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid) ");
                         sql.append("    table" + index + "  on table" + (index - 1) + ".objid=table" + index + ".objid");
                     }
                     if (index == m.size() && index != 1) {
                         sql.append(" inner join  ( select aa.objid   from t_obj_label_ref aa ");
                         sql.append("  where aa.objtypecatid = '14829' ");
                         sql.append("     and aa.labelid in (" + m.get(it.next()) + ") group by  aa.objid) ");
                         sql.append("    table" + index + "  on table" + (index - 1) + ".objid=table" + index + ".objid ) h on s.shopid = h.objid ");
                     }
                   }
                 }

         }

     }
     if (paraMap.get("keyword") != null && !"".equals(paraMap.get("keyword"))) {
         sql.append(" inner join t_object_search_keyword k on k.objectid=s.shopid ");
     }
 
 }

//		if (!StringUtil.isEmpty(shopname)) {
//			sql += "and s.shopsearchkeyword like '%" + shopname + "%'";
//		}
//		if (!StringUtil.isEmpty(siteid)) {
//			sql += "and s.siteid = '" + siteid + "'";
//		}
		sql.append(" where 1=1 and s.shopstatuscatid ='13311' and s.enableflag = '1' " );
		
        if (paraMap != null  &&  paraMap.size() > 0) {
            Set<String> paraSet = paraMap.keySet();
            Iterator<String> iter = paraSet.iterator();
            while (iter.hasNext()) {
                String key = (String) iter.next();
                if ("site".equals(key)) {
					sql.append(" and exists");
					sql.append(
							" (select gg.siteid from (select ff.siteid from t_site ff start with ff.siteid ='")
							.append(paraMap.get(key)).append("'");
					sql.append(" Connect by Prior ff.siteid=ff.parentid) gg")
							.append(" where s.siteid=gg.siteid").append(")");
				}
                if ("keyword".equals(key)) {
                    //给定字符串，删除开始和结尾处的空格，并将中间的多个连续的空格合并成一个
                    String keywordstr = StringUtil.deleteExtraSpace(paraMap.get(key).toString());
                    //以空格为分隔符  把keywordstr分隔成数组
                    String[] str = keywordstr.split(" ");
                    sql.append(" and (");

                    //循环数组 and条件查询
                    for (int i = 0; i < str.length; i++) {
                    	if (i == 0){
                    		sql.append("   k.searchkeyword like '%" + str[i] + "%' ");
                    	}
                    	else{
    						sql.append(" or k.searchkeyword like '%" + str[i] + "%' ");
    					}
                    	if (i == str.length-1){
    						sql.append(")");
    					}
                    }
                    sql.append(" and k.objecttypetypeid='shop' and  k.objecttypecateid='objecttype' ");
                }
            }
        }
		
		sql.append( " order by s.updatedate desc ");

		return this.findSql(sql.toString(), pageNo, pageSize);
	}

	@Override
	public List<Shop> getShopbymember(String memberid) {
		String hql = "from Shop model where model.member.memberid='" + memberid
				+ "' or model.member.parent.memberid='" + memberid + "'";
		List<Shop> list = getListByHql(hql);
		return list;

	}
	@Override
	public Pagination getPage(int pageNo, int pageSize) {
		Finder r = Finder.create("from Shop model where 1=1");

		r.append(" order by createtime desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public List<Shop> searchByName(String keyword) {
		String hql = "from Shop where shopname like :name||'%' order by shopname ";
		return getSession().createQuery(hql).setParameter("name", keyword)
				.list();
	}
	@Override
	public Pagination findShopNotBind(String shopName,int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM T_SHOP TS WHERE TS.ENABLEFLAG=1 AND TS.SHOPSTATUSCATID=(SELECT TD.DICTID FROM T_DICTIONARY TD WHERE TD.TYPEID='126' AND TD.CATEID='shopstatus') AND NOT EXISTS(SELECT TC.CUSTOMERID FROM T_CUSTOMER TC WHERE TC.OBJECTID=TS.SHOPID AND TC.ISENABLE=1)";
		if(!StringUtil.isEmpty( shopName)){
			sql = sql + " AND TS.SHOPNAME LIKE '%"+ shopName+"%'";
		}
		
		return findSql(sql, Shop.class, null, pageNo, pageSize);
	}
}
