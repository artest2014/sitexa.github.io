package com.cct9k.dao.main.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.TransportDao;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.main.Restaurant;
import com.cct9k.entity.main.Transport;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.ProductLabelInfo;
import com.cct9k.util.common.StringUtil;

@Repository
public class TransportDaoImpl extends BaseDaoImpl<Transport, String>
		implements
			TransportDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<Transport> getTransportsIsValidByMemberid(String memberId) {
		String hql = "from Transport t where t.member.memberid=? and t.enableflag=1 ";
		return getSession().createQuery(hql).setParameter(0, memberId).list();
	}
	
	@Override
	public List<Transport> getTransportsByTransportId(String transportId){
		String sql = "from Transport t where t.transportid = '"+transportId+"' and  t.enableflag=1 ";
		return getSession().createQuery(sql).list();
	}
	
	@Override
	public Pagination getPage(int pageNo, int pageSize) {
		Finder r = Finder.create("from Transport model where 1=1");

		r.append(" order by createdate desc");

		return find(r, pageNo, pageSize);
	}

	@Override
	public List<Transport> searchByName(String keyword) {
		String hql = "from Transport where companyname like :name||'%' and enableflag='1' order by companyname ";
		return getSession().createQuery(hql).setParameter("name", keyword)
				.list();
	}
	public List<Picture> getTransIntroPicListByTransportId(String transportid,boolean isAll){
		String hql = "from Picture a where a.objectID=? and (a.objectType=? or a.objectType=?) order by a.objectType";
		Query query = this.getSession().createQuery(hql);
		query.setString(0, transportid);
		query.setString(1, Picture.TRANSPORT_IMAGE_TYPE_XINGXIANG);
		query.setString(2, Picture.TRANSPORT_IMAGE_TYPE_JS);
		if (!isAll){
			query.setFirstResult(0);
			query.setMaxResults(4);
		}
		List<Picture> list = query.list();
		return list;
	}
	
	public List<ProductLabelInfo> getTransLabelInfoListByTransportId(String transportid){		
		StringBuffer buf = new StringBuffer();
		buf.append("select ff.*,l.labelname as parentName");
		buf.append(" from");
		buf.append("(");
		buf.append("select ");
		//buf.append(" wmsys.wm_concat(sub.hotelname) as hotelname,");
		buf.append(" wmsys.wm_concat(sub.labelid) as labelid,");
		buf.append(" wmsys.wm_concat(sub.labelname) as labelname,");
		buf.append(" sub.parentlabelid");
		buf.append(" from(");
		buf.append(" select c.labelid,c.labelname,c.parentlabelid");
		buf.append(" from");
		buf.append(" t_transport a");
		buf.append(" inner join T_OBJ_LABEL_REF b on a.transportid = b.objid");
		buf.append(" inner join T_PRODUCT_LABEL_INFO c on b.labelid = c.labelid");
		buf.append(" where a.transportid = ?");
		buf.append(" order by c.parentlabelid) sub"); 
		buf.append(" group by sub.parentlabelid) ff");
		buf.append(" inner join T_PRODUCT_LABEL_INFO l on ff.parentlabelid = l.labelid");
		Query query = this.getSession().createSQLQuery(buf.toString());
		query.setString(0, transportid);
		@SuppressWarnings("unchecked")
		List<Object[]> objList = query.list();
		List<ProductLabelInfo> result = new ArrayList<ProductLabelInfo>();
		ProductLabelInfo label = null;
		if (objList != null){
			for (Object[] arr : objList){
				label = new ProductLabelInfo();
				label.setLabelid((String)arr[0]);
				label.setLabelname((String)arr[1]);
				label.setParentlabelid((String)arr[2]);
				label.setParentLabelName((String)arr[3]);
				result.add(label);
			}
		}
		return null;
	}
	 @Override
	    public Pagination getPagination(Member member, String transportName, int pageNo, int pageSize) {

	        Finder f = Finder.create("from Transport  t where 1=1");
	        if (member != null) {
	            f.append(" and t.member.memberid=:memberid ");
	            f.setParam("memberid", member.getMemberid());
	        }

	        if (!StringUtil.isEmpty(transportName)) {
	            f.append(" and t.companyname like '%'||:transportName||'%' ");
	            f.setParam("transportName", transportName);
	        }

	        f.append(" order by t.iftop asc");

	        return find(f, pageNo, pageSize);
	    }
	 
	   @Override
	    public List<Object[]> getTransportPics(String objectType) {
	        String sql = " select p.picUrl,p.picTitle,p.descriptions ,t.transportid,t.companyname" +
	                " from  t_picture p ,t_transport t where t.transportid=p.objectID" +
	                " and p.objectType='" + objectType + "' and t.iftop='1' and rownum<=6 ";
	        List<Object[]> obj = getSession().createSQLQuery(sql).list();

	        return obj;
	    }

	/* (non-Javadoc)
	 * @see com.cct9k.dao.main.TransportDao#findDirectShopByCustomtype(java.util.Map, int, int)
	 */
	@Override
	public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize){
    	String sql = " select a.transportid,a.companyname,a.telephone from t_transport a where a.companystatus='14009' and a.enableflag='1' ";
    	if(!StringUtil.isEmpty(paraMap.get("Name").toString()))
			sql+=" and a.companyname like '%"+paraMap.get("Name").toString()+"%'";
		return findSql(sql, pageNo, pageSize);
	}
	
	@Override
	public List<Transport> get(String[] ids) {
		Assert.notEmpty(ids, "ids must not be empty");
		String hql = "from Transport as model where model.enableflag='1' and model.companystatus='14009' and model.id in(:ids)";
		return getSession().createQuery(hql).setParameterList("ids", ids).list();
	}

	@Override
	public Pagination getAllTransportList(String transportName,
			String sitetype, String siteid, int pageNo, int pageSize) {
		StringBuffer sb = new StringBuffer("from Transport transport where transport.companystatus='14009' and transport.enableflag='1' ");
		Map<String, Object> paramMap = new HashMap<String, Object>();
		if (!StringUtil.isEmpty(transportName)) {
			sb.append(" and transport.companyname like :transportName");
			paramMap.put("transportName", "%" + transportName + "%");
		}
		if (!StringUtil.isEmpty(sitetype)&&!StringUtil.isEmpty(siteid)) {
			if(sitetype.equals("2")){
				sb.append(" and transport.site.state = :siteid");
			}else if(sitetype.equals("3")){
				sb.append(" and transport.site.city = :siteid");
			}else if(sitetype.equals("4")){
				sb.append(" and transport.site.siteid = :siteid");
			}
			paramMap.put("siteid", siteid);
		}
		Finder f = Finder.create(sb.toString());
		f.append(" order by transport.transportid desc");
		f.setParams(paramMap);
		return find(f, pageNo, pageSize);
	}

	@Override
	public Pagination findTransportNotBind(String transportName,int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM T_TRANSPORT TR WHERE TR.ENABLEFLAG=1 AND TR.COMPANYSTATUS=(SELECT TD.DICTID FROM T_DICTIONARY TD WHERE TD.TYPEID='UP' AND TD.CATEID='Status')  AND NOT EXISTS(SELECT TC.CUSTOMERID FROM T_CUSTOMER TC WHERE TC.OBJECTID=TR.TRANSPORTID AND TC.ISENABLE=1)";
		if(!StringUtil.isEmpty( transportName)){
			sql = sql + " AND TR.COMPANYNAME LIKE '%"+transportName+"%'";
		}
		return findSql(sql, Transport.class, null, pageNo, pageSize);
	}	
	
}
