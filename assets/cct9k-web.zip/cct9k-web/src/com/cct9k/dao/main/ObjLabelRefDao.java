package com.cct9k.dao.main;

import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.ObjLabelRef;

public interface ObjLabelRefDao extends BaseDao<ObjLabelRef, String> {

	List<String> getLabelIdByObjIdAndCatId(String objId, String catId);

	public Pagination getPage(int pageNo, int pageSize);

	// 查询是否含早餐 标签
	public String getLabelId(String productId, String ParentLabelId,
			String OBJTYPECATID);

}
