package com.cct9k.dao.main;


import java.util.List;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;

import com.cct9k.entity.finance.Audit;

public interface HotelProductAuditDao extends BaseDao<Audit, String> {

	public String getSeqn();
	public Pagination getProductAuditList(String startTime,String endTime,String hotelStrs,String hotelId,String hotelProductId,String auditStatus,int pageNo,
			int pageSize);
	
	public List getProductAudit(String ProductId);
	
	public  List getProductAuditHistoryList(String hotelProductId);
	
	public String save(Audit audit);
}
