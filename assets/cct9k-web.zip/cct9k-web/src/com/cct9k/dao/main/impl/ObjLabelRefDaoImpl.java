package com.cct9k.dao.main.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.ObjLabelRefDao;
import com.cct9k.entity.main.ObjLabelRef;
import com.cct9k.util.common.StringUtil;

@Repository
public class ObjLabelRefDaoImpl extends BaseDaoImpl<ObjLabelRef, String>
		implements ObjLabelRefDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getLabelIdByObjIdAndCatId(String objId, String catId) {
		return getSession()
				.createSQLQuery(
						"select t.labelid from t_obj_label_ref t where t.objid=? and t.objtypecatid=?")
				.setParameter(0, objId).setParameter(1, catId).list();
	}
	 @Override
	    public Pagination getPage(int pageNo, int pageSize) {
	        Finder r = Finder.create("from ObjLabelRef model where 1=1");

	        r.append(" order by labelid desc");

	        return find(r, pageNo, pageSize);
	    }


		@Override
		public String getLabelId(String productId, String ParentLabelId,
				String OBJTYPECATID) {
			if(!StringUtil.isEmpty(productId)&&!StringUtil.isEmpty(ParentLabelId)&&!StringUtil.isEmpty(OBJTYPECATID))
			 {
			String sql="select T_PRODUCT_LABEL_INFO.LABELID "
	                   +"  from T_PRODUCT_LABEL_INFO "
	                   +"    INNER JOIN T_OBJ_LABEL_REF on T_OBJ_LABEL_REF.LABELID = "
	                   +"    T_PRODUCT_LABEL_INFO.LABELID "
	                   +"   where parentlabelid = ? "
	                   +"   and T_OBJ_LABEL_REF.objid = ? "
	                   +"   and T_OBJ_LABEL_REF.OBJTYPECATID = ? ";
			    Query query = this.getSession().createSQLQuery(sql);
			    query.setString(0, ParentLabelId);
			    query.setString(1, productId);
			    query.setString(2, OBJTYPECATID);
			    
			    List resultList = query.list();
				if (resultList != null && resultList.size() > 0) {
					return resultList.get(0).toString();
				} else {
					return null;
				}   
			 }
			else
				return null;
		}

}
