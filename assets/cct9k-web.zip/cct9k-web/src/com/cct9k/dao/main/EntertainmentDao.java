package com.cct9k.dao.main;
import java.util.Map;

import com.cct9k.common.Pagination;

import java.util.List;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Entertainment;
import com.cct9k.entity.main.Hotel;
import com.cct9k.entity.member.Member;
import com.cct9k.entity.order.OrderEstimateInfo;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.EntertainmentProduct;

public interface EntertainmentDao extends BaseDao<Entertainment, String> {

	/**
	 * 描述: 前台 首页娱乐场馆分页查询
	 * 
	 * @param object
	 * @param cpn
	 * @param pageSize
	 * @return
	 * @author yangkun date 2013-8-30
	 *         -------------------------------------------------- 修改人 修改日期 修改描述
	 *         yangkun 2013-8-30 创建
	 *         --------------------------------------------------
	 * @Version Ver1.0
	 */
	public Pagination getEntertainmentList(Map<String, Object> paraMap,
			int cpn, int pageSize);

	public List<Entertainment> getEntertainmentList(String memberid);

	public List<Entertainment> getEntertainmentIsValidByMemberId(String memberId);

	/**
	 * 
	 * 描述: 查询娱乐场馆可以卖的产品
	 * 
	 * @param entertainmentid
	 * @return --------------------------------------------------
	 * @Version Ver1.0
	 */
	public List<EntertainmentProduct> findProductListByEntertainmentid(String entertainmentid);

	public Pagination getPage(int pageNo, int pageSize);

	public List<Entertainment> searchByName(String keyword);
	/**
	 * 
	 * 描述: 查询娱乐场所的的所有图片
	 * @param enterainmentid
	 * @return
	 */
	public List<Picture> findPicListbyEnterainmentid(String enterainmentid);
	public Pagination getPagination(Member member, String entertainmentName, int pageNo, int pageSize);

	public List<Object[]> getEntertainmentPics(String objectType);
	/**
	 * 
	 * 描述: 分销商关联娱乐店铺
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @author    yangkun
	 * @Version  Ver1.0
	 */
	public Pagination findDirectShopByCustomtype(Map<String, Object> paraMap,int pageNo, int pageSize);
	
	/**
	 * @author cyj
	 * 根据id取上架娱乐
	 */
	public List<Entertainment> getOnSaleEntertainmentById(String entertainmentId);
	
	public List<Entertainment> get(String[] ids) ;

	public Pagination getAllShowList(String showName, String sitetype,
			String siteid, int pageNo, int pageSize);
	
	/**
	 * 查询没有被客户绑定的娱乐
	 * @return
	 */
	public Pagination findEntertainmentNotBind(String entertainmentName,int pageNo, int pageSize);
	
}
