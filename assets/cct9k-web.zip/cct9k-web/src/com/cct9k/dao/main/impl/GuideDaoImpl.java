package com.cct9k.dao.main.impl;

import com.cct9k.common.Finder;
import com.cct9k.common.Pagination;
import com.cct9k.dao.impl.BaseDaoImpl;
import com.cct9k.dao.main.GuideDao;
import com.cct9k.entity.allinpay.PersonMemberInfo;
import com.cct9k.entity.main.Guide;
import com.cct9k.entity.product.GuideProduct;
import com.cct9k.util.common.StringUtil;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

/**
 * Author: oscar peng <xnpeng@hotmail.com>
 * Date: 13-8-9
 * Time: 下午2:42
 */
@Repository
@SuppressWarnings("unchecked")
public class GuideDaoImpl extends BaseDaoImpl<Guide, String> implements GuideDao {

    @Override
    public Pagination getPage(int pageNo, int pageSize) {
        Finder r = Finder.create("from Guide  model where 1=1");

        r.append(" order by createtime desc");

        return find(r, pageNo, pageSize);
    }

    @Override
    public List<Guide> searchByName(String keyword,String memberid) {
    	//String sql = "select b.* from t_reseller_guide a,t_guide b,t_member_person c where a.GUIDEID=b.MEMBERID and b.memberid=c.memberid and a.RESELLERID=:memberid and c.realname like '%'||:name||'%' and b.enableflag='1'";
    	Map<String, Object> sqlMap = new HashMap<String, Object>();
    	StringBuffer sql = new StringBuffer("select b.* from v_reseller_guide b,t_member_person c where ");
       sql.append(" b.memberid=c.memberid ");
       if(memberid!=null && !memberid.isEmpty()){
    	   sql.append("and b.RESELLERID=:memberid ");
    	   sqlMap.put("memberid", memberid);
       }
       if(keyword!=null && !keyword.isEmpty()){
    	   sql.append("and c.realname like '%'||:name||'%' ");
    	   sqlMap.put("name", keyword);
       }
       SQLQuery query = getSession().createSQLQuery(sql.toString()).addEntity(Guide.class);
       Set<Entry<String, Object>> rawParameters = sqlMap.entrySet();
       for (Entry<String, Object> entry : rawParameters) {
			query.setParameter(entry.getKey(), entry.getValue());

		}
        return query.list();
    }

	@Override
	public Pagination getPagination(String guideName, int pageNo, int pageSize) {
		  Finder f = Finder.create("from Guide  g where 1=1");

	        if (!StringUtil.isEmpty(guideName)) {
	            f.append(" and g.member.membername like '%'||:guideName||'%' ");
	            f.setParam("guideName", guideName);
	        }

	        f.append(" order by g.iftop asc");

	        return find(f, pageNo, pageSize);
	}


	@Override
	public List<Guide> getTopGuide(String top) {
		
		return this.getListByHql("from Guide g where g.iftop='1' and rownum<='"+top+"'");
	}
	
	public List   getResellerGuideList(String guideId){
	    String sql = "select t.* from t_reseller_guide t where t.guideid='"+guideId+"' " ;
        List resultList = null;
	    resultList = this.getSession().createSQLQuery(sql).list();
        if (resultList != null && resultList.size() > 0) {
            return resultList;
        }else{
        	return null;
        }
   }


}
