package com.cct9k.dao.main;


import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.ObjectSearchKeyword;

public interface SearchKeywordDao extends BaseDao<ObjectSearchKeyword ,String> {
	//酒店
	public void addHotelSearchKeyword(String objectId,String objectTypeId,String objectCateId);
	//景点
	public void addScenerySearchKeyword(String objectId,String objectTypeId,String objectCateId);
	//娱乐场所
	public void addEntertainmentSearchKeyword(String objectId,String objectTypeId,String objectCateId);
	//餐饮
    public void addRestaurantSearchKeyword(String objectId,String objectTypeId,String objectCateId);
    //餐饮产品
    public void addRestaurantProductSearchKeyword(String objectId,String objectTypeId,String objectCateId);
    //旅运
    public void addTransportSearchKeyword(String objectId,String objectTypeId,String objectCateId);
    //旅运产品
    public void addTransportProductSearchKeyword(String objectId,String objectTypeId,String objectCateId);
    //购物广场
    public void addShopSearchKeyword(String objectId,String objectTypeId, String objectCateId);
    //拼车
    public void addCarSharingSearchKeyword(String objectId,String objectTypeId,String objectCateId);
    //游记
    public void addPostSearchKeyword(String objectId,String objectTypeId, String objectCateId);
    //线路
    public void addRouteSearchKeyword(String objectId,String objectTypeId,String objectCateId);
    //导游
    public void addGuideSearchKeyword(String objectId,String objectTypeId,String objectCateId);
    //删除
    public void delete(String objectId  ,String objectType);
    
}
