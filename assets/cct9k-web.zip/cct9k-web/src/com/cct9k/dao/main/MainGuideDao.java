package com.cct9k.dao.main;

import org.springframework.stereotype.Repository;

import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Guide;

@Repository
public interface MainGuideDao extends BaseDao<Guide, String> {

}
