package com.cct9k.dao.main;

import java.util.List;
import java.util.Map;

import com.cct9k.common.Pagination;
import com.cct9k.dao.BaseDao;
import com.cct9k.entity.main.Guide;
import com.cct9k.entity.post.Picture;
import com.cct9k.entity.product.GuideProduct;

public interface GuiderPageDao extends BaseDao<Guide, String>{
	/**
	 * 查询导游信息
	 * @param paraMap
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public Pagination getGuiderList(Map<String,Object> paraMap,int pageNo, int pageSize,String sort);
	
	/**
	 * 根据会员ID查找导游信息
	 * @param memberid
	 * @return
	 */
	public Guide getGuiderInfoById(String memberid);
	
	/**
	 * 根据图片类型查找导游图片
	 * @param memberid
	 * @param picType
	 * @return
	 */
	public List<Picture> findPicListByGuiderId(String memberid,String picType);
	
	/**
	 * 根据导游
	 * @param memberid
	 * @return
	 */
	public List<GuideProduct> findProductByGuider(String memberid);
	

}
