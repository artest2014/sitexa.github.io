package com.cct9k.bean;

import java.io.Serializable;

public abstract class BaseMessageTemplate implements Serializable {

    private static final long serialVersionUID = -8211075473717794855L;

    public BaseMessageTemplate() {

    }

    private String subject;
    private String text;
    private String toMail;

    public String getToMail() {
        return toMail;
    }

    public BaseMessageTemplate(String subject, String text, String toMail) {
        super();
        this.subject = subject;
        this.text = text;
        this.toMail = toMail;
    }

    public void setToMail(String toMail) {
        this.toMail = toMail;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String toString() {
        return super.toString();
    }

}
