/**
 * <p>Class Name: MyApplicationListener.</p>
 * <p>Description: 类功能说明</p>
 * <p>Sample: 该类的典型使用方法和用例</p>
 * <p>Author: 佘斌</p>
 * <p>Date: 2013-10-12</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */

package com.cct9k.bean;


import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.quartz.SchedulerException;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.cct9k.service.admin.ShopTradeLogService;
import com.cct9k.service.allinpay.AllinpayService;
import com.cct9k.util.quartz.QuartzManager;
import com.cct9k.util.quartz.job.HnmerchantFtpDownJob;
import com.cct9k.util.quartz.job.SignInJob;
import com.cct9k.util.quartz.job.SignOutJob;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

@Component
public class MyApplicationListener implements ApplicationListener<ContextRefreshedEvent> {

    @Resource
    private ShopTradeLogService shopTradeLogService;
    
    @Resource
    private AllinpayService allinpayServiceIn;
    
    @Resource
    private AllinpayService allinpayServiceOut;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (event.getApplicationContext().getParent() == null) return;
        //loadQuartz();
    }

    private void loadQuartz() {
        try {
            Map<String, Object> map = new HashMap<String, Object>();
//            map.put("shopTradeLogService", shopTradeLogService);
//            QuartzManager.instance().addJob("humerchant", new HnmerchantFtpDownJob(), "0/60 * * * * ?", map);
            
            map.put("signIn", allinpayServiceIn);
            QuartzManager.instance().addJob("signIn", new SignInJob(), "0 0 5 ? * *", map);
            
            map.put("signOut", allinpayServiceOut);
            QuartzManager.instance().addJob("signOut", new SignOutJob(), "0 0 4 ? * *", map);
            
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }
}
