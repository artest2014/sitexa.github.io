/**
 * <p>Class Name: Token.java</p>
 * <p>Description: </p>
 * <p>Sample: </p>
 * <p>Author: shebin</p>
 * <p>Date: 2013-10-18</p>
 * <p>Modified History: 修改记录，格式(Name)  (Version)  (Date) (Reason & Contents)</p>
 */
package com.cct9k.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)  
@Retention(RetentionPolicy.RUNTIME)  
public  @interface Token {
	boolean needSaveToken() default false;  
	boolean needRemoveToken() default false;
	String targetUrl() default "";
}
