package com.alipay.util;



import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import com.allinpay.gts.client.GtsEngine;
import com.allinpay.gts.client.GtsXmlRecordInfo;
import com.allinpay.gts.client.response.GtsResponseParser;
import com.allinpay.gts.client.util.GtsNameValuePair;
import com.allinpay.gts.client.xml.GtsXMLObject;
import com.cct9k.util.common.DateUtil;


public class GtsEngineTest extends TestCase{
	
	/**
	 * 出金请求
	 * @throws Exception
	 */
	public void test2005() throws Exception{
		//1. 根据报文规则构建请求record信息
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Apply_Code","2013121100400000002"));	//申请编号
		recordInfo.add(new GtsNameValuePair("Trade_Money","1000.00"));	//	划款金额
		recordInfo.add(new GtsNameValuePair("Member_Id","A00001"));	//	会员号
		recordInfo.add(new GtsNameValuePair("Member_Name","会员名称A"));	//	会员名称
		recordInfo.add(new GtsNameValuePair("Bank_Name_In","工商银行"));	//收账开户行名称
		recordInfo.add(new GtsNameValuePair("Account_Name_In","测试帐号A"));	//收账账号名称
		recordInfo.add(new GtsNameValuePair ("Account_Id_In","622588313344134"));	//收账账号
		recordInfo.add(new GtsNameValuePair("Trade_Date","20111110"));	//	申请日期
		recordInfo.add(new GtsNameValuePair("Resume","摘要"));	//	摘要
		//2.通过GtsEngine产生请求对象
		GtsResponseParser response = GtsEngine.requestToAllinpay("2005", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Apply_Code =(String)gtsXMLObject.getTagValue("Apply_Code");	//申请编号
			String Serial_Id  =(String)gtsXMLObject.getTagValue("Serial_Id");	//处理流水号
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
			if("0000".equals(Error_Code)){//出金成功
				System.out.println("出金成功:" + Serial_Id);
			}else{//失败
				System.out.println("出金失败:" +Error_Code);
			}
		}else{
			//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	
	/**
	 * 描述: .入金
	 * @throws Exception
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-12-6
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-12-6               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public void testDeposit() throws Exception{
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Bank_Name_Out","上海浦发银行"));//结算账户开户行名称\在浦发结算账户开户行名称
		recordInfo.add(new GtsNameValuePair("Account_Name_Out","陈小生"));//结算账户名称\浦发的结算账号名称
		recordInfo.add(new GtsNameValuePair("Account_Code_Out","1111111111111111"));//结算账户账号\浦发的结算账号
		recordInfo.add(new GtsNameValuePair("Trade_Dir","1"));//借贷方向\0-借 1-贷 入金固定填 1

		recordInfo.add(new GtsNameValuePair("Amount_In","888"));//入账金额\正值
		recordInfo.add(new GtsNameValuePair("Date_In", DateUtil.getDate(new Date(), "yyyyMMdd")));//入账日期\入金请求日期 yyyymmdd
		recordInfo.add(new GtsNameValuePair("Time_In",DateUtil.getDate(new Date(), "HHmmss")));//入账时间\入金请求时间 HHMMSS
		recordInfo.add(new GtsNameValuePair("Bank_Name_In","长沙银行"));//来账银行名称\入金会员帐号开户银行名称
		recordInfo.add(new GtsNameValuePair("Account_Name_In","111111111111111111111"));//来账账户名\入金会员帐号名称
		recordInfo.add(new GtsNameValuePair("Account_Code_In","小东子"));//来账账户账号\入金会员帐号
		recordInfo.add(new GtsNameValuePair("Bank_Remark","person_en"));//银行备注\填写会员号
		recordInfo.add(new GtsNameValuePair("Apply_Code","2013120600410000008"));//请求流水号\\主键。永不重复。


		recordInfo.add(new GtsNameValuePair("Flag","0"));//抹账标志\固定填0
		recordInfo.add(new GtsNameValuePair("Fee","2"));//手续费\正值
		recordInfo.add(new GtsNameValuePair("Channel","01"));//渠道\固定填 01
		recordInfo.add(new GtsNameValuePair("Pay_Type","1"));//支付方式0 代表组合支付方式1 代表个人网银支付  4代表企业网银支付   其他值非法
		recordInfo.add(new GtsNameValuePair("Issue_Id","vbank"));//支付银行机构代码
		recordInfo.add(new GtsNameValuePair("Receive_Url","http://124.232.165.57:8081/cct9k-web/order/plan/testDeposit"));//入金结果接收地址 用于接收入金处理结果
		recordInfo.add(new GtsNameValuePair("Pickup_Url",""));
		
		
		String msg = GtsEngine.createRequestMsg("2013", recordInfo);
		System.out.println("msg:"+msg);
	}
	
	public void testCallDeposit() throws Exception{
		String notifyMsg="";
		GtsResponseParser responseNotify = null;
    	if(null != notifyMsg)
    	{
    	responseNotify = GtsEngine.parsingResponse(notifyMsg); 
    	}

    	if(null != responseNotify && responseNotify.isSuccess()){//处理成功
    		List<GtsXMLObject> list = responseNotify.getRecords();

			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Apply_Code =(String)gtsXMLObject.getTagValue("Apply_Code");	//请求流水号
			String Serial_Id  =(String)gtsXMLObject.getTagValue("Serial_Id");	//处理流水号
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
			System.out.println("请求流水号：" + Apply_Code);
			System.out.println("处理流水号：" + Serial_Id);
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + responseNotify.getHeaderRet_Code());
			System.out.println("错误描述：" + responseNotify.getHeaderRet_Msg());
		}
	}
	
	/**
	 * 描述: .出金状态查询
	 * @throws Exception
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-12-5
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-12-5               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public void testWithdrawQuery() throws Exception {
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Serial_Id","20131205014730"));
		GtsResponseParser response = GtsEngine.requestToAllinpay("2008", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Serial_Id =(String)gtsXMLObject.getTagValue("Serial_Id");	//托管系统处理后的出金流水号
			String tally_status  =(String)gtsXMLObject.getTagValue("tally_status");	//记账状态
			String issue_status =(String)gtsXMLObject.getTagValue("issue_status");	//签发状态
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
			System.out.println("托管系统处理后的出金流水号：" + Serial_Id);
			System.out.println("记账状态：" + tally_status);
			System.out.println("签发状态：" + issue_status);
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	
	/**
	 * 入金查询
	 * @throws Exception
	 */
	public void test2014() throws Exception{
		//1. 根据报文规则构建请求record信息
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Query_Trans_Code","2013"));	//查詢交易
		recordInfo.add(new GtsNameValuePair("Agent_Order_No","2011113010000248"));	//申请编号
		//2.通过GtsEngine产生请求对象
		GtsResponseParser response = GtsEngine.requestToAllinpay("2014", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Apply_Code =(String)gtsXMLObject.getTagValue("Apply_Code");	//请求流水号
			String Serial_Id  =(String)gtsXMLObject.getTagValue("Serial_Id");	//处理流水号
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
		
	}
	/**
	 * 描述: .出金撤销
	 * @throws Exception
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-12-6
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-12-6               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public void testUnWithdraw() throws Exception{
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Apply_Code","2013120500400000001"));	//申请编号
		recordInfo.add(new GtsNameValuePair("Serial_Id","20131205014719"));//处理流水号
		recordInfo.add(new GtsNameValuePair("Trade_Money","1000"));	//划款金额
		recordInfo.add(new GtsNameValuePair("Member_Id","A00001"));	//	会员号
		recordInfo.add(new GtsNameValuePair("Member_Name","会员名称A"));	//	会员名称
		recordInfo.add(new GtsNameValuePair ("Operate_Flag","1"));	//操作标志
		
		GtsResponseParser response = GtsEngine.requestToAllinpay("2009", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Apply_Code =(String)gtsXMLObject.getTagValue("Apply_Code");	//请求流水号
			String Serial_Id  =(String)gtsXMLObject.getTagValue("Serial_Id");	//处理流水号
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
			System.out.println("处理流水号：" + Serial_Id);
			System.out.println("请求流水号：" + Apply_Code);
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	
	/**
	 * 描述: .买卖/成交交易
	 * @throws Exception
	 * @author     chp
	 * <p>Sample: 该方法使用样例</p>
	 * date        2013-12-6
	 * -----------------------------------------------------------
	 * 修改人                                             修改日期                                   修改描述
	 * chp                2013-12-6               创建
	 * -----------------------------------------------------------
	 * @Version  Ver1.0
	 */
	public void testConclude() throws Exception{
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Trade_Money","1000"));	//交易金额
		recordInfo.add(new GtsNameValuePair("Trade_Type","1"));	//	交易类型
		recordInfo.add(new GtsNameValuePair("B_Member_Code","会员名称A"));	//	买方会员号
		recordInfo.add(new GtsNameValuePair ("B_Member_Name","1"));	//买方会员名称
		recordInfo.add(new GtsNameValuePair ("S_Member_Code","1"));	//卖方会员号
		recordInfo.add(new GtsNameValuePair ("S_Member_Name","1"));	//卖方会员名称
		recordInfo.add(new GtsNameValuePair ("Trade_Date",DateUtil.getDate(new Date(), "yyyyMMdd")));	//交易日期
		recordInfo.add(new GtsNameValuePair ("Bargain_Code","1"));	//成交合同号
		recordInfo.add(new GtsNameValuePair ("Serial_Id","2013120500400000035"));	//成交流水号
		recordInfo.add(new GtsNameValuePair ("Good_Code","1"));	//货物编号
		recordInfo.add(new GtsNameValuePair ("Good_Name","1"));	//货物名称
		recordInfo.add(new GtsNameValuePair ("Good_Quantity","1"));	//货物数量
		recordInfo.add(new GtsNameValuePair ("Trade_Mode","0"));	//交易方式
		
		GtsResponseParser response = GtsEngine.requestToAllinpay("2003", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Bargain_Code =(String)gtsXMLObject.getTagValue("Bargain_Code");	//成交合同号
			String Serial_Id  =(String)gtsXMLObject.getTagValue("Serial_Id");	//成交流水号
			String Trade_Money =(String)gtsXMLObject.getTagValue("Trade_Money");	//交易金额
			String Trade_Type =(String)gtsXMLObject.getTagValue("Trade_Type");	//交易类型
			String B_Member_Code =(String)gtsXMLObject.getTagValue("B_Member_Code");	//买方会员号
			String S_Member_Code =(String)gtsXMLObject.getTagValue("S_Member_Code");	//卖方会员号
			String Trade_Date =(String)gtsXMLObject.getTagValue("Trade_Date");	//交易日期
			String Qs_Fee =(String)gtsXMLObject.getTagValue("Qs_Fee");	//清算费
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
			System.out.println("成交合同号：" + Bargain_Code);
			System.out.println("成交流水号：" + Serial_Id);
			System.out.println("交易金额：" + Trade_Money);
			System.out.println("交易类型：" + Trade_Type);
			System.out.println("买方会员号：" + B_Member_Code);
			System.out.println("卖方会员号：" + S_Member_Code);
			System.out.println("交易日期：" + Trade_Date);
			System.out.println("清算费：" + Qs_Fee);
			
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	
	//冻结
	public void testFreeze() throws Exception{
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair ("Serial_Id","2013120500400000032"));	//业务流水号
		recordInfo.add(new GtsNameValuePair("Trade_Type","1"));	//	交易类型
		recordInfo.add(new GtsNameValuePair("Trade_Money","2978.0"));	//交易金额
		recordInfo.add(new GtsNameValuePair("Member_Code","会员名称A"));	//	交易会员号
		recordInfo.add(new GtsNameValuePair ("Member_Name","1"));	//交易会员名称
		recordInfo.add(new GtsNameValuePair ("O_Member_Code","1"));	//交易对手会员号
		recordInfo.add(new GtsNameValuePair ("O_Member_Name","1"));	//交易对手会员名称
		recordInfo.add(new GtsNameValuePair ("Trade_Date",DateUtil.getDate(new Date(), "yyyyMMdd")));	//交易日期
		recordInfo.add(new GtsNameValuePair ("Trade_Mode","0"));	//交易方式
		
		recordInfo.add(new GtsNameValuePair ("Good_Code","6962"));	//货物编号
		recordInfo.add(new GtsNameValuePair ("Good_Name","订单订单订单订单订单"));	//货物名称
		recordInfo.add(new GtsNameValuePair ("Good_Quantity","1"));	//货物数量
		recordInfo.add(new GtsNameValuePair ("Bargain_Code","6962"));	//成交合同号
		
		
		GtsResponseParser response = GtsEngine.requestToAllinpay("2002", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			
			String Serial_Id  =(String)gtsXMLObject.getTagValue("Serial_Id");	//业务流水号
			String Trade_Type =(String)gtsXMLObject.getTagValue("Trade_Type");	//交易类型
			String Member_Code =(String)gtsXMLObject.getTagValue("Member_Code");	//交易会员号
			String Trade_Money =(String)gtsXMLObject.getTagValue("Trade_Money");	//交易金额
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			String Bargain_Code =(String)gtsXMLObject.getTagValue("Bargain_Code");	//成交合同号
			System.out.println("处理结果：" + Error_Code);
			System.out.println("成交合同号：" + Bargain_Code);
			System.out.println("业务流水号：" + Serial_Id);
			System.out.println("交易金额：" + Trade_Money);
			System.out.println("交易类型：" + Trade_Type);
			System.out.println("交易会员号：" + Member_Code);
			
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	//解冻
	public void testThraw() throws Exception {
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair ("Serial_Id","2013120500400000034"));	//业务流水号
		recordInfo.add(new GtsNameValuePair("Trade_Type","2"));	//	交易类型
		recordInfo.add(new GtsNameValuePair("Trade_Money","1000"));	//交易金额
		recordInfo.add(new GtsNameValuePair("Member_Code","会员名称A"));	//	交易会员号
		recordInfo.add(new GtsNameValuePair ("Member_Name","1"));	//交易会员名称
		recordInfo.add(new GtsNameValuePair ("O_Member_Code","1"));	//交易对手会员号
		recordInfo.add(new GtsNameValuePair ("O_Member_Name","1"));	//交易对手会员名称
		recordInfo.add(new GtsNameValuePair ("Trade_Date",DateUtil.getDate(new Date(), "yyyyMMdd")));	//交易日期
		recordInfo.add(new GtsNameValuePair ("Trade_Mode","0"));	//交易方式
		
		recordInfo.add(new GtsNameValuePair ("Good_Code","1"));	//货物编号
		recordInfo.add(new GtsNameValuePair ("Good_Name","1"));	//货物名称
		recordInfo.add(new GtsNameValuePair ("Good_Quantity","1"));	//货物数量
		recordInfo.add(new GtsNameValuePair ("Bargain_Code","0"));	//成交合同号
		
		
		GtsResponseParser response = GtsEngine.requestToAllinpay("2012", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			
			String Serial_Id  =(String)gtsXMLObject.getTagValue("Serial_Id");	//业务流水号
			String Trade_Type =(String)gtsXMLObject.getTagValue("Trade_Type");	//交易类型
			String Member_Code =(String)gtsXMLObject.getTagValue("Member_Code");	//交易会员号
			String Trade_Money =(String)gtsXMLObject.getTagValue("Trade_Money");	//交易金额
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			String Bargain_Code =(String)gtsXMLObject.getTagValue("Bargain_Code");	//成交合同号
			System.out.println("处理结果：" + Error_Code);
			System.out.println("成交合同号：" + Bargain_Code);
			System.out.println("业务流水号：" + Serial_Id);
			System.out.println("交易金额：" + Trade_Money);
			System.out.println("交易类型：" + Trade_Type);
			System.out.println("交易会员号：" + Member_Code);
			
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	
	//7.11	企业会员基本信息
	public void testOrganMemberInfo()throws Exception{
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		
		recordInfo.add(new GtsNameValuePair("Member_Id","person_en"));//会员号
		recordInfo.add(new GtsNameValuePair("Member_Name","黄洁"));//会员名称
		recordInfo.add(new GtsNameValuePair("Protocol_Code","20111110"));//入市协议编号 
		recordInfo.add(new GtsNameValuePair("Organization_Code","20111110"));//证件编号
		recordInfo.add(new GtsNameValuePair("Register_Date",DateUtil.getDate(new Date(), "yyyyMMdd")));//商户注册日期
		recordInfo.add(new GtsNameValuePair("Address","鸭子港"));//常用通信地址
		recordInfo.add(new GtsNameValuePair("Contact_Person","黄洁"));//联系人
		recordInfo.add(new GtsNameValuePair("Telephone","13333333333"));//联系电话
		recordInfo.add(new GtsNameValuePair("Fax","0731-83321111"));//传真
		recordInfo.add(new GtsNameValuePair("Mobile","18608419961"));//通知手机号
		recordInfo.add(new GtsNameValuePair("Email","chp1315@163.com"));//E-Mail地址
		recordInfo.add(new GtsNameValuePair("Represent_Name","陈欢碰"));//法定代表人
		recordInfo.add(new GtsNameValuePair("Registered_Capital","1111111"));//注册资本
		recordInfo.add(new GtsNameValuePair("Area_Code","4201"));//所属区域
		recordInfo.add(new GtsNameValuePair("Check_Amount","111111"));//核定额度
		recordInfo.add(new GtsNameValuePair("End_Date",DateUtil.getDate(new Date(), "yyyyMMdd")));//缴款截止日
		recordInfo.add(new GtsNameValuePair("Operate_Flag","0"));//0-新增；1-修改；2-销户。
		recordInfo.add(new GtsNameValuePair("Remark","备注"));//备注
		recordInfo.add(new GtsNameValuePair("NoticeFlag","3"));//及时语开通标志
		recordInfo.add(new GtsNameValuePair("NoticeLow","0"));//最低通知金额
		
		GtsResponseParser response = GtsEngine.requestToAllinpay("2001", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Member_Id  =(String)gtsXMLObject.getTagValue("Member_Id");	//会员号
			String Organization_Code =(String)gtsXMLObject.getTagValue("Organization_Code");	//证件编号
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			
			System.out.println("处理结果：" + Error_Code);
			System.out.println("会员号：" + Member_Id);
			System.out.println("证件编号：" + Organization_Code);
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	
	
	//7.11	个人会员基本信息
		public void testPersonMemberInfo()throws Exception{
			GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
			recordInfo.add(new GtsNameValuePair("Member_Id","admin"));//会员号
			recordInfo.add(new GtsNameValuePair("Member_Name","黄洁"));//会员名称
			recordInfo.add(new GtsNameValuePair("Register_Date",DateUtil.getDate(new Date(), "yyyyMMdd")));//注册日期
			recordInfo.add(new GtsNameValuePair("Register_Code","12312313213"));//会员注册流水号
			recordInfo.add(new GtsNameValuePair("English_Name","neky"));//英文名
			recordInfo.add(new GtsNameValuePair("Types_of_Certificates","20111110"));//证件类型
			recordInfo.add(new GtsNameValuePair("Organization_Code","20111110"));//证件编号
			recordInfo.add(new GtsNameValuePair("Gender","0"));//性别
			recordInfo.add(new GtsNameValuePair("Date_of_Birth",DateUtil.getDate(new Date(), "yyyyMMdd")));//出生日期
			recordInfo.add(new GtsNameValuePair("Telephone","13333333333"));//联系电话
			recordInfo.add(new GtsNameValuePair("Address","13333333333"));//常用通信地址
			recordInfo.add(new GtsNameValuePair("Post_Code","13333333333"));//邮编
			recordInfo.add(new GtsNameValuePair("NoticeFlag","3"));//及时语开通标志
			recordInfo.add(new GtsNameValuePair("NoticeLow","0"));//最低通知金额
			recordInfo.add(new GtsNameValuePair("Fax","0731-83321111"));//传真
			recordInfo.add(new GtsNameValuePair("Mobile","18608419961"));//通知手机号
			recordInfo.add(new GtsNameValuePair("Email","chp1315@163.com"));//E-Mail地址
			recordInfo.add(new GtsNameValuePair("Operate_Flag","0"));//0-新增；1-修改；2-销户。
			recordInfo.add(new GtsNameValuePair("Remark","备注"));//备注
			
			
			GtsResponseParser response = GtsEngine.requestToAllinpay("2007", recordInfo);
			if(response.isSuccess()){//处理成功
				List<GtsXMLObject> list = response.getRecords();
				GtsXMLObject gtsXMLObject = list.get(0);
				//取得record参数
				String Member_Id  =(String)gtsXMLObject.getTagValue("Member_Id");	//会员号
				String Credential_Number =(String)gtsXMLObject.getTagValue("Credential_Number");	//证件编号
				String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
				
				System.out.println("处理结果：" + Error_Code);
				System.out.println("会员号：" + Member_Id);
				System.out.println("证件编号：" + Credential_Number);
			}else{//处理失败
				//错误原因
				System.out.println("错误代码：" + response.getHeaderRet_Code());
				System.out.println("错误描述：" + response.getHeaderRet_Msg());
			}
		}
		
		//7.12	会员帐号信息
		public void testPersonMemberAccount()throws Exception{
			GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
			recordInfo.add(new GtsNameValuePair("Member_Id","admin"));//会员号
			recordInfo.add(new GtsNameValuePair("Bank_Name","长沙银行"));//银行名称
			recordInfo.add(new GtsNameValuePair("Account_Bank_Name","长沙"));//账户开户行名称
			recordInfo.add(new GtsNameValuePair("Account_Name","陈大大"));//账户名称
			recordInfo.add(new GtsNameValuePair("Account_Code","111111111111111"));//账户账号
			recordInfo.add(new GtsNameValuePair("Area_Code","4201"));//地区代码
			recordInfo.add(new GtsNameValuePair("Account_Type","3"));//账户类型
			recordInfo.add(new GtsNameValuePair("Operate_Flag","0"));//操作标志
			recordInfo.add(new GtsNameValuePair("AcctIn_Type","2"));//收款账类型
			
			GtsResponseParser response = GtsEngine.requestToAllinpay("2004", recordInfo);
			if(response.isSuccess()){//处理成功
				List<GtsXMLObject> list = response.getRecords();
				GtsXMLObject gtsXMLObject = list.get(0);
				//取得record参数
				String Member_Id  =(String)gtsXMLObject.getTagValue("Member_Id");	//会员号
				String Account_Code =(String)gtsXMLObject.getTagValue("Account_Code");	//账户账号
				String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
				
				System.out.println("处理结果：" + Error_Code);
				System.out.println("会员号：" + Member_Id);
				System.out.println("账户账号：" + Account_Code);
			}else{//处理失败
				//错误原因
				System.out.println("错误代码：" + response.getHeaderRet_Code());
				System.out.println("错误描述：" + response.getHeaderRet_Msg());
			}
		}	
	
	//7.16	出金通知交易
	public void testWithdrawNotify() throws Exception{
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Apply_Code","2013120500400000001"));	//业务申请流水号
		recordInfo.add(new GtsNameValuePair("Trade_Date","20111110"));	//业务申请日期
		recordInfo.add(new GtsNameValuePair("Trade_Code","1005"));	//	业务申请代码
		recordInfo.add(new GtsNameValuePair("Serial_Id","20131205014719"));	//	银行处理流水号
		recordInfo.add(new GtsNameValuePair("Deal_Status","0"));	//	业务申请处理状态
		recordInfo.add(new GtsNameValuePair("Deal_Result","100504"));//业务申请当前处理结果
		recordInfo.add(new GtsNameValuePair("Deal_Code","0000"));//处理代码
		
		GtsResponseParser response = GtsEngine.requestToAllinpay("5022", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Serial_Id  =(String)gtsXMLObject.getTagValue("Serial_Id");	//处理流水号
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
			System.out.println("处理流水号：" + Serial_Id);
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	
	//签到
	public void testSignIn() throws Exception{
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Operate_Flag","0"));	//操作标志
		
		GtsResponseParser response = GtsEngine.requestToAllinpay("2010", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	//签退
	public void testSignOut() throws Exception{
		GtsXmlRecordInfo recordInfo = new GtsXmlRecordInfo();
		recordInfo.add(new GtsNameValuePair("Operate_Flag","1"));	//操作标志
		
		GtsResponseParser response = GtsEngine.requestToAllinpay("2011", recordInfo);
		if(response.isSuccess()){//处理成功
			List<GtsXMLObject> list = response.getRecords();
			GtsXMLObject gtsXMLObject = list.get(0);
			//取得record参数
			String Error_Code =(String)gtsXMLObject.getTagValue("Error_Code");	//错误代码
			System.out.println("处理结果：" + Error_Code);
		}else{//处理失败
			//错误原因
			System.out.println("错误代码：" + response.getHeaderRet_Code());
			System.out.println("错误描述：" + response.getHeaderRet_Msg());
		}
	}
	
	
}
